#include "aiNLPParseTree.h"

CNLPParseTree::CNLPParseTree(): 
	Children(0)
{
	// temp
	SyntacticCategory = (ENLPSyntacticCategory)0;
}

CNLPParseTree::CNLPParseTree(const CNLPParseTree &ParseTree)
{
	*this = ParseTree;
}

CNLPParseTree::~CNLPParseTree()
{
}

const CNLPParseTree &CNLPParseTree::operator=(const CNLPParseTree &ParseTree)
{
	Word = ParseTree.Word;
	SyntacticCategory = ParseTree.SyntacticCategory;

	SetChildCount(ParseTree.GetChildCount());

	for (int Index=0; Index < ParseTree.GetChildCount(); Index++)
	{
		Children.Set(Index, ParseTree.GetChild(Index));
	}

	return *this;
}

CText CNLPParseTree::ToString(int TabCount) const
{
	CText String;
	CText TabString;

	// prepare initial tabs
	for (int TabIndex=0; TabIndex < TabCount; TabIndex++) TabString += "\t";

	// prefix
	String += TabString;
	String += "(";
	
	String += GetSyntacticCategoryName(SyntacticCategory);

	// if this is a leaf, print the word
	if (Children.GetLength() == 0)
	{
		String += ": ";
		String += Word;
		String += ")\n";
	}
	else
	{
		// newline
		String += "\n";

		// add all children
		for (int Index=0; Index<Children.GetLength(); Index++)
		{
			String += Children.Get(Index).ToString(TabCount+1);
		}

		// newline
		String += TabString;
		String += ")\n";
	}

	return String;
}
