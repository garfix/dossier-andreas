#include "aiNLPParseForest.h"
#include "aiNLPParseTree.h"

CNLPParseForest::CNLPParseForest()
{
}

CNLPParseForest::~CNLPParseForest()
{
	ParseTrees.DeleteContents();
}
