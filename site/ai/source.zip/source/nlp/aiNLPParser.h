#ifndef _NLPPARSER
#define _NLPPARSER

#include "generic.h"

using namespace generic;

class CNLPParseForest;

/// Abstract class of a parser.

class CNLPParser: public CElement
{
public:
	virtual void Parse(const CNLPGrammar &Grammar, const CNLPLexicon &Lexicon, const CText &Sentence, CNLPParseForest &ParseForest)=0;
};

#endif
