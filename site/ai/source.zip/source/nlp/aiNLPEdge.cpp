#include "aiNLPEdge.h"
#include "aiNLPGrammarRule.h"

CNLPEdge::CNLPEdge(int NewStartVertex, int NewEndVertex, CNLPGrammarRule *NewGrammarRule, int NewConsequentsCompleted):
	Children(NewConsequentsCompleted)
{
	GrammarRule = NewGrammarRule;
	ConsequentsCompleted = NewConsequentsCompleted;
	StartVertex = NewStartVertex;
	EndVertex = NewEndVertex;

	for (int Index=0; Index < NewConsequentsCompleted; Index++)
	{
		Children.Get(Index) = 0;
	}
}

ENLPSyntacticCategory CNLPEdge::GetFirstConsequentAfterDot(void)
{
	return GrammarRule->GetConsequent(ConsequentsCompleted);
}

ENLPSyntacticCategory CNLPEdge::GetLastConsequent(void)
{
	return GrammarRule->GetConsequent(GrammarRule->GetConsequentCount()-1);
}

void CNLPEdge::CopyChildren(CNLPEdge *Edge) const
{
	for (int Index=0; Index < Edge->GetConsequentsCompleted(); Index++)
	{
		Children.Get(Index) = Edge->Children.Get(Index);
	}
}

bool CNLPEdge::IsComplete(void) const
{
	// the edge is complete if the 'dot' is to the right of all consequents
	return (ConsequentsCompleted == GrammarRule->GetConsequentCount());
}

CText CNLPEdge::ToString(void)
{
	CText String;

	// vertices
	String += StartVertex;
	String += ", ";
	String += EndVertex;
	String += ", ";

	// antecedent
	String += GetSyntacticCategoryName((GrammarRule->GetAntecedent()));

	// ->
	String += " -> ";

	// consequents
	for (int Index=0; Index < GrammarRule->GetConsequentCount(); Index++)
	{
		// dot
		if (Index == ConsequentsCompleted) String += "* ";

		// syntactic category
		String += GetSyntacticCategoryName(GrammarRule->GetConsequent(Index));

		// space
		if (Index < GrammarRule->GetConsequentCount()-1) String += " ";
	}

	// dot
	if (GrammarRule->GetConsequentCount() == ConsequentsCompleted) String += " *";

	return String;
}
