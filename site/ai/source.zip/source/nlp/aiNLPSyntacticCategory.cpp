#include "aiNLPSyntacticCategory.h"

const CText GetSyntacticCategoryName(ENLPSyntacticCategory Category)
{
	static const CText SyntacticCategoryName[NLPSYNTACTICCATEGORY_COUNT] = 
	{
		CText("S'"),
		CText("S"),
		CText("NP"),
		CText("VP"),
		CText("ADJP"),
		CText("PP"),
		CText("Noun"),
		CText("Pronoun"),
		CText("Verb"),
		CText("Det"),
		CText("Article"),
		CText("Conjunction"),
		CText("Adjective"),
		CText("Adverb"),
		CText("Expletive"),
		CText("Interjection"),
		CText("Preposition"),
		CText("Element")
	};

	return SyntacticCategoryName[Category];
}
