#ifndef _NLPCHARTPARSER
#define _NLPCHARTPARSER

//#define DEBUG_PARSE

#include "aiNLPParser.h"
#include "generic.h"

using namespace generic;

class CNLPEdge;
class CNLPParseForest;
class CNLPParseTree;

/// This class implements the chart parsing algorithm as described in chapter 23 of
/// Artificial Intelligence: A Modern Approach; by Stuart Russell and Peter Norvig.

class CNLPChartParser: public CNLPParser
{
protected:
	#ifdef DEBUG_PARSE
		int Tab;
	#endif

	void Tokenize(const CText &String, CRow<CText> &Tokens);
	CNLPEdge *AddEdge(const CNLPGrammar &Grammar, CNLPChart &Chart, int StartVertex, int EndVertex, CNLPGrammarRule *GrammarRule, int NewConsequentsCompleted, bool CreateNew);
	void Scan(const CNLPGrammar &Grammar, const CNLPLexicon &Lexicon, CNLPChart &Chart, int StartVertex, const CText &Word);
	void Predict(const CNLPGrammar &Grammar, CNLPChart &Chart, CNLPEdge *Edge);
	void Complete(const CNLPGrammar &Grammar, CNLPChart &Chart, CNLPEdge *Edge);

	void VisitEdge(CNLPChart &Chart, CRow<CText> &Words, CNLPEdge *Edge, CNLPParseTree &ParseTree, CNLPParseTree &ParseTreeBranch, CNLPParseForest &ParseForest);
	void CreateParseTrees(CNLPChart &Chart, CRow<CText> &Words, CNLPParseForest &ParseForest);

public:
	CNLPChartParser();
	~CNLPChartParser();

	virtual void Parse(const CNLPGrammar &Grammar, const CNLPLexicon &Lexicon, const CText &Sentence, CNLPParseForest &ParseForest);
};

#endif
