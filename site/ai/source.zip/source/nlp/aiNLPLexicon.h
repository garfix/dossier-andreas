#ifndef _NLPLEXICON
#define _NLPLEXICON

#include "aiNLPSyntacticCategory.h"
#include "generic.h"

using namespace generic;

/// The lexicon contains all words, along with their syntactic categories.

class CNLPLexicon: public CElement
{
protected:
	CHashTable< CText, CRow<ENLPSyntacticCategory> > Entries;

public:
	CNLPLexicon();
	~CNLPLexicon();

	void AddEntry(const CText &Word, ENLPSyntacticCategory SyntacticCategory);
	CRow<ENLPSyntacticCategory> &GetSyntacticCategories(const CText &Word, bool &Found) const;
};

#endif
