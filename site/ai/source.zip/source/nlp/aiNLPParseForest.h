#ifndef _NLPPARSEFOREST
#define _NLPPARSEFOREST

#include "generic.h"

using namespace generic;

/// A parse forest is a collection of parse trees.

class CNLPParseTree;

class CNLPParseForest: public CElement
{
protected:
	CRow<CNLPParseTree *> ParseTrees;

public:
	CNLPParseForest();
	~CNLPParseForest();

	void AddParseTree(CNLPParseTree *NewParseTree){ ParseTrees.Add(NewParseTree); }
	int GetParseTreeCount(void) const { return ParseTrees.GetLength(); }
	CNLPParseTree *GetParseTree(int Index){ return ParseTrees.Get(Index); }
};

#endif
