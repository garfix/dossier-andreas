#ifndef _NLPGRAMMARRULE
#define _NLPGRAMMARRULE

#include "aiNLPSyntacticCategory.h"
#include "generic.h"

using namespace generic;

/// A grammar rules in a prodcution rule describing the grammar of some language.
/// An example: NP -> VP NP
/// A rule has an antecedent (category before the arrow) and one or more consequents
/// (category after the arrow)

class CNLPGrammarRule: public CElement
{
protected:
	ENLPSyntacticCategory Antecedent;
	CRow<ENLPSyntacticCategory> Consequents;

public:
	CNLPGrammarRule();
	~CNLPGrammarRule();

	void SetAntecedent(ENLPSyntacticCategory NewAntecedent){ Antecedent = NewAntecedent; };
	ENLPSyntacticCategory GetAntecedent(void){ return Antecedent; }

	void AddConsequent(ENLPSyntacticCategory NewConsequent){ Consequents.Add(NewConsequent); };
	int GetConsequentCount(void) const { return Consequents.GetLength(); }
	ENLPSyntacticCategory GetConsequent(int Index) const { return Consequents.Get(Index); }

	CText ToString(void);
};

#endif
