#ifndef _NLPMODEL
#define _NLPMODEL

#include "aiNLPGrammar.h"
#include "aiNLPLexicon.h"
#include "aiNLPSyntacticCategory.h"
#include "aiNLPParseForest.h"
#include "aiNLPParseTree.h"
#include "aiNLPChart.h"
#include "generic.h"

using namespace generic;

class CNLPParser;
class CNLPParseForest;

/// The base of all NLP work. Contains a (default) parser, a lexicon, and a grammar.

class CNLPModel: public CElement
{
protected:
	CNLPParser *Parser;
	CNLPGrammar Grammar;
	CNLPLexicon Lexicon;

	ENLPSyntacticCategory GetSyntacticCategory(const CText &String);

public:
	CNLPModel();
	~CNLPModel();

	void SetParser(CNLPParser *NewParser){ Parser = NewParser; };

	void AddLexicalEntry(const CText &Word, const CText &Category);
	void AddLexicalEntries(const CText &FileName, const CText &SyntacticCategoryName);

	void AddGrammarRule(const CText &Rule);
	void AddGrammarRules(const CText &FileName);

	void Parse(const CText &String, CNLPParseForest &ParseForest);
};

#endif
