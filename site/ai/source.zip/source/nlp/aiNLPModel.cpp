#include <assert.h>
#include "aiNLPModel.h"
#include "aiNLPGrammarRule.h"
#include "aiNLPParser.h"
#include "aiNLPChartParser.h"
#include "aiNLPSyntacticCategory.h"
#include "generic.h"

using namespace generic;

CNLPChartParser DefaultParser;

CNLPModel::CNLPModel()
{
	// set default parser
	Parser = &DefaultParser;
}

CNLPModel::~CNLPModel()
{
}

ENLPSyntacticCategory CNLPModel::GetSyntacticCategory(const CText &String)
{
	for (int Index=0; Index < (int)NLPSYNTACTICCATEGORY_COUNT; Index++)
	{
		if (String == GetSyntacticCategoryName((ENLPSyntacticCategory)Index)) return (ENLPSyntacticCategory)Index;
	}
	
	assert(false);
	return (ENLPSyntacticCategory)0;
}

void CNLPModel::AddLexicalEntry(const CText &Word, const CText &Category)
{
	Lexicon.AddEntry(Word, GetSyntacticCategory(Category));
}

/// Adds the words in the file named FileName into the lexicon by category SyntacticCategory
void CNLPModel::AddLexicalEntries(const CText &FileName, const CText &SyntacticCategoryName)
{
	CLoader Loader;
	ENLPSyntacticCategory SyntacticCategory = GetSyntacticCategory(SyntacticCategoryName);

	Loader.ReadFile(FileName);

	while (Loader.HasNext())
	{
		Lexicon.AddEntry(Loader.NextToken(), SyntacticCategory);
	}
}

void CNLPModel::AddGrammarRule(const CText &RuleString)
{
	CLoader Loader;
	CText Token;
	CNLPGrammarRule *GrammarRule;

	// initialize loader
	Loader.ReadString(RuleString);
	Loader.AddOperator("->");

	// create new Rule
	GrammarRule = new CNLPGrammarRule();

	// antecedent
	Token = Loader.NextToken();
	GrammarRule->SetAntecedent(GetSyntacticCategory(Token));

	// ->
	Token = Loader.NextToken();
	assert(Token == "->");

	// at least one consequent
	do
	{
		// parse next token
		Token = Loader.NextToken();

		// add consequent to rule
		GrammarRule->AddConsequent(GetSyntacticCategory(Token));
	}
	while (Loader.HasNext());

	// add rule to grammar
	Grammar.AddRule(GrammarRule);
}

void CNLPModel::AddGrammarRules(const CText &FileName)
{
	CLoader Loader;
	CText Token;
	CNLPGrammarRule *GrammarRule;

	Loader.ReadFile(FileName);
	Loader.SetWhitespaceChars(" \t");
	Loader.SetPunctuationChars("\n");
	Loader.AddOperator("->");

	while (Loader.HasNext())
	{
		// create new Rule
		Token = Loader.NextToken();
		GrammarRule = new CNLPGrammarRule();

		// antecedent
		GrammarRule->SetAntecedent(GetSyntacticCategory(Token));

		// ->
		Token = Loader.NextToken();
		assert(Token == "->");

		// at least one consequent
		do
		{
			// parse next token
			Token = Loader.NextToken();

			// end of line
			if (Token == "\n") break;

			// add consequent to rule
			GrammarRule->AddConsequent(GetSyntacticCategory(Token));
		}
		while (Loader.HasNext());

		// add rule to grammar
		Grammar.AddRule(GrammarRule);

		// skip newlines
		while (Loader.HasNext() && (Loader.LookAhead() == "\n")) Loader.NextToken();
	}
}

void CNLPModel::Parse(const CText &String, CNLPParseForest &ParseForest)
{
	assert(Parser != 0);

	Parser->Parse(Grammar, Lexicon, String, ParseForest);	
}
