#ifndef _NLPEDGE
#define _NLPEDGE

#include <assert.h>
#include "generic.h"

using namespace generic;

#include "aiNLPSyntacticCategory.h"

/// An edge is used by the phrase parsing process. It spans two vertices.
/// The children of the edge are the edges that form the nodes below this one in the parse tree.
/// Children are not a part of the chart parsing algorithm, but are added as to be able
/// to retrieve the different parse trees from the combined parse tree that the chart parsing
/// algorithm normally produces.\n\n
/// For example the children of [0, 7, S -> NP VP *] can be 
/// [0, 3, NP -> PP PP *] and [4, 7, VP -> PP PP *].\n
/// An edge only has one set of (nonoverlapping) edges. However, there can be edges that
/// are the same in all respects, except for their children.
/// All edges have children. Only the children of complete edges are useful in the end.

class CNLPGrammarRule;

class CNLPEdge: public CElement
{
protected:
	CNLPGrammarRule *GrammarRule;
	int ConsequentsCompleted;
	int StartVertex, EndVertex;
	CRow<CNLPEdge *> Children;

public:

	CNLPEdge(int NewStartVertex, int NewEndVertex, CNLPGrammarRule *NewGrammarRule, int NewConsequentsCompleted);
	~CNLPEdge(){}

	void SetGrammarRule(CNLPGrammarRule *NewGrammarRule){ NewGrammarRule = GrammarRule; }
	CNLPGrammarRule *GetGrammarRule(void) const { return GrammarRule; }

	void SetConsequentsCompleted(int NewConsequentsCompleted){ ConsequentsCompleted = NewConsequentsCompleted; }
	int GetConsequentsCompleted(void) const { return ConsequentsCompleted; }

	void SetVertices(int NewStartVertex, int NewEndVertex){ StartVertex = NewStartVertex; EndVertex = NewEndVertex; }
	int GetStartVertex(void) const { return StartVertex; }
	int GetEndVertex(void) const { return EndVertex; }
	int GetWidth(void) const { return EndVertex - StartVertex; }

	ENLPSyntacticCategory GetFirstConsequentAfterDot(void);
	ENLPSyntacticCategory GetLastConsequent(void);

	int GetChildCount(void) const { return Children.GetLength(); }
	void SetChild(int Index, CNLPEdge *NewChild){ Children.Set(Index, NewChild); }
	CNLPEdge *GetChild(int Index) const { return Children.Get(Index); }
	CRow<CNLPEdge *> &GetChildren(void) { return Children; }
	void CopyChildren(CNLPEdge *Edge) const;

	bool IsComplete(void) const;

	CText ToString(void);
};

#endif
