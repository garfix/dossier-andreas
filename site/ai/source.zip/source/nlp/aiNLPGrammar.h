#ifndef _NLPGRAMMAR
#define _NLPGRAMMAR

#include "aiNLPSyntacticCategory.h"
#include "generic.h"

using namespace generic;

class CNLPGrammarRule;
typedef CRow<CNLPGrammarRule *> CategoryRules;
typedef CRow<int> ConsequentIndices;

class CNLPGrammar: public CElement
{
protected:
	// all grammar rules
	CRow<CNLPGrammarRule *> Rules;
	// rules ordered by syntactic category of the antecedent
	CRow<CategoryRules> RulesWithAntecedent;

public:
	CNLPGrammar();
	~CNLPGrammar();

	void AddRule(CNLPGrammarRule *Rule);

	int GetRuleCount(void) const;
	CNLPGrammarRule *GetRule(int RuleIndex) const;

	int GetNumberOfRulesWithAntedent(ENLPSyntacticCategory Antecent) const;
	CNLPGrammarRule *GetRuleWithAntecedent(ENLPSyntacticCategory Antecent, int RuleIndex) const;

	// these are not used anymore
	int GetNumberOfRulesContainingConsequent(ENLPSyntacticCategory Consequent) const;
	CNLPGrammarRule *GetRuleContainingConsequent(ENLPSyntacticCategory Consequent, int RuleIndex) const;
	int GetConsequentIndexOfRuleContainingConsequent(ENLPSyntacticCategory Consequent, int RuleIndex) const;
};

#endif
