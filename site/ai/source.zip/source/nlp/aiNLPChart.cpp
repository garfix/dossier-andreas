#include "aiNLPChart.h"
#include "aiNLPGrammarRule.h"
#include "aiNLPSyntacticCategory.h"

#include <assert.h>

CNLPChart::CNLPChart()
{
}

CNLPChart::~CNLPChart()
{
	for (int Index=0; Index<SubCharts.GetLength(); Index++)
	{
		SubCharts.Get(Index).DeleteContents();
	}
}

/// Space allocation for better performance; NewSize should be the number of words in the 
/// sentence to be parsed, plus 1.
void CNLPChart::SetSize(int NewSize)
{
	SubCharts.SetLength(NewSize);
}

/// Adds an edge to the chart.
CNLPEdge *CNLPChart::AddEdge(int StartVertex, int EndVertex, CNLPGrammarRule *GrammarRule, int ConsequentsCompleted)
{
	SubChart &Sub = SubCharts.Get(EndVertex);
	
	Sub.Add(new CNLPEdge(StartVertex, EndVertex, GrammarRule, ConsequentsCompleted));

	return Sub.Get(Sub.GetLength()-1);
}

/// Retrieves specified edge from chart.
/// \CompleteEdgeChildren An array of children the edge should match; if 0, no match is required.
CNLPEdge *CNLPChart::GetEdge(int StartVertex, int EndVertex, CNLPGrammarRule *GrammarRule, int ConsequentsCompleted, CRow<CNLPEdge *> *CompleteEdgeChildren)
{
	// get the subchart this edge should be in
	SubChart &Edges = SubCharts.Get(EndVertex);

	// check all edges
	for (int EdgeIndex=0; EdgeIndex < Edges.GetLength(); EdgeIndex++)
	{
		// get edge
		CNLPEdge *Edge = Edges.Get(EdgeIndex);

		// compare all properties
		if (
			(Edge->GetStartVertex() == StartVertex) &&
			(Edge->GetGrammarRule() == GrammarRule) &&
			(Edge->GetConsequentsCompleted() == ConsequentsCompleted)
		)
		{	
			// should all children be compared as well?
			if (CompleteEdgeChildren != 0)
			{
				// childcount equal?
				if (Edge->GetChildCount() != CompleteEdgeChildren->GetLength()) break;

				// compare all children
				for (int ChildIndex=0; ChildIndex < Edge->GetChildCount(); ChildIndex++)
				{
					if (Edge->GetChild(ChildIndex) != CompleteEdgeChildren->Get(ChildIndex)) break;
				}
			}

			// all properties of this edge match
			return Edge;
		}
	}

	// none found
	return 0;
}

/// Dumps all edges to a string.
const CText CNLPChart::EdgesToString(void)
{
	CText String;

	for (int SubChartIndex=0; SubChartIndex<SubCharts.GetLength(); SubChartIndex++)
	{
		for (int EdgeIndex=0; EdgeIndex < SubCharts.Get(SubChartIndex).GetLength(); EdgeIndex++)
		{
			String += SubCharts.Get(SubChartIndex).Get(EdgeIndex)->ToString();
			String += "\n";
		}
		String += "\n";
	}

	return String;
}
