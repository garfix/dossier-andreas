#include "aiNLPLexicon.h"

CNLPLexicon::CNLPLexicon():
	Entries(59999)
{
}

CNLPLexicon::~CNLPLexicon()
{
}

void CNLPLexicon::AddEntry(const CText &Word, ENLPSyntacticCategory SyntacticCategory)
{
	bool Found;
	int HashCode;
	HashCode = CText::CreateHashCode(Word);

	// look for existing entry
	CRow<ENLPSyntacticCategory> &Categories = Entries.Get(HashCode, Word, Found);

	if (Found)
	{
		Categories.Add(SyntacticCategory);
	}
	else
	{
		// create new entry
		CRow<ENLPSyntacticCategory> NewEntry;

		NewEntry.Add(SyntacticCategory);

		Entries.Put(HashCode, Word, NewEntry);
	}
}

CRow<ENLPSyntacticCategory> &CNLPLexicon::GetSyntacticCategories(const CText &Word, bool &Found) const
{
	return Entries.Get(CText::CreateHashCode(Word), Word, Found);
}
