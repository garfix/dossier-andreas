#ifndef _NLPCHART
#define _NLPCHART

#include "aiNLPEdge.h"
#include "generic.h"

using namespace generic;

typedef CRow<CNLPEdge *> SubChart;

/// The chart is used by the chart parser to store edges.
/// Edges are first stored in SubCharts, which is indexed by the end vertex edges.

class CNLPChart: public CElement
{
protected:
	// array of edge arrays, indexed by end vertex
	CRow<SubChart> SubCharts;

public:
	CNLPChart();
	~CNLPChart();

	void SetSize(int NewSize);
	int GetSize(void) const { return SubCharts.GetLength(); }

	CNLPEdge *AddEdge(int StartVertex, int EndVertex, CNLPGrammarRule *GrammarRule, int ConsequentsCompleted);
	int GetEdgeCount(int EndVertex) const { return SubCharts.Get(EndVertex).GetLength(); }
	CNLPEdge *GetEdge(int EndVertex, int EdgeIndex) const { return SubCharts.Get(EndVertex).Get(EdgeIndex); }
	CNLPEdge *GetEdge(int NewStartVertex, int NewEndVertex, CNLPGrammarRule *NewGrammarRule, int NewConsequentsCompleted, CRow<CNLPEdge *> *CompleteEdgeChildren=0);

	const CText EdgesToString(void);
};

#endif
