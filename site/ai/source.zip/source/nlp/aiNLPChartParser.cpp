#include <windows.h>

#include "aiNLPLexicon.h"
#include "aiNLPChart.h"
#include "aiNLPGrammar.h"
#include "aiNLPChartParser.h"
#include "aiNLPGrammarRule.h"
#include "aiNLPEdge.h"
#include "aiNLPParseTree.h"
#include "aiNLPParseForest.h"

void PrintTabs(int Tab){ for(int T=0; T<Tab; T++) printf("\t"); }


CNLPChartParser::CNLPChartParser()
{
}

CNLPChartParser::~CNLPChartParser()
{
}

/// Tokenizes sentence String into words and places these in Tokens.
void CNLPChartParser::Tokenize(const CText &String, CRow<CText> &Tokens)
{
	CLoader Loader;

	// initialize loader
	Loader.ReadString(String);
	Loader.SetPunctuationChars(".,?");

	while (Loader.HasNext())
	{
		CText Token = Loader.NextToken();
		
		if (Token == ".") continue;
		if (Token == ",") continue;
		if (Token == "?") continue;

		Tokens.Add(Token);
	}
}

/// Adds an edge (with characteristics StartVertex, EndVertex, GrammarRule, ConsequentsCompleted) 
/// to the chart, if the chart did not already contain such an edge.
/// If the new edge is complete, Complete() is called on the edge.
/// If the edge is incomplete, Predict() is called.
/// patrick: added to create parse trees: CreateNew
/// \CreateNew Create a new edge always? If false, a new edge won't be created if one with the
///   given characteristics already existed
CNLPEdge *CNLPChartParser::AddEdge(const CNLPGrammar &Grammar, CNLPChart &Chart, int StartVertex, int EndVertex, CNLPGrammarRule *GrammarRule, int ConsequentsCompleted, bool CreateNew)
{
	CNLPEdge *ExistingEdge;

	#ifdef DEBUG_PARSE
		PrintTabs(Tab);
		printf("[AddEdge ] Start: %d, End: %d, Rule: %s, DotPos: %d\n", 
			StartVertex, EndVertex, GrammarRule->ToString().GetBuffer(), ConsequentsCompleted);

		Sleep(10);
	#endif

	// if the chart contains such an edge, do nothing
	if (!CreateNew)
	{
		ExistingEdge = Chart.GetEdge(StartVertex, EndVertex, GrammarRule, ConsequentsCompleted);
		if (ExistingEdge != 0) return ExistingEdge;
	}

	#ifdef DEBUG_PARSE
		Tab++;
	#endif

	// add new edge to chart
	CNLPEdge *Edge = Chart.AddEdge(StartVertex, EndVertex, GrammarRule, ConsequentsCompleted);

	// is the edge complete?
	if (Edge->IsComplete())
	{
		// it is, so finish it
		Complete(Grammar, Chart, Edge);
	}
	else
	{
		// it is not, predict
		Predict(Grammar, Chart, Edge);
	}

	#ifdef DEBUG_PARSE
		Tab--;
	#endif

	return Edge;
}

/// Bottom-up procedure.
/// First finds out the syntactic category of Word. Then goes through all rules in Grammar that
/// contain this syntactic category as one of their consequents. Then it adds edges for all
/// these rules to Chart.
void CNLPChartParser::Scan(const CNLPGrammar &Grammar, const CNLPLexicon &Lexicon, CNLPChart &Chart, int StartVertex, const CText &Word)
{
	ENLPSyntacticCategory WordCategory;
	CNLPGrammarRule *GrammarRule;
	CNLPEdge *IncompleteEdge, *CompleterEdge;
	int FirstConsequentAfterDot;
	bool Found;

	#ifdef DEBUG_PARSE
		PrintTabs(Tab);
		printf("[Scan    ] Start: %d, Word: %s\n", StartVertex,	Word.GetBuffer());
		Tab++;
	#endif

	// get the syntactic categories of the word
	CRow<ENLPSyntacticCategory> &WordCategories = Lexicon.GetSyntacticCategories(Word, Found);
	assert(Found);
	if (!Found) printf("The word '%s' could not be found in the lexicon\n", Word.GetBuffer());

	// loop through all categories
	for (int CatIndex=0; CatIndex < WordCategories.GetLength(); CatIndex++)
	{
		WordCategory = WordCategories.Get(CatIndex);

		// loop through all edges that expect this word's syntactic category, and complete them
		for (int EdgeIndex=0; EdgeIndex < Chart.GetEdgeCount(StartVertex); EdgeIndex++)
		{
			// fetch the incomplete edge and its rule
			IncompleteEdge = Chart.GetEdge(StartVertex, EdgeIndex);
			GrammarRule = IncompleteEdge->GetGrammarRule();

			// get the first consequent after the 'dot' in the grammar rule of the incomplete edge
			FirstConsequentAfterDot = IncompleteEdge->GetFirstConsequentAfterDot();

			// does the antecedent of Edge's rule equal the first consequent of the incomplete edge?
			if (WordCategory == FirstConsequentAfterDot)
			{
				// create an edge that completes one more consequent of the found incomplete edge
				CompleterEdge = AddEdge(Grammar, Chart, IncompleteEdge->GetStartVertex(), IncompleteEdge->GetEndVertex()+1, GrammarRule, IncompleteEdge->GetConsequentsCompleted()+1, true);
				// patrick: added to create parse trees
				CompleterEdge->CopyChildren(IncompleteEdge);
			}
		}
	}

	#ifdef DEBUG_PARSE
		Tab--;
	#endif
}

/// Given the incomplete edge Edge that is looking for some syntactic category
/// (the first consequent after the dot), adds edges to the chart that have this
/// syntactic category as a antedent.
void CNLPChartParser::Predict(const CNLPGrammar &Grammar, CNLPChart &Chart, CNLPEdge *Edge)
{
	ENLPSyntacticCategory FirstConsequentAfterDot;
	int RuleCount;
	int EndVertex;
	CNLPGrammarRule *GrammarRule;

	#ifdef DEBUG_PARSE
		PrintTabs(Tab);
		printf("[Predict ] Edge: %s\n", Edge->ToString().GetBuffer());
		Tab++;
	#endif

	// get the first consequent after the 'dot' in the grammar rule of the edge
	FirstConsequentAfterDot = Edge->GetFirstConsequentAfterDot();

	// how many grammar rules have as antecedent this consequent
	RuleCount = Grammar.GetNumberOfRulesWithAntedent(FirstConsequentAfterDot);

	// go through all grammar rules with this antecedent
	for (int RuleIndex=0; RuleIndex < RuleCount; RuleIndex++)
	{
		// get grammar rule
		GrammarRule = Grammar.GetRuleWithAntecedent(FirstConsequentAfterDot, RuleIndex);

		// add incomplete edge that starts and ends at Edge's end vertex
		EndVertex = Edge->GetEndVertex();

		AddEdge(Grammar, Chart, EndVertex, EndVertex, GrammarRule, 0, false);
	}

	#ifdef DEBUG_PARSE
		Tab--;
	#endif
}

/// Edge is a complete edge.
/// We extend all incomplete edges that wait for this edge.
void CNLPChartParser::Complete(const CNLPGrammar &Grammar, CNLPChart &Chart, CNLPEdge *Edge)
{
	int StartVertex;
	ENLPSyntacticCategory Antecedent;
	ENLPSyntacticCategory FirstConsequentAfterDot;
	CNLPGrammarRule *GrammarRule;
	CNLPEdge *IncompleteEdge, *CompleterEdge, *ExistingEdge;
	CRow<CNLPEdge *> CompleteEdgeChildren;

	#ifdef DEBUG_PARSE
		PrintTabs(Tab);
		printf("[Complete] Edge: %s\n", 
			Edge->ToString().GetBuffer()
		);
		Tab++;
	#endif

	// get the start vertex of Edge
	StartVertex = Edge->GetStartVertex();

	// get the antecent of edge
	Antecedent = Edge->GetGrammarRule()->GetAntecedent();

	// go through all edges with end index = the start vertex of Edge
	for (int EdgeIndex=0; EdgeIndex < Chart.GetEdgeCount(StartVertex); EdgeIndex++)
	{
		// fetch the incomplete edge and its rule
		IncompleteEdge = Chart.GetEdge(StartVertex, EdgeIndex);
		GrammarRule = IncompleteEdge->GetGrammarRule();

		// get the first consequent after the 'dot' in the grammar rule of the incomplete edge
		FirstConsequentAfterDot = IncompleteEdge->GetFirstConsequentAfterDot();

		// does the antecedent of Edge's rule equal the first consequent of the incomplete edge?
		if (Antecedent == FirstConsequentAfterDot)
		{
			// we are going to create a new edge; but only if that edge did not exist yet
			// so we are going to perform a existence check including the child edges
			CompleteEdgeChildren = IncompleteEdge->GetChildren();
			CompleteEdgeChildren.Add(Edge);

			ExistingEdge = Chart.GetEdge(IncompleteEdge->GetStartVertex(), Edge->GetEndVertex(), GrammarRule, IncompleteEdge->GetConsequentsCompleted()+1, &CompleteEdgeChildren);
			if (ExistingEdge != 0)
			{
				// an identical edge existed
				break;
			}

			// create an edge that completes one more consequent of the found incomplete edge
			CompleterEdge = AddEdge(Grammar, Chart, IncompleteEdge->GetStartVertex(), Edge->GetEndVertex(), GrammarRule, IncompleteEdge->GetConsequentsCompleted()+1, true);
			// patrick: added to create parse trees
			CompleterEdge->CopyChildren(IncompleteEdge);
			CompleterEdge->SetChild(IncompleteEdge->GetConsequentsCompleted(), Edge);
		}
	}

	#ifdef DEBUG_PARSE
		Tab--;
	#endif
}

void CNLPChartParser::VisitEdge(CNLPChart &Chart, CRow<CText> &Words, CNLPEdge *Edge, CNLPParseTree &ParseTree, CNLPParseTree &ParseTreeBranch, CNLPParseForest &ParseForest)
{
	CNLPGrammarRule *GrammarRule;
	ENLPSyntacticCategory Antecedent;
	int StartVertex, EndVertex, CurrentVertex;
	int ConsequentCount; 
	CNLPEdge *ChildEdge;

	// get some data
	GrammarRule = Edge->GetGrammarRule();
	Antecedent = GrammarRule->GetAntecedent();
	StartVertex = Edge->GetStartVertex();
	EndVertex = Edge->GetEndVertex();
	ConsequentCount = Edge->GetGrammarRule()->GetConsequentCount();

	// set the tree's syntactic category
	ParseTreeBranch.SetSyntacticCategory(Antecedent);

	// create space for the children
	ParseTreeBranch.SetChildCount(ConsequentCount);

	CurrentVertex = StartVertex;
	for (int Index = 0; Index < ConsequentCount; Index++)
	{
		// get child edge
		ChildEdge = Edge->GetChild(Index);

		// get child branch
		CNLPParseTree &Childbranch = ParseTreeBranch.GetChild(Index);

		// the child edge is not defined 
		if (ChildEdge == 0)
		{
			Childbranch.SetSyntacticCategory(GrammarRule->GetConsequent(Index));
			Childbranch.SetWord(Words.Get(CurrentVertex));
			Childbranch.SetChildCount(0);

			// advance vertex
			CurrentVertex++;
			
			// is this the last word in the tree?
			if (CurrentVertex == Words.GetLength())
			{
				// copy the working tree into the forest
				ParseForest.AddParseTree(new CNLPParseTree(ParseTree));
			}
		}
		else
		{
			// visit the child edge, and create the child branch
			VisitEdge(Chart, Words, ChildEdge, ParseTree, Childbranch, ParseForest);

			// advance vertex
			CurrentVertex = ChildEdge->GetEndVertex();
		}
	}
}

/// Turns the chart into parse trees and places them in ParseForest.
void CNLPChartParser::CreateParseTrees(CNLPChart &Chart, CRow<CText> &Words, CNLPParseForest &ParseForest)
{
	CNLPParseTree TemplateParseTree;
	CNLPEdge *EndEdge;
	int RightMostVertex;

	// find all completed sentences
	RightMostVertex = Words.GetLength();
	for (int Index=0; Index < Chart.GetEdgeCount(RightMostVertex); Index++)
	{
		// get next edge that ends at the rightmost vertex
		EndEdge = Chart.GetEdge(RightMostVertex, Index);

		// is it a sentence, does it start at the leftmost vertex, and is it complete?
		if (
			(EndEdge->GetGrammarRule()->GetAntecedent() == NLPSYNTACTICCATEGORY_SENTENCE) && 
			(EndEdge->GetStartVertex() == 0) && 
			(EndEdge->IsComplete()))
		{
			// create a parse trees and place it in the forest
			VisitEdge(Chart, Words, EndEdge, TemplateParseTree, TemplateParseTree, ParseForest);
		}
	}
}

/// Given a (Phrase Structure) Grammar and a Lexicon, it is able to find
/// all possible parse trees. The trees are placed in ParseForest.
void CNLPChartParser::Parse(const CNLPGrammar &Grammar, const CNLPLexicon &Lexicon, const CText &Sentence, CNLPParseForest &ParseForest)
{
	CNLPGrammarRule InitialRule;
	CRow<CText> Words;
	CNLPChart Chart;

	#ifdef DEBUG_PARSE
		Tab = 0;
	#endif

	// initialize S' -> S
	InitialRule.SetAntecedent(NLPSYNTACTICCATEGORY_SENTENCE_START);
	InitialRule.AddConsequent(NLPSYNTACTICCATEGORY_SENTENCE);

	// split up the sentence into words
	Tokenize(Sentence, Words);

	// set number of subcharts
	Chart.SetSize(Words.GetLength() + 1);

	// initialize chart:
	// top-down: predict all incomplete edges
	AddEdge(Grammar, Chart, 0, 0, &InitialRule, 0, true);

	// main loop
	for (int Vertex=0; Vertex < Words.GetLength(); Vertex++)
	{
		Scan(Grammar, Lexicon, Chart, Vertex, Words.Get(Vertex));
	}

	// create a forest of parse trees from the chart
	CreateParseTrees(Chart, Words, ParseForest);
}
