#ifndef _NLPPARSETREE
#define _NLPPARSETREE

#include "aiNLPSyntacticCategory.h"
#include "generic.h"

using namespace generic;

/// A parse tree is phrase structure of a sentence. The children (branches) of a parse tree are 
/// parse trees themselves. If a parse tree has no children, its called a leaf, and it
/// contains the word of the sentence that is connected to this position.
/// Each parse tree has a syntactic category, like NP, or Verb, that this tree represents.

class CNLPParseTree: public CElement
{
protected:
	CRow<CNLPParseTree> Children;
	ENLPSyntacticCategory SyntacticCategory;
	CText Word;

public:
	CNLPParseTree();
	CNLPParseTree(const CNLPParseTree &ParseTree);
	~CNLPParseTree();

	const CNLPParseTree &operator=(const CNLPParseTree &ParseTree);

	void SetChildCount(int NewChildCount) { Children.SetLength(NewChildCount); }
	int GetChildCount(void) const { return Children.GetLength(); }
	void SetChild(int Index, const CNLPParseTree &NewValue){ Children.Set(Index, NewValue); }
	CNLPParseTree &GetChild(int Index) const { return Children.Get(Index); }

	void SetSyntacticCategory(ENLPSyntacticCategory NewSyntacticCategory){ SyntacticCategory = NewSyntacticCategory; }
	ENLPSyntacticCategory GetSyntacticCategory(void) const { return SyntacticCategory; }

	void SetWord(const CText &NewWord){ Word = NewWord; }
	const CText &GetWord(void) const { return Word; }

	CText ToString(int TabCount=0) const;
};

#endif
