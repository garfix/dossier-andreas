#include "aiNLPGrammar.h"
#include "aiNLPGrammarRule.h"

CNLPGrammar::CNLPGrammar():
	RulesWithAntecedent(NLPSYNTACTICCATEGORY_COUNT)//, RulesContainingConsequent(NLPSYNTACTICCATEGORY_COUNT)
{
}

CNLPGrammar::~CNLPGrammar()
{
	Rules.DeleteContents();
}

void CNLPGrammar::AddRule(CNLPGrammarRule *Rule)
{ 
	ENLPSyntacticCategory Consequent;
    
	// add rule
	Rules.Add(Rule);

	// add rule in the array ordered by antecedent
	RulesWithAntecedent.Get((int)Rule->GetAntecedent()).Add(Rule);

	// add rule in the array ordered by consequent
	for (int Index=0; Index < Rule->GetConsequentCount(); Index++)
	{
		// get Index'th consequent
		Consequent = Rule->GetConsequent(Index);
	}
}

/// Returns the number of rules whose antedent is SyntacticCategory.
int CNLPGrammar::GetRuleCount(void) const
{
	return Rules.GetLength();
}

/// Returns the RuleIndex'th rule.
CNLPGrammarRule *CNLPGrammar::GetRule(int RuleIndex) const
{
	return Rules.Get(RuleIndex);
}

/// Returns the number of rules whose antedent is SyntacticCategory.
int CNLPGrammar::GetNumberOfRulesWithAntedent(ENLPSyntacticCategory Antecedent) const
{
	return RulesWithAntecedent.Get((int)Antecedent).GetLength();
}

/// Returns the RuleIndex'th number whose antedent is SyntacticCategory.
CNLPGrammarRule *CNLPGrammar::GetRuleWithAntecedent(ENLPSyntacticCategory Antecedent, int RuleIndex) const
{
	return RulesWithAntecedent.Get((int)Antecedent).Get(RuleIndex);
}
