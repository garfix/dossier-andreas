#include "aiNLPGrammarRule.h"
#include "aiNLPSyntacticCategory.h"

CNLPGrammarRule::CNLPGrammarRule()
{
}

CNLPGrammarRule::~CNLPGrammarRule()
{
}

CText CNLPGrammarRule::ToString(void)
{
	CText String;

	// antecedent
	String += GetSyntacticCategoryName(Antecedent);

	// ->
	String += " -> ";

	// consequents
	for (int Index=0; Index < Consequents.GetLength(); Index++)
	{
		// syntactic category
		String += GetSyntacticCategoryName(Consequents.Get(Index));

		// space
		if (Index < Consequents.GetLength()-1) String += " ";
	}

	return String;
}
