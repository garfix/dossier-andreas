#ifndef _STOPWATCH
#define _STOPWATCH

#include "genericElement.h"
#include <time.h>

namespace generic
{
	
class CStopwatch: public CElement
{
protected:
	clock_t StartTime, IntervalTime, EndTime;
	double Duration;

public:
	CStopwatch();

	const CStopwatch &Start(void);
	const CStopwatch &Stop(void);
	const CStopwatch &Reset(void);
	const CStopwatch &Print(void) const;

	double GetDuration(void) const { return Duration; }
};

}

#endif