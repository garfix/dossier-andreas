#ifndef _SAVER
#define _SAVER

#include "genericElement.h"
#include "genericText.h"
#include "genericLinkedList.h"

namespace generic
{
	
/// Base class for savers
class CSaver: public CElement
{
protected:
	CLinkedList<CText> Target;
	CText Error;

public:
	CSaver();

	bool SaveToFile(const CText &Filename, bool Create=true, bool Append=false);
	void SaveToString(CText &String);

	void Append(const CText &String);
};

}

#endif