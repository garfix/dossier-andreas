#ifndef _ARRAY
#define _ARRAY

#include <assert.h>
#include "genericMath.h"
#include "genericText.h"

namespace generic
{

#define DEFAULT_MAX_LENGTH 10

template <class TYPE>
class CRow
{
protected:
	int Length;
	int MaxLength;
	TYPE *Values;

	void Init(int NewLength, bool AllocateExtra, int NewMaxLength=-1)
	{
		Length = 0;
		MaxLength = -1;
		Values = 0;

		ReAllocate(NewLength, AllocateExtra, NewMaxLength);
	}

	void ReAllocate(int NewLength, bool AllocateExtra, int NewMaxLength=-1)
	{
		// should the array be resized?
		if (NewLength > MaxLength)
		{
			// create extra storage to reduce resize frequency
			if (AllocateExtra)
			{
				if (NewMaxLength == -1)
				{
					// allocate space for twice the previous length or the new length;
					// whichever is more
					MaxLength = CMath::Max(2*MaxLength, NewLength);
					// there is a minimum allocation space
					MaxLength = CMath::Max(MaxLength, DEFAULT_MAX_LENGTH);
					// allocate space
				}
				else
					MaxLength = NewMaxLength;

				Values = new TYPE [MaxLength];
			}
			else
			{
				// adjust maxim number of elements
				MaxLength = NewLength;

				// allocate elements only if there's at least one of them
				Values = (MaxLength == 0 ? 0 : new TYPE [MaxLength]);
			}
		}

		Length = NewLength;
	}

public:
	/// Initializes array with 0 elements
	/// elements
	CRow()
	{
		Init(0, false);
	}

	/// Initializes array with NewLength elements; space is allocated for NewLength
	/// elements
	CRow(int NewLength)
	{
		Init(NewLength, false);
	}

	/// Initializes array with NewLength elements; space is allocated for NewMaxLength
	/// elements
	CRow(int NewLength, int NewMaxLength)
	{
		Init(NewLength, true, NewMaxLength);
	}

	/// The elements of NewArray are copied into this array; space is allocated for
	/// as many elements as NewArray has
	CRow(const CRow &NewArray)
	{
		Init(NewArray.GetLength(), false);
		(*this) = NewArray;
	}

	~CRow()
	{
		delete[] Values;
	}

	bool IsEmpty(void) const { return (Length==0); }

	/// Calls the destructor on all values.
	/// The method is meaningless if the values are not objects
	void DeleteContents(void)
	{
		int Index;

		for (Index=0; Index<Length; Index++)
		{
			delete Values[Index];
		}
	}

	void Set(int Index, const TYPE &Value){ assert(Index < Length); Values[Index] = Value; }

	TYPE &Get(int Index) const { return Values[Index]; }

	void Fill(const TYPE &Value)
	{
		for (int Index=0; Index < Length; Index++) Values[Index] = Value;
	}

	void SetLength(int NewLength, bool AllocateExtra=false) 
	{
		TYPE *OldValues = Values;
		int OldLength = Length;

		ReAllocate(NewLength, AllocateExtra);

		// check if a new array was created
		if (Values != OldValues) 
		{
			// yes: copy old values to new array
			for (int Index=0; ((Index<Length) && (Index<OldLength)); Index++)
			{
				Values[Index] = OldValues[Index];
			}

			// delete old values
			delete[] OldValues;
		}
	}

	/// Adds Value to the end of the array
	CRow &Add(const TYPE &Value, bool AllocateExtra=true)
	{ 
		SetLength(Length+1, AllocateExtra);
		Values[Length-1] = Value; 

		return (*this);
	}

	/// Adds elements of NewArray to the array
	CRow &Add(const CRow &NewArray, bool AllocateExtra=true)
	{
		int OldLength = Length;

		SetLength(Length+NewArray.Length, AllocateExtra);
		for (int Index=0; Index < NewArray.Length; Index++)
		{
			Values[OldLength+Index] = NewArray.Values[Index];
		}

		return (*this);
	}

	void Clear(void){ Length = 0; }

	int GetLength(void) const { return Length; }

	void operator=(const CRow<TYPE> &NewArray)
	{
		int Index;
		TYPE *OldValues = Values;

		// allocate space for new values
		ReAllocate(NewArray.Length, false);

		// copy all values
		for(Index=0; Index<Length; Index++)
		{
			Values[Index] = NewArray.Get(Index);
		}

		// delete old values, if a new array was created
		if (Values != OldValues) delete[] OldValues;
	}

	int GetIndex(const TYPE &Item) const
	{
		int Index;

		for (Index=0; Index<Length; Index++)
		{
			if (Get(Index) == Item) return Index;
		}
		return -1;
	}

	bool Contains(const TYPE &Item) const
	{
		return (GetIndex(Item) != -1);
	}

	/// Inserts Item at NewIndex
	CRow &InsertAt(int ItemIndex, const TYPE &Item, bool AllocateExtra=true)
	{ 
		SetLength(Length+1, AllocateExtra);

		for (int Index=Length-1; Index > ItemIndex; Index--)
		{
			Values[Index] = Values[Index-1];
		}

		Values[ItemIndex] = Item;

		return (*this);
	}

	/// Remove Item at NewIndex
	void RemoveAt(int ItemIndex)
	{
		assert(ItemIndex >= 0);
		assert(ItemIndex < Length);

		// copy old values after deleted item
		for (int Index=ItemIndex+1; Index<Length; Index++)
		{
			Values[Index-1] = Values[Index];
		}

		// decrease length
		Length--;
	}

	/// Removes the first item from the array (all later values shift one position)
	void Remove(const TYPE &Item)
	{
		int ItemIndex;

		// find item
		ItemIndex = GetIndex(Item);
		if (ItemIndex == -1) return;

		RemoveAt(ItemIndex);
	}

	/// Randomizes the order of the values.
	/// Implementation: swaps Length times two random values.
	void Randomize(void)
	{
		int RandomIndex1, RandomIndex2;
		TYPE Swapper;

		for (int i=0; i<Length; i++)
		{
			// select two random elements
			RandomIndex1 = rand() % Length;
			RandomIndex2 = rand() % Length;

			// swap them
			Swapper = Values[RandomIndex1];
			Values[RandomIndex1] = Values[RandomIndex2];
			Values[RandomIndex2] = Swapper;
		}
	}

	friend class CTest;
};

}

#endif