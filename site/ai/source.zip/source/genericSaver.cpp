#include "genericSaver.h"

namespace generic
{

#define ERROR_WRITING_TO_FILE "Error reading file."

CSaver::CSaver()
{
}

/// Saves the accumulated target string to file
/// \return Success or failure
bool CSaver::SaveToFile(const CText &FileName, bool Create, bool Append)
{
	FILE *File;
	CListNode<CText> *Node;
	CText Mode;
	const char *Buffer;

	// set mode
	if (Append) Mode = "a"; else Mode = "w";
	Mode += "t";
	if (Create) Mode += "+";

	if (!(File = fopen((const char*)FileName.GetBuffer(), Mode.GetBuffer()))) 
	{	
		Error = ERROR_WRITING_TO_FILE;
		return false;
	}

	// write all pieces
	Node = Target.GetFirst();
	while (Node != Target.GetEnd())
	{
		Buffer = Node->GetValue().GetBuffer();
		if (Buffer != 0) fputs(Buffer, File);
		Node = Node->GetNext();
	}

	fclose(File);
	return true;
}

/// Saves the accumulated target string into String
void CSaver::SaveToString(CText &String)
{
	int Size=0;
	CListNode<CText> *Node;

	// first determine the length of String
	Node = Target.GetFirst();
	while (Node != Target.GetEnd())
	{
		Size += Node->GetValue().GetLength();
		Node = Node->GetNext();
	}

	// allocate space
	String.Allocate(Size);

	// fill the string
	Node = Target.GetFirst();
	while (Node != Target.GetEnd())
	{
		String += Node->GetValue();
		Node = Node->GetNext();
	}
}

void CSaver::Append(const CText &String)
{
	Target.Add(String);
}

}
