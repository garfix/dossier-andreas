#ifndef _TEST
#define _TEST

#include "crtdbg.h"
#include "Generic.h"
#include "AI.h"

namespace generic
{

class CTest
{
protected:
	bool Success;
	_CrtMemState DebugHeapState;

	void Reset(void);
	void Assert(const CText &Remark, float Actual, float Asserted);
	void Assert(const CText &Remark, int Actual, int Asserted);
	void Assert(const CText &Remark, const CText &Actual, const CText &Asserted);
	void Assert(const CText &Remark, bool Asserted);
	bool LeakOccurred(void);
	void TestCase(const CText &TestName, void (CTest::*TestFunction)(void));

public:
	CTest();

	void TestString(void);
	void TestHashTable(void);
	void TestArray(void);
	void TestRing(void);
	void TestStack(void);
	void TestSmartPointer(void);

	void TestFuzzyCategory(void);
	void TestFuzzy(void);
	void TestFuzzySet(void);
	void TestFuzzyOutputSet(void);
	void TestFuzzyOperator(void);
	void TestFuzzyRule(void);
	void TestFuzzyModelFCLLoader(void);

	void TestGeneticPopulation(void);
	void TestGeneticModel(void);

	void TestBitPatternHelper(CBitPattern &Pattern, int Length);
	void TestBitPattern(void);

	void TestPL(void);
	void TestdMARS(void);

	void TestAll();
};

}

#endif