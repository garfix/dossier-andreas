#ifndef _LOADER
#define _LOADER

#include "genericElement.h"
#include "genericText.h"
#include "genericRow.h"

namespace generic
{
	
struct SCommentInfo
{
	CText StartTag;
	CText EndTag;
	// can you nest (paired) comments?
	bool Nestable;
	// start and endtag valid?
	bool Paired;

	SCommentInfo(){};
	SCommentInfo(const CText &NewStartTag, const CText &NewEndTag, bool NewNestable);
	SCommentInfo(const CText &NewStartTag);
	SCommentInfo(const SCommentInfo &NewCommentInfo);

	const SCommentInfo &operator=(const SCommentInfo &NewCommentInfo);
};

/// Base class for loaders
class CLoader: public CElement
{
protected:
	CText Source;
	CText Error;
	CText Token;
	CText WhitespaceChars;
	CText PunctuationChars;
	CRow<CText> Operators;
	CRow<SCommentInfo> CommentInfos;
	int LineNumber;
	int SourceIndex;
	bool Done;
	bool CaseSensitive;

	bool IsCommentStartTag(const CText &String);
	bool IsDigit(char Char);
	char GetChar(void);
	bool TryParseFloat(void);
	bool TryParseOperator(void);
	bool ParseWhitespace(void);
	bool OnlyWhitespaceFollows(void);
	bool TryParseCommentStartTag(SCommentInfo *&CommentInfo);
	bool TryParseCommentEndTag(void);
	bool ParseComment(SCommentInfo *CommentInfo);

public:
	CLoader();

	void Reset(void);
	bool ReadFile(const CText &Filename);
	void ReadString(const CText &String);

	CText NextToken(bool SkipComments=true);
	CText &LookAhead(void);
	bool HasNext(void);
	const CText &GetBuffer(void) const { return Source; }

	const CText &GetError(void) const { return Error; };
	int GetLineNumber(void) const { return LineNumber; };
	bool IsSuccessful(void) const;

	void SetWhitespaceChars(const CText &NewWhitespaceChars);
	bool IsWhitespace(char Char);
	void SetPunctuationChars(const CText &NewPunctuationChars);
	bool IsPunctuationChar(char Char);
	void AddOperator(const CText &NewOperator){ Operators.Add(NewOperator ); }
	bool IsOperator(CText &String);
	void SetCaseSensitive(bool NewCaseSensitive){ CaseSensitive = NewCaseSensitive; }
	bool IsCaseSensitive(void){ return CaseSensitive; }
	bool IsIdentifier(const CText &String);
	void AddCommentInfo(SCommentInfo NewCommentInfo){ CommentInfos.Add(NewCommentInfo); }
};

}


#endif