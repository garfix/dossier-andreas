#ifndef _FSRELATION
#define _FSRELATION

#include "aiFSFrame.h"
#include "generic.h"

using namespace generic;

class CFSObject;
class CFSRelationType;

/// This class corresponds to a multi-valued relation in predicate logic.

class CFSRelation: public CFSFrame
{
protected:
	CFSRelationType *RelationType;
	CRow<CFSFrame *> RoleValues;
	// truth value of this relation (true / false)
	bool Truth;

	void Initialize(void);

public:
	CFSRelation(CFSRelationType *NewRelationType, const CText &NewName="");
	CFSRelation(CFSRelation *NewRelation);

	void SetRoleValue(const CText &RoleName, CFSFrame *RoleValue);
	void SetRoleValue(int Index, CFSFrame *RoleValue);
	int GetRoleValueCount(void) const;
	CFSFrame *GetRoleValue(const CText &RoleName) const;
	CFSFrame *GetRoleValue(int Index) const;
	void SetTruth(bool NewTruth){ Truth = NewTruth; }

	bool Matches(CFSRelation *Relation) const;
	bool IsBound(void) const;

	virtual const CText ToString(void) const;
};

#endif