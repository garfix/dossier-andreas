#include "aiFSModel.h"

//#define _TEST

CFSModel::CFSModel()
{
}

CFSModel::~CFSModel()
{
	Frames.DeleteContents();
}

/// Creates a new variable binding: the variables in Answer are bound to the corresponding values 
/// of Query (but only if the Query values are not variables themselves).
CFSBinding CFSModel::CreateBinding(CFSRelation *Query, CFSRelation *Answer)
{
	CFSBinding Binding;
	CFSFrame *QueryRoleValue, *AnswerRoleValue;

	for (int Index=0; Index < Query->GetRoleValueCount(); Index++)
	{
		QueryRoleValue = Query->GetRoleValue(Index);
		AnswerRoleValue = Answer->GetRoleValue(Index);

		if (AnswerRoleValue->IsVariable() && !QueryRoleValue->IsVariable())
		{
			Binding.SetValue((CFSObjectVariable *)AnswerRoleValue, QueryRoleValue);
		}
	}

	return Binding;
}

/// Creates a new binding (NewBinding): the variables in Original are bound to the
/// corresponding values in Action. But if these values turn out to be variables, 
/// the value of the variable is looked up in Binding, and assigned to the variable in Original.
CFSBinding CFSModel::BindBack(CFSRelation *Original, CFSRelation *Action, CFSBinding &Binding)
{
	CFSBinding NewBinding;
	CFSFrame *OriginalValue;
	CFSFrame *ActionValue;
	CFSFrame *TargetValue;

	for (int Index=0; Index < Original->GetRoleValueCount(); Index++)
	{
		OriginalValue = Original->GetRoleValue(Index);
		if (OriginalValue->IsVariable())
		{
			ActionValue = Action->GetRoleValue(Index);
			if (ActionValue->IsVariable())
			{
				TargetValue = Binding.GetValue((CFSObjectVariable *)ActionValue);
			}
			else
			{
				TargetValue = ActionValue;
			}
			NewBinding.SetValue((CFSObjectVariable *)OriginalValue, TargetValue);
		}
	}

	return NewBinding;
}

/// Create a relation BoundRelation based on Relation, in which all variables are replaced by their bindings
/// (from Binding).
void CFSModel::Bind(CFSRelation *Relation, CFSBinding &Binding, CFSRelation &BoundRelation)
{
	CFSFrame *RoleValue, *VariableValue;

	for (int Index=0; Index < Relation->GetRoleValueCount(); Index++)
	{
		RoleValue = Relation->GetRoleValue(Index);

		// is the role value a variable?
		if (RoleValue->IsVariable())
		{
			// is it available in the current variable binding?
			VariableValue = Binding.GetValue((CFSObjectVariable *)RoleValue);
			if (VariableValue != 0)
			{
				// replace the variable with the bound value
				BoundRelation.SetRoleValue(Index, VariableValue);
			}
		}
	}
}

/// Add existing variable bindings to new variable bindings
void CFSModel::CombineBindings(CFSBinding &ExistingBinding, CRow<CFSBinding> &NewBindings)
{
    for (int Index=0; Index < NewBindings.GetLength(); Index++)
	{
		NewBindings.Get(Index).Add(ExistingBinding);
	}
}

/// This method tries to match a certain relation, described by {RelationType, TruthValue, Bindings}
/// to as many relations as possible. The variable bindings that belong to these relations are
/// returned. An example:\n
/// Match(Gives(Bill, Y, Z)) would return\n
/// { { Y=Opus,Z=Paper} { Y=Pat,Z=Scissors } } \n
/// A resulting binding can be empty; in that case the match involved no variables.
CRow<CFSBinding> CFSModel::Match(CFSRelation *Query)
{
    CRow<CFSBinding> Bindings, RuleBindings, NewRuleBindings, FoundBindings;
	CFSRelation *Condition;
	CFSRule *Rule;
	CFSRelation *Relation;

//printf("--match---------------\n%s\n", Query->ToString().GetBuffer());

    // check if there exist relations that match exactly
    for (int Index=0; Index < Relations.GetLength(); Index++)
    {
        Relation = Relations.Get(Index);
        if (Relation->Matches(Query))
        {
            // the specific binding is successful
			// bind Relation values to query variables
            Bindings.Add(CreateBinding(Relation, Query));
        }
    }

    // check all rules that could match Relation
    for (int RuleIndex=0; RuleIndex < Rules.GetLength(); RuleIndex++)
    {
        Rule = Rules.Get(RuleIndex);

        // check if the action matches
		if (Query->Matches(Rule->GetAction()))
        {
            // all bindings this rule delivers
			CRow<CFSBinding> RuleBindings;

            // initial binding
			// bind Query values to rule action variables
            RuleBindings.Add(CreateBinding(Query, Rule->GetAction()));	

            // check all conditions
            for (int ConditionIndex=0; ConditionIndex < Rule->GetConditionCount(); ConditionIndex++)
            {
				Condition = Rule->GetCondition(ConditionIndex);

#ifdef _TEST
				printf("condition: %s\n", Condition->ToString().GetBuffer());
#endif

                // The bindings that are created this condition
				CRow<CFSBinding> NewRuleBindings;
    
                // check all current bindings
                for (int BindingIndex = 0; BindingIndex < RuleBindings.GetLength(); BindingIndex++)
                {
					CFSRelation BoundRelation(Condition);

					// the condition is bound to the bound variables
					Bind(Condition, RuleBindings.Get(BindingIndex), BoundRelation);

#ifdef _TEST
					printf("binding: %s\n", BoundRelation.ToString().GetBuffer());
#endif

					// we try to find as many matches of this condition as possible
					FoundBindings = Match(&BoundRelation);

					// combine the variables that we bound earlier with the newly bound variables
					CombineBindings(RuleBindings.Get(BindingIndex), FoundBindings);

#ifdef _TEST
					for (int a=0; a < FoundBindings.GetLength(); a++) printf("%s\n", FoundBindings.Get(a).ToString().GetBuffer());
#endif

					// accumulate the bindings
					NewRuleBindings.Add(FoundBindings);
                }

				// replace old rule bindings
                RuleBindings = NewRuleBindings;
            }

            // the bindings that survive all conditions, are stored
			for (int BindingIndex=0; BindingIndex < RuleBindings.GetLength(); BindingIndex++)
			{
				Bindings.Add(BindBack(Query, Rule->GetAction(), RuleBindings.Get(BindingIndex)));
			}
        }
    }

	return Bindings;
}

void CFSModel::Add(CFSObjectType *NewObjectType)
{
	ObjectTypes.Add(NewObjectType);
	Frames.Add(NewObjectType);
}

void CFSModel::Add(CFSObject *NewObject)
{
	Objects.Add(NewObject);
	Frames.Add(NewObject);
}

void CFSModel::Add(CFSRelationType *NewRelationType)
{
	RelationTypes.Add(NewRelationType);
	Frames.Add(NewRelationType);
}

void CFSModel::Add(CFSRelation *NewRelation)
{
	Relations.Add(NewRelation);
	Frames.Add(NewRelation);
}

void CFSModel::Add(CFSRule *Rule)
{
	Rules.Add(Rule);
	Frames.Add(Rule);
}

/// Ask the model to find and return all relations that match Relation.
/// Relation may contain Variable objects.
CRow<CFSBinding> CFSModel::Ask(CFSRelation *Relation)
{
	CRow<CFSBinding> Bindings;

	Bindings = Match(Relation);

	return Bindings;
}

/// Ask the model if any relations exist that match Relation
bool CFSModel::AskExists(CFSRelation *Relation)
{
	return (!Ask(Relation).IsEmpty());
}

int CFSModel::AskCount(CFSRelation *Relation)
{
	return (Ask(Relation).GetLength());
}

const CFSObjectType *CFSModel::GetObjectTypeNumber(void)
{
	static CFSObjectType Number("Number");

	return &Number;
}

const CFSObjectType *CFSModel::GetObjectTypeVariable(void)
{
	static CFSObjectType Variable("Variable");

	return &Variable;
}

