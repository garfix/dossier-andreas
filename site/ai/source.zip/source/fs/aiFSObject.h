#ifndef _FSOBJECT
#define _FSOBJECT

#include "aiFSFrame.h"
#include "generic.h"

using namespace generic;

class CFSObjectType;

/// An object represents a thing in reality.

class CFSObject: public CFSFrame
{
public:
	CFSObject(const CText &NewName="");
};

/// Specific object: a floating point number

class CFSObjectNumber: public CFSObject
{
protected:
	float Number;

public:
	CFSObjectNumber(float Number);

	float GetFloat(void) const { return Number;  }
};

/// Specific object: a variable

class CFSObjectVariable: public CFSObject
{
public:
	CFSObjectVariable(const CText &NewName);
};

#endif