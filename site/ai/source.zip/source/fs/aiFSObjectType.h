#ifndef _FSOBJECTTYPE
#define _FSOBJECTTYPE

#include "aiFSType.h"
#include "generic.h"

using namespace generic;

/// An object type is a class of things, a collection of properties that are typical of a group.

class CFSObjectType: public CFSType
{
public:
	CFSObjectType(const CText &NewName);
};

#endif