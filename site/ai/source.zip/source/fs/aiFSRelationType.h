#ifndef _FSRELATIONTYPE
#define _FSRELATIONTYPE

#include "aiFSType.h"
#include "generic.h"

using namespace generic;

class CFSObjectType;

/// A relation type represents a group of relations, or the typical properties of a number of
/// relations.
/// A relation type desribes the roles objects may take in this relation type. For example:
/// the relation type 'has-child' may have the roles: 'parent' and 'child'.

class CFSRelationType: public CFSType
{
protected:
	CRow<CText> RoleNames;

public:
	CFSRelationType(const CText &NewName);

	void AddRole(const CText &NewName);

	int GetRoleCount(void) const { return RoleNames.GetLength(); }
	int GetRoleIndex(const CText &RoleName) const;
};

#endif