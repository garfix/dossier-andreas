#include "aiFSRule.h"
#include "aiFSRelation.h"
#include "aiFSModel.h"

CFSRule::CFSRule(CFSRelation *NewAction)
{
	Action = NewAction;

	SeekVariables(Action);
}

CFSRule::~CFSRule()
{
	Conditions.DeleteContents();
	delete Action;
}

/// Seeks all variables in Relation and stores them in Variables for easier lookup.
void CFSRule::SeekVariables(CFSRelation *Relation)
{
	CFSFrame *RoleValue;

	// check all roles of the relation
	for (int Index=0; Index < Relation->GetRoleValueCount(); Index++)
	{
		RoleValue = Relation->GetRoleValue(Index);

		// if the role is a variable and is not in the variable list, add it
		if (RoleValue->HasType(CFSModel::GetObjectTypeVariable()) && !Variables.Contains((CFSObjectVariable *)RoleValue))
		{
			Variables.Add((CFSObjectVariable *)RoleValue);
		}
	}
}

void CFSRule::AddCondition(CFSRelation *Condition)
{ 
	Conditions.Add(Condition);

	SeekVariables(Condition);
}
