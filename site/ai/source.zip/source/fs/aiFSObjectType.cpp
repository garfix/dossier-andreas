#include "aiFSObjectType.h"

CFSObjectType::CFSObjectType(const CText &NewName):
	CFSType(NewName)
{
}
