#ifndef _FSFRAME
#define _FSFRAME

#include "generic.h"

using namespace generic;

class CFSType;

/// A frame is the basic element in a frame system.
/// Anything is a frame.
/// A frame can be an instance of any number of types, and be a type itself.

class CFSFrame: public CElement
{
protected:
    CRow<const CFSType *> Types;

public:
	void AddType(const CFSType *NewType){ Types.Add(NewType); }
	bool HasType(const CFSType *NewType) const;

	virtual bool IsType(void) const { return false; }
	bool IsVariable(void) const;

	virtual const CText ToString(void) const;
};

#endif