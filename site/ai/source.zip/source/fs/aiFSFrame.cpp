#include "aiFSModel.h"

/// Checks if this frame has NewType as type or supertype
bool CFSFrame::HasType(const CFSType *NewType) const
{
	const CFSType *Type;

	for (int Index=0; Index < Types.GetLength(); Index++)
	{
		Type = Types.Get(Index);

		if ((Type == NewType) || (Type->HasType(NewType))) return true;
	}

	return false;
}

bool CFSFrame::IsVariable(void) const
{
	return (HasType(CFSModel::GetObjectTypeVariable()));
}

const CText CFSFrame::ToString(void) const
{
	return Name;
}
