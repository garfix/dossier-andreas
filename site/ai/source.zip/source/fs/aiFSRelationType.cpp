#include "aiFSRelationType.h"
#include "aiFSObjectType.h"

CFSRelationType::CFSRelationType(const CText &NewName):
	CFSType(NewName)
{
}

void CFSRelationType::AddRole(const CText &NewName)
{ 
	RoleNames.Add(NewName);
}

int CFSRelationType::GetRoleIndex(const CText &RoleName) const
{
	for (int Index=0; Index < RoleNames.GetLength(); Index++)
	{
		if (RoleNames.Get(Index) == RoleName) return Index;
	}

	return -1;
}
