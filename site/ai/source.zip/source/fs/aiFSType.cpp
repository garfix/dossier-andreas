#include "aiFSType.h"

CFSType::CFSType(const CText &NewName)
{
	Name = NewName;
}