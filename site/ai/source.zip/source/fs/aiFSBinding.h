#ifndef _FSBINDING
#define _FSBINDING

#include "aiFSFrame.h"
#include "generic.h"

using namespace generic;

class CFSObjectVariable;

/// A binding is a set of variables, each of which is bound to a value.

class CFSBinding: public CElement
{
	CRow<CFSObjectVariable *> Variables;
	CRow<CFSFrame *> Values;

public:
	void SetValue(CFSObjectVariable *Variable, CFSFrame* Value);
	CFSFrame*GetValue(CFSObjectVariable *Variable) const;
	void Add(CFSBinding &Binding);

	virtual const CText ToString(void) const;
};

#endif