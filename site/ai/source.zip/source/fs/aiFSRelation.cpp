#include "aiFSModel.h"
#include "aiFSRelationType.h"

CFSRelation::CFSRelation(CFSRelationType *NewRelationType, const CText &NewName)
{
	RelationType = NewRelationType;
	Name = NewName;
	Truth = true;

	Initialize();
}

CFSRelation::CFSRelation(CFSRelation *NewRelation)
{
	int RoleCount;

	RelationType = NewRelation->RelationType;
	Name = NewRelation->Name;
	Truth = NewRelation->Truth;

	RoleCount = RelationType->GetRoleCount();
	RoleValues.SetLength(RoleCount);
	for (int Index=0; Index < RoleCount; Index++) RoleValues.Set(Index, NewRelation->GetRoleValue(Index));
}

void CFSRelation::Initialize(void)
{
	int RoleCount;

	RoleCount = RelationType->GetRoleCount();
	RoleValues.SetLength(RoleCount);
	for (int Index=0; Index < RoleCount; Index++) RoleValues.Set(Index, 0);
}

void CFSRelation::SetRoleValue(const CText &RoleName, CFSFrame *RoleValue)
{
	int RoleIndex;

	RoleIndex = RelationType->GetRoleIndex(RoleName);

	// the role must have been defined before
	assert(RoleIndex != -1);

	RoleValues.Set(RoleIndex, RoleValue);
}

void CFSRelation::SetRoleValue(int Index, CFSFrame *RoleValue)
{
	RoleValues.Set(Index, RoleValue);
}

CFSFrame *CFSRelation::GetRoleValue(const CText &RoleName) const
{
	int RoleIndex;

	RoleIndex = RelationType->GetRoleIndex(RoleName);

	// the role must have been defined before
	assert(RoleIndex != -1);

	return RoleValues.Get(RoleIndex);
}

CFSFrame *CFSRelation::GetRoleValue(int Index) const
{
	return RoleValues.Get(Index);
}

int CFSRelation::GetRoleValueCount(void) const
{ 
	return RelationType->GetRoleCount(); 
}

/// Relation is an abstract template. If this relation is an instance of that Relation,
/// the match occurred.
bool CFSRelation::Matches(CFSRelation *Relation) const
{
	CFSFrame *MyRoleValue, *HisRoleValue;
	bool Match = true;

	if (RelationType != Relation->RelationType)
	{
		// the relation type (predicate) does not match, but perhaps our predicate is a specification?
		if (!RelationType->HasType(Relation->RelationType))
		{
			// it's not
			return false;
		}
	}
	if (Truth != Relation->Truth) return false;

	for (int Index=0; Index < RelationType->GetRoleCount(); Index++)
	{
		HisRoleValue = Relation->GetRoleValue(Index);

		// if the role contains a variable, it always matches
		if (HisRoleValue->HasType(CFSModel::GetObjectTypeVariable())) continue;

		MyRoleValue = RoleValues.Get(Index);

		// values are identical
		if (HisRoleValue == MyRoleValue) continue;

		// check if this value is a type of the requested value
		if (!MyRoleValue->IsType() || !HisRoleValue->HasType((CFSType *)MyRoleValue))
		{
			// no its not
			Match = false;
			break;
		}
	}

	return Match;
}

bool CFSRelation::IsBound(void) const
{
	for (int Index=0; Index < GetRoleValueCount(); Index++)
	{
		if (RoleValues.Get(Index)->IsVariable()) return false;
	}
	return true;
}

const CText CFSRelation::ToString(void) const
{
	CText String;
	int RoleValueCount;

	RoleValueCount = GetRoleValueCount();

	if (!Truth) String += "NOT ";
	String += RelationType->GetName();
	String += "(";
	for(int Index=0; Index < RoleValueCount; Index++)
	{
		String += RoleValues.Get(Index)->ToString();
		if (Index < RoleValueCount-1) String += ", ";
	}
	String +=")";

	return String;
}

