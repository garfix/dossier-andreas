#include <assert.h>
#include "aiFSBinding.h"
#include "aiFSObject.h"

void CFSBinding::SetValue(CFSObjectVariable *Variable, CFSFrame* Value)
{
	for (int Index=0; Index < Variables.GetLength(); Index++)
	{
		if (Variables.Get(Index) == Variable) 
		{
			Values.Set(Index, Value);
			return;
		}
	}

	// variable not available yet
	Variables.Add(Variable);
	Values.Add(Value);
}

CFSFrame*CFSBinding::GetValue(CFSObjectVariable *Variable) const
{
	for (int Index=0; Index < Variables.GetLength(); Index++)
	{
		if (Variables.Get(Index) == Variable) 
		{
			return Values.Get(Index);
		}
	}

	return 0;
}

void CFSBinding::Add(CFSBinding &Binding)
{
	Variables.Add(Binding.Variables);
	Values.Add(Binding.Values);
}

const CText CFSBinding::ToString(void) const
{
	CText String;

	String += "{\n";

	for (int Index=0; Index < Variables.GetLength(); Index++)
	{
		String += "\t" + Variables.Get(Index)->ToString();
		String += "=";
		String += Values.Get(Index)->ToString();
		String += "\n";
	}

	String += "}\n";

	return String;
}

