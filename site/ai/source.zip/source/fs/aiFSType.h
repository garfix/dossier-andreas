#ifndef _FSTYPE
#define _FSTYPE

#include "aiFSFrame.h"
#include "generic.h"

using namespace generic;

/// A type describes a group of either objects or relations.

class CFSType: public CFSFrame
{
public:
	CFSType(const CText &NewName="");

	virtual bool IsType(void) const { return true; }
};

#endif