#include "aiFSModel.h"

CFSObject::CFSObject(const CText &NewName)
{
	Name = NewName;
}

CFSObjectNumber::CFSObjectNumber(float NewNumber):
	CFSObject()
{
	AddType(CFSModel::GetObjectTypeNumber());
	Number = NewNumber;
}

CFSObjectVariable::CFSObjectVariable(const CText &NewName):
	CFSObject()
{
	AddType(CFSModel::GetObjectTypeVariable());
	Name = NewName;
}
