#ifndef _FSRULE
#define _FSRULE

#include "aiFSFrame.h"
#include "generic.h"

using namespace generic;

class CFSRelation;
class CFSObjectVariable;

/// A rule contains any number of conditions and a single action.
/// An action says what relation should be added to the model.

class CFSRule: public CFSFrame
{
protected:
	CRow<CFSRelation *> Conditions;
	CRow<CFSObjectVariable *> Variables;
	CFSRelation * Action;

	void SeekVariables(CFSRelation *Relation);

public:
	CFSRule(CFSRelation *NewAction);
	~CFSRule();

	void AddCondition(CFSRelation *Condition);

	// queries
	CFSRelation* GetAction(void) const { return Action; }

	int GetConditionCount(void) const { return Conditions.GetLength(); }
	CFSRelation *GetCondition(int Index) const { return Conditions.Get(Index); }

	int GetVariableCount(void) const { return Variables.GetLength(); }
};

#endif