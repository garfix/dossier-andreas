#ifndef _FSMODEL
#define _FSMODEL

#include "generic.h"

using namespace generic;

/// The model implements a frame system, extended by production rules.
/// The system borrows from a number of other systems, but does not implement
/// any of these systems completely.
/// It borrows from Frame Systems, Semantic Nets, Prolog and SOAR, 

/// The model contains objects and relations. These represent the arguments and predicates of
/// first order logic. They are concrete.

/// The model also contains object types and relation types. They are abstract and describe
/// classes of resp. objects and relations.

/// The model also contains rules. These are logical inferences, like the Horn
/// clauses of Prolog. The production rules are activated when the model is asked a question.
/// At that time the appropriate production rules are fired to answer the query. The productions
/// of the rules (new relations and objects) remain present in the model. This way future
/// questions can be answered more quickly.

/// Queries:
/// If relations are available that deal with types of classes, they are applied to the instances,
/// and subtypes (dog -> mammal).
/// If specific predicates are available, they are applied automatically (flies -> goes).

#include "aiFSObject.h"
#include "aiFSObjectType.h"
#include "aiFSRelation.h"
#include "aiFSRelationType.h"
#include "aiFSRule.h"
#include "aiFSBinding.h"

class CFSFrame;

class CFSModel
{
protected:
    CRow<CFSFrame *> Frames;
    CRow<CFSObject *> Objects;
    CRow<CFSObjectType *> ObjectTypes;
    CRow<CFSRelation *> Relations;
    CRow<CFSRelationType *> RelationTypes;
	CRow<CFSRule *> Rules;

	CFSBinding CreateBinding(CFSRelation *Query, CFSRelation *Answer);
	CFSBinding BindBack(CFSRelation *Original, CFSRelation *Action, CFSBinding &Binding);
	void Bind(CFSRelation *Relation, CFSBinding &Binding, CFSRelation &BoundRelation);
	void CombineBindings(CFSBinding &ExistingBinding, CRow<CFSBinding> &NewBindings);
	CRow<CFSBinding> Match(CFSRelation *Query);

public:
	CFSModel();
	~CFSModel();

	// structure
	void Add(CFSObjectType *NewObjectType);
	void Add(CFSObject *NewObject);
	void Add(CFSRelationType *NewRelationType);
	void Add(CFSRelation *NewRelation);
	void Add(CFSRule *Rule);

	// queries
	CRow<CFSBinding> Ask(CFSRelation *Relation);
	bool AskExists(CFSRelation *Relation);
	int AskCount(CFSRelation *Relation);

	static const CFSObjectType *GetObjectTypeNumber(void);
	static const CFSObjectType *GetObjectTypeVariable(void);
};

#endif