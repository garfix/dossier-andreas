#ifndef _PAIREDROW
#define _PAIREDROW

#include "genericRow.h"

namespace generic
{

template <class TYPE1, class TYPE2>
class CPairedRow
{
protected:
	CRow<TYPE1> Firsts;
	CRow<TYPE2> Seconds;

public:
	void Add(const TYPE1 &First, const TYPE2 &Second)
	{
		Firsts.Add(First);
		Seconds.Add(Second);
	}

	TYPE2 &GetSecond(const TYPE1 &First, bool &Found) const
	{
		static TYPE2 Dummy;
		for (int i=0; i < Firsts.GetLength(); i++)
		{
			if (Firsts.Get(i) == First)
			{
				Found = true;
				return Seconds.Get(i);
			}
		}
		Found = false;
		return Dummy;
	}

	void RemoveFromFirst(const TYPE1 &First)
	{
		int Index = Firsts.GetIndex(First);
        
		if (Index != -1)
		{
			Firsts.RemoveAt(Index);
			Seconds.RemoveAt(Index);
		}
	}

	void RemoveFromSecond(const TYPE2 &Second)
	{
		int Index = Seconds.GetIndex(Second);
        
		if (Index != -1)
		{
			Firsts.RemoveAt(Index);
			Seconds.RemoveAt(Index);
		}
	}

	int GetLength(void) const { return Firsts.GetLength(); }

	TYPE1 GetFirst(int Index) const { return Firsts.Get(Index); }

	TYPE2 GetSecond(int Index) const { return Seconds.Get(Index); }

	int GetIndexFirst(const TYPE1 &First) const { return Firsts.GetIndex(First); }
	int GetIndexSecond(const TYPE2 &Second) const { return Seconds.GetIndex(Second); }

	void DeleteContentsFirsts(void){ Firsts.DeleteContents(); }
	void DeleteContentsSeconds(void){ Seconds.DeleteContents(); }
};

}

#endif
