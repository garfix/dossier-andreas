#ifndef _CRITICALSECTION
#define _CRITICALSECTION

#include "genericElement.h"

namespace generic
{

/// A critical section provides a mutex lock for a single process.
/// Create your thread-safe code within a Lock() <your_code> Unlock() pair. If a second
/// thread reaches this code, it waits until the first thread is done executing the code.
/// see also http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dllproc/base/critical_section_objects.asp

class CCriticalSection: public CElement
{
protected:
	void *CriticalSection;

public:
	CCriticalSection();
	virtual ~CCriticalSection();

	void Lock(void);
	void Unlock(void);
};

}

#endif
