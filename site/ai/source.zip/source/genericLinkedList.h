#ifndef _LINKEDLIST
#define _LINKEDLIST

#include "genericListNode.h"

namespace generic
{
	
template <class TYPE>
class CLinkedList
{
protected:
	CListNode<TYPE> Start;
	CListNode<TYPE> End;

public:
	CLinkedList(): Start(), End()
	{
		Start.Next = &End;
		End.Previous = &Start;
	}

	~CLinkedList()
	{
		Clear();
	}

	void Clear(void)
	{
		CListNode<TYPE> *Node, *OldNode;

		Node = Start.Next;
		while (Node != &End) 
		{
			OldNode = Node;
			Node = Node->Next;
			delete OldNode;
		}
		Start.Next = &End;
		End.Previous = &Start;
	}

	bool IsEmpty(void) const { return (Start.Next == &End); }

	CListNode<TYPE> *GetFirst(void) const
	{
		return Start.Next;
	}

	CListNode<TYPE> *GetLast(void) const
	{
		return End.Previous;
	}

	const CListNode<TYPE> *GetEnd(void) const
	{
		return &End;
	}

	void Add(const TYPE &NewValue)
	{
		CListNode<TYPE> *NewNode = new CListNode<TYPE>(NewValue);
		NewNode->Next = &End;
		NewNode->Previous = End.Previous;
		End.Previous->Next = NewNode;
		End.Previous = NewNode;
	}

	void AddToFront(const TYPE &NewValue)
	{
		CListNode<TYPE> *NewNode = new CListNode<TYPE>(NewValue);
		NewNode->Next = Start.Next;
		NewNode->Previous = &Start;
		Start.Next->Previous = NewNode;
		Start.Next = NewNode;
	}

	void Remove(CListNode<TYPE> *Node)
	{
		Node->Previous->Next = Node->Next;
		Node->Next->Previous = Node->Previous;
        delete Node;
	}

	TYPE RemoveFirst(void)
	{
		CListNode<TYPE> *First = GetFirst();
		TYPE Value = First->GetValue();
		Remove(First);
		return Value;
	}

	void InsertBefore(const TYPE &NewValue, CListNode<TYPE> *OldNode)
	{
		CListNode<TYPE> *NewNode = new CListNode<TYPE>(NewValue);
		NewNode->Next = OldNode;
		NewNode->Previous = OldNode->Previous;
		OldNode->Previous->Next = NewNode;
		OldNode->Previous = NewNode;
	}

	/// Calls the destructor on all values.
	void DeleteContents(void)
	{
		CListNode<TYPE> *Node;

		Node = Start.Next;
		while (Node != &End) 
		{
			delete Node->Value;
			Node = Node->Next;
		}
	}
};

}

#endif