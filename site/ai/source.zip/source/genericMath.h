#ifndef _MATH
#define _MATH

#include <math.h>

namespace generic
{

class CMath
{

public:
	static int GetRandomInt(int Min, int Max);
	static float GetRandomFloat(float Min, float Max);
	static bool GetRandomBool(void);

	static int Max(int a, int b){ return (a > b ? a : b); }
	static int Min(int a, int b){ return (a < b ? a : b); }
	static float Max(float a, float b){ return (a > b ? a : b); }
	static float Min(float a, float b){ return (a < b ? a : b); }
	static int Abs(int a){ return (a > 0 ? a : -a); }
	static float Abs(float a){ return (a > 0 ? a : -a); }
	static float LogN(float n, float a){ return (float)(log(a) / log(n)); }

	static double GetGaussianProbability(double Mean, double SD, double Value);
	static double GetInverseGaussianProbability(double Mean, double SD, double Value);
};

}

#endif