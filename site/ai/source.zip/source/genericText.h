#ifndef _STRING
#define _STRING

/// CText is a combination of a Java String and a StringBuffer.
/// Its Length holds the total capacity of characters in its array.
/// Its End index serves as a pointer just after the last useful character.
/// The main purpose of End is to be able to concatenate strings without
/// heavy heap allocation functions.

namespace generic
{

class CText
{
protected:
	int Capacity;
	char *CharArray;
	int Length;

	void Init(const char *NewCharArray, int NewCapacity);
	void Append(const CText &NewString);

public:
	CText();
	CText(const CText &NewString);
	CText(const CText &NewString, int Count);
	CText(const char *NewCharArray);
	CText(const char NewChar);
	CText(int NewInteger);
	CText(unsigned int NewInteger);
	CText(float NewFloat);
	~CText();

	void Allocate(int NewCapacity);
	int GetCapacity(void) const { return Capacity; }

	void Clear(void);
	void SetLength(int NewLength);
	int GetLength() const { return Length; }
	
	const CText &operator=(const CText &NewString);
	const CText &operator=(const char *NewCharArray);

	char *GetBuffer(void) const { return CharArray; };
	void Set(int Index, char Char);
	char Get(int Index) const;
	bool Contains(char Char) const;
	bool Contains(const CText &String) const;
	CText ToUppercase(void) const;
	CText ToLowercase(void) const;
	int ToInteger(void) const;
	static int CreateHashCode(const CText &String);
	int GetIndex(char Char, int StartAt=0) const;
	int GetIndex(const CText &Substring, int Start=0) const;
	int GetLastIndex(char Char, int StartAt=-1) const;
	int GetLastIndex(const CText &Substring, int StartAt=-1) const;
	CText Substring(int Start, int End) const;
	CText SubstringUpToFirst(char c) const;
	CText SubstringFromFirst(char c) const;
	CText SubstringUpToLast(char c) const;
	CText SubstringFromLast(char c) const;
	CText SubstringUpToFirst(const CText &String) const;
	CText SubstringFromFirst(const CText &String) const;
	CText SubstringUpToLast(const CText &String) const;
	CText SubstringFromLast(const CText &String) const;
	CText Replace(char OldChar, char NewChar) const;
	CText Replace(const CText &OldSubstring, const CText &NewSubstring) const;

	void operator+=(const CText &NewString);
	void operator+=(const char *NewCharArray);
	void operator+=(char NewChar);
	void operator+=(int NewInteger);
	void operator+=(float NewFloat);
	bool operator==(const CText &NewString) const;
	bool operator==(const char *NewCharArray) const;
	bool operator!=(const CText &NewString) const;
	bool operator!=(const char *NewCharArray) const;
	operator const char*( ) const;

	friend CText operator+(const CText &NewString1, const CText &NewString2);
	friend CText operator+(const char *NewCharArray, const CText &NewString);
	friend CText operator+(const CText &NewString1, int NewInteger);
	friend CText operator+(const CText &NewString1, unsigned int NewInteger);
	friend CText operator+(const CText &NewString1, float NewFloat);

	virtual int GetHashCode(void) const;
};

}

#endif