#include "aiFSMSignal.h"
#include "aiFSMState.h"

CFSMSignal::CFSMSignal(): Id(-1)
{ 
}
