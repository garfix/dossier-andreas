#include "aiFSMModel.h"
#include "Windows.h"
#include "WinApp.h"

CFSMModel::CFSMModel()
{
	// create the default root state
	Root = new CFSMState(this);
	Root->SetName("<root>");

	// create the moment field
	CurrentMoment = new CMoment();

	// reset the id generator for signals
	SignalIdGenerator = 0;

	// Update strategy
	Strategy = FSMMODELSTRATEGY_CYCLE;
}

CFSMModel::~CFSMModel()
{
	// if the model wasn't stopped; do it now
	Stop();

	SignalObservers.DeleteContents();
	Signals.DeleteContents();
	delete Root;
	delete CurrentMoment;
}

/// A transition would use this function to tell the model to observe Signal and to
/// fire Transition when Signal is sent.
void CFSMModel::AddSignalObserver(CFSMTransition *Transition, CFSMSignal *Signal)
{
	int TransitionLevel;
	int SignalId;

	TransitionLevel = Transition->GetLevel();
	SignalId = Signal->GetId();

	SignalObservers.Get(SignalId)->Add(Transition);
}

/// Tell the model to stop observing Signal.
void CFSMModel::RemoveSignalObserver(CFSMTransition *Transition, CFSMSignal *Signal)
{
	int TransitionLevel;
	int SignalId;

	TransitionLevel = Transition->GetLevel();
	SignalId = Signal->GetId();

	SignalObservers.Get(SignalId)->Remove(Transition);
}

/// Tell the model to fire Transition after Transition->SecondsInState seconds.
void CFSMModel::ScheduleDelayedTransition(CFSMTimeTransition *Transition)
{
	DelayedTransitions.Add(Transition, GetCurrentUpdateTime());
}

/// Undo ScheduleDelayedTransition
void CFSMModel::UnscheduleDelayedTransition(CFSMTimeTransition *Transition)
{
	DelayedTransitions.RemoveFromFirst(Transition);
}

/// Tell the model to fire Transition next cycle.
void CFSMModel::ScheduleAutomaticTransition(CFSMTransition *Transition)
{
	CurrentAutomaticTransitions.Add(Transition);
}

/// Undo ScheduleAutomaticTransition.
void CFSMModel::UnscheduleAutomaticTransition(CFSMTransition *Transition)
{
	CurrentAutomaticTransitions.Remove(Transition);
}

/// Tell the model to fire Transition at Transition->Moment or a.s.a.p. thereafter
void CFSMModel::ScheduleMomentTransition(CFSMMomentTransition *Transition)
{
	MomentTransitions.Add(Transition);
}

/// Undo ScheduleMomentTransiton
void CFSMModel::UnscheduleMomentTransition(CFSMMomentTransition *Transition)
{
	MomentTransitions.Remove(Transition);
}

/// Processes all incoming signals and find the transitions that are were observing these signals.
/// These transitions are then inserted into FireableTransitions.
void CFSMModel::ProcessSignals(CRow<CFSMTransition *> &FireableTransitions)
{
	CFSMSignal *Signal;
	CFSMTransition *Transition;

	// process all signals in order of arrival
	for (int SignalIndex=0; SignalIndex < CurrentSignals.GetLength(); SignalIndex++)
	{
		// look up all observers
		Signal = CurrentSignals.Get(SignalIndex);
		CRow<CFSMTransition *> *Transitions = SignalObservers.Get(Signal->GetId());

		// process transitions from last to first, because transitions will be removed from this
		// list during this loop
		// NOTE: no longer necessary, since DeactivateAllSourceStateExitTransitions is not executed
		for (int TransitionIndex=Transitions->GetLength()-1; TransitionIndex >= 0; TransitionIndex--)
		{
			Transition = Transitions->Get(TransitionIndex);
			
			// prepare the transiton to be fired
			AddFireableTransition(FireableTransitions, Transition);
		}
	}
}

/// Insert all transitions CurrentAutomaticTransitions into FireableTransitions.
void CFSMModel::ProcessAutomaticTransitions(CRow<CFSMTransition *> &FireableTransitions)
{
	for (int Index=0; Index < CurrentAutomaticTransitions.GetLength(); Index++)
	{
		// prepare the transiton to be fired
		AddFireableTransition(FireableTransitions, CurrentAutomaticTransitions.Get(Index));
	}
}

/// All time transitions are checked. If they are active for SecondsInState seconds, they are 
/// inserted into FireableTransitions.
void CFSMModel::ProcessTimers(CRow<CFSMTransition *> &FireableTransitions)
{
	CFSMTimeTransition *TimeTransition;
	float StartTime;

	for (int Index=0; Index < DelayedTransitions.GetLength(); Index++)
	{
		TimeTransition = DelayedTransitions.GetFirst(Index);
		StartTime = DelayedTransitions.GetSecond(Index);
		if (GetCurrentUpdateTime() >= StartTime + TimeTransition->GetSecondsInState())
		{
			// prepare to fire
			AddFireableTransition(FireableTransitions, TimeTransition);
		}
	}
}

/// All moment transitions are checked. If a moment has passed, the transition is
/// inserted into FireableTransitions.
void CFSMModel::ProcessMomentTransitions(CRow<CFSMTransition *> &FireableTransitions)
{
	CFSMMomentTransition *MomentTransition;

	for (int Index=0; Index < MomentTransitions.GetLength(); Index++)
	{
		MomentTransition = MomentTransitions.Get(Index);
		if (*GetCurrentMoment() >= MomentTransition->GetMoment())
		{
			// prepare to fire
			AddFireableTransition(FireableTransitions, MomentTransition);
		}
	}
}

/// The new transition is added to the list of transitions that are about to be fired.
/// The list is ordered by level. Transitions with lower levels are fired first.
/// Transitions in the same level are ordered by priority. Transitions with higher priority are fired
/// first.
void CFSMModel::AddFireableTransition(CRow<CFSMTransition *> &FireableTransitions, CFSMTransition *NewTransition)
{
	int Index;
	int Count = FireableTransitions.GetLength();
	int NewLevel = NewTransition->GetLevel();
	int Level;
	CFSMTransition *Transition;

	// FireableTransitions are ordered first by increasing level and secondly, by decreasing priority
	Index = 0;
	while (Index < Count)
	{
		Transition = FireableTransitions.Get(Index);
		Level = Transition->GetLevel();
		if (
			// if the new transition has a lower level than the indexed transition
			(NewLevel < Level) ||
			// or it has the same level, but a higher priority
			(
				(NewLevel == Level) &&
				(NewTransition->GetPriority() > Transition->GetPriority())
			)
		)
		{
			// this is the right place to insert the new transition
			FireableTransitions.InsertAt(Index, NewTransition, true);
			return;
		}
		Index++;
	}
	// apparently no lower level could be found: we add the new one in the back
	FireableTransitions.Add(NewTransition);
}

/// Fires the transitions in FireableTransitions. Firing a transition may deactivate
/// transitions further on in the array; these will not be fired.
void CFSMModel::FireTransitions(CRow<CFSMTransition *> &FireableTransitions)
{
	CFSMTransition *Transition;

	for (int Index=0; Index < FireableTransitions.GetLength(); Index++)
	{
		Transition = FireableTransitions.Get(Index);

		// since earlier transitions may deactivate later transitions in this array,
		// check if the transition is still active
		if (Transition->AreAllSourceStatesActivate()) Transition->Execute();
	}
}

/// Checks all active transitions.
void CFSMModel::Cycle(void)
{
	CRow<CFSMTransition *> FireableTransitions;

	LOG_DEBUG("--> update");

	// determine the time of the update

	this->CurrentUpdateTime = (float)clock() / CLOCKS_PER_SEC;

	// set the moment of the update
	*(this->CurrentMoment) = CMoment::Now();

	// check all moment transitions to see if their moment has lapsed
	ProcessMomentTransitions(FireableTransitions);

	// make all automatic transitions fireable
	ProcessAutomaticTransitions(FireableTransitions);

	// check all time transitions to see if they have timed out
	ProcessTimers(FireableTransitions);

	// process all pending signals; returns an array of fireable transitions
	ProcessSignals(FireableTransitions);

	// destroy signals
	CurrentSignals.Clear();

	// fire these transitions; this:
	// - broadcasts new signals;
	// - starts/stops timers
	// - adds automatic transitions to the list AutomaticTransitions
	FireTransitions(FireableTransitions);

	// save update time for next update
	this->PreviousUpdateTime = this->CurrentUpdateTime;
}

// this function predicts if at least one active transition will fire before Time
bool CFSMModel::WillTransitionsFireBefore(float Time)
{
	CFSMTimeTransition *TimeTransition;
	float StartTime;

	// automatic transitions always fire
	if (!CurrentAutomaticTransitions.IsEmpty()) return true;
	// if there are any signals, they may cause transitions to fire
	if (!CurrentSignals.IsEmpty()) return true;

	// if Time is later than the time of the delayed transitions, it's worth waiting for
	for (int Index=0; Index < DelayedTransitions.GetLength(); Index++)
	{
		TimeTransition = DelayedTransitions.GetFirst(Index);
		StartTime = DelayedTransitions.GetSecond(Index);
		if (Time > StartTime + TimeTransition->GetSecondsInState())
		{
			return true;
		}
	}
	return false;
}

/// Returns state by path. 
/// An absolute path is a string describing a state embedded in its substate.
/// Examples: rootstate: "/"
/// A substate of root: "/main"
/// A substate of main: "/main/inactive"
CFSMState *CFSMModel::GetState(const CText &AbsolutePath) const
{
	CText RelativePath;
	
	if (AbsolutePath == "") 
	{
		LOG_ERROR("CFSMModel::GetState: Empty absolute path name.");
		return 0;
	}

	if (AbsolutePath.Get(0) == '/')
	{
		RelativePath = AbsolutePath.Substring(1, AbsolutePath.GetLength()-1);
		return Root->GetSubState(RelativePath);
	}

	return 0;
}

/// Adds signal to this model; the signal will be deleted when the model is deleted.
/// \return The the signal
CFSMSignal *CFSMModel::AddSignal(const CText &SignalName, CFSMSignal *NewSignal)
{
	int NewId = SignalIdGenerator;

	// sanity check: has the signal been added to a model before?
	if (NewSignal->GetId() != -1) 
	{
		LOG_ERROR("CFSMModel::AddSignal: State has been added to the model before: " + NewSignal->ToString());
		return NewSignal;
	}

	// give the signal a unique identifier; also serves as index in the incoming/outgoing arrays
	NewSignal->SetId(NewId);
	NewSignal->SetName(SignalName);

	// add to list
	Signals.Add(NewSignal);

	// add a new array of observers for the new signal
	SignalObservers.Add(new CRow<CFSMTransition *>());

	// prepare signal id generator for next time
	SignalIdGenerator++;

	return NewSignal;
}

/// A simple signal by the name of SignalName is added to the model.
/// \return The signal
CFSMSignal *CFSMModel::AddSignal(const CText &SignalName)
{
	return AddSignal(SignalName, new CFSMSignal());
}

/// Performs some initializations, and activates the Initial State
void CFSMModel::Start(void)
{
	// reset time
	CurrentUpdateTime = PreviousUpdateTime = StartTime = (float)clock() / CLOCKS_PER_SEC;

	// set substate levels
	Root->SetLevelsRecursively(0);

	// activate root state
	Root->Activate();
}

/// Deactivates all states of the model
void CFSMModel::Stop(void)
{
	// deactivate all states (calls exit code)
	if (Root->IsActive()) Root->Deactivate();

	// thorough cleanup of ALL states
	Root->CleanUp();

	// remove incoming signals
	CurrentSignals.Clear();
}

/// Performs an update strategy on the model.
void CFSMModel::Update(void)
{
	float TimeFrameStart;
	float Time, TimePassed, TimeLeft;
	bool TransitionsWillFire;

	switch (Strategy)
	{
	case FSMMODELSTRATEGY_CYCLE:
		// check (and fire) all transitions
		Cycle();
		break;
	case FSMMODELSTRATEGY_TIMEFRAME_KEEP_CYCLING:
		TimeFrameStart = (float)clock() / CLOCKS_PER_SEC;
		LOG_DEBUG("--> time frame");
		do 
		{
			// check and fire all transitions
			Cycle();
			// calculate duration in this time frame
			Time = (float)clock() / CLOCKS_PER_SEC;
			TimePassed = Time - TimeFrameStart;
			TimeLeft = this->TimeFrameDuration - TimePassed;
		}
		while (TimeLeft > 0);
		break;
	case FSMMODELSTRATEGY_TIMEFRAME_CYCLE_WHILE_USEFUL:
		TimeFrameStart = (float)clock() / CLOCKS_PER_SEC;
		LOG_DEBUG("--> time frame");
		do
		{
			// check and fire all transitions
			Cycle();
			// calculate duration in this time frame
			Time = (float)clock() / CLOCKS_PER_SEC;
			TimePassed = Time - TimeFrameStart;
			TimeLeft = this->TimeFrameDuration - TimePassed;
			// are any transitions likely to fire this time-frame
			TransitionsWillFire = WillTransitionsFireBefore(TimeFrameStart + this->TimeFrameDuration);
		}
		while (TransitionsWillFire && (TimeLeft > 0));
		break;
	case FSMMODELSTRATEGY_TIMEFRAME_CYCLE_AND_BURN:
		TimeFrameStart = (float)clock() / CLOCKS_PER_SEC;
		LOG_DEBUG("--> time frame");
		do
		{
			// check and fire all transitions
			Cycle();
			// calculate duration in this time frame
			Time = (float)clock() / CLOCKS_PER_SEC;
			TimePassed = Time - TimeFrameStart;
			TimeLeft = this->TimeFrameDuration - TimePassed;
			// are any transitions likely to fire this time-frame
			TransitionsWillFire = WillTransitionsFireBefore(TimeFrameStart + this->TimeFrameDuration);
		}
		while (TransitionsWillFire && (TimeLeft > 0));
		// "burn" the rest of the time frame
		if (TimeLeft > 0)
		{
			Sleep ((DWORD)(TimeLeft * 1000.0f));
		}
		break;
	}
}

/// The model is finished if the Root state is finished.
/// A state is finished when at least one of its final children is active.
bool CFSMModel::IsFinished(void) const
{
	return Root->IsFinished();
}

/// The full procedure: Start, Update until finished, Stop.
void CFSMModel::Run(void)
{
	Start();
	while (!IsFinished()) Update();
	Stop();
}

/// Tell the FSM to broadcast a Signal to all states in the FSM.
/// This method is thread-safe, it may be used from different threads.
void CFSMModel::BroadcastSignal(CFSMSignal *Signal)
{
    CriticalSectionBroadcastSignal.Lock();
	{
		LOG_INFO("Broadcast:\t" + Signal->GetName());

		// signal will be processed in the next Update()
		CurrentSignals.Add(Signal);
	}
    CriticalSectionBroadcastSignal.Unlock();
}

const CText CFSMModel::ToString(void) const
{
	return Root->ToString(0);
}
