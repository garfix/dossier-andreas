#include "aiFSMState.h"
#include "aiFSMSignal.h"
#include "aiFSMModel.h"
#include "aiFSMSpecialTransitions.h"
#include "WinApp.h"

CFSMState::CFSMState(CFSMModel *NewModel)
{
	Model = NewModel;
	Initialize();
}

CFSMState::~CFSMState()
{
	CFSMTransition *Transition;

	// delete all transitions of which you are the first source state
	for (int Index=0; Index < ExitTransitions.GetLength(); Index++)
	{
		Transition = ExitTransitions.Get(Index);
		if (Transition->GetSourceState(0) == this) delete Transition;
	}

	// delete substates
	SubStates.DeleteContents();
}

void CFSMState::Initialize(void)
{
	Level = 0;
    SuperState = 0;
	Active = false;
	Final = false;
	History = false;
	HistoryStored = false;
	ActiveBefore = false;
	Initial = false;
	AccumulatedSecondsActive = 0;
}

/// Activates or deactivates the state.
/// If the state is activated, its StartTimeActive is saved
/// If the state is deactivated, its AccumulatedSecondsActive is increased by the time it was active.
void CFSMState::SetActive(bool NewActive)
{ 
	float CurrentTimeActive;
	
	if (!Active && NewActive)
	{
		// activation: start keeping track of time
		StartTimeActive = Model->GetCurrentUpdateTime();
	}
	else if (Active && !NewActive)
	{
		// deactivation: stop keeping track of time
		CurrentTimeActive = Model->GetCurrentUpdateTime();
		AccumulatedSecondsActive += (CurrentTimeActive - StartTimeActive);
	}
	Active = NewActive;
}

/// returns the time this state is active since its last activation
/// it is not defined if the state is inactive, so don't call it then
float CFSMState::GetSecondsActive(void) const
{
	float CurrentTimeActive = Model->GetCurrentUpdateTime();
	if (!Active) LOG_ERROR("CFSMState::GetSecondsActive: '" + this->ToString() +"' is not active.");
	return CurrentTimeActive - StartTimeActive;
}

/// returns the time this state has been active since CFSMModel::Start()
float CFSMState::GetTotalSecondsActive(void) const
{
	float Time = AccumulatedSecondsActive;
	if (Active) Time += GetSecondsActive();
	return Time;
}

/// Cleans up state and substates (mainly history and active time)
void CFSMState::CleanUp(void)
{
	CFSMState *SubState;

	Active = false;
	AccumulatedSecondsActive = 0.0f;
	HistoryStored = false;
	ActiveBefore = false;

	for (int Index=0; Index < SubStates.GetLength(); Index++)
	{
		SubState = SubStates.Get(Index);
		SubState->CleanUp();
	}
}

/// This code is _only_ executed when a intermediate state is entered on a transition.
/// It is part of the activation code if a real target state is entered.
void CFSMState::ActivateCommon(void)
{
	// the state is now active
	SetActive(true);

	// activate all exit-transitions
	ActivateExitTransitions();

	// execute its entry code
	LOG_INFO("Enter: \t" + this->ToString());
	Enter();
}

/// Activates State, and all substates.
void CFSMState::Activate(void)
{
	CFSMState *SubState;

	ActivateCommon();

	// if the state has history and the activity pattern has been stored before
	// (the state has been deactivated before)
	if (HasHistory() && HistoryHasBeenStored())
	{
		// activate the substates that were active last time this state was active
		for (int Index=0; Index < SubStates.GetLength(); Index++)
		{
			SubState = SubStates.Get(Index);
			if (SubState->WasActiveBefore()) SubState->Activate();
		}
	}
	else
	{
		// activate initial substates
		for (int Index=0; Index < SubStates.GetLength(); Index++)
		{
			SubState = SubStates.Get(Index);
			if (SubState->IsInitial()) SubState->Activate();
		}
	}
}

/// Deactivates the state, and all its substates. If a substate is active,
/// its exit code is called. Exit code of lower states is called before
/// that of higher states.
void CFSMState::Deactivate(void)
{
	CFSMState *SubState;

	// if the state has history, store the activity pattern of all substates
	if (HasHistory())
	{
		// store the activity pattern of all substates
		for (int Index=0; Index < SubStates.GetLength(); Index++)
		{
			SubState = SubStates.Get(Index);
			SubState->SetActiveBefore(SubState->IsActive());
		}

		// note that the activity pattern has been stored (for a later activation)
		SetHistoryStored(true);
	}

	for (int Index=0; Index < SubStates.GetLength(); Index++)
	{
		SubState = SubStates.Get(Index);

		if (SubState->IsActive())
		{
			// first deactivate the children of the substate
			SubState->Deactivate();
		}
	}

	// execute exit code
	LOG_INFO("Exit:  \t" + this->ToString());
	Exit();

	// deactivate all exit-transitions
	DeactivateExitTransitions();

	// the state is now inactive
	SetActive(false);
}

/// Sets the level of this state to NewLevel. NewLevel is equal to the number of superstates this
/// state has. This number could be easily calculated at runtime, but it would mean some time-overhead.
/// To avoid this, the level is stored as a class-member.
/// This function also sets the level of the substates, recusively.
void CFSMState::SetLevelsRecursively(int NewLevel)
{
	Level = NewLevel;
	for (int Index=0; Index < SubStates.GetLength(); Index++)
		SubStates.Get(Index)->SetLevelsRecursively(NewLevel+1);
}

/// Checks all transitions that start in this state. If all their source states are active,
/// the transition is activated.
void CFSMState::ActivateExitTransitions(void)
{
	CFSMTransition *Transition;
	for (int Index=0; Index < ExitTransitions.GetLength(); Index++)
	{
		// if this state is the last source state to become active, activate the transition
		Transition = ExitTransitions.Get(Index);
		if (Transition->AreAllSourceStatesActivate()) Transition->Activate();
	}
}

/// Checks all transitions that start in this state. If all their source states are active,
/// the transition is deactivated.
void CFSMState::DeactivateExitTransitions(void)
{
	CFSMTransition *Transition;

	for (int Index=0; Index < ExitTransitions.GetLength(); Index++)
	{
		// only deactivate the exit transition it was activated
		Transition = ExitTransitions.Get(Index);
		if (Transition->AreAllSourceStatesActivate()) Transition->Deactivate();
	}
}

/// Creates an array of all superstates of this state, up to, but not including LowestSpanningState.
void CFSMState::GetParents(CFSMState *LowestSpanningState, CRow<CFSMState *> &Parents)
{
	CFSMState *ParentState;

	// special case: occurs in internal state transitions
	if (this == LowestSpanningState) return;

	ParentState = this->GetSuperState();
	while (ParentState != LowestSpanningState)
	{
		Parents.Add(ParentState);
		ParentState = ParentState->GetSuperState();
	}
}

/// Adds SubState as a substate by name NewName; this state deletes SubState when it is destructed
void CFSMState::AddSubState(const CText &NewName, CFSMState *SubState)
{
	// tell the state its name
	SubState->SetName(NewName);

	// tell the state its superstate
	SubState->SetSuperState(this);

	// add substate to substate list
	SubStates.Add(SubState);
}

/// Removes the substate by the name SubStateName from this state.
/// Warning: the programmer is responsible for cleaning up all transitions
/// that begin or end with it.
void CFSMState::RemoveSubState(const CText &SubStatePath)
{
 	CFSMState *SuperState;
	CFSMState *SubState = GetSubState(SubStatePath);
	if (!SubState) 
	{
		LOG_ERROR("CFSMState::RemoveSubState: '" + this->ToString() + "' does not contain a substate " + "'" + SubState->ToString() + "'.");
		return;
	}

	// if the substate is active, it is removed gracefully
	LOG_INFO("RemoveState: \t" + SubStatePath + " (Are all transitions connected to it removed?");
	if (SubState->IsActive())
	{
		// deactive substates and execute exit code
		SubState->Deactivate();
	}

	// actual removal
	SuperState = SubState->GetSuperState();
	SuperState->SubStates.Remove(SubState);
}

/// Returns (sub(sub...))state by path. 
/// A (relative) path is a string describing a state embedded in its substate.
/// Examples: 
/// A substate of this state: "active"
/// A substate of substate active: "active/working"
/// A subsubstate of substate working: "active/working/programming"
/// \Return returns the state or 0 if no such state could be found
CFSMState *CFSMState::GetSubState(const CText &RelativePath)
{
	static CLoader Loader;
	Loader.SetPunctuationChars("/");
	Loader.SetWhitespaceChars("");

	CFSMState *State = this;
	CFSMState *SubState;
	CText Name;
	bool Found;

	Loader.ReadString(RelativePath);
	while (Loader.HasNext())
	{
		// lookup substate by name
		Name = Loader.NextToken();
		Found = false;
		for (int Index=0; Index < State->GetSubStateCount(); Index++)
		{
			SubState = State->GetSubState(Index);
			if (SubState->GetName() == Name)
			{
				State = SubState;
				Found = true;
				break;
			}
		}
		if (!Found) { 
			LOG_ERROR("CFSMState::GetSubState: '" + RelativePath +"' is not a substate of '" + this->ToString() + "'.");
			break; 
		}

		// parse /
		if (!Loader.HasNext()) break;
		Loader.NextToken();
	}

	return State;
}

/// Is NewSuperState a (direct) superstate of this state?
bool CFSMState::HasSuperState(CFSMState *NewSuperState) const
{
	// this state has no super state; only return true if NewSuperState is 0 too
	if (SuperState == 0) return (SuperState == NewSuperState);
	// yes: my direct superstate is NewSuperState
	else if (SuperState == NewSuperState) return true;
	// I will ask my superstate to answer that question
	else return SuperState->HasSuperState(NewSuperState);
}

/// Adds the state by the name SubStateName as one of the states that is activated by default.
void CFSMState::AddInitialSubState(const CText &SubStateName)
{
	CFSMState *SubState = GetSubState(SubStateName);
	if (!SubState) 
	{
		LOG_ERROR("CFSMState::AddInitialSubState: '" + this->ToString() + "' does not contain a substate " + "'" + SubStateName + "'.");
		return;
	}

	SubState->SetInitial(true);
}

/// Add a transition between substates of this state
void CFSMState::AddTransition(CFSMTransition *NewTransition)
{
	NewTransition->LowestSpanningState = this;
}

/// Removes transition between substates of this state.
/// All source and target states of this transitions are updated.
void CFSMState::RemoveTransition(CFSMTransition *Transition)
{
	Transition->RemoveAllStates();
	delete Transition;
}

void CFSMState::AddAutomaticTransition(const CText &SourceStateName, const CText &TargetStateName)
{
	CFSMState *SourceState = GetSubState(SourceStateName);
	CFSMState *TargetState = GetSubState(TargetStateName);

	if (!SourceState) LOG_ERROR("'" + SourceStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!TargetState) LOG_ERROR("'" + TargetStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!SourceState || !TargetState) return;

	AddTransition(new CFSMAutomaticTransition(Model, SourceState, TargetState));
}

void CFSMState::AddSignalTransition(const CText &SourceStateName, const CText &TargetStateName, CFSMSignal *Signal)
{
	CFSMState *SourceState = GetSubState(SourceStateName);
	CFSMState *TargetState = GetSubState(TargetStateName);

	if (!SourceState) LOG_ERROR("'" + SourceStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!TargetState) LOG_ERROR("'" + TargetStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!SourceState || !TargetState) return;

	AddTransition(new CFSMSignalTransition(Model, SourceState, TargetState, Signal));
}

void CFSMState::AddTimeTransition(const CText &SourceStateName, const CText &TargetStateName, float Seconds)
{
	CFSMState *SourceState = GetSubState(SourceStateName);
	CFSMState *TargetState = GetSubState(TargetStateName);

	if (!SourceState) LOG_ERROR("'" + SourceStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!TargetState) LOG_ERROR("'" + TargetStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!SourceState || !TargetState) return;

	AddTransition(new CFSMTimeTransition(Model, SourceState, TargetState, Seconds));
}

void CFSMState::AddUpdateTransition(float UpdateInterval)
{
	AddTransition(new CFSMUpdateTransition(Model, this, UpdateInterval));
}

void CFSMState::AddMomentTransition(const CText &SourceStateName, const CText &TargetStateName, CMoment *Moment)
{
	CFSMState *SourceState = GetSubState(SourceStateName);
	CFSMState *TargetState = GetSubState(TargetStateName);

	if (!SourceState) LOG_ERROR("'" + SourceStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!TargetState) LOG_ERROR("'" + TargetStateName + "' is not a substate of '"+ this->ToString() +"'");
	if (!SourceState || !TargetState) return;

	AddTransition(new CFSMMomentTransition(Model, SourceState, TargetState, Moment));
}

/// Tell this state to remember the activaty pattern of its substates on deactivation.
/// The pattern should be restored on reactivation.
/// \RecurseSubStates Execute SetHistory on all substates as well (recursively)?
///    If true, the history is said to be deep; if false, the history is shallow.
void CFSMState::SetHistory(bool NewHistory, bool RecurseSubStates)
{
	History = NewHistory;

	if (RecurseSubStates)
	{
		for (int Index=0; Index < SubStates.GetLength(); Index++)
		{
			SubStates.Get(Index)->SetHistory(NewHistory, RecurseSubStates);
		}
	}
}

/// A state is called 'finished', when at least one of its (direct) substates is both final and active
bool CFSMState::IsFinished(void) const
{
	CFSMState *SubState;

	for (int Index=0; Index < SubStates.GetLength(); Index++)
	{
		SubState = SubStates.Get(Index);
		if (SubState->IsActive() && SubState->IsFinal()) return true;
	}
	return false;
}

CText CFSMState::ToString(int TabCount)
{
	CText String;
	CText Tabs("\t", TabCount);
	CText ActiveName = (IsActive() ? CText("-> ") + Name : Name);

	if (SubStates.GetLength() == 0)
	{
		String = Tabs + ActiveName;
	}
	else
	{
		// prefix
		String += Tabs + ActiveName + " {\n";

		// children
		for (int Index=0; Index < SubStates.GetLength(); Index++)
		{
			String += SubStates.Get(Index)->ToString(TabCount+1) + "\n";
		}

		// postfix
		String += Tabs + "}\n";
	}

	return String;
}

const CText CFSMState::ToString(void) const
{
	return Name;
}
