#ifndef _FSMMODEL
#define _FSMMODEL

#include "generic.h"
#include "aiFSMState.h"
#include "aiFSMSignal.h"
#include "aiFSMTransition.h"
#include "aiFSMSpecialTransitions.h"

using namespace generic;

/// A concurrent, hierarchical, finite state machine framework.
///
/// Hierarchical: a state may contain substates
/// Concurrent: multiple substates may be activated at the same time
///
/// The model may be operated at these levels of convenience:
/// 1. low level
/// Call Start(), Call Update() a number of times (for example, until IsFinished()), Call Stop
/// Update() updates the model according to the UpdateStrategy
///
/// 2. high level
/// Call Run(), this will call Start(), Update() until finished, and Stop()

class CFSMModel: public CElement
{
	/// the strategy that is applied when you call update
	enum EFSMModelStrategy
	{
		/// Default strategy: just check (and fire) all transitions once (this is a cycle)
		FSMMODELSTRATEGY_CYCLE,
		/// Perform cycles during the time-frame (of TimeFrameDuration seconds)
		FSMMODELSTRATEGY_TIMEFRAME_KEEP_CYCLING,
		/// Perform cycles during the time-frame (or until no more transitions are likely to occur;
		/// if so, quit prematurely)
		FSMMODELSTRATEGY_TIMEFRAME_CYCLE_WHILE_USEFUL,
		/// Perform cycles during the time-frame (or until no more transitions are likely to occur;
		/// if so, call Sleep() for the rest of the time; this is called time-burning)
		FSMMODELSTRATEGY_TIMEFRAME_CYCLE_AND_BURN
	};

	friend class CFSMState;
	friend class CFSMSignalTransition;
	friend class CFSMAutomaticTransition;
	friend class CFSMTimeTransition;
	friend class CFSMMomentTransition;

protected:
	// structure
	CFSMState *Root;
	// counter that generates unique signal id's
	int SignalIdGenerator;
	// the time the model was started
	float StartTime;
	// the start time of the previous update
	float PreviousUpdateTime;
	// the start time of the current update
	float CurrentUpdateTime;
	// the start moment (date and time) of the current update
	CMoment *CurrentMoment;
	// the strategy that is used by Update()
	EFSMModelStrategy Strategy;
	// the duration of a time frame (in seconds)
	float TimeFrameDuration;

	// signals
	CRow<CFSMSignal *> Signals;
	// signals entering the fsm on the next update
	CRow<CFSMSignal *> CurrentSignals;

	// signal observers: has 2 dimensions: signal-id and observers
	CRow< CRow<CFSMTransition *> *>	SignalObservers;
	// delayed transitions: a transition-start time pair: the transition was activated at the 
	// start time and should be fired SecondsInState (a time transition field) later
	CPairedRow<CFSMTimeTransition *, float> DelayedTransitions;
	// automatic transitions that have just been made firable
	CRow<CFSMTransition *> CurrentAutomaticTransitions;
	// transitions that should fire at (or after) a certain moment
	CRow<CFSMMomentTransition *> MomentTransitions;

	// critical sections
	CCriticalSection CriticalSectionBroadcastSignal;

	// transition (de)activation functions
	void AddSignalObserver(CFSMTransition *Transition, CFSMSignal *Signal);
	void RemoveSignalObserver(CFSMTransition *Transition, CFSMSignal *Signal);
	void ScheduleDelayedTransition(CFSMTimeTransition *Transition);
	void UnscheduleDelayedTransition(CFSMTimeTransition *Transition);
	void ScheduleAutomaticTransition(CFSMTransition *Transition);
	void UnscheduleAutomaticTransition(CFSMTransition *Transition);
	void ScheduleMomentTransition(CFSMMomentTransition *Transition);
	void UnscheduleMomentTransition(CFSMMomentTransition *Transition);

	// transition processing and firing functions
	void ProcessSignals(CRow<CFSMTransition *> &FireableTransitions);
	void ProcessTimers(CRow<CFSMTransition *> &FireableTransitions);
	void ProcessMomentTransitions(CRow<CFSMTransition *> &FireableTransitions);
	void ProcessAutomaticTransitions(CRow<CFSMTransition *> &FireableTransitions);
	void AddFireableTransition(CRow<CFSMTransition *> &FireableTransitions, CFSMTransition *NewTransition);
	void FireTransitions(CRow<CFSMTransition *> &FireableTransitions);

	// process all active transitions
	void Cycle(void);
	bool WillTransitionsFireBefore(float Time);

public:
    CFSMModel();
    ~CFSMModel();
    
	// states
    CFSMState *GetRootState(void) const { return Root; }
	CFSMState *GetState(const CText &AbsolutePath) const;

	// signals
	CFSMSignal *AddSignal(const CText &SignalName, CFSMSignal *NewSignal);
	CFSMSignal *AddSignal(const CText &SignalName);

	// strategies that are used in Update(), and Run()
	void SetStrategySingleCycle(void){ Strategy = FSMMODELSTRATEGY_CYCLE; }
	void SetStrategyTimeFrameKeepCycling(float NewTimeFrameDuration){ Strategy = FSMMODELSTRATEGY_TIMEFRAME_KEEP_CYCLING, TimeFrameDuration=NewTimeFrameDuration; }
	void SetStrategyTimeFrameCycleWhileUseful(float NewTimeFrameDuration){ Strategy = FSMMODELSTRATEGY_TIMEFRAME_CYCLE_WHILE_USEFUL, TimeFrameDuration=NewTimeFrameDuration; }
	void SetStrategyTimeFrameCycleWhileUsefulAndBurn(float NewTimeFrameDuration){ Strategy = FSMMODELSTRATEGY_TIMEFRAME_CYCLE_AND_BURN, TimeFrameDuration=NewTimeFrameDuration; }
    
	// global actions
	void Start(void);
    void Update(void);
	void Stop(void);
	bool IsFinished(void) const;
	void Run(void);

	// the only method that is thread-safe
	void BroadcastSignal(CFSMSignal *Signal);

	// timing
	float GetStartTime(void) const { return StartTime; }
	float GetCurrentUpdateTime(void) const { return CurrentUpdateTime; }
	float GetPreviousUpdateTime(void) const { return PreviousUpdateTime; }
	float GetSecondsSinceLastUpdate(void) const { return CurrentUpdateTime - PreviousUpdateTime; }
	CMoment *GetCurrentMoment(void) const { return CurrentMoment; }

	virtual const CText ToString(void) const;
};

#endif