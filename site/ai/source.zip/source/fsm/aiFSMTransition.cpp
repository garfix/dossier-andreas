#include "aiFSMTransition.h"
#include "aiFSMState.h"

/// Constructor for a simple transition
CFSMTransition::CFSMTransition(CFSMModel *NewModel, CFSMState *NewSourceState, CFSMState *NewTargetState, const CText &NewName)
{
	Model = NewModel;
	AddSourceState(NewSourceState);
	AddTargetState(NewTargetState);
	SetName(NewName);
	Priority = 0;
}

// Constructor for a complex transition
CFSMTransition::CFSMTransition(CFSMModel *NewModel, const CText &NewName)
{
	Model = NewModel;
	SetName(NewName);
	Priority = 0;
}

void CFSMTransition::AddSourceState(CFSMState *NewSourceState)
{
	SourceStates.Add(NewSourceState);

	// tell the source state your are a transition
	NewSourceState->AddExitTransition(this);
}

/// Removes all source states.
/// This is off course a advanced method. If all source states are removed from a transition,
/// it is no longer managed by the FSM. The application is responsible for cleaning it up.
void CFSMTransition::RemoveAllSourceStates(void)
{
	CFSMState *State;

	// source states
	for (int Index=0; Index < SourceStates.GetLength(); Index++)
	{
		State = SourceStates.Get(Index);
		State->RemoveExitTransition(this);
	}
	SourceStates.Clear();
}

void CFSMTransition::AddTargetState(CFSMState *NewTargetState)
{
	TargetStates.Add(NewTargetState);
}

/// Removes all target states.
/// Use only if you know what you're doing.
void CFSMTransition::RemoveAllTargetStates(void)
{
	TargetStates.Clear();
}

/// Checks if all source states are active. If so, the complex transition should fire.
bool CFSMTransition::AreAllSourceStatesActivate(void) const
{
	bool AreAllSourceStatesActive = true;

	for (int Index=0; Index < SourceStates.GetLength(); Index++)
	{
		if (!SourceStates.Get(Index)->IsActive()) AreAllSourceStatesActive = false;
	}

	return AreAllSourceStatesActive;
}

/// Helper function to help destroy a transition; removes all source and target states; notifies
/// these states of that.
void CFSMTransition::RemoveAllStates(void)
{
	RemoveAllSourceStates();
	RemoveAllTargetStates();
}

/*void CFSMTransition::DeactivateAllSourceStateExitTransitions(void)
{
	for (int SourceIndex=0; SourceIndex < SourceStates.GetLength(); SourceIndex++)
	{
		SourceStates.Get(SourceIndex)->DeactivateExitTransitions();
	}
}*/

void CFSMTransition::ActivateTargetStates(void)
{
	CFSMState *TargetState;
	CFSMState *ParentState;

	// activate all target states
	for (int Index=0; Index < TargetStates.GetLength(); Index++)
	{
		TargetState = TargetStates.Get(Index);

		// quick check if the target state has parents that need to be activated first
		if (TargetState->GetSuperState() != LowestSpanningState)
		{
			// create new Parents object for every target
			CRow<CFSMState *> Parents;

			// find all super states of the target state, up to the spanning state
			TargetState->GetParents(LowestSpanningState, Parents);
			
			// execute the entry code of all these parents
			for (int ParentIndex=Parents.GetLength()-1; ParentIndex >= 0; ParentIndex--)
			{
				ParentState = Parents.Get(ParentIndex);

				// if this state is active, a design error was made
				if (ParentState->IsActive()) LOG_ERROR("CFSMModel::FireTransition: Transition " + this->ToString() + " tries to activate the state " + ParentState->ToString() + " which is already active.");

				// activate the state
				ParentState->ActivateCommon();
			}
		}

		// if the target state is active, a design error was made
		if (TargetState->IsActive()) LOG_ERROR("CFSMModel::FireTransition: Transition " + this->ToString() + " tries to activate the state " + TargetState->ToString() + " which is already active.");

		// activate the target state
		TargetState->Activate();
	}
}

void CFSMTransition::DeactivateSourceStates(void)
{
	CFSMState *State;

	// special case: internal state transition
	//if (IsInternalStateTransition()) return;

	// deactivate all source states
	for (int Index=0; Index < SourceStates.GetLength(); Index++)
	{
		State = SourceStates.Get(Index);
		while (State != LowestSpanningState)
		{
			// deactivate
			// check if the source state is still active, it may have been deactivated
			// by the deactivation of other source states earlier on in this same for loop
			if (State->IsActive()) State->Deactivate();

			// one state up
			State = State->GetSuperState();
		}
	}
}

void CFSMTransition::Execute(void)
{
	if (IsInternalStateTransition())
	{
		// do not deactivate the other transitions; do not deactivate the state;
		// only reactivate this transition (for instance, resets the timer)
		Deactivate();
		LOG_INFO("Internal: \t" + this->ToString());
		Fire();
		Activate();
	}
	else
	{

		// deactivate all source states
		DeactivateSourceStates();

		// execute application code
		LOG_INFO("Trans: \t" + this->ToString());
		Fire();

		// activate target states
		ActivateTargetStates();
	}
}

int CFSMTransition::GetLevel(void) const 
{ 
	return LowestSpanningState->GetLevel(); 
}

bool CFSMTransition::AreAllSourceStatesFinished(void) const
{
	for (int Index=0; Index < SourceStates.GetLength(); Index++)
	{
		if (!SourceStates.Get(Index)->IsFinished()) return false;
	}

	return true;
}

bool CFSMTransition::IsInternalStateTransition(void) const
{
	return (LowestSpanningState == SourceStates.Get(0));
}

const CText CFSMTransition::ToString(void) const
{
	CText String;
	int Length;

	String = "(";

	Length = SourceStates.GetLength();
	for (int Index=0; Index < Length; Index++)
	{
		String += SourceStates.Get(Index)->GetName();
		if (Index < Length-1) String += ", ";
	}

	String += ") -> (";

	Length = TargetStates.GetLength();
	for (int Index=0; Index < Length; Index++)
	{
		String += TargetStates.Get(Index)->GetName();
		if (Index < Length-1) String += ", ";
	}

	String += ")";

	return String;
}


