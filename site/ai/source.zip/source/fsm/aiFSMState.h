#ifndef _FSMSTATE
#define _FSMSTATE

#include "generic.h"

using namespace generic;

class CFSMTransition;
class CFSMSignal;
class CMoment;

/// A single state in the Finite State Machine.

/// A state is called 'finished', when at least one of its (direct) substates is both final and active

class CFSMState: public CElement
{
	friend class CFSMModel;
	friend class CFSMTransition;

protected:
	CFSMModel *Model;
	bool Active;
	bool Final;
	// Level: the depth of the state (or: how many superstates does it have) 
	int Level;
	/// SubStates: The model's direct substates
	CRow<CFSMState *> SubStates;
	/// InitialSubState: the substate that is initially activated when this state is activated
	/// Initial: is this state an initial substate of its superstate?
	/// SuperState: this state's parent
	CFSMState *SuperState;
	/// ExitTransitions: transitions that have this state as one of their source states
	CRow<CFSMTransition *> ExitTransitions;
	/// StartTimeActive: the moment this state got last activated 
	/// (in seconds since the start of the program's execution)
	float StartTimeActive;
	/// AccumulatedTimeActive: the time this state has been active in previous active periods
	float AccumulatedSecondsActive;
	bool Initial;
	/// History: does this state remember the activity pattern of its substates?
	bool History;
	/// HistoryStored: only applicable if (History==true); has the activity pattern been stored?
	bool HistoryStored;
	/// ActiveBefore: only applicable if (SuperState->History==true)
	/// the value of Active before activation
	bool ActiveBefore;

	void Initialize(void);
	void SetSuperState(CFSMState *NewSuperState){ SuperState = NewSuperState; }
	void CleanUp(void);
	void ActivateCommon(void);
	void Activate(void);
	void Deactivate(void);
	void SetLevelsRecursively(int NewLevel);

	// transitions having this state as a source state
	void AddExitTransition(CFSMTransition *NewExitTransition){ ExitTransitions.Add(NewExitTransition); }
	void RemoveExitTransition(CFSMTransition *ExitTransition){ ExitTransitions.Remove(ExitTransition); }
	int GetExitTransitionCount(void) const { return ExitTransitions.GetLength(); }
	CFSMTransition *GetExitTransition(int Index) const { return ExitTransitions.Get(Index); }
	void ActivateExitTransitions(void);
	void DeactivateExitTransitions(void);

	// helper functions
	void GetParents(CFSMState *LowestSpanningState, CRow<CFSMState *> &Parents);

	// history
	void SetActiveBefore(bool NewActiveBefore){ ActiveBefore = NewActiveBefore; }
	bool WasActiveBefore(void) const { return ActiveBefore; }
	void SetHistoryStored(bool NewHistoryStored){ HistoryStored = NewHistoryStored; }
	bool HistoryHasBeenStored(void) const { return HistoryStored; }

public:
    CFSMState(CFSMModel *NewModel);
    ~CFSMState();

	// superstate
	CFSMState *GetSuperState(void) const { return SuperState; }
	bool HasSuperState(void) const { return (SuperState != 0); }
	bool HasSuperState(CFSMState *SuperState) const;

	// substates
	void AddSubState(const CText &NewName, CFSMState *NewState);
	void RemoveSubState(const CText &SubStatePath);
	int GetSubStateCount(void) const { return SubStates.GetLength(); }
	CFSMState *GetSubState(int Index) const { return SubStates.Get(Index); }
	CFSMState *GetSubState(const CText &RelativePath);

	// transitions (between substates!)
	void AddTransition(CFSMTransition *NewTransition);
	void RemoveTransition(CFSMTransition *NewTransition);
	void AddAutomaticTransition(const CText &SourceStateName, const CText &TargetStateName);
	void AddSignalTransition(const CText &SourceStateName, const CText &TargetStateName, CFSMSignal *Signal);
	void AddTimeTransition(const CText &SourceStateName, const CText &TargetStateName, float Seconds);
	void AddUpdateTransition(float UpdateInterval);
	void AddMomentTransition(const CText &SourceStateName, const CText &TargetStateName, CMoment *Moment);

	void SetLevel(int NewLevel){ Level = NewLevel; }
	int GetLevel(void) const { return Level; }

	// history
	void SetHistory(bool NewHistory, bool RecurseSubStates);
	bool HasHistory(void) const { return History; }

	// final
	void SetFinal(bool NewFinal){ Final = NewFinal; }
	bool IsFinal(void) const { return Final; }
    bool IsFinished(void) const;

	// active
	void SetActive(bool NewActive);
	bool IsActive(void) const { return Active; }

	// adding initial substates via superstate 
	void AddInitialSubState(const CText &NewName);
	// setting/getting initialness directly
	void SetInitial(bool NewInitial){ Initial = NewInitial; }
	bool IsInitial(void) const { return Initial; }

	// time active
	float GetSecondsActive(void) const;
	float GetTotalSecondsActive(void) const;

	CText ToString(int TabCount);

	// abstract functionality

	/// Application specific code for update transitions
	virtual void Update(void){}
	/// Application specific code for entering State
	virtual void Enter(void){}
	/// Application specific code for exiting State
	virtual void Exit(void){}

	virtual const CText ToString(void) const;
};

#endif