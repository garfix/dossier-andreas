#include "aiFSMSpecialTransitions.h"
#include "aiFSMModel.h"
#include "WinApp.h"

/// automatic transition
CFSMAutomaticTransition::CFSMAutomaticTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState):
	CFSMTransition(NewModel, SourceState, TargetState)
{
}

void CFSMAutomaticTransition::Activate(void)
{
	Model->ScheduleAutomaticTransition(this);
}

void CFSMAutomaticTransition::Deactivate(void)
{
	Model->UnscheduleAutomaticTransition(this);
}

/// Signal transition
CFSMSignalTransition::CFSMSignalTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, CFSMSignal *NewSignal):
	CFSMTransition(NewModel, SourceState, TargetState)
{
	Signal = NewSignal;
}

void CFSMSignalTransition::Activate(void)
{
	Model->AddSignalObserver(this, Signal);
}

void CFSMSignalTransition::Deactivate(void)
{
	Model->RemoveSignalObserver(this, Signal);
}

/// time transition
CFSMTimeTransition::CFSMTimeTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, float NewSecondsInState):
	CFSMTransition(NewModel, SourceState, TargetState)
{
	SecondsInState = NewSecondsInState;
}

void CFSMTimeTransition::Activate(void)
{
	Model->ScheduleDelayedTransition(this);
}

void CFSMTimeTransition::Deactivate(void)
{
	Model->UnscheduleDelayedTransition(this);
}

/// update transition
CFSMUpdateTransition::CFSMUpdateTransition(CFSMModel *NewModel, CFSMState *State, float NewSecondsInState):
	CFSMTimeTransition(NewModel, State, State, NewSecondsInState)
{
}

void CFSMUpdateTransition::Fire(void)
{
	CFSMState *State = SourceStates.Get(0);
	State->Update();
}

/// pop transition
CFSMPopTransition::CFSMPopTransition(CFSMModel *NewModel, CFSMState *SourceState):
	CFSMTransition(NewModel), Stack(2)
{
	AddSourceState(SourceState);
}

void CFSMPopTransition::Add(CFSMTransition *Transition)
{
	Stack.Push(Transition);
}

void CFSMPopTransition::Fire(void)
{
	CFSMTransition *Transition;
	
	// sanity check
	if (Stack.GetDepth() == 0)
	{
		LOG_ERROR("Tried to pop transition when there was none.");
		return;
	}

	// take the last transition to our source state
	Transition = Stack.Pop();
	// add the source states of Transition as our target states
	RemoveAllTargetStates();
	for (int Index=0; Index < Transition->GetSourceStateCount(); Index++)
	{
		AddTargetState(Transition->GetSourceState(Index));
	}
}

void CFSMPopTransition::Reset(void)
{
	Stack.PopAll();
}

/// push transition
CFSMPushTransition::CFSMPushTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, CFSMPopTransition *NewPopTransition):
	CFSMTransition(NewModel, SourceState, TargetState)
{
	PopTransition = NewPopTransition;
}
void CFSMPushTransition::Fire(void)
{
	PopTransition->Add(this);
}

/// pop on finished transition
CFSMPopOnFinishedTransition::CFSMPopOnFinishedTransition(CFSMModel *NewModel, CFSMState *SourceState):
	CFSMPopTransition(NewModel, SourceState)
{
}

CFSMMomentTransition::CFSMMomentTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, CMoment *NewMoment):
	CFSMTransition(NewModel, SourceState, TargetState)
{
	Moment = new CMoment(*NewMoment);
}

CFSMMomentTransition::~CFSMMomentTransition()
{
	delete Moment;
}

void CFSMMomentTransition::Activate(void)
{
	Model->ScheduleMomentTransition(this);
}

void CFSMMomentTransition::Deactivate(void)
{
	Model->UnscheduleMomentTransition(this);
}
