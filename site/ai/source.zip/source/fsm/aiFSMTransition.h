#ifndef _FSMTRANSITION
#define _FSMTRANSITION

#include "generic.h"

using namespace generic;

class CFSMState;
class CFSMModel;
class CFSMSignal;

/// The class models a complex transition. 
/// A complex transition is a transition from one or more source states to one or more target states.
/// The transition fires when all source states are active. At that time the source states
/// are deactivated and the target states are activated.
/// The (simple) transition is just a special case of the complex transition, with
/// a single source state and a single target state.

class CFSMTransition: public CElement
{
	friend class CFSMModel;
	friend class CFSMState; // for lowest spanning state

protected:
	CFSMModel *Model;
	CRow<CFSMState *> SourceStates;
	CRow<CFSMState *> TargetStates;
	/// The lowest state that still contains (spans) all SourceStates and TargetStates.
	CFSMState *LowestSpanningState;
	/// Priority: when two or more transitions at the same level may fire at the same time,
	/// the one with the highest priority is chosen
	int Priority;

	CFSMState *GetLowestSpanningState(void) const { return LowestSpanningState; }
	bool AreAllSourceStatesActivate(void) const;
	void RemoveAllStates(void);
//	void DeactivateAllSourceStateExitTransitions(void);

	void ActivateTargetStates(void);
	void DeactivateSourceStates(void);
	void Execute(void);

	// abstract functions that will be executed when all their source states are activates or
	// deactivated, repectively
	virtual void Activate(void){};
	virtual void Deactivate(void){};

public:
	CFSMTransition(CFSMModel *NewModel, CFSMState *NewSourceState, CFSMState *NewTargetState, const CText &NewName="");
    CFSMTransition(CFSMModel *NewModel, const CText &NewName="");
	virtual ~CFSMTransition(){};

	void AddSourceState(CFSMState *NewSourceState);
	int GetSourceStateCount(void) const { return SourceStates.GetLength(); }
	CFSMState *GetSourceState(int Index) const { return SourceStates.Get(Index); }
	void RemoveAllSourceStates(void);

	void AddTargetState(CFSMState *NewTargetState);
	int GetTargetStateCount(void) const { return TargetStates.GetLength(); }
	CFSMState *GetTargetState(int Index) const { return TargetStates.Get(Index); }
	void RemoveAllTargetStates(void);

	int GetLevel(void) const;

	void SetPriority(int NewPriority){ Priority = NewPriority; }
	int GetPriority(void) const { return Priority; }

	bool AreAllSourceStatesFinished(void) const;
	bool IsInternalStateTransition(void) const;

	/// Application specific code that should be executed when Transition fires
	virtual void Fire(void){}

	virtual const CText ToString(void) const;
};

#endif