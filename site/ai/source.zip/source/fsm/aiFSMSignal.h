#ifndef _FSMSIGNAL
#define _FSMSIGNAL

#include "generic.h"

using namespace generic;

/// A signal transfers knowledge of a current event.
/// Every object of the CFSMSignal class or of a subclass is unique; that means,
/// creating two objects of a CFSMSignal makes two unique signals with different Id's.

class CFSMSignal: public CElement
{
	friend class CFSMModel;

protected:
	int Id;

	void SetId(int NewId){ Id = NewId; }

public:
	CFSMSignal();
	int GetId(void) const { return Id; } 
};

#endif
