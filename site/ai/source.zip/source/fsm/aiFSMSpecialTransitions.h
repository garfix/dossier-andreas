#ifndef _FSMSPECIALTRANSITIONS
#define _FSMSPECIALTRANSITIONS

#include "aiFSMTransition.h"
#include "aiFSMSignal.h"
#include "aiFSMState.h"

class CMoment;

/// The automatic transition fires just after the first Update() of the source state, unconditionally.
class CFSMAutomaticTransition: public CFSMTransition
{
public:
	CFSMAutomaticTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState);
	virtual void Activate(void);
	virtual void Deactivate(void);
};

/// This transition fires when an event Event occurs.
class CFSMSignalTransition: public CFSMTransition
{
protected:
	CFSMSignal *Signal;
public:
	CFSMSignalTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, CFSMSignal *NewSignal);
	virtual void Activate(void);
	virtual void Deactivate(void);
};

/// This transition fires if ALL source states are at least SecondsInState seconds active
class CFSMTimeTransition: public CFSMTransition
{
protected:
	float SecondsInState;
public:
	CFSMTimeTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, float NewSecondsInState);
	virtual void Activate(void);
	virtual void Deactivate(void);

	void SetSecondsInState(float NewSecondsInState){ SecondsInState = NewSecondsInState; }
	float GetSecondsInState(void) const { return SecondsInState; }
};

/// This is a special internal state transition that is also a time transition.
/// It fires when the state is NewSecondsInState active.
/// At that point the Update() function of the state is called and the state is deactivated/activated.
/// The latter is necessary for the underlaying time transition and it also allows the Update function
/// to check the time since the previous update.
class CFSMUpdateTransition: public CFSMTimeTransition
{
public:
	CFSMUpdateTransition(CFSMModel *NewModel, CFSMState *State, float NewSecondsInState);
	virtual void Fire(void);
};

/// These push- and pop transitions implement a stack-based state machine.
/// Motivation:
///   When a state is done, you may want to revert to the previous state. This previous state however
///   may not be known at design time (there may be multiple possible source states).
///   If so, create a pop transition and a push transition. Pass a pointer to the pop transition to
///   the push transition. 
///   If the push transition fires, it adds (pushes) itself to the pop transition.
///   If the pop transition fires, it pops the latest transition and uses its source states as its
///     own target states.
/// If you overload these classes, remember to call the baseclass methods ShouldFire() and Fire()!
class CFSMPopTransition: public CFSMTransition
{
protected:
	generic::CStack<CFSMTransition *> Stack;
public:
	CFSMPopTransition(CFSMModel *NewModel, CFSMState *SourceState);
	void Add(CFSMTransition *Transition);
	virtual void Fire(void);
	void Reset(void);
};

class CFSMPushTransition: public CFSMTransition
{
protected:
	CFSMPopTransition *PopTransition;
public:
	CFSMPushTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, CFSMPopTransition *NewPopTransition);
	virtual void Fire(void);
};

/// A special pop transition that fires if all source states are finished.
class CFSMPopOnFinishedTransition: public CFSMPopTransition
{
public:
	CFSMPopOnFinishedTransition(CFSMModel *NewModel, CFSMState *SourceState);
};

/// A transition that fires after a certain date and time have passed
class CFSMMomentTransition: public CFSMTransition
{
protected:
	CMoment *Moment; // Defined as pointer to avoid including WinApp

public:
	CFSMMomentTransition(CFSMModel *NewModel, CFSMState *SourceState, CFSMState *TargetState, CMoment *NewMoment);
	~CFSMMomentTransition();
	virtual void Activate(void);
	virtual void Deactivate(void);

	const CMoment &GetMoment(void) const { return *Moment; }
};

#endif