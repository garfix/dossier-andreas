#include "genericLogger.h"
#include <time.h>

namespace generic
{
	
CLogger::CLogger()
{
	LogLevel = LOGLEVEL_ALL;
	LogFile = 0;
	ShouldFlush = true;
}

void CLogger::Log(ELogLevel Level, const CText &Message)
{
	static char *LevelNames[] = 
	{
		"off    ",
		"*FATAL*",
		"*ERROR*",
		"WARNING",
		"info   ",
		"debug  ",
		"all    "
	};
		
	// if no logfile was specified, we presume logging is not necessary
	if(!LogFile) return;

	// check if this message needs to be logged
	if (Level > LogLevel) return;

	// create time string
	char Time[100];
	_strtime(Time);

	// write the message to file
	if (Message.GetLength() > 0)
		fprintf(LogFile, "%s %s %s\n", Time, LevelNames[Level], Message.GetBuffer());
	else
		fprintf(LogFile, "%s %s\n", Time, LevelNames[Level]);

	// flush
	if (ShouldFlush) fflush(LogFile);
}

CLogger::~CLogger()
{
	if (LogFile) fclose(LogFile);
}

CLogger &CLogger::GetLogger(void)
{
	static CLogger Logger;

	return Logger;
}

void CLogger::SetLogFile(const CText &LogFileName)
{
	// close previous logfile (if any)
	if (LogFile) fclose(LogFile);

	LogFile = fopen(LogFileName.GetBuffer(), "wt");
}

}
