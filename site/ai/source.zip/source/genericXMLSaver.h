#ifndef _XMLSAVER
#define _XMLSAVER

#include "genericText.h"
#include "genericSaver.h"

namespace generic
{

/// Very simple xml writer. Just uses tags.

class CXMLSaver: public CSaver
{
protected:
	// A common repository needed by different types of element in the xml tree
	void *Context;

	void Write(const CText &String);

public:
	CXMLSaver();
	~CXMLSaver();

	void SetContext(void *NewContext){ Context = NewContext; }
	void *GetContext(void) const { return Context; }

	void EnterChild(const CText &ChildName);
	void LeaveChild(const CText &ChildName);

	void WriteCDataChild(const CText &Child, const CText &CData);
	void WriteIntChild(const CText &Child, int Value);
	void WriteBooleanChild(const CText &Child, bool Value);
	void WriteEmptyElement(const CText &Child);
};

}

#endif
