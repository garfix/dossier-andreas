#ifndef _FUZZYATOM
#define _FUZZYATOM

#include "aiFuzzy.h"
#include "aiFuzzyNode.h"
#include "generic.h"

using namespace generic;

class CFuzzySet;
class CFuzzyVariable;

/// An Atomic Proposition.
/// In predicate logic: predicate + argument
/// In fuzzy logic: fuzzy set + fuzzy variable
/// Examples: temperature is hot; the man is fast
class CFuzzyAtom: public CFuzzyNode
{
protected:
	CFuzzyVariable *FuzzyVariable;
	CFuzzySet *FuzzySet;

public:
	CFuzzyAtom();
	CFuzzyAtom(CFuzzyVariable *NewFuzzyVariable, CFuzzySet *NewFuzzySet);

	void SetFuzzyVariable(CFuzzyVariable *NewFuzzyVariable){ FuzzyVariable = NewFuzzyVariable; }
	const CFuzzyVariable *GetFuzzyVariable(void) const { return FuzzyVariable; }
	
	void SetFuzzySet(CFuzzySet *NewFuzzySet){ FuzzySet = NewFuzzySet; }
	const CFuzzySet *GetFuzzySet(void) const { return FuzzySet; }

	virtual CFuzzy CalculateFuzzyValue(void);

	virtual const CText ToString(void) const;
};

#endif