#ifndef _FUZZYPIECEWISELINEARSET 
#define _FUZZYPIECEWISELINEARSET

#include "aiFuzzySet.h"
#include "generic.h"

using namespace generic;

/// The fuzzy set is a.k.a the membership function
class CFuzzyPiecewiseLinearSet: public CFuzzySet
{
protected:
	CRow< CPair<CFloat *, CFloat *> > Coordinates;
	// (more than) one of the coordinates contains avariable?
	bool ContainsVariableCoordinates;

	void CalculateCharacteristicValue(void);
	void OrderCoordinates(void);

public:
  CFuzzyPiecewiseLinearSet();

  virtual float GetCharacteristicValue(void) const { return CharacteristicValue; };
  virtual CFuzzy GetDegreeOfMembership(float Value) const;
  virtual float GetLeftmostValue(const CFuzzy &DOM, bool &Found) const;
  virtual float GetRightmostValue(const CFuzzy &DOM, bool &Found) const;

  void AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *> &NewCoordinate);

  void Update();
};

#endif