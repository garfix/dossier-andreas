#include "aiFuzzy.h"

CFuzzy::CFuzzy(float NewValue): CFloat(NewValue)
{
	assert((NewValue >= 0.0f) && (NewValue <= 1.0f));
}

/// performs fuzzy OR and returns the result\n
/// the fuzzy OR is the maximum value
CFuzzy CFuzzy::Or(const CFuzzy &Operand) const
{
	return CFuzzy(Value > Operand.Value ? Value : Operand.Value);
}

/// performs fuzzy AND and returns the result\n
/// the fuzzy AND is the minimum value
CFuzzy CFuzzy::And(const CFuzzy &Operand) const
{
	return CFuzzy(Value < Operand.Value ? Value : Operand.Value);
}

/// performs fuzzy NOT and returns the result\n
/// the fuzzy NOT is the value subtracted from 1.0
CFuzzy CFuzzy::Not(void) const
{
	return CFuzzy(1.0f - Value);
}

