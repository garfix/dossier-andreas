#include "aiFuzzyVariable.h"
#include "aiFuzzyOutputSet.h"
#include "aiFuzzyResultSet.h"
#include <math.h>

CFuzzyVariable::CFuzzyVariable():
  CFloat(-666.0f), FuzzySets(0)
{
	Init();
}

CFuzzyVariable::CFuzzyVariable(float NewCrispValue):
  CFloat(NewCrispValue), FuzzySets(0)
{
	Init();
}

CFuzzyVariable::~CFuzzyVariable()
{
	delete OutputSet;
}

void CFuzzyVariable::Init(void)
{
	DefuzzificationMethod = DEFUZZIFICATIONMETHOD_CENTREOFGRAVITY;
	VariableType = VARIABLETYPE_REAL;
	DefaultMethod = DEFAULTMETHOD_NOCHANGE;
	DefaultValue = 666.0f;
	UseRange = false;
	MinimumValue = 666.0f;
	MaximumValue = 666.0f;
	OutputSet = new CFuzzyOutputSet();
}

/// Defuzzify according to the method Centre Of Gravity.\n
/// Not all DOMs should be 0
float CFuzzyVariable::DefuzzifyCOG(void)
{
	float CrispValue = 0;
	float CumulativeDOMs = 0;

	for (int Index = 0; Index < OutputSet->GetResultCount(); Index++)
	{
		CFuzzyResultSet &ResultSet = OutputSet->GetResultSet(Index);

		CrispValue += 
			ResultSet.GetCharacteristicValue()
			* ResultSet.GetResultDOM().GetValue();

		CumulativeDOMs += ResultSet.GetResultDOM().GetValue();
	}

	assert(CumulativeDOMs != 0);

	CrispValue /= CumulativeDOMs;

	return CrispValue;
}

/// Defuzzify according to the method Centre Of Gravity for Singletons.\n
/// Uses the method COG, and then rounds up to the nearest singleton.
float CFuzzyVariable::DefuzzifyCOGS(void)
{
	float CrispValue;
	float Singleton, NearestSingleton;
	float Difference, SmallestDifference;

	// use the COG method to start with
	CrispValue = DefuzzifyCOG();

	// take the first singleton as the singleton to start with
	Singleton = FuzzySets.Get(0)->GetCharacteristicValue();
	SmallestDifference = (float)fabs(Singleton - CrispValue);
	NearestSingleton = Singleton;

	// round up to the nearest singleton value
	for(int Index=1; Index < FuzzySets.GetLength(); Index++)
	{
		Singleton = FuzzySets.Get(Index)->GetCharacteristicValue();
		Difference = (float)fabs(Singleton - CrispValue);
		if (Difference < SmallestDifference)
		{
			SmallestDifference = Difference;
			NearestSingleton = Singleton;
		}
	}
	CrispValue = NearestSingleton;

	return CrispValue;
}

/// Defuzzify according to the method Mean of Maxima
/// Looks for the maximum result values of all the rules.
/// There may be more results that are equally maximal.
/// The characteristic values of their respecive fuzzy subsets are then taken.
/// When there are multiple subsets, the mean of their characteristic values
/// is taken.
float CFuzzyVariable::DefuzzifyMOM(void)
{
	CRow<CFuzzyResultSet> MaxResults(0);
	float CrispValue;
	float Sum;

	// get all maximum results in the output set
	OutputSet->GetMaxResults(MaxResults);

	// determine the sum of the characteristic values of these result sets
	Sum = 0.0f;
	for (int Index = 0; Index < MaxResults.GetLength(); Index++)
	{
		Sum += MaxResults.Get(Index).GetCharacteristicValue();
	}

	// the crisp value is the mean of the characteristic values
	CrispValue = Sum / MaxResults.GetLength();

	return CrispValue;
}

/// Defuzzify according to method Leftmost Maximum
/// Searches for the leftmost set in the output set with the maximum DOM;
/// And takes the leftmost value of the set with this DOM
float CFuzzyVariable::DefuzzifyLM(void)
{
	CRow<CFuzzyResultSet> MaxResults(0);
	float CrispValue;
	bool Found;

	// get all maximum results in the output set
	OutputSet->GetMaxResults(MaxResults);

	// get the leftmost result from these results
	const CFuzzyResultSet &LeftmostMaxResult = MaxResults.Get(0);

	// get the leftmost value in this set for the DOM of the result
	CrispValue = LeftmostMaxResult.GetLeftmostValue(LeftmostMaxResult.GetResultDOM(), Found);

	// if no crisp value could be determined, something serious is probably wrong
	assert(Found);

	return CrispValue;
}

/// Defuzzify according to method Rightmost Maximum
/// Searches for the rightmost set in the output set with the maximum DOM;
/// And takes the rightmost value of the set with this DOM
float CFuzzyVariable::DefuzzifyRM(void)
{
	CRow<CFuzzyResultSet> MaxResults(0);
	float CrispValue;
	bool Found;

	// get all maximum results in the output set
	OutputSet->GetMaxResults(MaxResults);

	// get the rightmost result from these results
	const CFuzzyResultSet &RightmostMaxResult = MaxResults.Get(MaxResults.GetLength()-1);

	// get the rightmost value in this set for the DOM of the result
	CrispValue = RightmostMaxResult.GetRightmostValue(RightmostMaxResult.GetResultDOM(), Found);

	// if no crisp value could be determined, something serious is probably wrong
	assert(Found);

	return CrispValue;
}

/// calculate new crisp value based on the fuzzy output set
/// also clears the fuzzy output set
void CFuzzyVariable::Defuzzify(void)
{
	float CrispValue;

	// first check if all rules have failed
	if (OutputSet->GetResultCount() == 0)
	{
		// check which default method to use
		if (DefaultMethod == DEFAULTMETHOD_NOCHANGE){ CrispValue = Value; }
		else if (DefaultMethod == DEFAULTMETHOD_SETVALUE) CrispValue = DefaultValue;
	}
	else if (DefuzzificationMethod == DEFUZZIFICATIONMETHOD_CENTREOFGRAVITY) 
	{
		// Centre of Gravity
		CrispValue = DefuzzifyCOG();
	}
	else if	(DefuzzificationMethod == DEFUZZIFICATIONMETHOD_CENTREOFGRAVITYFORSINGLETONS)
	{
		// Centre of Gravity for Singletons
		CrispValue = DefuzzifyCOGS();
	}
	else if (DefuzzificationMethod == DEFUZZIFICATIONMETHOD_MEANOFMAXIMA)
	{
		// Mean of Maxima
		CrispValue = DefuzzifyMOM();
	}
	else if (DefuzzificationMethod == DEFUZZIFICATIONMETHOD_LEFTMOSTMAXIMUM)
	{
		// Leftmost Maximum
		CrispValue = DefuzzifyLM();
	}
	else if (DefuzzificationMethod == DEFUZZIFICATIONMETHOD_RIGHTMOSTMAXIMUM)
	{
		// Rightmost Maximum
		CrispValue = DefuzzifyRM();
	}

	// check the range of the variable;
	// if the value falls outside it, the closest allowed value will be used in stead
	if (UseRange)
	{
		if (CrispValue < MinimumValue) CrispValue = MinimumValue;
		else if (CrispValue > MaximumValue) CrispValue = MaximumValue;
	}

	SetValue(CrispValue);

	// clear output set
	OutputSet->Clear();
}

void CFuzzyVariable::AddFuzzySet(CFuzzySet *FuzzySet)
{
	FuzzySets.Add(FuzzySet); 
}

/// Returns the fuzzy set by the name specified.
CFuzzySet *CFuzzyVariable::GetFuzzySet(const CText &Name) const
{
	for (int Index=0; Index < FuzzySets.GetLength(); Index++)
	{
		if (FuzzySets.Get(Index)->GetName() == Name) return FuzzySets.Get(Index);
	}

	return 0;
}

CFuzzyOutputSet *CFuzzyVariable::GetFuzzyOutputSet(void) const 
{ 
	return OutputSet; 
}
