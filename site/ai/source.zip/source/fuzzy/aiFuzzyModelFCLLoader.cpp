#include "aiFuzzyModelFCLLoader.h"
#include "aiFuzzyOperator.h"
#include "aiFuzzyVariable.h"
#include "aiFuzzyAtom.h"
#include "aiFuzzyPiecewiseLinearSet.h"
#include "aiFuzzySingletonSet.h"

#define ERROR_FILE_NOT_FOUND_ "File not found"
#define ERROR_WRITING_TO_FILE "Error reading file."
#define LOADER_MAX_TOKEN_LENGTH 1024

#define ERROR_FUNCTION_BLOCK_EXPECTED "Function block expected"
#define ERROR_FUNCTION_BLOCK_NAME "The function block requires a name"
#define ERROR_UNKNOWN_KEYWORD "Keyword unknown"
#define ERROR_SEMICOLON_EXPECTED "Semicolon (;) expected"
#define ERROR_TYPE_EXPECTED "Variable type expected (for example, REAL)"
#define ERROR_UNDEFINED_VARIABLE "Variable not defined"
#define ERROR_TERM_EXPECTED "Term expected"
#define ERROR_ASSIGNMENT_EXPECTED "Assignment operator (:=) expected"
#define ERROR_OPENING_BRACKET_EXPECTED "Opening bracket '(' expected"
#define ERROR_CLOSING_BRACKET_EXPECTED "Closing bracket ')' expected"
#define ERROR_COMMA_EXPECTED "Comma (,) expected"
#define ERROR_COLON_EXPECTED "Colon (:) expected"
#define ERROR_DEFUZZIFICATION_METHOD_EXPECTED "Defuzzification method expected"
#define ERROR_RANGE_DOTS_EXPECTED "Two dots (..) expected"
#define ERROR_RULE_EXPECTED "Rule or specifier expected"
#define ERROR_UNKNOWN_METHOD "Unknown method"
#define ERROR_IF_EXPECTED "Keyword 'if' expected"
#define ERROR_IS_EXPECTED "Keyword 'is' expected"
#define ERROR_UNDEFINED_SET "Fuzzy set not defined"
#define ERROR_IN_EXPRESSION "Error in expression"
#define ERROR_DOM_CONSTANT "The degree of membership should be a constant"

#define MAX_PARSESTACK_DEPTH 1000

CFuzzyModelFCLLoader::CFuzzyModelFCLLoader()
{
	SetWhitespaceChars(" \t\n");
	SetPunctuationChars(".()*;,:=");
	AddOperator(":=");
	AddOperator("..");
	AddCommentInfo(SCommentInfo("(*", "*)", false));
	SetCaseSensitive(false);
}

bool CFuzzyModelFCLLoader::ParsePage(void)
{
	bool Success = true;

	// FUNCTION_BLOCK
	NextToken();
	if (Token != "FUNCTION_BLOCK"){ Error = ERROR_FUNCTION_BLOCK_EXPECTED; return false; }

	// function block name
	NextToken();
	Model->SetName(Token);
	// the name is likely to be left out and since this would generate 
	// an incomprehensible error message, we will handle this case here
	if (Token == "VAR_INPUT"){ Error = ERROR_FUNCTION_BLOCK_NAME; return false; }

	NextToken();
	while (Success && (Token != "END_FUNCTION_BLOCK"))
	{
		if (Token == "VAR_INPUT") Success = ParseVar();
		else if (Token == "VAR_OUTPUT") Success = ParseVar();
		else if (Token == "FUZZIFY") Success = ParseFuzzify();
		else if (Token == "DEFUZZIFY") Success = ParseDefuzzify();
		else if (Token == "RULEBLOCK") Success = ParseRuleblock();
		else { Error = ERROR_UNKNOWN_KEYWORD; return false; }

		NextToken();
	}

	return Success;	
}

bool CFuzzyModelFCLLoader::ParseVar(void)
{
	CFuzzyVariable *NewVariable;
	EFuzzyVariableTypes VariableType;
	// multiple variables may shape type (var1, var2, var3: type; )
	CRow<CFuzzyVariable *> VariablesSharingType(0);
	
	NextToken();
	while (Token != "END_VAR")
	{
        while (true)
		{
			// variable name
			NewVariable = new CFuzzyVariable(0);
			NewVariable->SetName(Token);
			Model->AddVariable(NewVariable);
			
			// multiple variables can have the same type
			VariablesSharingType.Add(NewVariable);
			
			// , or :
			NextToken();
			if (Token == ":") break;
			if (Token != ","){ Error = ERROR_COLON_EXPECTED; return false; }

			// next variable name
			NextToken();
		}

		// variable type
		NextToken();
		if (Token == "REAL") 
		{
			VariableType = VARIABLETYPE_REAL;
		}
		else { Error = ERROR_TYPE_EXPECTED; return false; }

		// one or more variables get their type
		for (int Index=0; Index < VariablesSharingType.GetLength(); Index++)
		{
			VariablesSharingType.Get(Index)->SetVariableType(VARIABLETYPE_REAL);
		}
		VariablesSharingType.Clear();

		// ;
		NextToken();
		if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

		NextToken();
	}

	return true;
}

bool CFuzzyModelFCLLoader::ParseFuzzify(void)
{
	CFuzzyVariable *Variable;
	bool Success = true;

	// variable
	NextToken();
	Variable = Model->GetVariable(Token);
	if (!Variable){ Error = ERROR_UNDEFINED_VARIABLE; return false; }

	NextToken();
	while (Success && Token != "END_FUZZIFY")
	{
		// fuzzy set specifier
		if (Token == "TERM") Success = ParseTerm(Variable);
		else { Error = ERROR_TERM_EXPECTED; return false; }
		
		NextToken();
	}

	return Success;
}

bool CFuzzyModelFCLLoader::ParseTerm(CFuzzyVariable *Variable)
{
	CFloat *XValue;
	CFuzzySet *NewFuzzySet;
	CText SetName;

	// fuzzy set name
	SetName = NextToken();

	// operator :=
	NextToken();
	if (Token != ":="){ Error = ERROR_ASSIGNMENT_EXPECTED; return false; }

	// Coordinates or single value
	LookAhead();
	if (Token == "(") 
	{
		// coordinates
		NewFuzzySet = new CFuzzyPiecewiseLinearSet();
		if (!ParseCoordinates((CFuzzyPiecewiseLinearSet *)NewFuzzySet)) return false;
	}
	else 
	{
		// single value
		XValue = new CFloat((float)atof(NextToken()));
		Model->AddConstant(XValue);
		NewFuzzySet = new CFuzzySingletonSet(XValue);

		// ;
		NextToken();
		if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }
	}

	NewFuzzySet->SetName(SetName);
	Model->AddSet(NewFuzzySet);
	Variable->AddFuzzySet(NewFuzzySet);

	return true;
}

bool CFuzzyModelFCLLoader::ParseCoordinates(CFuzzyPiecewiseLinearSet *NewFuzzySet)
{
	CFloat *XValue, *YValue;

	NextToken();
	while (Token != ";")
	{
		// (
		if (Token != "("){ Error = ERROR_OPENING_BRACKET_EXPECTED; return false; }

		// X coordinate
		ParseConstantOrVariable(XValue);

		// ,
		NextToken();
		if (Token != ","){ Error = ERROR_COMMA_EXPECTED; return false; }

		// Y coordinate
		NextToken();
		if (IsIdentifier(Token)){ Error = ERROR_DOM_CONSTANT; return false; }
		YValue = new CFloat((float)atof(Token));
		Model->AddConstant(YValue);

		// )
		NextToken();
		if (Token != ")"){ Error = ERROR_CLOSING_BRACKET_EXPECTED; return false; }

		// add set coordinate
		NewFuzzySet->AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(XValue, YValue));

		NextToken();
	}

	return true;
}

bool CFuzzyModelFCLLoader::ParseDefuzzify(void)
{
	bool Success = true;
	CFuzzyVariable *Variable;

	// variable
	NextToken();
	Variable = Model->GetVariable(Token);
	if (!Variable){ Error = ERROR_UNDEFINED_VARIABLE; return false; }

	NextToken();
	while (Success && Token != "END_DEFUZZIFY")
	{
		// fuzzy set specifier
		if (Token == "TERM") Success = ParseTerm(Variable);
		else if (Token == "METHOD") Success = ParseVariableMethod(Variable);
		else if (Token == "DEFAULT") Success = ParseVariableDefault(Variable);
		else if (Token == "RANGE") Success = ParseVariableRange(Variable);
		else { Error = ERROR_TERM_EXPECTED; return false; }
		
		NextToken();
	}

	return Success;
}

bool CFuzzyModelFCLLoader::ParseVariableMethod(CFuzzyVariable *Variable)
{
	// :
	NextToken();
	if (Token != ":"){ Error = ERROR_COLON_EXPECTED; return false; }

	// methodname
	NextToken();
	// MoM is not part of FCL spec.
	if (Token == "MOM") Variable->SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_MEANOFMAXIMA);
	else if (Token == "COG") Variable->SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_CENTREOFGRAVITY);
	else if (Token == "COGS") Variable->SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_CENTREOFGRAVITYFORSINGLETONS);
	else if (Token == "LM") Variable->SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_LEFTMOSTMAXIMUM);
	else if (Token == "RM") Variable->SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_RIGHTMOSTMAXIMUM);
	else { Error = ERROR_DEFUZZIFICATION_METHOD_EXPECTED; return false; };

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

	return true;
}

bool CFuzzyModelFCLLoader::ParseVariableDefault(CFuzzyVariable *Variable)
{
	float DefaultValue;

	// :=
	NextToken();
	if (Token != ":="){ Error = ERROR_ASSIGNMENT_EXPECTED; return false; }

	// default value
	NextToken();
	if (Token == "NC") Variable->SetDefaultMethod(DEFAULTMETHOD_NOCHANGE);
	else
	{
		DefaultValue = (float)atof(Token);
		Variable->SetDefaultMethod(DEFAULTMETHOD_SETVALUE);
		Variable->SetDefaultValue(DefaultValue);
	}

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

	return true;
}

bool CFuzzyModelFCLLoader::ParseVariableRange(CFuzzyVariable *Variable)
{
	float MinValue, MaxValue;

	// :=
	NextToken();
	if (Token != ":="){ Error = ERROR_ASSIGNMENT_EXPECTED; return false; }

	// (
	NextToken();
	if (Token != "("){ Error = ERROR_OPENING_BRACKET_EXPECTED; return false; }

	// minimum value
	NextToken();
	MinValue = (float)atof(Token);

	// ..
	NextToken();
	if (Token != ".."){ Error = ERROR_RANGE_DOTS_EXPECTED; return false; }

	// maximum value
	NextToken();
	MaxValue = (float)atof(Token);

	// )
	NextToken();
	if (Token != ")"){ Error = ERROR_CLOSING_BRACKET_EXPECTED; return false; }

	Variable->SetUseRange(true);
	Variable->SetRange(MinValue, MaxValue);

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }
	
	return true;
}

bool CFuzzyModelFCLLoader::ParseRuleblock(void)
{
	bool Success = true;
	CFuzzyRuleblock *Ruleblock;

	// ruleblock's name
	NextToken();
	Ruleblock = new CFuzzyRuleblock();
	Ruleblock->SetName(Token);
	Model->AddRuleblock(Ruleblock);

	NextToken();
	while (Success && Token != "END_RULEBLOCK")
	{
		// fuzzy set specifier
		if (Token == "RULE") Success = ParseRule(Ruleblock);
		else if (Token == "AND") Success = ParseOperatorMethodAnd(Ruleblock);
		else if (Token == "OR") Success = ParseOperatorMethodOr(Ruleblock);
		else if (Token == "ACT") Success = ParseActivationMethod(Ruleblock);
		else if (Token == "ACCU") Success = ParseAccumulationMethod(Ruleblock);
		else { Error = ERROR_RULE_EXPECTED; return false; }
		
		NextToken();
	}

	if (!Success) return false;

	// all operators should get the appropriate methods
	Ruleblock->Init();

	return true;
}

bool CFuzzyModelFCLLoader::ParseRule(CFuzzyRuleblock *Ruleblock)
{
	CFuzzyRule *NewRule;
	CFuzzyNode *RootNode;
	bool Success;

	// rule name
	NextToken();

	// create new rule
	NewRule = new CFuzzyRule();
	NewRule->SetName(Token);
	Model->AddRule(NewRule);
	Ruleblock->AddRule(NewRule);

	// :
	NextToken();
	if (Token != ":"){ Error = ERROR_COLON_EXPECTED; return false; }

	// IF
	NextToken();
	if (Token != "IF") { Error = ERROR_IF_EXPECTED; return false; }

	// antecedents
	Success = ParseExpression(RootNode);
	if (!Success) return false;
	NewRule->SetAntecedentRoot(RootNode);

	// consequents
	LookAhead();
	while (Token != ";")
	{
		Success = ParseConsequent(NewRule);
		if (!Success) return false;
	}

	return true;
}

bool CFuzzyModelFCLLoader::ParseExpression(CFuzzyNode *&ParsedNode)
{
	CLinkedList<CFuzzyNode *> NodeList;
	CListNode<CFuzzyNode *> *ListIterator;
	CFuzzyNode *NewNode, *Node, *Operand;
	bool Success;

	// turn all tokens into nodes
	LookAhead();
	while ((Token != ")") && (Token != "THEN"))
	{
		Success = ParseExpressionNode(NewNode);
		if (!Success) return false;
		NodeList.Add(NewNode);

		LookAhead();
	}

	NextToken(); // eat ')' or 'THEN'

	// change the list of nodes into a tree of nodes

	// NOT
	ListIterator = NodeList.GetFirst();
	while (ListIterator != NodeList.GetEnd())
	{
		Node = ListIterator->GetValue();

		// operand is NOT and is not a tree yet?
		if (Node->IsNOT() && (((CFuzzyOperator *)Node)->GetOperandCount() == 0))
		{
			// the next node contains the operand of NOT
			Operand = ListIterator->GetNext()->GetValue();

			// add this operand to the operator node
			((CFuzzyOperator *)Node)->AddOperand(Operand);

			// remove the operand from the list
			NodeList.Remove(ListIterator->GetNext());
		}

		ListIterator = ListIterator->GetNext();
	}

	// AND
	ListIterator = NodeList.GetFirst();
	while (ListIterator != NodeList.GetEnd())
	{
		Node = ListIterator->GetValue();

		// operand is AND and is not a tree yet?
		if (Node->IsAND() && (((CFuzzyOperator *)Node)->GetOperandCount() == 0))
		{
			// previous node contains the 1st operand of AND
			Operand = ListIterator->GetPrevious()->GetValue();

			// add this operand to the operator node
			((CFuzzyOperator *)Node)->AddOperand(Operand);

			// next node contains the 2nd operand of AND
			Operand = ListIterator->GetNext()->GetValue();

			// add this operand to the operator node
			((CFuzzyOperator *)Node)->AddOperand(Operand);

			// remove the operands from the list
			NodeList.Remove(ListIterator->GetPrevious());
			NodeList.Remove(ListIterator->GetNext());
		}

		ListIterator = ListIterator->GetNext();
	}

	// OR
	ListIterator = NodeList.GetFirst();
	while (ListIterator != NodeList.GetEnd())
	{
		Node = ListIterator->GetValue();

		// operand is OR and is not a tree yet?
		if (Node->IsOR() && (((CFuzzyOperator *)Node)->GetOperandCount() == 0))
		{
			// previous node contains the 1st operand of OR
			Operand = ListIterator->GetPrevious()->GetValue();

			// add this operand to the operator node
			((CFuzzyOperator *)Node)->AddOperand(Operand);

			// next node contains the 2nd operand of OR
			Operand = ListIterator->GetNext()->GetValue();

			// add this operand to the operator node
			((CFuzzyOperator *)Node)->AddOperand(Operand);

			// remove the operands from the list
			NodeList.Remove(ListIterator->GetPrevious());
			NodeList.Remove(ListIterator->GetNext());
		}

		ListIterator = ListIterator->GetNext();
	}

	// there should be one node left
	if (NodeList.IsEmpty()) return false;

	// return the top node
	ParsedNode = NodeList.GetFirst()->GetValue();

	return true;
}

bool CFuzzyModelFCLLoader::ParseExpressionNode(CFuzzyNode *&ParsedNode)
{
	bool Success;

	if (Token == "(")
	{
		NextToken();
		Success = ParseExpression(ParsedNode);
		if (!Success) return false;
	}
	else if (Token == "NOT")
	{
		NextToken(); // eat it
		ParsedNode = new CFuzzyOperator(OPERATORTYPE_NOT);
		Model->AddNode(ParsedNode);
	}
	else if (Token == "AND")
	{
		NextToken(); // eat it
		ParsedNode = new CFuzzyOperator(OPERATORTYPE_AND);
		Model->AddNode(ParsedNode);
	}
	else if (Token == "OR")
	{
		NextToken(); // eat it
		ParsedNode = new CFuzzyOperator(OPERATORTYPE_OR);
		Model->AddNode(ParsedNode);
	}
	else 
	{
		// A IS (NOT)B -> <atom>							(1)
		Success = ParseNotOrAtom(ParsedNode);
		if (!Success) return false;
	}

	return true;
}

bool CFuzzyModelFCLLoader::ParseNotOrAtom(CFuzzyNode *&ParsedNode)
{
	CFuzzyVariable *Variable;
	CFuzzySet *Set;
	CFuzzyAtom *Atom;
	bool Success = true;

	// new atom
	Atom = new CFuzzyAtom();
	Model->AddNode(Atom);

	// variable
	NextToken();
	Variable = Model->GetVariable(Token);
	if (!Variable){ Error = ERROR_UNDEFINED_VARIABLE; return false; }
	Atom->SetFuzzyVariable(Variable);

	// is
	NextToken();
	if (Token != "IS"){ Error = ERROR_IS_EXPECTED; return false; }

	// set or NOT
	NextToken();

	// not
	if (Token == "NOT")
	{
		// create operator NOT
		ParsedNode = new CFuzzyOperator(OPERATORTYPE_NOT);
		Model->AddNode(ParsedNode);
		// add the atom as its operand
		((CFuzzyOperator *)ParsedNode)->AddOperand(Atom);

		NextToken();
	}
	else
	{
		ParsedNode = Atom;
	}

	// set
	Set = Variable->GetFuzzySet(Token);
	if (Set == 0){ Error = ERROR_UNDEFINED_SET; return false; }
	Atom->SetFuzzySet(Set);
	
	return true;
}

bool CFuzzyModelFCLLoader::ParseAtom(CFuzzyAtom *Atom)
{
	CFuzzyVariable *Variable;
	CFuzzySet *Set;
	bool Success = true;

	// variable
	NextToken();
	Variable = Model->GetVariable(Token);
	if (!Variable){ Error = ERROR_UNDEFINED_VARIABLE; return false; }
	Atom->SetFuzzyVariable(Variable);

	// is
	NextToken();
	if (Token != "IS"){ Error = ERROR_IS_EXPECTED; return false; }

	// set
	NextToken();
	Set = Variable->GetFuzzySet(Token);
	if (Set == 0){ Error = ERROR_UNDEFINED_SET; return false; }
	Atom->SetFuzzySet(Set);
	
	return true;
}

bool CFuzzyModelFCLLoader::ParseConstantOrVariable(CFloat *&Value)
{
	// parse float or variable
	NextToken();

	if (IsIdentifier(Token))
	{
		// variable name
		Value = Model->GetVariable(Token);
		if (Value == 0){ Error = ERROR_UNDEFINED_VARIABLE; return false; }
	}
	else
	{
		// token is value
		Value = new CFloat((float)atof(Token));
		Model->AddConstant(Value);
	}

	return true;
}

bool CFuzzyModelFCLLoader::ParseConsequent(CFuzzyRule *FuzzyRule)
{
	bool Success;
	CFuzzyAtom *Consequent;
	CFloat *WeightingFactor;

	// consequent: atom
	Consequent = new CFuzzyAtom();
	Model->AddNode(Consequent);
	Success = ParseAtom(Consequent);

	// next: ',' or 'WITH'
	NextToken();

	if (Token == "WITH") 
	{
		// weighting factor
		ParseConstantOrVariable(WeightingFactor);

		// next: ',' or ';'
		NextToken();
	}
	else
	{
		// default weighting factor
		WeightingFactor = new CFloat(1.0f);
		Model->AddConstant(WeightingFactor);
	}

	if ((Token != ",") && (Token != ";")){ Error = ERROR_COMMA_EXPECTED; return false; }

	FuzzyRule->AddConsequent(Consequent, WeightingFactor);

	return Success;
}

bool CFuzzyModelFCLLoader::ParseOperatorMethodAnd(CFuzzyRuleblock *Ruleblock)
{
	// :
	NextToken();
	if (Token != ":"){ Error = ERROR_COLON_EXPECTED; return false; }

	// Method name
	NextToken();
	if (Token == "MIN") Ruleblock->SetOperatorMethod(OPERATORMETHOD_MIN_MAX);
	else if (Token == "PROD") Ruleblock->SetOperatorMethod(OPERATORMETHOD_ASUM_PROD);
	else if (Token == "BDIF") Ruleblock->SetOperatorMethod(OPERATORMETHOD_BSUM_BDIF);
	else { Error = ERROR_UNKNOWN_METHOD; return false; }

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

	return true;
}

bool CFuzzyModelFCLLoader::ParseOperatorMethodOr(CFuzzyRuleblock *Ruleblock)
{
	// :
	NextToken();
	if (Token != ":"){ Error = ERROR_COLON_EXPECTED; return false; }

	// Method name
	NextToken();
	if (Token == "MAX") Ruleblock->SetOperatorMethod(OPERATORMETHOD_MIN_MAX);
	else if (Token == "ASUM") Ruleblock->SetOperatorMethod(OPERATORMETHOD_ASUM_PROD);
	else if (Token == "BSUM") Ruleblock->SetOperatorMethod(OPERATORMETHOD_BSUM_BDIF);
	else { Error = ERROR_UNKNOWN_METHOD; return false; }

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

	return true;
}

bool CFuzzyModelFCLLoader::ParseActivationMethod(CFuzzyRuleblock *Ruleblock)
{
	// :
	NextToken();
	if (Token != ":"){ Error = ERROR_COLON_EXPECTED; return false; }

	// Method name
	NextToken();
	if (Token == "PROD") Ruleblock->SetActivationMethod(ACTIVATIONMETHOD_PROD);
	else if (Token == "MIN") Ruleblock->SetActivationMethod(ACTIVATIONMETHOD_MIN);
	else { Error = ERROR_UNKNOWN_METHOD; return false; }

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

	return true;
}

bool CFuzzyModelFCLLoader::ParseAccumulationMethod(CFuzzyRuleblock *Ruleblock)
{
	// :
	NextToken();
	if (Token != ":"){ Error = ERROR_COLON_EXPECTED; return false; }

	// Method name
	NextToken();
	if (Token == "MAX") Ruleblock->SetAccumulationMethod(ACCUMULATIONMETHOD_MAX);
	else if (Token == "BSUM") 
	{
		Ruleblock->SetAccumulationMethod(ACCUMULATIONMETHOD_BSUM);
		printf("The BSUM accumulation method is not implemented. Defaulting to MAX method.");
	}
	else if (Token == "NSUM") 
	{
		Ruleblock->SetAccumulationMethod(ACCUMULATIONMETHOD_NSUM);
		printf("The NSUM accumulation method is not implemented. Defaulting to MAX method");
	}
	else { Error = ERROR_UNKNOWN_METHOD; return false; }

	// ;
	NextToken();
	if (Token != ";"){ Error = ERROR_SEMICOLON_EXPECTED; return false; }

	return true;
}

/// Parses Fuzzy Control Language file by name Filename and places 
/// resulting content in NewModel.
/// \return Was the parse successful?
bool CFuzzyModelFCLLoader::Load(CText &Filename, CFuzzyModel *NewModel)
{
	CText Source;
    
	Model = NewModel;

	if (!ReadFile(Filename))
	{ 
		Error = ERROR_FILE_NOT_FOUND_; 
		return false; 
	}

	Reset();
	if (!ParsePage()) return false;

	return true;
}

