#include "aiFuzzyNode.h"
#include "aiFuzzyOperator.h"

/// Is this node a NOT operator?
bool CFuzzyNode::IsNOT(void)
{
	return (
		(typeid(*this) == typeid(CFuzzyOperator)) &&
		(((CFuzzyOperator *)this)->GetOperatorType() == OPERATORTYPE_NOT));
}

/// Is this node an AND operator?
bool CFuzzyNode::IsAND(void)
{
	return (
		(typeid(*this) == typeid(CFuzzyOperator)) &&
		(((CFuzzyOperator *)this)->GetOperatorType() == OPERATORTYPE_AND));
}

/// Is this node an OR operator?
bool CFuzzyNode::IsOR(void)
{
	return (
		(typeid(*this) == typeid(CFuzzyOperator)) &&
		(((CFuzzyOperator *)this)->GetOperatorType() == OPERATORTYPE_OR));
}

/// Is this node an operator?
bool CFuzzyNode::IsOperator(void)
{
	return ((typeid(*this) == typeid(CFuzzyOperator)) != 0);
}

