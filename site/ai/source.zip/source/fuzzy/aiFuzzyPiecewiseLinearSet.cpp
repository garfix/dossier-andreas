#include "aiFuzzyPiecewiseLinearSet.h"
#include "aiFuzzyVariable.h"

CFuzzyPiecewiseLinearSet::CFuzzyPiecewiseLinearSet():
  CFuzzySet(), Coordinates(0)
{
	CharacteristicValue = 666.0f;
	ContainsVariableCoordinates = false;
}

/// Calculates the most typical example of the set
/// Implemented as the mean of the first and the last of the values
/// with the highest degree of membership
/// examples: the middle point of a triangle; the mean of the top of a trapezoid.
void CFuzzyPiecewiseLinearSet::CalculateCharacteristicValue(void)
{
	CFuzzy Membership, MembershipFirst;
	float ValueFirst;
	float X, Y;

	// the first coordinate specifies the default characteristic value
	X = Coordinates.Get(0).GetFirst()->GetValue();
	Y = Coordinates.Get(0).GetSecond()->GetValue();
	ValueFirst = X;
	MembershipFirst = Y;
	CharacteristicValue = X;

	// see if you can find a better one
	for (int Index=1; Index<Coordinates.GetLength(); Index++)
	{
		X = Coordinates.Get(Index).GetFirst()->GetValue();
		Y = Coordinates.Get(Index).GetSecond()->GetValue();
		Membership = Y;

		if (Membership > MembershipFirst)
		{
			// found a coordinate that is better
			ValueFirst = X;
			CharacteristicValue = X;
			MembershipFirst = Membership;
		}
		else if (Membership == MembershipFirst)
		{
			// found a coordinate that is just as good
			CharacteristicValue = (ValueFirst + X) / 2;
		}
	}
}

/// Puts the coordinates in the right order
void CFuzzyPiecewiseLinearSet::OrderCoordinates(void)
{
	CPair<CFloat *, CFloat *> Swapper;

	// bubblesort coordinates
	for(int I=0; I < Coordinates.GetLength()-1; I++)
	{
		for(int J=0; J < Coordinates.GetLength()-1-I; J++)
		{
			if (Coordinates.Get(J).GetFirst()->GetValue() > Coordinates.Get(J+1).GetFirst()->GetValue())
			{
				// swap coordinates
				Swapper = Coordinates.Get(J);
				Coordinates.Get(J) = Coordinates.Get(J+1);
				Coordinates.Get(J+1) = Swapper;
			}
		}
	}
}

/// Adds a coordinate to the linear interpolation function\n
/// It also calculates the most characteristic (typical) value of the set,
/// according to its function.\n
/// The coordinates may be added in any order, they are sorted automatically.
void CFuzzyPiecewiseLinearSet::AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *> &NewCoordinate)
{ 
	Coordinates.Add(NewCoordinate);

	// is this coordinate variable?
	if (typeid(*NewCoordinate.GetFirst()) == typeid(CFuzzyVariable))
	{
		ContainsVariableCoordinates = true;
	}

	// move the new coordinate down to its correct position
	OrderCoordinates();

	// calculate the characteristic value
	// this is the only time it is done for a constant set
	CalculateCharacteristicValue();
}

/// Calculates the DOM (Degree of membership) of a crisp value according
/// to this fuzzy set.
CFuzzy CFuzzyPiecewiseLinearSet::GetDegreeOfMembership(float Value) const
{
	float StartX, StartY, EndX, EndY;

	assert(Coordinates.GetLength() > 0);

	StartX = CFloat::GetMinimum();
	StartY = Coordinates.Get(0).GetSecond()->GetValue();
	for (int Index = 0; Index < Coordinates.GetLength(); Index++)
	{
		EndX = Coordinates.Get(Index).GetFirst()->GetValue();
		EndY = Coordinates.Get(Index).GetSecond()->GetValue();
		if (EndX >= Value)
		{
			return CFuzzy(StartY + (Value - StartX) * 
				((EndY - StartY) / (EndX - StartX)));
		}

		StartX = EndX;
		StartY = EndY;
	}
	return CFuzzy(StartY);
}

/// In the case that the set contains variable coordinates:\n
/// Places the membership coordinates in the correct order.\n
/// Calculates the characteristic value
void CFuzzyPiecewiseLinearSet::Update()
{
	if (ContainsVariableCoordinates) 
	{
		OrderCoordinates();
		CalculateCharacteristicValue();
	}
}

/// Determine the leftmost value of the set if
/// the degree of membership equals DOM;\n
/// it corresponds to fist intersection of the set with the line y=DOM.
/// \param Found is returned to indicate whether such a leftmost value could be found
float CFuzzyPiecewiseLinearSet::GetLeftmostValue(const CFuzzy &DOM, bool &Found) const
{
	float StartX, StartY, EndX, EndY;

	assert(Coordinates.GetLength() > 0);

	StartX = Coordinates.Get(0).GetFirst()->GetValue();
	StartY = Coordinates.Get(0).GetSecond()->GetValue();

	// exception for open ended functions
	if (StartY > DOM.GetValue()) return CFloat::GetMinimum();

	for (int Index = 1; Index < Coordinates.GetLength(); Index++)
	{
		EndX = Coordinates.Get(Index).GetFirst()->GetValue();
		EndY = Coordinates.Get(Index).GetSecond()->GetValue();
		if (EndY >= DOM.GetValue())
		{
			Found = true;
			return StartX + (DOM.GetValue() - StartY) * 
				((EndX - StartX) / (EndY - StartY) );
		}

		StartX = EndX;
		StartY = EndY;
	}

	Found = false;
	return -1;
}

/// Determine the rightmost value of the set if
/// the degree of membership equals DOM;\n
/// it corresponds to last intersection of the set with the line y=DOM.
/// \param Found is returned to indicate whether such a leftmost value could be found
float CFuzzyPiecewiseLinearSet::GetRightmostValue(const CFuzzy &DOM, bool &Found) const
{
	float StartX, StartY, EndX, EndY;

	assert(Coordinates.GetLength() > 0);

	StartX = Coordinates.Get(Coordinates.GetLength()-1).GetFirst()->GetValue();
	StartY = Coordinates.Get(Coordinates.GetLength()-1).GetSecond()->GetValue();

	// exception for open ended functions
	if (StartY > DOM.GetValue()) return CFloat::GetMaximum();

	for (int Index = Coordinates.GetLength()-2; Index >= 0; Index--)
	{
		EndX = Coordinates.Get(Index).GetFirst()->GetValue();
		EndY = Coordinates.Get(Index).GetSecond()->GetValue();
		if (EndY >= DOM.GetValue())
		{
			Found = true;
			return StartX + (DOM.GetValue() - StartY) * 
				((EndX - StartX) / (EndY - StartY) );
		}

		StartX = EndX;
		StartY = EndY;
	}

	Found = false;
	return -1;
}