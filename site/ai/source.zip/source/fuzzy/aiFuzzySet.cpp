#include "aiFuzzySet.h"

CFuzzySet::CFuzzySet()
{
}
