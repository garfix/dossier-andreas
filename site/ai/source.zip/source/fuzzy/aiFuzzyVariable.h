#ifndef _FUZZYVARIABLE
#define _FUZZYVARIABLE

#include "aiFuzzy.h"
#include "aiFuzzyRule.h"
#include "aiFuzzyOutputSet.h"
#include "generic.h"

using namespace generic;

class generic::CTest;

enum EFuzzyDefuzzificationMethods
{
	DEFUZZIFICATIONMETHOD_CENTREOFGRAVITY,
	DEFUZZIFICATIONMETHOD_CENTREOFGRAVITYFORSINGLETONS,
	DEFUZZIFICATIONMETHOD_MEANOFMAXIMA,
	DEFUZZIFICATIONMETHOD_LEFTMOSTMAXIMUM,
	DEFUZZIFICATIONMETHOD_RIGHTMOSTMAXIMUM
};

enum EFuzzyVariableTypes
{
	VARIABLETYPE_REAL
};

enum EFuzzyDefaultMethods
{
	DEFAULTMETHOD_NOCHANGE,
	DEFAULTMETHOD_SETVALUE
};

class CFuzzyVariable: public CFloat
{
protected:
	// the sets describing the variable
	CRow<CFuzzySet *> FuzzySets;
	// method to turn the fuzzy value into a crisp value
	EFuzzyDefuzzificationMethods DefuzzificationMethod;
	// the output set that results from applying all rules to this variable
	CFuzzyOutputSet *OutputSet;
	EFuzzyVariableTypes VariableType;
	EFuzzyDefaultMethods DefaultMethod;
	float DefaultValue;
	float MinimumValue;
	float MaximumValue;
	bool UseRange;

	void Init(void);

	float DefuzzifyCOG(void);
	float DefuzzifyCOGS(void);
	float DefuzzifyMOM(void);
	float DefuzzifyLM(void);
	float DefuzzifyRM(void);

public:
	// output variables
	CFuzzyVariable();
	// input variables
	CFuzzyVariable(float NewCrispValue);
	~CFuzzyVariable();

	void SetVariableType(EFuzzyVariableTypes NewVariableType){ VariableType = NewVariableType; }
	EFuzzyVariableTypes GetVariableType(void) { return VariableType; }

	void AddFuzzySet(CFuzzySet *FuzzySet);
	CFuzzySet *GetFuzzySet(const CText &Name) const;

	CFuzzyOutputSet *GetFuzzyOutputSet(void) const;

	void SetDefuzzificationMethod(EFuzzyDefuzzificationMethods NewDefuzzificationMethod){ DefuzzificationMethod = NewDefuzzificationMethod; }
	void SetDefaultMethod(EFuzzyDefaultMethods NewDefaultMethod){ DefaultMethod = NewDefaultMethod; }
	void SetDefaultValue(float NewDefaultValue){ DefaultValue = NewDefaultValue; }
	void SetRange(float NewMinimumValue, float NewMaximumValue){ MinimumValue = NewMinimumValue; MaximumValue = NewMaximumValue; }
	void SetUseRange(bool NewUseRange){ UseRange = NewUseRange; }
	
	void Defuzzify(void);

	friend class generic::CTest;
};

#endif