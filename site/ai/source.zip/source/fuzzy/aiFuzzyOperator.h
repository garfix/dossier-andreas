#ifndef _FUZZYOPERATOR
#define _FUZZYOPERATOR

#include "aiFuzzyVariable.h"
#include "aiFuzzyNode.h"
#include "generic.h"

using namespace generic;

enum EFuzzyOperatorTypes
{
	OPERATORTYPE_AND, OPERATORTYPE_OR, OPERATORTYPE_NOT
};

enum EFuzzyOperatorMethods
{
	OPERATORMETHOD_MIN_MAX,
	OPERATORMETHOD_ASUM_PROD,
	OPERATORMETHOD_BSUM_BDIF
};

/// An operator in a fuzzy expression.
class CFuzzyOperator: public CFuzzyNode
{
protected:
	EFuzzyOperatorTypes OperatorType;
	EFuzzyOperatorMethods OperatorMethod;
	CRow<CFuzzyNode *> Operands;

public:
	CFuzzyOperator(EFuzzyOperatorTypes NewOperatorType);
	~CFuzzyOperator();

	void SetOperatorMethod(EFuzzyOperatorMethods NewOperatorMethod);
	EFuzzyOperatorMethods GetOperatorMethod(void){ return OperatorMethod; }

	void AddOperand(CFuzzyNode *NewOperand){ Operands.Add(NewOperand); }
	int GetOperandCount(void){ return Operands.GetLength(); }
	
	EFuzzyOperatorTypes GetOperatorType(void){ return OperatorType; }

	CFuzzy CalcOrMax(CFuzzy &Value1, CFuzzy &Value2);
	CFuzzy CalcOrASum(CFuzzy &Value1, CFuzzy &Value2);
	CFuzzy CalcOrBSum(CFuzzy &Value1, CFuzzy &Value2);
	CFuzzy CalcAndMin(CFuzzy &Value1, CFuzzy &Value2);
	CFuzzy CalcAndProd(CFuzzy &Value1, CFuzzy &Value2);
	CFuzzy CalcAndBDif(CFuzzy &Value1, CFuzzy &Value2);
	
	virtual const CText ToString(void) const;

	virtual CFuzzy CalculateFuzzyValue(void);
};

#endif