#ifndef _FUZZY
#define _FUZZY

#include "generic.h"

using namespace generic;

#define FUZZY_FALSE 0.0f
#define FUZZY_TRUE 1.0f

/// This class represents a fuzzy value, a floating point value in the range [0..1]
/// signifying a truth value of some proposition, where 0 is completely false
/// and 1 is completely true.
class CFuzzy: public CFloat
{
public:
	CFuzzy(float NewValue=FUZZY_FALSE);

	CFuzzy Or(const CFuzzy &Operand) const;
	CFuzzy And(const CFuzzy &Operand) const;
	CFuzzy Not(void) const;

	bool operator==(const CFuzzy &Other) const { return (this->Value == Other.Value ); }
	bool operator!=(const CFuzzy &Other) const { return (this->Value != Other.Value ); }
	bool operator>(const CFuzzy &Other) const { return (this->Value > Other.Value ); }

	CFuzzy operator/(const CFuzzy &Other) const { return (this->Value / Other.Value ); }
	CFuzzy operator*(const CFuzzy &Other) const { return (this->Value * Other.Value ); }

	void operator/=(const CFuzzy &Other) { this->Value /= Other.Value; }
	void operator*=(const CFuzzy &Other) { this->Value *= Other.Value; }
};

#endif