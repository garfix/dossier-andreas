#include "aiFuzzyModel.h"
#include "aiFuzzyModelFCLLoader.h"

CFuzzyModel::CFuzzyModel():
  Rules(0),
  Variables(0),
  Sets(0), 
  Ruleblocks(0), 
  Nodes(0),
  Constants(0)
{
}

CFuzzyModel::~CFuzzyModel()
{
	Rules.DeleteContents();
	Variables.DeleteContents();
	Sets.DeleteContents();
	Ruleblocks.DeleteContents();
	Nodes.DeleteContents();
	Constants.DeleteContents();
}

/// Reads the Fuzzy Control Language file by the specified name,
/// and builds its own structure with it.\n
/// Prints a detailed error message if the file contains some mistake
/// \return was the file loaded and parsed succesfully?
bool CFuzzyModel::Load(CText Filename)
{
	CFuzzyModelFCLLoader Loader;
	bool Success;

	Success = Loader.Load(Filename, this);

	if (!Success) printf(Loader.GetError() + " in line " + Loader.GetLineNumber() + ".\n");

	return Success;
}

/// Returns a specific variable by name.
CFuzzyVariable *CFuzzyModel::GetVariable(const CText &Name) const
{
	CText UppercasedName = Name.ToUppercase();

	for (int Index=0; Index < Variables.GetLength(); Index++)
	{
		if (Variables.Get(Index)->GetName() == UppercasedName) return Variables.Get(Index);
	}

	return 0;
}

/// The main method. Evaluates and executes all rules. Defuzzifies all variables
/// according to the results of the rules.
void CFuzzyModel::Update()
{
	int Index;

	// update all sets (the order of the coordinates may have changed if they are variable)
	for (Index=0; Index < Sets.GetLength(); Index++)
	{
		Sets.Get(Index)->Update();
	}

	// inference: try to fire all rules
	// implements the phases aggregation, activation and accumulation (MAX)
	for (Index=0; Index < Rules.GetLength(); Index++)
	{
		Rules.Get(Index)->Execute();
	}

	// defuzzification
	for (Index=0; Index < Variables.GetLength(); Index++)
	{
		Variables.Get(Index)->Defuzzify();
	}
}
