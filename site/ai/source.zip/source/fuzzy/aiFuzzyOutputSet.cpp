#include "aiFuzzyOutputSet.h"
#include "aiFuzzyResultSet.h"

CFuzzyOutputSet::CFuzzyOutputSet():
	Results(0)
{
}

/// Add a new set to the output set.
/// If DOM equals 0 (FALSE), it will not be included in the outputset,
/// for efficiency reasons.
void CFuzzyOutputSet::AddResult(const CFuzzySet *Set, CFuzzy &DOM, EFuzzyActivationMethods NewActivationMethod)
{
	if (DOM != FUZZY_FALSE) Results.Add(CFuzzyResultSet(Set, DOM, NewActivationMethod)); 
}

/// Fills the array MaxResults with all results with maximal DOMs
void CFuzzyOutputSet::GetMaxResults(CRow<CFuzzyResultSet> &MaxResults)
{
	CFuzzy DOM, MaxDOM;
	int Index;

	// first a quick run to determine the largest DOM
	MaxDOM = GetResultSet(0).GetResultDOM();
	for (Index = 1; Index < Results.GetLength(); Index++)
	{
		DOM = GetResultSet(Index).GetResultDOM();
		if (DOM > MaxDOM)
		{
			MaxDOM = DOM;
		}
	}

	// then place all results with the highest DOM in the MaxResults array
	for (Index = 0; Index < Results.GetLength(); Index++)
	{
		CFuzzyResultSet &ResultSet = Results.Get(Index);
		if (ResultSet.GetResultDOM() == MaxDOM)
		{
			MaxResults.Add(ResultSet);
		}
	}
}
