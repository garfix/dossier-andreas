#ifndef _FUZZYRESULTSET 
#define _FUZZYRESULTSET

#include "aiFuzzySet.h"

enum EFuzzyActivationMethods
{
	ACTIVATIONMETHOD_PROD,
	ACTIVATIONMETHOD_MIN
};

/// The fuzzy set that results from applying one rules to one variable.
/// It is a transformation of one of the sets of a variable.
/// Transformation occurs by scaling (activation method 'product') or clipping
/// (activation method 'min').

class CFuzzyResultSet: public CFuzzySet
{
protected:
	const CFuzzySet *FuzzySet;
	CFuzzy ResultDOM;
	EFuzzyActivationMethods ActivationMethod;

public:
	CFuzzyResultSet();
	CFuzzyResultSet(const CFuzzySet *NewFuzzySet, const CFuzzy &NewResultDOM, EFuzzyActivationMethods NewActivationMethod);

	virtual CFuzzy GetDegreeOfMembership(float Value) const;
	virtual float GetCharacteristicValue(void) const;
	virtual float GetLeftmostValue(const CFuzzy &DOM, bool &Found) const;
	virtual float GetRightmostValue(const CFuzzy &DOM, bool &Found) const;
	virtual void Update(){}
	
	/// The resulting DOM is a.k.a. the sets's alpha
	const CFuzzy &GetResultDOM(void) const { return ResultDOM; }
	EFuzzyActivationMethods GetActivationMethod(void) { return ActivationMethod; }
};

#endif