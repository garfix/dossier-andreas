#ifndef _FUZZYMODELFCLLOADER
#define _FUZZYMODELFCLLOADER

#include "aiFuzzyModel.h"
#include "aiFuzzyAtom.h"
#include "aiFuzzyPiecewiseLinearSet.h"
#include "generic.h"

using namespace generic;

class CFuzzyModel;

class CFuzzyModelFCLLoader: public CLoader
{
protected:
	CFuzzyModel *Model;

	bool ParsePage(void); 
	bool ParseVar(void);
	bool ParseFuzzify(void);
	bool ParseTerm(CFuzzyVariable *FuzzyVariable);
	bool ParseCoordinates(CFuzzyPiecewiseLinearSet *NewFuzzySet);
	bool ParseDefuzzify(void);
	bool ParseVariableMethod(CFuzzyVariable *FuzzyVariable);
	bool ParseVariableDefault(CFuzzyVariable *FuzzyVariable);
	bool ParseVariableRange(CFuzzyVariable *FuzzyVariable);
	bool ParseRuleblock(void);
	bool ParseRule(CFuzzyRuleblock *Ruleblock);
	bool ParseExpression(CFuzzyNode *&ParsedNode);
	bool ParseExpressionNode(CFuzzyNode *&ParsedNode);
	bool ParseConsequent(CFuzzyRule *FuzzyRule);
	bool ParseConstantOrVariable(CFloat *&Value);
	bool ParseNotOrAtom(CFuzzyNode *&ParsedNode);
	bool CFuzzyModelFCLLoader::ParseAtom(CFuzzyAtom *Atom);
	bool ParseOperatorMethodAnd(CFuzzyRuleblock *Ruleblock);
	bool ParseOperatorMethodOr(CFuzzyRuleblock *Ruleblock);
	bool ParseActivationMethod(CFuzzyRuleblock *Ruleblock);
	bool ParseAccumulationMethod(CFuzzyRuleblock *Ruleblock);

public:
	CFuzzyModelFCLLoader();

	bool Load(CText &Filename, CFuzzyModel *NewModel);

	friend class CTest;
};

#endif