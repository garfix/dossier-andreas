#include "aiFuzzyResultSet.h"
#include "aiFuzzyRuleblock.h"

CFuzzyResultSet::CFuzzyResultSet()
{ 
	FuzzySet = 0; 
	ActivationMethod = ACTIVATIONMETHOD_MIN; 
}

CFuzzyResultSet::CFuzzyResultSet(const CFuzzySet *NewFuzzySet, const CFuzzy &NewResultDOM, EFuzzyActivationMethods NewActivationMethod)
{
	FuzzySet = NewFuzzySet; 
	ResultDOM = NewResultDOM; 
	ActivationMethod = NewActivationMethod;
}

/// Returns the characteristic value of the original set\n
/// The idea is that the characteristic value of a set stays the same after
/// clipping (activation method 'min') or scaling (activation method 'product')
float CFuzzyResultSet::GetCharacteristicValue(void) const 
{ 
	return FuzzySet->GetCharacteristicValue(); 
}

CFuzzy CFuzzyResultSet::GetDegreeOfMembership(float Value) const
{
	CFuzzy DOM;

	// ask the original set
	DOM = FuzzySet->GetDegreeOfMembership(Value);

	if (ActivationMethod == ACTIVATIONMETHOD_MIN)
	{
		// clip 
		if (DOM > ResultDOM) DOM = ResultDOM;
	}
	else if (ActivationMethod == ACTIVATIONMETHOD_PROD)
	{
		// scale
		DOM /= ResultDOM;
	}

	return DOM;
}

/// Returns the leftmost value of this set where the degree of membership equals DOM.\n
/// \param Found returns true if such a value could be found
float CFuzzyResultSet::GetLeftmostValue(const CFuzzy &DOM, bool &Found) const
{
	float Value;
	CFuzzy ActivatedDOM = DOM;

    if (ActivationMethod == ACTIVATIONMETHOD_PROD) 
	{
		// with activationmethod 'product' the DOM is first scaled up
		ActivatedDOM /= DOM;
	}
	else if (ActivationMethod == ACTIVATIONMETHOD_MIN)
	{
		// check if DOM is not above the clipping line
		if (DOM > ResultDOM)
		{
			Found = false;
			return 0;
		}
	}

	Value = FuzzySet->GetLeftmostValue(ActivatedDOM, Found);
	return Value;
}

/// Returns the rightmost value of this set where the degree of membership equals DOM.\n
/// \param Found returns true if such a value could be found
float CFuzzyResultSet::GetRightmostValue(const CFuzzy &DOM, bool &Found) const
{
	float Value;
	CFuzzy ActivatedDOM = DOM;

    if (ActivationMethod == ACTIVATIONMETHOD_PROD) 
	{
		// with activationmethod 'product' the DOM is first scaled up
		ActivatedDOM /= DOM;
	}
	else if (ActivationMethod == ACTIVATIONMETHOD_MIN)
	{
		// check if DOM is not above the clipping line
		if (DOM > ResultDOM)
		{
			Found = false;
			return 0;
		}
	}

	Value = FuzzySet->GetRightmostValue(ActivatedDOM, Found);

	return Value;
}

