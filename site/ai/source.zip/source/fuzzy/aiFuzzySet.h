#ifndef _FUZZYSET 
#define _FUZZYSET

#include "aiFuzzy.h"
#include "generic.h"

using namespace generic;

/// The fuzzy set is a.k.a the membership function
class CFuzzySet: public CElement
{
protected:
	float CharacteristicValue;

public:
  CFuzzySet();

  virtual float GetCharacteristicValue(void) const=0;
  virtual CFuzzy GetDegreeOfMembership(float Value) const=0;
  virtual float GetLeftmostValue(const CFuzzy &DOM, bool &Found) const=0;
  virtual float GetRightmostValue(const CFuzzy &DOM, bool &Found) const=0;

  virtual void Update()=0;
};

#endif