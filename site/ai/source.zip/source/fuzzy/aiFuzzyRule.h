#ifndef _FUZZYRULE
#define _FUZZYRULE

#include "aiFuzzySet.h"
#include "aiFuzzyNode.h"
#include "aiFuzzyAtom.h"
#include "generic.h"

using namespace generic;

class CFuzzyNode;

enum EFuzzyActivationMethods;
enum EFuzzyOperatorMethods;

class CFuzzyRule: public CElement
{
protected:
	// antecedents
	CFuzzyNode *AntecedentRoot;
	// method to combine the antecedents
	CRow<CFuzzyAtom *> Consequents;
	CRow<CFloat *> WeightingFactors;
	EFuzzyActivationMethods ActivationMethod;

public:
	CFuzzyRule();

	void Init(EFuzzyOperatorMethods NewOperatorMethod);

	void SetAntecedentRoot(CFuzzyNode *NewAntecedentRoot){AntecedentRoot = NewAntecedentRoot; }
	void AddConsequent(CFuzzyAtom *NewConsequent, CFloat *NewWeightingFactor){ Consequents.Add(NewConsequent); WeightingFactors.Add(NewWeightingFactor); }

	void SetActivationMethod(EFuzzyActivationMethods NewActivationMethod){ ActivationMethod = NewActivationMethod; }
	EFuzzyActivationMethods GetActivationMethod(void){ return ActivationMethod; }

	void Execute(void);
};

#endif