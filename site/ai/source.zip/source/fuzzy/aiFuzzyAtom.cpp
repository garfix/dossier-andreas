#include "aiFuzzyAtom.h"
#include "aiFuzzySet.h"
#include "aiFuzzyVariable.h"

CFuzzyAtom::CFuzzyAtom()
{
	FuzzyVariable = 0;
	FuzzySet = 0;
}

CFuzzyAtom::CFuzzyAtom(CFuzzyVariable *NewFuzzyVariable, CFuzzySet *NewFuzzySet)
{
	FuzzyVariable = NewFuzzyVariable;
	FuzzySet = NewFuzzySet;
}

/// Calculates DOM (degree of membership) of the crisp value of the variable
/// as it belongs to the set
CFuzzy CFuzzyAtom::CalculateFuzzyValue(void)
{
	assert(FuzzyVariable != 0);
	assert(FuzzySet != 0);
	
	return FuzzySet->GetDegreeOfMembership(FuzzyVariable->GetValue());
}

/// Yields the string 'VARIABLENAME IS SETNAME'
const CText CFuzzyAtom::ToString(void) const 
{
	CText String;

	String += FuzzyVariable->GetName();
	String += " IS ";
	String += FuzzySet->GetName();

	return String;
}