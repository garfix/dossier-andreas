#ifndef _FUZZYMODEL
#define _FUZZYMODEL

#include "aiFuzzyRule.h"
#include "aiFuzzyRuleblock.h"
#include "aiFuzzySet.h"
#include "aiFuzzyPiecewiseLinearSet.h"
#include "aiFuzzySingletonSet.h"
#include "aiFuzzyVariable.h"
#include "aiFuzzyNode.h"
#include "aiFuzzyModelFCLLoader.h"
#include "generic.h"

using namespace generic;

/// What was not implemented:
/// * COA defuzzification method; because it is too complicated for me
/// * BSUM and NSUM accumulation methods: because I have no idea how they should 
///   be implemented (with regard to the defuzzification process that follows it)
///   and I am not even sure what they should do exactly
/// * The OPTIONS / END_OPTIONS block: no idea what the syntax should be

/// Remarks:
/// Each ruleblock can have its own aggregation method
/// How are the results of different ruleblocks to be aggregated?

/// The fuzzy model is a complete system of fuzzy rules and variables. The contents 
/// of a fuzzy model can be loaded from a Fuzzy Control Language file.
class CFuzzyModel: public CElement
{
	CRow<CFuzzyRule *> Rules;
	CRow<CFuzzyVariable *> Variables;
	CRow<CFuzzySet *> Sets;
	CRow<CFuzzyRuleblock *> Ruleblocks;
	CRow<CFuzzyNode *> Nodes;
	CRow<CFloat *> Constants;

public:
	CFuzzyModel();
	~CFuzzyModel();

	bool Load(CText Filename);

	void AddSet(CFuzzySet *NewSet){ Sets.Add(NewSet); }
	void AddRule(CFuzzyRule *NewRule){ Rules.Add(NewRule); }
	void AddRuleblock(CFuzzyRuleblock *NewRuleblock){ Ruleblocks.Add(NewRuleblock); }
	void AddVariable(CFuzzyVariable *NewVariable){ Variables.Add(NewVariable); }
	void AddNode(CFuzzyNode *NewNode){ Nodes.Add(NewNode); }
	void AddConstant(CFloat *NewConstant){ Constants.Add(NewConstant); }

	CFuzzyVariable *GetVariable(const CText &Name) const;

	void Update();
};

#endif