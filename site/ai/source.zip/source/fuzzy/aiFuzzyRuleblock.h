#ifndef _FUZZYRULEBLOCK
#define _FUZZYRULEBLOCK

#include "aiFuzzyRule.h"
#include "aiFuzzyOperator.h"
#include "aiFuzzyResultSet.h"
#include "generic.h"

using namespace generic;

enum EFuzzyAccumulationMethods
{
	ACCUMULATIONMETHOD_MAX,
	ACCUMULATIONMETHOD_BSUM,
	ACCUMULATIONMETHOD_NSUM
};

class CFuzzyRuleblock: public CElement
{
protected:
	EFuzzyOperatorMethods OperatorMethod;
	EFuzzyActivationMethods ActivationMethod;
	EFuzzyAccumulationMethods AccumulationMethod;
	CRow<CFuzzyRule *> Rules;

public:
	CFuzzyRuleblock();

	void AddRule(CFuzzyRule *NewRule){ Rules.Add(NewRule); }
	void Init();

	void SetOperatorMethod(EFuzzyOperatorMethods NewOperatorMethod){ OperatorMethod = NewOperatorMethod; }
	EFuzzyOperatorMethods GetOperatorMethod(void){ return OperatorMethod; }
	
	void SetActivationMethod(EFuzzyActivationMethods NewActivationMethod){ ActivationMethod = NewActivationMethod; }
	EFuzzyActivationMethods GetActivationMethod(void){ return ActivationMethod; }
	
	void SetAccumulationMethod(EFuzzyAccumulationMethods NewAccumulationMethod){ AccumulationMethod = NewAccumulationMethod; }
	EFuzzyAccumulationMethods GetAccumulationMethod(void){ return AccumulationMethod; }
};

#endif