#ifndef _FUZZYOUTPUTSET 
#define _FUZZYOUTPUTSET

#include "aiFuzzyResultSet.h"
#include "generic.h"

using namespace generic;

/// The fuzzy output set that results from applying all rules to a variable
class CFuzzyOutputSet: public CElement
{
protected:
	// an array of DOMs for different sets of this variable
	// a set may occur more than once
	CRow<CFuzzyResultSet> Results;

public:
  CFuzzyOutputSet();

  void Clear(void){ Results.Clear(); }

  void AddResult(const CFuzzySet *Set, CFuzzy &DOM, EFuzzyActivationMethods NewActivationMethod);
  int GetResultCount(void) const { return Results.GetLength(); }
  CFuzzyResultSet &GetResultSet(int Index) const { return Results.Get(Index); }
  void GetMaxResults(CRow<CFuzzyResultSet> &MaxResults);
};

#endif