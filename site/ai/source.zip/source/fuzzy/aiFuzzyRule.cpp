#include "aiFuzzyRule.h"
#include "aiFuzzyNode.h"
#include "aiFuzzyOperator.h"
#include "aiFuzzyVariable.h"
#include "aiFuzzySet.h"

CFuzzyRule::CFuzzyRule():
	Consequents(0), WeightingFactors(0)
{
	AntecedentRoot = 0;
}

/// Ensures all operators in the antecedent will use NewOperatorMethod
void CFuzzyRule::Init(EFuzzyOperatorMethods NewOperatorMethod)
{
	if (AntecedentRoot->IsOperator())
	{
		((CFuzzyOperator *)AntecedentRoot)->SetOperatorMethod(NewOperatorMethod);
	}
}

/// Fires the rule. The output set of all variables in the consequent part
/// of the rule are adjusted
void CFuzzyRule::Execute(void)
{
	CFuzzy Result, WeightedResult;
	int Index;
	const CFuzzySet *Set;
	const CFuzzyVariable *Variable;

	// evaluate the antecedent
	Result = AntecedentRoot->CalculateFuzzyValue();
	
	// if the rule yields some positive result, fire it
	if (Result != 0.0f)
	{
		// update all output sets in the consequents
		for (Index=0; Index < Consequents.GetLength(); Index++)
		{
			// scale by weighting factor
			WeightedResult = Result * WeightingFactors.Get(Index)->GetValue();

			Variable = Consequents.Get(Index)->GetFuzzyVariable();
			Set = Consequents.Get(Index)->GetFuzzySet();
			Variable->GetFuzzyOutputSet()->AddResult(Set, WeightedResult, ActivationMethod);
		}
	}
}
