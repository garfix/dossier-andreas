#ifndef _FUZZYNODE
#define _FUZZYNODE

#include "aiFuzzy.h"
#include "generic.h"

using namespace generic;

/// A node in a fuzzy expression
class CFuzzyNode: public CElement
{
public:
	virtual CFuzzy CalculateFuzzyValue(void)=0;

	bool IsNOT();
	bool IsAND();
	bool IsOR();
	bool IsOperator(void);
};

#endif