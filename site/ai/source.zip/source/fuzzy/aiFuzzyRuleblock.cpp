#include "aiFuzzyRuleblock.h"

CFuzzyRuleblock::CFuzzyRuleblock():
	Rules(0)
{
	OperatorMethod = OPERATORMETHOD_MIN_MAX;
	ActivationMethod = ACTIVATIONMETHOD_MIN;
	AccumulationMethod = ACCUMULATIONMETHOD_MAX;
}

/// takes care that all operators of all rules get the operator method
/// of this ruleblock
void CFuzzyRuleblock::Init()
{
	for(int Index=0; Index<Rules.GetLength(); Index++)
	{
		Rules.Get(Index)->Init(OperatorMethod);
	}
}