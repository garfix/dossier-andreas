#ifndef _FUZZYSINGLETONSET 
#define _FUZZYSINGLETONSET 

#include "aiFuzzySet.h"

/// The fuzzy set is a.k.a the membership function
class CFuzzySingletonSet: public CFuzzySet
{
protected:
	CFloat *Singleton;

public:
	CFuzzySingletonSet(CFloat *NewSingleton){ Singleton = NewSingleton; };

	virtual float GetCharacteristicValue(void) const { return Singleton->GetValue(); }
	virtual CFuzzy GetDegreeOfMembership(float Value) const { return Value == Singleton->GetValue() ? FUZZY_TRUE : FUZZY_FALSE; }
	virtual float GetLeftmostValue(const CFuzzy &DOM, bool &Found) const { Found=true; return Singleton->GetValue(); }
	virtual float GetRightmostValue(const CFuzzy &DOM, bool &Found) const { Found=true; return Singleton->GetValue(); }

	virtual void Update(){};
};

#endif