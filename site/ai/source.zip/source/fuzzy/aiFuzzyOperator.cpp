#include "aiFuzzyOperator.h"
#include "aiFuzzy.h"
#include <math.h>

typedef CFuzzy (CFuzzyOperator::*EvaluationFunction)(CFuzzy &, CFuzzy &);

CFuzzyOperator::CFuzzyOperator(EFuzzyOperatorTypes NewOperatorType):
  Operands(0)
{
	OperatorType = NewOperatorType;
	OperatorMethod = OPERATORMETHOD_MIN_MAX;
}

CFuzzyOperator::~CFuzzyOperator()
{
}

/// Sets the method of performing the operator for itself and all its children
void CFuzzyOperator::SetOperatorMethod(EFuzzyOperatorMethods NewOperatorMethod)
{ 
	OperatorMethod = NewOperatorMethod;

	for(int Index=0; Index<Operands.GetLength(); Index++)
	{
		if (Operands.Get(Index)->IsOperator())
		{
			((CFuzzyOperator *)Operands.Get(Index))->SetOperatorMethod(NewOperatorMethod);
		}
	}
}

/// Aggregation: Performs the fuzzy operator on its operands
/// \return The resulting fuzzy value.
CFuzzy CFuzzyOperator::CalculateFuzzyValue(void)
{
	static const EvaluationFunction EvaluationFunctions [2][3] = 
	{
		{
			&CFuzzyOperator::CalcAndMin,
			&CFuzzyOperator::CalcAndProd,
			&CFuzzyOperator::CalcAndBDif
		},
		{
			&CFuzzyOperator::CalcOrMax,
			&CFuzzyOperator::CalcOrASum,
			&CFuzzyOperator::CalcOrBSum
		}
	};
	CFuzzy OperandValue;

	if (OperatorType == OPERATORTYPE_NOT)
	{
		// NOT requires 1 and only 1 operand
		assert(Operands.GetLength() == 1);

		OperandValue = Operands.Get(0)->CalculateFuzzyValue();
		return CFuzzy(1.0f - OperandValue.GetValue());
	}
	else
	{
		// operands AND and OR
		CFuzzy Value(OperatorType == OPERATORTYPE_AND);

		// they use different evaluation methods
		for (int Index=0; Index<Operands.GetLength(); Index++)
		{
			OperandValue = Operands.Get(Index)->CalculateFuzzyValue();
			Value = (this->*EvaluationFunctions[OperatorType][OperatorMethod])(Value, OperandValue);
		}
		return Value;
	}
}

/// returns a fuzzy value that equals the highest of the 2 parameter values
CFuzzy CFuzzyOperator::CalcOrMax(CFuzzy &Value1, CFuzzy &Value2)
{
	float V1 = Value1.GetValue(); 
	float V2 = Value2.GetValue();

	return CFuzzy(V1 > V2 ? V1 : V2);
}

/// returns a fuzzy value that equals the algebraic sum 
/// of the 2 parameter values
CFuzzy CFuzzyOperator::CalcOrASum(CFuzzy &Value1, CFuzzy &Value2)
{
	float V1 = Value1.GetValue(); 
	float V2 = Value2.GetValue();

	return CFuzzy(V1 + V2 - V1 * V2);
}

/// returns a fuzzy value that equals the bounded sum 
/// of the 2 parameter values
CFuzzy CFuzzyOperator::CalcOrBSum(CFuzzy &Value1, CFuzzy &Value2)
{
	float V1 = Value1.GetValue(); 
	float V2 = Value2.GetValue();
	float BSum = V1 + V2;

	return CFuzzy(BSum < 1.0f ? BSum : 1.0f);
}

/// returns a fuzzy value that equals the minimum of the 2 parameter values
CFuzzy CFuzzyOperator::CalcAndMin(CFuzzy &Value1, CFuzzy &Value2)
{
	float V1 = Value1.GetValue(); 
	float V2 = Value2.GetValue();

	return CFuzzy(V1 < V2 ? V1 : V2);
}

/// returns a fuzzy value that equals the product of the 2 parameter values
CFuzzy CFuzzyOperator::CalcAndProd(CFuzzy &Value1, CFuzzy &Value2)
{
	float V1 = Value1.GetValue(); 
	float V2 = Value2.GetValue();

	return CFuzzy(V1 * V2);
}

/// returns a fuzzy value that equals the bounded difference 
/// of the 2 parameter values
CFuzzy CFuzzyOperator::CalcAndBDif(CFuzzy &Value1, CFuzzy &Value2)
{
	float V1 = Value1.GetValue(); 
	float V2 = Value2.GetValue();
	float BDif = V1 + V2 - 1.0f;

	return CFuzzy(BDif > 0.0f ? BDif : 0.0f);
}

/// Returns the string 'OPERATORNAME(OPERAND1, OPERAND2, ...)'
const CText CFuzzyOperator::ToString(void) const
{
	CText String;
	int Index;

	if (OperatorType == OPERATORTYPE_AND) String += "AND";
	else if (OperatorType == OPERATORTYPE_OR) String += "OR";
	else if (OperatorType == OPERATORTYPE_NOT) String += "NOT";

	String += "(";

	for(Index=0; Index < Operands.GetLength(); Index++)
	{
		String += Operands.Get(Index)->ToString();
		if (Index != Operands.GetLength()-1) String += ", ";
	}

	String += ")";

	return String;
}
