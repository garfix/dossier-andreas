#include "genericLoader.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

namespace generic
{

#define ERROR_NONE "OK"
#define ERROR_FILE_NOT_FOUND_ "File not found"
#define ERROR_READING_FILE "Error reading file."
#define ERROR_WRITING_TO_FILE "Error reading file."
#define ERROR_MISSING_COMMENT_ENDTAG "Missing comment end tag."

#define LOADER_MAX_TOKEN_LENGTH 1024

///////////////////////////////////////////////////////////////////////////////
// SCommentInfo
///////////////////////////////////////////////////////////////////////////////

/// Constructor for a paired comment
SCommentInfo::SCommentInfo(const CText &NewStartTag, const CText &NewEndTag, bool NewNestable)
{
	StartTag = NewStartTag;
	EndTag = NewEndTag;
	Paired = true;
	Nestable = NewNestable;
}

/// Constructor for a rest-of-the-line comment 
SCommentInfo::SCommentInfo(const CText &NewStartTag)
{
	StartTag = NewStartTag;
	Paired = false;
	Nestable = false;
}

SCommentInfo::SCommentInfo(const SCommentInfo &NewCommentInfo)
{
	StartTag = NewCommentInfo.StartTag;
	EndTag = NewCommentInfo.EndTag;
	Paired = NewCommentInfo.Paired;
	Nestable = NewCommentInfo.Nestable;
}

const SCommentInfo &SCommentInfo::operator=(const SCommentInfo &NewCommentInfo)
{
	StartTag = NewCommentInfo.StartTag;
	EndTag = NewCommentInfo.EndTag;
	Paired = NewCommentInfo.Paired;
	Nestable = NewCommentInfo.Nestable;

	return *this;
}

///////////////////////////////////////////////////////////////////////////////
// CLoader
///////////////////////////////////////////////////////////////////////////////

CLoader::CLoader():
	Operators(0), CommentInfos(0)
{
	Error = ERROR_NONE;
	Token.Allocate(LOADER_MAX_TOKEN_LENGTH);
	SetWhitespaceChars("\t\n ");
	SetCaseSensitive(true);

	Reset();
}

/// Is the character a digit (0..9)?
bool CLoader::IsDigit(char Char)
{
	return ((Char >= '0') && (Char <= '9'));
}

bool CLoader::IsCommentStartTag(const CText &String)
{
	for(int Index=0; Index < CommentInfos.GetLength(); Index++)
	{
		if (CommentInfos.Get(Index).StartTag == String) return true;
	}

	return false;
}

/// Returns the next character in the Source string.\n
/// Turns the character into uppercase if the loader is not case sensitive.\n
/// Sets the variable 'Done' to true if the end of the Source string was reached.
char CLoader::GetChar()
{
	char Char = Source.Get(SourceIndex);
	if (Char == '\0') Done = true;
	if (!CaseSensitive) 
	{
		if ((Char >= 'a') && (Char <= 'z')) Char += ('A' - 'a');
	}
	return Char;
}

/// Tries to parse a floating point number from the Source string at the 
/// current position SourceIndex. The number should have the form a[.b]\n
/// if a dot is present, it should be followed by digits. The float should
/// always start with a digit. The dot is not obligatory.\n
/// If the parse is successful, Token contains the parsed float, and SourceIndex 
/// is increased to the position just after the float.
bool CLoader::TryParseFloat(void)
{
	char Char;
	bool Success = false;
	int OldSourceIndex = SourceIndex;
	int FloatLength;

	// -
	Char = GetChar();
	if (Char == '-') 
	{
		SourceIndex++;
		Char = GetChar();
	}

	// number of digits
	while (IsDigit(Char))
	{
		// we can now speak of a float
		Success = true; 

		SourceIndex++;
		Char = GetChar();
	}

	// dot
	if (Success && (Char == '.'))
	{
		// we now have a number of digits and a dot;
		// is the dot followed by a digit?
		SourceIndex++;
		Char = GetChar();
		if (IsDigit(Char))
		{
			// the dot is followed by a digit, so the dot
			// is part of the float

			// number of digits
			SourceIndex++;
			Char = GetChar();
			while (IsDigit(Char))
			{
				SourceIndex++;
				Char = GetChar();
			}
		}
		else
		{
			// the dot is not part of the float
			SourceIndex--;
		}
	}

	if (Success)
	{
		// copy into token
		FloatLength = SourceIndex - OldSourceIndex;
		Token.Clear();
		Token.SetLength(FloatLength);
		strncpy(Token.GetBuffer(), Source.GetBuffer() + OldSourceIndex, FloatLength);
	}
	else
	{
		SourceIndex = OldSourceIndex;
	}

	return Success;
}

/// Tries to parse an operator as defined in Operators.\n
/// If the parse is succesful, SourceIndex contains the position just after the 
/// operator and Token contains the operator.
bool CLoader::TryParseOperator(void)
{
	for (int Index=0; Index<Operators.GetLength(); Index++)
	{
		const CText &Operator = Operators.Get(Index);
		if (strncmp(Operator.GetBuffer(), Source.GetBuffer() + SourceIndex, Operator.GetLength()) == 0) 
		{
			Token.Clear();
			Token += Operator;
			SourceIndex += Operator.GetLength();
			return true;
		}
	}

	return false;
}

/// Skip any whitespace characters in Source, and increasing SourceIndex
/// \return Was there any white space?
bool CLoader::ParseWhitespace(void)
{
	char Char;
	bool WhiteSpaceAvailable = false;

	Char = GetChar();
	while (!Done && IsWhitespace(Char))
	{
		WhiteSpaceAvailable = true;
		if (Char == '\n') LineNumber++;
		SourceIndex++;
		Char = GetChar();
	}

	return WhiteSpaceAvailable;
}

/// used by HasNext() to determine if the following characters are all whitespace, and do not
/// include a token
bool CLoader::OnlyWhitespaceFollows(void)
{
	char Char;
	bool AllWhitespace = true;
	int Index = SourceIndex;

	Char = Source.Get(Index);
	while (Char != '\0')
	{
		if (!IsWhitespace(Char))
		{
			AllWhitespace = false;
			break;
		}

		Index++;
		Char = Source.Get(Index);
	}

	return AllWhitespace;
}

/// Tries to parse a start tag of a comment
/// \param CommentInfo Output parameter that holds information about the
///   type of comment that was parsed.
/// \return Was a comment parsed?
bool CLoader::TryParseCommentStartTag(SCommentInfo *&CommentInfo)
{
	for (int Index=0; Index<CommentInfos.GetLength(); Index++)
	{
		const SCommentInfo &Info = CommentInfos.Get(Index);

		// does the start tag equal the following chacters is Source?
		if (strncmp(Info.StartTag.GetBuffer(), Source.GetBuffer() + SourceIndex, Info.StartTag.GetLength()) == 0) 
		{
			// return comment information
			CommentInfo = &CommentInfos.Get(Index);

			// parse start tag
			Token.Clear();
			Token += Info.StartTag;
			SourceIndex += Info.StartTag.GetLength();
			return true;
		}
	}

	return false;
}

/// Tries to parse a end tag of a comment
/// \return Was a comment parsed?
bool CLoader::TryParseCommentEndTag(void)
{
	for (int Index=0; Index<CommentInfos.GetLength(); Index++)
	{
		const SCommentInfo &Info = CommentInfos.Get(Index);

		// does the comment type have an end tag?
		if (!Info.Paired) continue;

		// does the end tag equal the following chacters is Source?
		if (strncmp(Info.EndTag.GetBuffer(), Source.GetBuffer() + SourceIndex, Info.EndTag.GetLength()) == 0) 
		{
			// parse end tag
			Token.Clear();
			Token += Info.EndTag;
			SourceIndex += Info.EndTag.GetLength();
			return true;
		}
	}

	return false;
}

/// Skip all characters belonging to the comment of type CommentInfo.
/// The start tag of this comment should have been parsed previously
/// \return was the comment wellformed?
bool CLoader::ParseComment(SCommentInfo *CommentInfo)
{
	char Char;
	int NestingDepth = 1;

	// Paired?
	if (CommentInfo->Paired)
	{
		// Nestable?
		if (CommentInfo->Nestable)
		{
			// Nestable: parse until end tag; check if a nested comment starts
			NextToken(false);
			while (!Done)
			{
				if (Token == CommentInfo->EndTag)
				{
					NestingDepth--;
					if (NestingDepth == 0) break;
				} 
				else if (Token == CommentInfo->StartTag)
				{
					NestingDepth++;
				}
				NextToken(false);
			}
			if (Done)
			{ 
				// no end tag could be found in Source
				Token.Clear();
				Error = ERROR_MISSING_COMMENT_ENDTAG; return false; 
			}
		}
		else
		{
			// Not Nestable: parse all tokens until the end tag
			NextToken(false);
			while (Token != CommentInfo->EndTag)
			{
				NextToken(false);
			}
		}
	}
	else
	{
		// skip till end of line
		Char = Source.Get(SourceIndex);
		while((Char != '\n') && (Char != '\0'))
		{
			SourceIndex++;
			Char = Source.Get(SourceIndex);
		}
		SourceIndex++;
	}

	return true;
}

void CLoader::Reset(void)
{
	Done = false;
	SourceIndex = 0;
	LineNumber = 1;
	Error = ERROR_NONE;
}

/// A repeated calling of this function results all the tokens of the Source string.
/// The token is taken from Source starting from position SourceIndex.
/// Returning from the function, SourceIndex is increased by the length of the
/// token found.\n 
/// Firsty, any Whitespace characters are skipped.
/// Then all Operators are attempted to be parsed.
/// Then a floating point number is attempted.
/// Then a Punctuation character is attempted.
/// Then a comment is attempted and skipped (if SkipComments is true);
/// if one was found, the process is repeated from the start.
/// Then any string is parsed until either a Whitespace char or a Punctuation
/// char is reached. The token found is placed in the member string Token.
/// \param SkipComments Should comment tags and comment contents be skipped?
/// \return A reference to Token.
CText CLoader::NextToken(bool SkipComments)
{
	char Char;
	int TokenIndex = 0;
	bool CommentParsed;
	SCommentInfo *CommentInfo;

	// if comments should be skipped, repeat this process as long as the token
	// found is not a comment starttag
	do
	{
		// parse whitespace (if any)
		ParseWhitespace();

		// try to parse (skip) comment (if any)
		CommentParsed = false;
		if (TryParseCommentStartTag(CommentInfo))
		{
			// if comment tags should be considered like tokens, return the start tag
			if (!SkipComments) return Token;
			
			// parse the comment and return "" if no end tag could be found
			if (!ParseComment(CommentInfo)) return Token;

			CommentParsed = true;
			continue;
		}

		// try to parse a comment end tag
		if (TryParseCommentEndTag()) continue;

		// try to parse one of the operators
		if (TryParseOperator()) continue;

		// try to parse a floating point number
		if (TryParseFloat()) continue;

		// punctuation character?
		Char = GetChar();
		if (IsPunctuationChar(Char))
		{
			Token.SetLength(TokenIndex+1);
			Token.Set(TokenIndex, Char);
//			Token.Set(TokenIndex+1, '\0');
			SourceIndex++;
		}
		else
		{
			// other token
			while (!Done && !IsWhitespace(Char) && !IsPunctuationChar(Char))
			{
				Token.SetLength(TokenIndex+1);
				Token.Set(TokenIndex, Char);
				TokenIndex++;
				SourceIndex++;
				Char = GetChar();
			}
//			Token.Set(TokenIndex, '\0');
//			Token.SetLength(TokenIndex);
		}
	}
	while (SkipComments && CommentParsed);

	return Token;
}

/// Same functionality as NextToken(), except that neither SourceIndex nor Done
/// are changed after this call. It is meant to peek into the next token without 
/// actually progressing the parse.
CText &CLoader::LookAhead(void)
{
	int OldIndex = SourceIndex;
	bool OldDone = Done;

	NextToken();

	SourceIndex = OldIndex;
	Done = OldDone;

	return Token;
}

bool CLoader::HasNext(void)
{
	// if nothing follows, or only whitespace, return false
	return (!OnlyWhitespaceFollows());
}

bool CLoader::IsSuccessful(void) const 
{ 
	return (Error == ERROR_NONE); 
}

void CLoader::SetWhitespaceChars(const CText &NewWhitespaceChars)
{
	WhitespaceChars = NewWhitespaceChars;
}

bool CLoader::IsWhitespace(char Char)
{
	return WhitespaceChars.Contains(Char);
}

void CLoader::SetPunctuationChars(const CText &NewPunctuationChars)
{
	PunctuationChars = NewPunctuationChars;
}

bool CLoader::IsPunctuationChar(char Char)
{
	return PunctuationChars.Contains(Char);
}

bool CLoader::IsOperator(CText &String)
{
	return (Operators.Contains(String));
}

/// Reads the file by name Filename into the member string Source.
/// If the file was not found th member Error contains a message.
/// \return Could the file be loaded into the string?
bool CLoader::ReadFile(const CText &Filename)
{
	FILE *File;
	int FileLength, Length;

	if (!(File = fopen((const char*)Filename.GetBuffer(), "rt"))) 
	{	
		Error = ERROR_FILE_NOT_FOUND_;
		return false;
	}

	fseek(File, 0, SEEK_END);
	FileLength = ftell(File);
	fseek(File, 0, SEEK_SET);
	Source.Allocate(FileLength+1);

	Length = (int)fread(Source.GetBuffer(), 1, FileLength, File);
	if (ferror(File)){ Error = ERROR_READING_FILE; return false; }
	Source.SetLength(Length);

	Reset();

	return true;
}

/// Copies String into Source
void CLoader::ReadString(const CText &String)
{
	Source = String;

	Reset();
}

bool CLoader::IsIdentifier(const CText &String)
{
	if (String.GetLength() == 0) return false;

	return (isalpha(String.Get(0)) != 0);
}

}
