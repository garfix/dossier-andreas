#include "genericFloat.h"

namespace generic
{
	
CFloat::CFloat()
{
	Value = 0.0f;
}

CFloat::CFloat(float NewValue)
{
	Value = NewValue;
}

float CFloat::GetValue(void) const
{
	return Value;
}

}
