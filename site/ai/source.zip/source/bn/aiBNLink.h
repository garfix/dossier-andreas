#ifndef _BNLINK
#define _BNLINK

#include "generic.h"

using namespace generic;

class CBNVariable;

/// A link represents the causal relation between two variables Source and Target.
/// The link contains the conditional probabilities for every two possible variable value
/// combinations of the variables Source and Target.

/// A change in PriorProbability or Likelihood is immediately propagated throughout the network.

class CBNLink: public CElement
{
protected:
	/// The source, or cause variable
	CBNVariable *Source;
	/// The target, or effect variable
	CBNVariable *Target;
	/// The conditional probability matrix: 
	/// each value [SourceIndex, TargetIndex] stands for P(SourceIndex | TargetIndex).
	CArray2<float> ConditionalProbabilities;
	/// Prior probabilities of all values (a.k.a. pi)
	CArray<float> PriorProbability;
	/// Likelihood of all values (a.k.a. lambda)
	CArray<float> Likelihood;
	
public:
	CBNLink(CBNVariable *NewSource, CBNVariable *NewTarget);

	void SetConditionalProbability(int SourceDomainIndex, int TargetDomainIndex, float Probability);
	/// void SetConditionalProbabilities(...
	//void SetPriorProbability(CArray<float> &NewPriorProbability);
};

#endif