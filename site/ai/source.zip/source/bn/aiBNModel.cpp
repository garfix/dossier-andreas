#include "aiBNModel.h"

CBNModel::CBNModel()
{
}

CBNModel::~CBNModel()
{
	Variables.DeleteContents();
	VariableDomains.DeleteContents();
}

CBNVariable *CBNModel::GetVariable(const CString &Name) const
{
	for (int Index=0; Index < Variables.GetLength(); Index++)
	{
		if (Variables.Get(Index)->GetName() == Name) return Variables.Get(Index);
	}

	return 0;
}
