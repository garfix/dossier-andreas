#include "aiBNVariableValue.h"

CBNVariableValue::CBNVariableValue(float NewFloatValue)
{
	FloatValue = NewFloatValue;
}

CBNVariableValue::CBNVariableValue(const CString &NewName)
{
	FloatValue = 0.0f;
	SetName(NewName);
}
