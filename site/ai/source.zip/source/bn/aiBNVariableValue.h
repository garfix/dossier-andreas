#ifndef _BNVARIABLEVALUE
#define _BNVARIABLEVALUE

#include "generic.h"

using namespace generic;

/// This is one of the values of a variable. It is only addressed by its index in the 
/// variable domain. It has a name and a floating point value. None of these needs ever
/// to be used.

class CBNVariableValue: public CElement
{
protected:
	float FloatValue;

public:
	CBNVariableValue(float NewFloatValue);
	CBNVariableValue(const CString &NewName);

	float GetFloatValue(void) const { return FloatValue; }
};

#endif