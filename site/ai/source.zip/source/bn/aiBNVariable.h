#ifndef _BNVARIABLE
#define _BNVARIABLE

#include "generic.h"

using namespace generic;

class CBNVariableDomain;
class CBNNode;
class CBNVariableValue;

/// A so called Random, or Discrete Variable.
/// Its value is taken from some Domain of possible values.

class CBNVariable: public CElement
{
protected:
	/// Domain: the set of possible values
	CBNVariableDomain *Domain;
	CArray<CBNLink *> Parents;
	CArray<CBNLink *> Children;
	/// Causal Support of all values (a.k.a. pi)
	CArray<float> CausalSupport;
	/// Diagnostic Support of all values (a.k.a. lambda)
	CArray<float> DiagnosticSupport;
	/// Belief for all values (a.k.a. BEL)
	CArray<float> Belief;

	float GetCausalSupportRecursive(CArray<int> &Indices, int ParentIndex);

	void UpdateCausalSupport(void);
	void UpdateDiagnosticSupport(void);

public:
	CBNVariable(const CString &NewName, CBNVariableDomain *NewDomain);
	~CBNVariable();

	CBNVariableDomain *GetDomain(void) const { return Domain; }

	// parents
	void AddParent(CBNLink* NewParent);
	bool HasParents(void) const { return (Parents.GetLength() != 0); }
	int GetParentCount(void) const { return Parents.GetLength(); }
	CBNVariable *GetParent(int Index) const { return Parents.Get(Index); }

	// children
	void AddChild(CBNVariable* NewChild);
};

#endif