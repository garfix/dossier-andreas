#include "aiBNVariable.h"
#include "aiBNVariableDomain.h"

CBNVariable::CBNVariable(const CString &NewName, CBNVariableDomain *NewDomain)
{
	Name = NewName;
	Domain = NewDomain;
}

CBNVariable::~CBNVariable()
{
}

/// scales Values, so that they sum to 1
float CBNVariable::Normalize(CArray<float> &Values)
{
	float Sum = 0.0f;

	// calculate the sum of all values
	for (int Index=0; Index < Values.GetLength(); Index++) Sum += Values.Get(Index);

	// special case
	if (Sum == 0.0f) return;

	// divide all values by sum
	for (int Index=0; Index < Values.GetLength(); Index++) Values.Set(Index, Values.Get(Index) / Sum);
}

float CBNVariable::GetCausalSupportRecursive(CArray<int> &Indices, int ParentIndex)
{
	CBNVariable *Parent = Parents.Get(ParentIndex);
	float CausalSupport = 0.0f;

	for (int ValueIndex=0; ValueIndex < Parent->GetDomain()->GetValueCount(); ValueIndex++)
	{
		Indices.Set(ParentIndex, ValueIndex);

		// causal support product
		CausalSupportProduct = 1.0f;
		for (int ParentIndex=0; ParentIndex < GetParentCount(); ParentIndex++)
		{
			CausalSupportProduct *= GetParentLink(ParentIndex)->GetCausalSupport();
		}

		CausalSupport += PriorProbability(Indices) * CausalSupportProduct;

		if (ParentIndex < GetParentCount()) 
		{
			CausalSupport += GetCausalSupportRecursive(Indices, ParentIndex+1);
		}
	}

	return CausalSupport;
}

/// updates the causal support (pi) for all possible values of the variable
void CBNVariable::UpdateCausalSupport(void)
{
	float SingleCausalSupport;
	CArray<int> Indices(Domain->GetValueCount());

	// consider all possible values of the variable
	for (int ValueIndex=0; ValueIndex < Domain->GetValueCount(); ValueIndex++)
	{
		SingleCausalSupport = 0.0f;
		//for (int Index=0; Index < Parents.GetLength(); Index++)
		//{
		Indices.Fill(0.0f);

		// calculate probability of the value given the values of all parents
		SingleCausalSupport = UpdateCausalSupportRecursive(Indices, 0);

		//}
		CausalSupport.Set(ValueIndex, SingleCausalSupport);
}

/// Updates the diagnostic support (lambda) for all possible values of the variable
void CBNVariable::UpdateDiagnosticSupport(void)
{
	float DiagnosticSupport;

	// consider all possible values of the variable
	for (int ValueIndex=0; ValueIndex < Domain->GetValueCount(); ValueIndex++)
	{
		SingleDiagnosticSupport = 1.0f;
		for (int Index=0; Index < Children.GetLength(); Index++)
		{
			SingleDiagnosticSupport *= (Children.Get(Index))->GetDiagnosticSupport();
		}
		DiagnosticSupport.Set(ValueIndex, SingleDiagnosticSupport);
	}
}

void CBNVariable::UpdateParentDiagnosticSupport(CBNLink *ParentLink)
{
	float DiagnosticSupport = 0.0f;

	// consider all possible values of the variable
	for (int ValueIndex=0; ValueIndex < Domain->GetValueCount(); ValueIndex++)
	{
		SingleDiagnosticSupport = DiagnosticSupport.Get(ValueIndex);

		
	}

	ParentLink->SetDiagnosticSupport(DiagnosticSupport);
}

void CBNVariable::Update(void)
{
	// Likelihood
	UpdateDiagnosticSupport();

	// update Prior Probability
	UpdateCausalSupport();

	// update Belief
	for (int Index=0; Index < GetValueCount(); Index++)
		Belief.Set(Index, DiagnosticSupport.Get(Index) * CausalSupport.Get(Index));
	
	// normalize (alpha)
	Normalize(Belief);

	// bottom-up propagation
	// creates the 'messages' lambda for the parents
	for (int Index=0; Index < Parents.GetLength(); Index++)
	{
		UpdateParentDiagnosticSupport(ParentLinks.Get(Index));
	}

	// top-down propagation
	// creates the 'messages' pi for the children
	for (int Index=0; Index < Children.GetLength(); Index++)
	{
		SetChildCausalSupport(ChildrenLinks.Get(Index));
	}
}

/// Is equivalent with sending the message 'pi'.
void CBNVariable::NotifyChangeInPriorProbability(void)
{
	// update
	Update();

	// update all child links
	for (int Index=0; Index < Children.GetLenght(); Index++)
	{
		Children.Get(Index)->GetTarget()->NotifyChangeInPriorProbability();
	}
}

/// Is equivalent with sending the message 'lambda'.
void CBNVariable::NotifyChangeInLikelihood(void)
{
	// update
	Update();

	// pass message to all parents
	for (int Index=0; Index < Parents.GetLenght(); Index++)
	{
		Parents.Get(Index)->GetSource()->NotifyChangeInLikelihood();
	}

	// pass message to all children
	for (int Index=0; Index < Children.GetLenght(); Index++)
	{
		Children.Get(Index)->GetTarget()->NotifyChangeInPriorProbability();
	}
}

void CBNVariable::AddParent(CBNLink* NewParent)
{
	Parents.Add(NewParent);
}
