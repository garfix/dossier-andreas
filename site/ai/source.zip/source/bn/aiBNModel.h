#ifndef _BNMODEL
#define _BNMODEL

#include "generic.h"
#include "aiBNVariableDomain.h"
#include "aiBNVariable.h"
#include "aiBNVariableValue.h"

using namespace generic;

/// The model for a Belief Network (or Bayesian Network).

class CBNModel: public CElement
{
protected:
	CArray<CBNVariable *> Variables;
	CArray<CBNVariableDomain *> VariableDomains;

public:
	CBNModel();
	~CBNModel();

	void AddVariable(CBNVariable *NewVariable){ Variables.Add(NewVariable); }
	void AddVariableDomain(CBNVariableDomain *NewVariableDomain){ VariableDomains.Add(NewVariableDomain); }

	CBNVariable *GetVariable(const CString &Name) const;
};

#endif