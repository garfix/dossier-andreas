#include "aiBNLink.h"
#include "aiBNVariable.h"
#include "aiBNVariableDomain.h"

CBNLink::CBNLink(CBNVariable *NewSource, CBNVariable *NewTarget)
{
	int Width, Height;

	Source = NewSource;
	Target = NewTarget;

	Width = Source->GetDomain()->GetValueCount();
	Height = Target->GetDomain()->GetValueCount();
	ConditionalProbabilities.SetDimension(Width, Height);
}

/// Set the conditional probability for two values of Source and Target.
/// The variable values are given by index in the variable domain, since this
/// is the way they will usually be stored (in an array).
void CBNLink::SetConditionalProbability(int SourceDomainIndex, int TargetDomainIndex, float Probability)
{
	ConditionalProbabilities.Set(SourceDomainIndex, TargetDomainIndex, Probability);
}

//void CBNLink::SetPriorProbability(CArray<float> &NewPriorProbability)

/*void CBNLink::SetLikelihood(CArray<float> &NewLikelihood)
{
	// there should be a prior probability for every value of Source
	assert(NewLikelihood.GetLength() == Source->GetDomain()->GetValueCount());

	// store new values
	Likelihood = NewLikelihood;

	// send message 'lambda' to Source
	Source->NotifyChangeInLikelihood(this, NewLikelihood);
}*/

/*/// Is equivalent with the message 'pi'.
void CBNVariable::NotifyChangeInPriorProbability(void)
{

}

/// Is equivalent with the message 'lambda'.
void CBNLink::NotifyChangeInLikelihood(void)
{

}*/
