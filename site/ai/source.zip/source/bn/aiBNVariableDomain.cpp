#include "aiBNVariableDomain.h"
#include "aiBNVariableValue.h"

CBNVariableDomain::~CBNVariableDomain()
{ 
	Values.DeleteContents(); 
}

CBNVariableValue *CBNVariableDomain::GetValue(const CString &Name) const
{
	for (int Index=0; Index < Values.GetLength(); Index++)
	{
		if (Values.Get(Index)->GetName() == Name) return Values.Get(Index);
	}

	return 0;
}
