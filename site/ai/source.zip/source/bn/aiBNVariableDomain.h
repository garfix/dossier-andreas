#ifndef _BNVARIABLEDOMAIN
#define _BNVARIABLEDOMAIN

#include "generic.h"

using namespace generic;

class CBNVariableValue;

/// The domain of a variable contains all possible values a variable can have.
/// A variable will address the values by an index into this domain's value array.

class CBNVariableDomain: public CElement
{
protected:
	CArray<CBNVariableValue *> Values;

public:
	~CBNVariableDomain();

	void AddValue(CBNVariableValue *NewValue){ Values.Add(NewValue); }

	int GetValueCount(void) const { return Values.GetLength(); }
	CBNVariableValue *GetValue(int Index) const { return Values.Get(Index); }
	CBNVariableValue *GetValue(const CString &Name) const;
};

#endif
