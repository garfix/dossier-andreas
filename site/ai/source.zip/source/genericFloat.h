#ifndef _FLOAT
#define _FLOAT

#include "genericElement.h"
#include <float.h>

namespace generic
{
	
class CFloat: public CElement
{
protected:
	float Value;

public:
	CFloat();
	CFloat(float NewValue);

	void SetValue(float NewValue){ Value = NewValue; }
	float GetValue(void) const;

	static float GetMinimum(void){ return -FLT_MAX; }
	static float GetMaximum(void){ return FLT_MAX; }
};

}

#endif