#include "aiDTAttribute.h"

CDTAttribute::CDTAttribute(const CText &Name)
{
	SetName(Name);
}

/// Only the value is given. No name is given to the attribute value.
void CDTAttribute::AddValue(int NewValue)
{
	AddValue(NewValue, "");
}

/// Only the name is given. A unique value is made up for the attribute value.
void CDTAttribute::AddValue(const CText &NewValueName)
{
	AddValue(Values.GetLength(), NewValueName);
}

/// Both name and value are given
void CDTAttribute::AddValue(int NewValue, const CText &NewValueName)
{
	Values.Add(NewValue);
	ValueNames.Add(NewValueName);
}
