#include "aiDTExample.h"

CDTExample::CDTExample(CDTObject *NewObject, bool NewDecision)
{
	Object = NewObject;
	Decision = NewDecision;
}