#include <assert.h>
#include "aiDTModel.h"
#include "aiDTExample.h"
#include "aiDTAttribute.h"

CDTModel::CDTModel(int NewAttributeCount):
	Attributes(NewAttributeCount)
{
	// create empty values for attributes
	for (int Index=0; Index < Attributes.GetLength(); Index++)
	{
		Attributes.Set(Index, 0);
	}
}

CDTModel::~CDTModel()
{
	Attributes.DeleteContents();
	Examples.DeleteContents();
	Objects.DeleteContents();
}

/// Checks if the decision (classification) of all examples in Examples is the same.
/// \Decision the decision (only valid if the return value is true)
/// \return are all decisions the same?
bool CDTModel::DoAllExamplesHaveSameDecision(const CRow<CDTExample *> &Examples, bool &Decision) const
{
	// Examples may be assumed nonempty
	assert(!Examples.IsEmpty());

	// find the first decision
	Decision = Examples.Get(0)->GetDecision();
	
	// check if all examples have the same classification (as the first example)
	for (int Index=1; Index < Examples.GetLength(); Index++)
	{
		if (Examples.Get(Index)->GetDecision() != Decision) return false;
	}

	return true;
}

/// Returns the value of the goal attribute that is most frequent in the examples.
/// \returns 'false' if less than half the decisions is false, otherwise, 'true'
bool CDTModel::GetMajority(const CRow<CDTExample *> &Examples) const
{
	// create an array for the number of examples that support each value of the goal attribute
	int FalseCount = 0;
	int TrueCount = 0;

	// Examples may be assumed nonempty
	assert(!Examples.IsEmpty());

	// count all true and false decisions
	for (int Index=0; Index < Examples.GetLength(); Index++)
	{
		if (Examples.Get(Index)->GetDecision() == true) TrueCount++; else FalseCount++;
	}

	return (TrueCount >= FalseCount);
}

/// Returns the information content of two probabilities (positive and negative)
/// I(P1, P2, ...) = sum[n=1...](-Pn*log(Pn))
float CDTModel::GetInformationContent(float ProbabilityPositiveDecision, float ProbabilityNegativeDecision) const
{
	float InformationContent;

	// special case: if one of the possibilities is 0, no information can be gained
	// (is also necessary, because the log functions cannot deal with 0 numbers)
	if ((ProbabilityPositiveDecision == 0.0f) || (ProbabilityNegativeDecision == 0.0f))
	{
		 return 0.0f;
	}

	// calculate information content
	InformationContent = 
		-(ProbabilityPositiveDecision * CMath::LogN(2.0f, ProbabilityPositiveDecision)) +
		-(ProbabilityNegativeDecision * CMath::LogN(2.0f, ProbabilityNegativeDecision));

	return InformationContent;
}

/// Returns the Remainder value of an attribute, a necessary component to calculate the Gain.
float CDTModel::GetRemainder(const CDTAttribute *Attribute, int AttributeIndex, const CRow<CDTExample *> &Examples) const
{
	CDTExample *Example;
	float Remainder = 0.0f;
	int Value;
	int PositiveCount, NegativeCount, TotalCount;
	float ValueProbability;
	float ProbabilityPositiveDecision;
	float ProbabilityNegativeDecision;
	float InformationContent;

	// go through all values of the attribute
	for (int ValueIndex=0; ValueIndex < Attribute->GetValueCount(); ValueIndex++)
	{
		// get the attribute value
		Value = Attribute->GetValue(ValueIndex);
		
		// count positive and negative decisions
		PositiveCount = 0;
		NegativeCount = 0;
		for (int Index=0; Index < Examples.GetLength(); Index++)
		{
			Example = Examples.Get(Index);
			if (Example->GetObject()->GetAttributeValue(AttributeIndex) == Value)
			{
				if (Example->GetDecision())	PositiveCount++; else NegativeCount++;
			}
		}

		// the number of times the attribute value occurs in the Examples
		TotalCount = PositiveCount + NegativeCount;

		// if the value does not occur in the examples, we can skip the rest
		// (this is also necessary to avoid bad calculations)
		if (TotalCount == 0) continue;

		// calculate possibilities
		ProbabilityPositiveDecision = (float)PositiveCount / (float)TotalCount;
		ProbabilityNegativeDecision = (float)NegativeCount / (float)TotalCount;

		// the probability of the attribute value in the Examples
		ValueProbability = (float)TotalCount / (float)Examples.GetLength();

		// calculate the information content for this attribute value
		InformationContent = GetInformationContent(ProbabilityPositiveDecision, ProbabilityNegativeDecision);

		// calculate Remainder
		Remainder += ValueProbability * InformationContent;
	}

	return Remainder;
}

/// Returns the Gain value of an Attribute.
float CDTModel::GetGain(const CDTAttribute *Attribute, int AttributeIndex, const CRow<CDTExample *> &Examples) const
{
	int PositiveCount=0;
	int NegativeCount=0;
	float ProbabilityPositiveDecision;
	float ProbabilityNegativeDecision;
	float InformationContent, Gain, Remainder;

	// count positive and negative decisions
	for (int Index=0; Index < Examples.GetLength(); Index++)
	{
		if (Examples.Get(Index)->GetDecision()) PositiveCount++; else NegativeCount++;
	}

	// calculate probabilities
	ProbabilityPositiveDecision = (float)PositiveCount / (float)Examples.GetLength();
	ProbabilityNegativeDecision = (float)NegativeCount / (float)Examples.GetLength();

	// calculate remainder and information
	Remainder = GetRemainder(Attribute, AttributeIndex, Examples);
	InformationContent = GetInformationContent(ProbabilityPositiveDecision, ProbabilityNegativeDecision);

	// Gain = I( p / (p+n) ), (n / (p+n) ) )
	Gain = InformationContent - Remainder;

	return Gain;
}

/// Returns the index of the attribute that is most informative in the decision tree.
int CDTModel::ChooseMostImportantAttribute(const CRow<CDTExample *> &Examples, CRow<bool> &AttributeAvailable) const
{
	CDTAttribute *Attribute;
	float Gain;
	float MaxGain = -100000.0f;
	int MostImportantAttribute = -1;

	// assume there are attributes
	assert(Attributes.GetLength() > 0);

	// go through all attributes
	for (int AttributeIndex=0; AttributeIndex < Attributes.GetLength(); AttributeIndex++)
	{
		// if the attribute is no longer applicable, skip it
		if (!AttributeAvailable.Get(AttributeIndex)) continue;

		// fetch attribute
		Attribute = Attributes.Get(AttributeIndex);

		// get gain
		Gain = GetGain(Attribute, AttributeIndex, Examples);

		// select attribute with highest information Gain
		if (Gain > MaxGain)
		{
			MaxGain = Gain;
			MostImportantAttribute = AttributeIndex;
		}
	}

	return MostImportantAttribute;
}

/// Returns true if AttributeAvailable contains at least one value 'true'.
/// \AttributeAvailable An array that represents the active attributes.
bool CDTModel::HasAvailableAttributes(CRow<bool> &AttributeAvailable) const
{
	for (int Index=0; Index < Attributes.GetLength(); Index++)
	{
		if (AttributeAvailable.Get(Index)) return true;
	}

	return false;
}

CDTDecisionTree *CDTModel::LearnDecisionTree(const CRow<CDTExample *> &Examples, CRow<bool> &AttributeAvailable, bool DefaultDecision) const
{
	bool Decision;
	int MostImportantAttributeIndex;
	CDTAttribute *MostImportantAttribute;
	CDTDecisionTree *DecisionTree;
	CDTDecisionTree *SubTree;
	CDTExample *Example;
	int Value;

	// create the tree
	DecisionTree = new CDTDecisionTree();

	if (Examples.IsEmpty())
	{
		// leaf: there are no examples
		DecisionTree->SetDecision(DefaultDecision);
	}
	else if (DoAllExamplesHaveSameDecision(Examples, Decision))
	{
		// leaf: all examples have the same classification
		DecisionTree->SetDecision(Decision);
	}
	else if (!HasAvailableAttributes(AttributeAvailable))
	{
		// leaf: there are no attributes
		DecisionTree->SetDecision(GetMajority(Examples));
	}
	else
	{
		// the tree has subtrees (branches)

		// find the most important attribute
		MostImportantAttributeIndex = ChooseMostImportantAttribute(Examples, AttributeAvailable);

		// fetch the matching attribute
		MostImportantAttribute = Attributes.Get(MostImportantAttributeIndex);

		// set the attribute index of the tree
		DecisionTree->SetAttribute(MostImportantAttribute);
		DecisionTree->SetAttributeIndex(MostImportantAttributeIndex);

		// add a sub decision tree for each of the values of the most important attribute
		for (int ValueIndex=0; ValueIndex < MostImportantAttribute->GetValueCount(); ValueIndex++)
		{
			CRow<CDTExample *> SelectedExamples;

			// get the next value of the most important attribute
			Value = MostImportantAttribute->GetValue(ValueIndex);

			// select examples that match this value of the attribute
			for (int ExampleIndex = 0; ExampleIndex < Examples.GetLength(); ExampleIndex++)
			{
				// fetch example
				Example = Examples.Get(ExampleIndex);

				// is the attribute value in the example the value of the important attribute?
				if (Example->GetObject()->GetAttributeValue(MostImportantAttributeIndex) == Value)
				{
					// add this example to the ones we'll keep
					SelectedExamples.Add(Example);
				}
			}

			// don't use the most important attribute in the subtrees 
			AttributeAvailable.Set(MostImportantAttributeIndex, false);

			// create subtree
			SubTree = LearnDecisionTree(SelectedExamples, AttributeAvailable, GetMajority(Examples));

			// add the subtree to the decision tree
			DecisionTree->AddBranch(SubTree);

			// make the most important attribute available again
			AttributeAvailable.Set(MostImportantAttributeIndex, true);
		}
	}

	return DecisionTree;
}

void CDTModel::SetAttribute(int Index, CDTAttribute *NewAttribute)
{
	Attributes.Set(Index, NewAttribute);
}

/// Adds NewObject as object to this model
void CDTModel::AddObject(CDTObject *NewObject)
{
	Objects.Add(NewObject); 
}

/// Adds NewExample as example to this model
void CDTModel::AddExample(CDTObject *NewObject, bool Decision)
{
	// check if the number of attributes corresponds with this model's
	assert(NewObject->GetAttributeCount() == Attributes.GetLength());

	// ok, add the example
	Examples.Add(new CDTExample(NewObject, Decision));
}

/// Finds attribute by name.
CDTAttribute *CDTModel::GetAttribute(const CText &Name) const
{
	for (int Index=0; Index < Attributes.GetLength(); Index++)
	{
		if (Attributes.Get(Index)->GetName() == Name) return Attributes.Get(Index);
	}

	return 0;
}

CDTDecisionTree *CDTModel::CreateDecisionTree(void) const
{
	CRow<bool> AttributeAvailable(Attributes.GetLength());

	// check if all attributes are there
	for (int Index=0; Index < Attributes.GetLength(); Index++)
	{
		assert(Attributes.Get(Index) != 0);
	}

	// we won't proceed without any examples
	assert(Examples.GetLength() != 0);

	// initially, all attributes are available
	for (int Index=0; Index < Attributes.GetLength(); Index++)
	{
		AttributeAvailable.Set(Index, true);
	}

	return LearnDecisionTree(Examples, AttributeAvailable, true);
}
