#ifndef _DTMODEL
#define _DTMODEL

#include "aiDTExample.h"
#include "aiDTObject.h"
#include "aiDTAttribute.h"
#include "aiDTDecisionTree.h"
#include "generic.h"

using namespace generic;

class CDTAttribute;
class CDTObject;
class CDTExample;
class CDTDecisionTree;

/// Base class of the Decision Tree classes. 
/// Stores the attributes, examples, and creates decision trees.
/// The attributes and examples are managed (deleted in the end) by the model.
/// If you want the objects to be managed by the model as well, use AddObject.
/// The number of attributes is fixed, and attributes are used by index.

/// The decision tree algorithm and example are taken from chapter 18 of
/// Artificial Intelligence: A Modern Approach; by Stuart Russell and Peter Norvig.

class CDTModel: public CElement
{
protected:
	CRow<CDTAttribute *> Attributes;
	CRow<CDTObject *> Objects;
	CRow<CDTExample *> Examples;

	bool DoAllExamplesHaveSameDecision(const CRow<CDTExample *> &Examples, bool &Decision) const;
	bool GetMajority(const CRow<CDTExample *> &Examples) const;
	float GetInformationContent(float PossibilityPositiveDecision, float PossibilityNegativeDecision) const;
	float GetRemainder(const CDTAttribute *Attribute, int AttributeIndex, const CRow<CDTExample *> &Examples) const;
	float GetGain(const CDTAttribute *Attribute, int AttributeIndex, const CRow<CDTExample *> &Examples) const;
	int ChooseMostImportantAttribute(const CRow<CDTExample *> &Examples, CRow<bool> &AttributeAvailable) const;
	bool HasAvailableAttributes(CRow<bool> &AttributeAvailable) const;
	CDTDecisionTree *LearnDecisionTree(const CRow<CDTExample *> &Examples, CRow<bool> &AttributeAvailable, bool DefaultDecision) const;

public:
	CDTModel(int NewAttributeCount);
	~CDTModel();

	void SetAttribute(int Index, CDTAttribute *NewAttribute);
	void AddObject(CDTObject *NewObject);
	void AddExample(CDTObject *NewObject, bool Decision);

	int GetAttributeCount(void) const { return Attributes.GetLength(); }
	CDTAttribute *GetAttribute(const CText &Name) const;
	CDTAttribute *GetAttribute(int Index) const { return Attributes.Get(Index); }

	CDTDecisionTree *CreateDecisionTree(void) const;
};

#endif