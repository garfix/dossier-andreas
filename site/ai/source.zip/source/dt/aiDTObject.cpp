#include "aiDTObject.h"

CDTObject::CDTObject(int NewAttributeValueCount)
{
	AttributeValues.SetLength(NewAttributeValueCount);
}

