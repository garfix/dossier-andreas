#ifndef _DTATTRIBUTE
#define _DTATTRIBUTE

#include "generic.h"

using namespace generic;

/// An attribute is an aspect of an object through which it may be distinguished from other 
/// objects.
/// The attribute can have any number of values. A value may have a name. If a value is only
/// given a name, a value is made up (the value will be the same as the index of the value).

class CDTAttribute: public CElement
{
protected:
	CRow<int> Values;
	CRow<CText> ValueNames;

public:
	CDTAttribute(const CText &Name);

	// three ways to add values
	void AddValue(int NewValue);
	void AddValue(const CText &NewValueName);
	void AddValue(int NewValue, const CText &NewValueName);

	int GetValueCount(void) const { return Values.GetLength(); }
	const CText &GetValueName(int Index) const { return ValueNames.Get(Index); }
	int GetValue(int Index) const { return Values.Get(Index); }
};

#endif