#ifndef _DTOBJECT
#define _DTOBJECT

#include "generic.h"

using namespace generic;

/// An object represents an object in the world that is described by a number of attributes.
/// An attribute can have any number of values.

class CDTObject: public CElement
{
protected:
	CRow<int> AttributeValues;

public:
	CDTObject(int NewAttributeCount);

	void SetAttributeValue(int Index, int Value){ AttributeValues.Set(Index, Value); }
	int GetAttributeValue(int Index) const { return AttributeValues.Get(Index); }
	int GetAttributeCount(void) const { return AttributeValues.GetLength(); }
};

#endif