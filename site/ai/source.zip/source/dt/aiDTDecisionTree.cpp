#include "aiDTDecisionTree.h"
#include "aiDTExample.h"
#include "aiDTObject.h"
#include "aiDTAttribute.h"

CDTDecisionTree::CDTDecisionTree()
{
}

CDTDecisionTree::~CDTDecisionTree()
{
	Branches.DeleteContents();
}

const CText CDTDecisionTree::ToString(int TabCount) const
{
	CText String;
	CText Tabs;

	for (int Index=0; Index < TabCount; Index++)
	{
		Tabs += "\t";
	}

	if (IsLeaf())
	{
		String += (Decision ? "yes" : "no");
	}
	else
	{
		String += Attribute->GetName();

		String += Tabs + "\n";

		String += Tabs + "{\n";

		TabCount++;
		Tabs += "\t";

		for (int Index=0; Index < Attribute->GetValueCount(); Index++)
		{
			String += Tabs + Attribute->GetValueName(Index) + ":\t";
			String += Branches.Get(Index)->ToString(TabCount+1) + "\n";
		}

		String += Tabs + "}\n";
	}

	return String;
}

bool CDTDecisionTree::MakeDecision(const CDTObject &Object) const
{
	int ObjectAttributeValue;

	// if this is a leaf, the decision is simple
	if (IsLeaf()) return Decision;

	// get the example's attribute value
	ObjectAttributeValue = Object.GetAttributeValue(AttributeIndex);

	// ask the branches
	for (int Index=0; Index < Attribute->GetValueCount(); Index++)
	{
		// does this branch have the same attribute value?
		if (Attribute->GetValue(Index) == ObjectAttributeValue)
		{
			return Branches.Get(Index)->MakeDecision(Object);
		}
	}

	// the example contains an illegal value
	assert(false);
	return false;
}

const CText CDTDecisionTree::ToString(void) const
{
	return ToString(0);
}

