#ifndef _DTEXAMPLE
#define _DTEXAMPLE

#include "generic.h"

using namespace generic;

class CDTObject;

/// An example is the combination of an object and the decision to classify the object or not.

class CDTExample: public CElement
{
protected:
	/// any object
	CDTObject *Object;
	/// is this object part of the set?
	bool Decision;

public:
	CDTExample(CDTObject *NewObject, bool NewDecision);

	CDTObject *GetObject(void) const { return Object; }
	bool GetDecision(void) const { return Decision; }
};

#endif