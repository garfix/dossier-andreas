#ifndef _DTDECISIONTREE
#define _DTDECISIONTREE

#include "generic.h"

using namespace generic;

class CDTObject;
class CDTAttribute;

/// A decision tree maps an object (a series of attributes) to a decision wether this object
/// belongs to the set or not.

class CDTDecisionTree: public CElement
{
protected:
	/// This tree represents an attribute
	CDTAttribute *Attribute;
	/// The index of the attribute in the model
	int AttributeIndex;
	/// The decision this tree represents (only applicable if the tree has no branches)
	bool Decision;
	/// The branches that belong to each of the values
	CRow<CDTDecisionTree *> Branches;

	const CText ToString(int TabCount) const;

public:
	CDTDecisionTree();
	~CDTDecisionTree();

	void SetAttribute(CDTAttribute *NewAttribute){ Attribute = NewAttribute; }
	void SetAttributeIndex(int NewAttributeIndex){ AttributeIndex = NewAttributeIndex; }
	void SetDecision(bool NewDecision){ Decision = NewDecision; }
	void AddBranch(CDTDecisionTree *NewBranch){ Branches.Add(NewBranch); }
	bool IsLeaf(void) const { return Branches.IsEmpty(); }
	bool MakeDecision(const CDTObject &Object) const;

	virtual const CText ToString(void) const;
};

#endif