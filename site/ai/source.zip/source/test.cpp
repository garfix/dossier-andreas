#include "test.h"
#include <math.h>

#pragma warning(disable: 4101)

#define EPSILON 0.00001f

namespace generic
{

class CTestGenome: public CGeneticGenome
{
protected:
    int Ints[5];
    int Id;

public:
    CTestGenome::CTestGenome(int NewId)
    {
        Id = NewId;
        Fitness = (float)Id;
    }

    /// create a new genome, no randomization is required
    virtual CGeneticGenome *NewGenome()
    { 
        static int IdGenerator=-1;
        const static int Ids[6] = { 1, 3, 4, 5, 0, 2};
        
        IdGenerator++;
        if (IdGenerator == 6) IdGenerator = 0;

        return new CTestGenome(Ids[IdGenerator]); 
    }

    /// create default (random) values for the genes
    virtual void Initialize(){ for (int i=0; i<5; i++){ Ints[i]=Id; } }

    /// set the length (i.e. the number of genes)
    virtual void SetLength(int NewLength){ }

    /// return the length
    virtual int GetLength(void){ return 5; }

    /// copy gene at position Pos to Child at pos ChildPos
    virtual void CopyGene(int Pos, CGeneticGenome *Child, int ChildPos)
    {
        ((CTestGenome *)Child)->Ints[ChildPos] = Ints[Pos];
    }

    /// is this genome equal to Genome
    virtual bool Equals(CGeneticGenome *Genome)
    {
        for (int i=0; i<5; i++) if (Ints[i] != ((CTestGenome *)Genome)->Ints[i]) return false;
        return true;
    }

    /// store a random value in the gene
    virtual void MutateGene(int GeneIndex){}

    /// calculate the fitness of this genome
    virtual void CalculateFitness(void){ }

    /// is the genome fit enough to stop evolving?
    virtual bool IsFitEnough(void){ return true; };

    virtual const CText ToString(void) const
    {
        CText String;
        for (int i=0; i<5; i++)
        {
            String += Ints[i];
            String += ' ';
        }
        return String;
    }

    friend class CTest;
};

CTest::CTest()
{
}

void CTest::Assert(const CText &Remark, float Actual, float Asserted)
{
    if (fabs(Actual - Asserted) > EPSILON) 
    {
        Success = false;
        printf("%s (%f should be %f)\n", Remark.GetBuffer(), Actual, Asserted);
    }
}

void CTest::Assert(const CText &Remark, int Actual, int Asserted)
{
    if (Actual != Asserted)
    {
        Success = false;
        printf("%s (%d should be %d)\n", Remark.GetBuffer(), Actual, Asserted);
    }
}

void CTest::Assert(const CText &Remark, const CText &Actual, const CText &Asserted)
{
    if (Actual != Asserted)
    {
        Success = false;
        printf("%s ('%s' should be '%s')\n", Remark.GetBuffer(), Actual.GetBuffer(), Asserted.GetBuffer());
    }
}
void CTest::Assert(const CText &Remark, bool Asserted)
{
    if (!Asserted)
    {
        Success = false;
        printf("%s\n", Remark.GetBuffer());
    }
}

void CTest::Reset(void)
{
    Success = true;
    _CrtMemCheckpoint(&DebugHeapState);
}

bool CTest::LeakOccurred(void)
{
    bool LeakFree;

    _CrtMemState NewDebugHeapState;
    _CrtMemState DiffDebugHeapState;

    _CrtMemCheckpoint(&NewDebugHeapState);
    LeakFree = (_CrtMemDifference(&DiffDebugHeapState, &DebugHeapState, &NewDebugHeapState) == 0);
    return !LeakFree;
}

void CTest::TestCase(const CText &TestName, void (CTest::*TestFunction)(void))
{
    // reset memory state
    Reset();

    // execute test function
    (this->*TestFunction)();

    // check for memory leaks
    if (LeakOccurred())
	{
		printf("Leak occurred in " + TestName + "\n");
		_CrtDumpMemoryLeaks();
	}
}

void CTest::TestString(void)
{
    CText String1("een");
    CText String2("twee");
    CText String3;

    String3.Allocate(String1.GetLength() + 1 + String2.GetLength());
    String3 += String1;
    String3 += " ";
    String3 += String2;
    Assert("Adding two strings", String3, "een twee");

    CText String4;
    CText String5;
    String5.Allocate(100);
    String5 += "Doing fine.";
    String4 = String5;
    Assert("GetLength 1", String4.GetLength(), 11);

    CText String6("aan het ");
    CText String7("aanrecht");
    CText String8 = String6 + String7;

    Assert("String + (1)", String6 + String7 == "aan het aanrecht");
    Assert("String + (2)", String6 == "aan het ");
    Assert("String + (3)", String7 == "aanrecht");

    CText String9;
    String9 = CText("1+1=") + 3;
    Assert("String + int", String9 == "1+1=3");

    // End
    CText String10;
    String10.Allocate(5);
    String10 += "123";
    Assert("End (1)", String10.GetLength(), 3);
    String10.Set(3, '\0');
    Assert("End (2)", String10.GetLength(), 3);

    // ""
    CText String11;
    Assert("Empty string (1)", String11 == "");
    String11 = "";
    Assert("Empty string (2)", String11 == "");
    String11 += "";
    Assert("Empty string (3)", String11 == "");
    String11 += CText();
    Assert("Empty string (4)", String11 == "");
    CText String11a("aap");
    String11a += "";
    Assert("Empty string (5)", String11a == "aap");

    // +=
    CText String12;
    String12 += 'a';
    String12 += 'b';
    Assert("String::+=char", String12, "ab");

    CText String13;
    String13 += 1;
    String13 += ' ';
    String13 += 2;
    Assert("String::+=int", String13, "1 2");

    // constructor with integer
    CText String14(169);
    Assert("String::String(int)", String14, "169");

    // floating point
    CText String15(8.3337f);
    Assert("String(float)", String15, " 8.334");
    CText String16(-0.01f);
    Assert("String(float)", String16, "-0.010");

    // substring
    CText String17("0123456789");
    CText String18 = String17.Substring(3, 5);
    Assert("substring", String18, "345");

    // repeat
    CText String19("aap", 3);
    CText String20("", 2);
    Assert("repeat string 1", String19, "aapaapaap");
    Assert("repeat string 2", String20, "");

	// getindex
	CText String21("abc");
	Assert("getindex 1", String21.GetIndex("abc"), 0);
	Assert("getindex 2", String21.GetIndex("bc"), 1);
	Assert("getindex 3", String21.GetIndex("ab"), 0);
	Assert("getindex 4", String21.GetIndex("abcd"), -1);
	Assert("getindex 5", String21.GetIndex("bcde"), -1);
	Assert("getindex 6", String21.GetIndex(""), 0);
	Assert("getindex 7", String21.GetIndex("b"), 1);

	// replace
	CText String22("--ab--ab--");
	Assert("replace 1", String22.Replace("ab", "cd"), "--cd--cd--");
	Assert("replace 2", String22.Replace("--", "++"), "++ab++ab++");
	Assert("replace 3", String22.Replace("--", ""), "abab");
	Assert("replace 4", String22.Replace("ab", ""), "------");
}

void CTest::TestHashTable(void)
{
	CHashTable<CText, int> Hash(10);
	CText Key;
	int Value;
	bool Found;

	CHashTableIterator<CText, int> Iter1 = Hash.GetIterator();
	Found = Iter1.GetNext(Key, Value);
	Assert("HashTable iter1", !Found);

	Hash.Put("aap", 1);
	Hash.Put("noot", 2);
	Hash.Put("mies", 3);

	Assert("HashTable 1", Hash.Get("noot", Found) == 2);

	CHashTableIterator<CText, int> Iter2 = Hash.GetIterator();
	Found = Iter2.GetNext(Key, Value);
	Assert("HashTable iter2a", Found);
	Found = Iter2.GetNext(Key, Value);
	Assert("HashTable iter2b", Found);
	Found = Iter2.GetNext(Key, Value);
	Assert("HashTable iter2c", Found);
	Found = Iter2.GetNext(Key, Value);
	Assert("HashTable iter2d", !Found);

	Hash.Rehash();
	Assert("HashTabel Rehash", Hash.GetCapacity() == 9);
	Assert("HashTable 3", Hash.Get("aap", Found) == 1);
	Assert("HashTable 3", Hash.Get("noot", Found) == 2);
	Assert("HashTable 3", Hash.Get("mies", Found) == 3);
}

void CTest::TestArray(void)
{
    CRow<CText> StringArray(0);

    // add
    StringArray.Add(CText("first string"));
    StringArray.Add(CText("second string"));
    Assert("String Array get 1", StringArray.Get(0) == "first string");
    Assert("String Array get 2", StringArray.Get(1) == "second string");

    // remove
    StringArray.Remove(CText("not available"));
    Assert("String Array remove 1", StringArray.GetLength() == 2);
    StringArray.Remove(CText("first string"));
    Assert("String Array remove 2", StringArray.GetLength() == 1);
    StringArray.Remove(CText("second string"));
    Assert("String Array remove 3", StringArray.GetLength() == 0);

    // test reallocation
    CRow<int> IntArray;
    Assert("Array realloc 1", IntArray.MaxLength == 0);
    for (int i=0; i<10; i++) IntArray.Add(i);
    Assert("Array realloc 2", (IntArray.MaxLength == 10) || (IntArray.MaxLength == DEFAULT_MAX_LENGTH));
    IntArray.Add(11);
    Assert("Array realloc 3", (IntArray.MaxLength == 20) || (IntArray.MaxLength == DEFAULT_MAX_LENGTH));

    CRow<int> IntArray2(0);
    IntArray2.Add(1);
    IntArray2.Add(2);
    IntArray2.Add(3);
    Assert("Array last element", IntArray2.Get(IntArray2.GetLength()-1) == 3);
}

void CTest::TestRing(void)
{
    CRing<int> IntRing;

    IntRing.Add(1);

    Assert("IntRing::GetNext 1", IntRing.GetNext(), 1);
    Assert("IntRing::GetNext 2", IntRing.GetNext(), 1);

    IntRing.Add(2);
    Assert("IntRing::GetNext 3", IntRing.GetNext(), 1);
    Assert("IntRing::GetNext 4", IntRing.GetNext(), 2);
    Assert("IntRing::GetNext 5", IntRing.GetNext(), 1);

    IntRing.Remove(1);
    Assert("IntRing::GetNext 6", IntRing.GetNext(), 2);
}

void CTest::TestStack(void)
{
	CStack<CText> S(3);

	S.Push("a");
	S.Push("b");
	S.Push("c");
	Assert("Stack: 1", S.Peek() == "c");
	Assert("Stack: 2", S.Peek(1) == "b");
	Assert("Stack: 3", S.GetDepth() == 3);
	S.Pop();
	Assert("Stack: 4", S.Peek() == "b");
	Assert("Stack: 5", S.Peek(1) == "a");
	Assert("Stack: 6", S.GetDepth() == 2);
	S.Push("d");
	S.Push("e");
	Assert("Stack: 7", S.Peek() == "e");
	Assert("Stack: 8", S.Peek(1) == "d");
	Assert("Stack: 9", S.Peek(2) == "b");
	Assert("Stack: 10", S.GetDepth() == 4);
}

void CTest::TestSmartPointer()
{
	CText *bla = new CText("My resource");
	CText *bla2 = new CText("My resource 2");

	CSmartPointer<CText> SP1(bla);
	CSmartPointer<CText> SP2(SP1);
	CSmartPointer<CText> SP3 = SP1;

	Assert("Smartpointer 1", SP1 == SP2);
	Assert("Smartpointer 2", SP2 == SP3);

	SP1 = bla2;
	SP2 = SP1;
	Assert("Smartpointer 3", SP1 == SP2);
}

void CTest::TestBitPattern(void)
{
	CBitPattern Pattern1(3);
	CBitPattern Pattern2(4);
	CBitPattern Pattern3(5);
	CBitPattern Pattern4(2001);

	Pattern1.SetName("Pattern1");
	Pattern2.SetName("Pattern2");
	Pattern3.SetName("Pattern3");
	Pattern4.SetName("Pattern4");

	TestBitPatternHelper(Pattern1, 3);
	TestBitPatternHelper(Pattern2, 4);
	TestBitPatternHelper(Pattern3, 5);
	TestBitPatternHelper(Pattern4, 2001);

	CBitPattern Pattern_0(1);
	CBitPattern Pattern_1(1);
	CBitPattern Mean(1);
	CRow<CBitPattern> Row1(2);
	CRow<CBitPattern> Row2(3);

	Pattern_0.SetBit(0, 0);
	Pattern_1.SetBit(0, 1);

	Row1.Set(0, Pattern_0); Row1.Set(1, Pattern_1);
	CBitPattern::CalculateMean(Row1, Mean);
	Assert("CBitPattern - mean (1) - 1", Mean.GetBit(0));
	Row1.Set(0, Pattern_1); Row1.Set(1, Pattern_1);
	CBitPattern::CalculateMean(Row1, Mean);
	Assert("CBitPattern - mean (1) - 2", Mean.GetBit(0));
	Row1.Set(0, Pattern_0); Row1.Set(1, Pattern_0);
	CBitPattern::CalculateMean(Row1, Mean);
	Assert("CBitPattern - mean (1) - 3", !Mean.GetBit(0));

	Row2.Set(0, Pattern_0); Row2.Set(1, Pattern_1); Row2.Set(2, Pattern_0);
	CBitPattern::CalculateMean(Row2, Mean);
	Assert("CBitPattern - mean (2) - 1", !Mean.GetBit(0));
	Row2.Set(0, Pattern_0); Row2.Set(1, Pattern_1); Row2.Set(2, Pattern_1);
	CBitPattern::CalculateMean(Row2, Mean);
	Assert("CBitPattern - mean (2) - 2", Mean.GetBit(0));
}

void CTest::TestFuzzyCategory(void)
{
    CFloat F00(0.0f);
    CFloat F05(0.5f);
    CFloat F10(1.0f);
    CFloat F30(3.0f);
    CFloat F50(5.0f);

    CFuzzyPiecewiseLinearSet Nearness;
    Nearness.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F30, &F10));
    Nearness.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F50, &F00));

    Assert("Nearness 1", Nearness.GetDegreeOfMembership(1.0f).GetValue(), 1.0f);
    Assert("Nearness 4", Nearness.GetDegreeOfMembership(4.0f).GetValue(), 0.5f);
    Assert("Nearness 10", Nearness.GetDegreeOfMembership(10.0f).GetValue(), 0.0f);

    CFuzzyPiecewiseLinearSet NearDeath;
    NearDeath.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F00, &F00));
    NearDeath.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F00, &F10));
    NearDeath.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F50, &F00));

    Assert("NearDeath 0", NearDeath.GetDegreeOfMembership(0.0f).GetValue(), 0.0f);
}

void CTest::TestFuzzy(void)
{
    CFuzzy Fuzzy1(0.2f);
    CFuzzy Fuzzy2(0.7f);

    Assert("Fuzzy 0.2 AND 0.7 == 0.2", Fuzzy1.And(Fuzzy2).GetValue(), 0.2f);
    Assert("Fuzzy 0.2 OR 0.7 == 0.7", Fuzzy1.Or(Fuzzy2).GetValue(), 0.7f);
    Assert("NOT Fuzzy 0.2 == 0.8", Fuzzy1.Not().GetValue(), 0.8f);
}

void CTest::TestFuzzySet(void)
{
    bool Found;
    CFloat F00(0.0f);
    CFloat F10(1.0f);
    CFloat F100(10.0f);
    CFloat F200(20.0f);
    CFloat F300(30.0f);
    CFloat F400(40.0f);
    CFloat F500(50.0f);
    CFloat F600(60.0f);

    CFuzzyPiecewiseLinearSet OneElementSet;
    OneElementSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F100, &F10));

    CFuzzyPiecewiseLinearSet LeftOpenEndedSet;
    LeftOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F200, &F10));
    LeftOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F300, &F00));

    CFuzzyPiecewiseLinearSet RightOpenEndedSet;
    RightOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F200, &F00));
    RightOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F300, &F10));

    CFuzzyPiecewiseLinearSet TriangleSet;
    TriangleSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F400, &F00));
    TriangleSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F500, &F10));
    TriangleSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F600, &F00));

    CFuzzyPiecewiseLinearSet TrapezoidSet;
    TrapezoidSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F00, &F00));
    TrapezoidSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F100, &F10));
    TrapezoidSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F200, &F10));
    TrapezoidSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F300, &F00));
    
    Assert("OneElementSet", OneElementSet.GetCharacteristicValue(), 10.0f);
    Assert("TriangleSet", TriangleSet.GetCharacteristicValue(), 50.0f);
    Assert("TrapezoidSet", TrapezoidSet.GetCharacteristicValue(), 15.0f);

    // leftmost value
    Assert("Leftmost Trapezoid 0.25", TrapezoidSet.GetLeftmostValue(CFuzzy(0.25), Found), 2.5f);
    Assert("Leftmost LeftOpen 0.25", LeftOpenEndedSet.GetLeftmostValue(CFuzzy(0.25), Found), CFloat::GetMinimum());
    
    // rightmost value
    Assert("Rightmost 0.25", TrapezoidSet.GetRightmostValue(CFuzzy(0.25), Found), 27.5f);
    Assert("Rightmost RightOpen 0.25", RightOpenEndedSet.GetRightmostValue(CFuzzy(0.25), Found), CFloat::GetMaximum());
}

void CTest::TestFuzzyOutputSet(void)
{
    CFloat F00(0.0f);
    CFloat F10(1.0f);
    CFloat F100(10.0f);
    CFloat F200(20.0f);
    CFloat F300(30.0f);
    CFloat F400(40.0f);
    CFloat F500(50.0f);
    CFloat F600(60.0f);

    CFuzzyPiecewiseLinearSet OneElementSet;
    OneElementSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F100, &F10));

    CFuzzyPiecewiseLinearSet LeftOpenEndedSet;
    LeftOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F200, &F10));
    LeftOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F300, &F00));

    CFuzzyPiecewiseLinearSet RightOpenEndedSet;
    RightOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F300, &F00));
    RightOpenEndedSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F400, &F10));

    CFuzzyPiecewiseLinearSet TriangleSet;
    TriangleSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F200, &F00));
    TriangleSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F300, &F10));
    TriangleSet.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F400, &F00));

    CFuzzyVariable Variable;
    CFuzzyOutputSet *OutputSet = Variable.OutputSet;

    // leftmost maximum; open and triangle set; triangle set wins
    OutputSet->AddResult(&LeftOpenEndedSet, CFuzzy(0.25f), ACTIVATIONMETHOD_MIN);
    OutputSet->AddResult(&TriangleSet, CFuzzy(0.50f), ACTIVATIONMETHOD_MIN);
    Variable.SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_LEFTMOSTMAXIMUM);
    Variable.Defuzzify();
    Assert("outputset 1", Variable.GetValue(), 25.0f);
    OutputSet->Clear();
    
    // leftmost maximum; open and triangle set; open set wins
    OutputSet->AddResult(&LeftOpenEndedSet, CFuzzy(0.25f), ACTIVATIONMETHOD_MIN);
    OutputSet->AddResult(&TriangleSet, CFuzzy(0.10f), ACTIVATIONMETHOD_MIN);
    Variable.SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_LEFTMOSTMAXIMUM);
    Variable.Defuzzify();
    Assert("outputset 2", Variable.GetValue(), CFloat::GetMinimum());
    OutputSet->Clear();

    // rightmost maximum; open and triangle set; triangle set wins
    OutputSet->AddResult(&RightOpenEndedSet, CFuzzy(0.25f), ACTIVATIONMETHOD_MIN);
    OutputSet->AddResult(&TriangleSet, CFuzzy(0.50f), ACTIVATIONMETHOD_MIN);
    Variable.SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_RIGHTMOSTMAXIMUM);
    Variable.Defuzzify();
    Assert("outputset 3", Variable.GetValue(), 35.0f);
    OutputSet->Clear();

    // rightmost maximum; open and triangle set; open set wins
    OutputSet->AddResult(&RightOpenEndedSet, CFuzzy(0.25f), ACTIVATIONMETHOD_MIN);
    OutputSet->AddResult(&TriangleSet, CFuzzy(0.10f), ACTIVATIONMETHOD_MIN);
    Variable.SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_RIGHTMOSTMAXIMUM);
    Variable.Defuzzify();
    Assert("outputset 4", Variable.GetValue(), CFloat::GetMaximum());
    OutputSet->Clear();

    // product activation; rightmost maximum; open and triangle set; triangle set wins
    OutputSet->AddResult(&RightOpenEndedSet, CFuzzy(0.25f), ACTIVATIONMETHOD_PROD);
    OutputSet->AddResult(&TriangleSet, CFuzzy(0.50f), ACTIVATIONMETHOD_PROD);
    Variable.SetDefuzzificationMethod(DEFUZZIFICATIONMETHOD_RIGHTMOSTMAXIMUM);
    Variable.Defuzzify();
    Assert("outputset 5", Variable.GetValue(), 30.0f);
    OutputSet->Clear();
}

void CTest::TestFuzzyOperator(void)
{
    CFloat F00(0.0f);
    CFloat F10(1.0f);
    CFloat F175(1.75f);
    CFloat F200(2.00f);
    CFloat F160(1.60f);
    CFloat F180(1.80f);

    CFuzzyPiecewiseLinearSet Tall;
    Tall.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F175, &F00));
    Tall.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F200, &F10));

    CFuzzyPiecewiseLinearSet Small;
    Small.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F160, &F10));
    Small.AddMembershipFunctionCoordinate(CPair<CFloat *, CFloat *>(&F180, &F00));

    // person In1 is tall
    CFuzzyVariable In1(1.95f);
    // person In2 is small
    CFuzzyVariable In2(1.70f);

    // proposition 'person In1 is tall'
    CFuzzyAtom Atom1(&In1, &Tall);
    // proposition 'person In2 is small'
    CFuzzyAtom Atom2(&In2, &Small);

    // 'person In1 is tall AND person In2 is small' 
    CFuzzyOperator Op1(OPERATORTYPE_AND);
    Op1.AddOperand(&Atom1);
    Op1.AddOperand(&Atom2);
    Assert("Operator AND", Op1.CalculateFuzzyValue().GetValue(), 0.5f);

    // 'person In1 is tall OR person In2 is small' 
    CFuzzyOperator Op2(OPERATORTYPE_OR);
    Op2.AddOperand(&Atom1);
    Op2.AddOperand(&Atom2);
    Assert("Operator OR", Op2.CalculateFuzzyValue().GetValue(), 0.80f);

    // person In2 is NOT small
    CFuzzyOperator Op3(OPERATORTYPE_NOT);
    Op3.AddOperand(&Atom2);

    // 'person In1 is tall AND person In2 is not small'
    CFuzzyOperator Op4(OPERATORTYPE_AND);
    Op4.AddOperand(&Atom1);
    Op4.AddOperand(&Op3);
    Assert("Operator NOT", Op4.CalculateFuzzyValue().GetValue(), 0.5f);
}

void CTest::TestFuzzyRule(void)
{
}

void CTest::TestFuzzyModelFCLLoader(void)
{
    CFuzzyModel FuzzyModel;
    CFuzzyModelFCLLoader FuzzyModelFCLLoader;
    bool Success;
    CFuzzyNode *RootNode;
    
    CText Source = 
    "FUNCTION_BLOCK Agent_Aggressiveness " \

    "VAR_INPUT " \
        "Our_Health:        REAL; " \
        "Enemy_Health:      REAL; " \
    "END_VAR "\

    "VAR_OUTPUT " \
        "Aggressiveness:    REAL; " \
    "END_VAR " \

    "FUZZIFY Our_Health " \
        "TERM Near_Death := (0, 1) (50, 0); " \
        "TERM Good := (14, 0) (50, 1) (83, 0); " \
        "TERM Excellent := (50, 0) (100, 1); " \
    "END_FUZZIFY " \

    "FUZZIFY Enemy_Health " \
        "TERM Near_Death := (0, 1) (50, 0); " \
        "TERM Good := (14, 0) (50, 1) (83, 0); " \
        "TERM Excellent := (50, 0) (100, 1); " \
    "END_FUZZIFY " \

    "DEFUZZIFY Aggressiveness " \
        "TERM Run_Away := 1; " \
        "TERM Fight_Defensively := 2; " \
        "TERM All_Out_Attack := 3; " \
        "METHOD: MoM; " \
        "DEFAULT := 1; " \
        "RANGE := (0..3); " \
    "END_DEFUZZIFY " \

    "RULEBLOCK first " \
        "AND: MIN; " \
        "ACCU: MAX; " \
    "END_RULEBLOCK " \

    "END_FUNCTION_BLOCK";

    // load the model
    FuzzyModelFCLLoader.Model = &FuzzyModel;
    FuzzyModelFCLLoader.Source = Source;
    FuzzyModelFCLLoader.Reset();
    FuzzyModelFCLLoader.ParsePage();

    FuzzyModelFCLLoader.Source = "OUR_HEALTH IS GOOD THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 0", Success);
    Assert("Expression 0", RootNode->ToString(), "OUR_HEALTH IS GOOD");

    FuzzyModelFCLLoader.Source = "OUR_HEALTH IS GOOD AND ENEMY_HEALTH IS GOOD THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 1", Success);
    Assert("Expression 1", RootNode->ToString(), "AND(OUR_HEALTH IS GOOD, ENEMY_HEALTH IS GOOD)");

    FuzzyModelFCLLoader.Source = "OUR_HEALTH IS GOOD OR ENEMY_HEALTH IS GOOD THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 2", Success);
    Assert("Expression 2", RootNode->ToString(), "OR(OUR_HEALTH IS GOOD, ENEMY_HEALTH IS GOOD)");

    FuzzyModelFCLLoader.Source = "NOT OUR_HEALTH IS GOOD THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 3", Success);
    Assert("Expression 3", RootNode->ToString(), "NOT(OUR_HEALTH IS GOOD)");

    FuzzyModelFCLLoader.Source = "(OUR_HEALTH IS GOOD OR ENEMY_HEALTH IS GOOD) THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 4", Success);
    Assert("Expression 4", RootNode->ToString(), "OR(OUR_HEALTH IS GOOD, ENEMY_HEALTH IS GOOD)");

    FuzzyModelFCLLoader.Source = "(OUR_HEALTH IS EXCELLENT OR (OUR_HEALTH IS GOOD AND ENEMY_HEALTH IS NEAR_DEATH)) THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 5", Success);
    Assert("Expression 5", RootNode->ToString(), "OR(OUR_HEALTH IS EXCELLENT, AND(OUR_HEALTH IS GOOD, ENEMY_HEALTH IS NEAR_DEATH))");

    FuzzyModelFCLLoader.Source = "NOT OUR_HEALTH IS EXCELLENT AND NOT (OUR_HEALTH IS GOOD AND ENEMY_HEALTH IS NEAR_DEATH)) THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 6", Success);
    Assert("Expression 6", RootNode->ToString(), "AND(NOT(OUR_HEALTH IS EXCELLENT), NOT(AND(OUR_HEALTH IS GOOD, ENEMY_HEALTH IS NEAR_DEATH)))");

    FuzzyModelFCLLoader.Source = "OUR_HEALTH IS GOOD AND ENEMY_HEALTH IS NEAR_DEATH AND OUR_HEALTH IS NEAR_DEATH THEN";
    FuzzyModelFCLLoader.Reset();
    Success = FuzzyModelFCLLoader.ParseExpression(RootNode);
    Assert("Expression 7", Success);
    Assert("Expression 7", RootNode->ToString(), "AND(AND(OUR_HEALTH IS GOOD, ENEMY_HEALTH IS NEAR_DEATH), OUR_HEALTH IS NEAR_DEATH)");
}

void CTest::TestGeneticPopulation(void)
{
    const int Count = 6; 

    CTestGenome Prototype(-1);
    CGeneticPopulation Population;

    Population.Initialize(Count, &Prototype);
    Population.SortByFitness();
    for (int i=0; i < Count; i++)
    {
        Assert("Population SortByFitness", (int)Population.GetGenome(i)->GetFitness(), Count-1-i);
    }
}

void CTest::TestGeneticModel(void)
{
    const int Count = 6; 

    CTestGenome Prototype(-1);
    CGeneticModel Model(&Prototype);
    CGeneticGenome *Parent1, *Parent2, *Child1, *Child2;
//  CRow<float> RandomNumberArray(0);

    Model.SetPopulationSize(Count, 2, 1, -1);
    Model.Initialize();
    Parent1 = Model.GetGenome(0);
    Parent2 = Model.GetGenome(1);
    Child1 = Model.GetGenome(2);
    Child2 = Model.GetGenome(3);
    Assert("GeneticModel::Initialize 1", Parent1->ToString(), "5 5 5 5 5 ");
    Assert("GeneticModel::Initialize 2", Parent2->ToString(), "4 4 4 4 4 ");
//  CMath::SetMode(MATHMODE_PSEUDO, 2);
//  Model.CrossoverFixedLengthOnePoint(Parent1, Parent2, Child1, Child2);
//  CMath::SetMode(MATHMODE_RANDOM);
//  Assert("GeneticModel::CrossoverFixedLengthOnePoint 1", Child1->ToString(), "5 5 4 4 4 ");
//  Assert("GeneticModel::CrossoverFixedLengthOnePoint 2", Child2->ToString(), "4 4 5 5 5 ");
    
//  RandomNumberArray.Clear();
//  RandomNumberArray.Add(2);
//  RandomNumberArray.Add(4);
//  CMath::SetMode(MATHMODE_PSEUDO, RandomNumberArray);
//  Model.CrossoverFixedLengthTwoPoints(Parent1, Parent2, Child1, Child2);
//  CMath::SetMode(MATHMODE_RANDOM);
//  Assert("GeneticModel::CrossoverFixedLengthTwoPoints 1", Child1->ToString(), "5 5 4 4 5 ");
//  Assert("GeneticModel::CrossoverFixedLengthTwoPoints 2", Child2->ToString(), "4 4 5 5 4 ");

//  RandomNumberArray.Clear();
//  RandomNumberArray.Add(1);
//  RandomNumberArray.Add(3);
//  CMath::SetMode(MATHMODE_PSEUDO, RandomNumberArray);
//  Model.MutationSwapGenes(Child1);
//  Assert("GeneticModel::MutationSwapGenes 1", ((CTestGenome *)Child1)->Ints[3], 5);
//  Assert("GeneticModel::MutationSwapGenes 2", ((CTestGenome *)Child1)->Ints[2], 4);
//  Assert("GeneticModel::MutationSwapGenes 3", ((CTestGenome *)Child1)->Ints[1], 4);
//  CMath::SetMode(MATHMODE_RANDOM);
}

void CTest::TestBitPatternHelper(CBitPattern &Pattern, int Length)
{
	for (int i=0; i < Length; i++)
	{
		Assert("BitPatterns (check bit "+CText(i)+" clear): " + Pattern.GetName(), !Pattern.GetBit(i));
		Pattern.SetBit(i, true);
		Assert("BitPatterns (set bit "+CText(i)+" to 1): " + Pattern.GetName(), Pattern.GetBit(i));
		Pattern.SetBit(i, false);
		Assert("BitPatterns (set bit "+CText(i)+" to 0): " + Pattern.GetName(), !Pattern.GetBit(i));
	}
}

void CTest::TestPL(void)
{
	CPLModel Model;
	CPLParser &Parser = Model.GetParser();
	CPLRule *Rule;
	bool Success;
	CText Substitution;
	CText SubstitutionString;

	Rule = (CPLRule *)Parser.Parse("grandparent(X, Y) :- parent(X, _), parent(_, Y).");
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Rule);

	Assert("pl2: "+Rule->ToString(), Rule->ToString() == "grandparent(X, Y) :- parent(X, _), parent(_, Y).");

	CPLAtom Atom;

	// http://www.csse.monash.edu.au/~lloyd/tildeLogic/Prolog.toy/Examples/
	// After Monty Python (Sir Bedevere).
	Rule = (CPLRule *)Parser.Parse("witch(X) :- burns(X), female(X).");
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Rule);
	Rule = (CPLRule *)Parser.Parse("burns(X) :- wooden(X).");
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Rule);
	Rule = (CPLRule *)Parser.Parse("wooden(X) :- floats(X).");
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Rule);
	Rule = (CPLRule *)Parser.Parse("floats(X) :- sameweight(duck, X).");
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Rule);
	Parser.ParseAtom("female(girl).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Atom);
	Parser.ParseAtom("sameweight(duck,girl).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Atom);
	Parser.ParseAtom("witch(girl).", Atom);
	Success = Model.Ask(Atom);
	Assert("PL 3: ", Success);
	Parser.ParseAtom("witch(X).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Ask(Atom, SubstitutionString);
	Assert("PL 4: " + SubstitutionString, SubstitutionString == "{ {X=girl} }");

	Parser.ParseAtom("parent(cor, patrick).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Atom);
	Parser.ParseAtom("parent(patrick, sky_sarah).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Atom);
	Parser.ParseAtom("parent(patrick, lila_sophia).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Tell(Atom);
	Parser.ParseAtom("grandparent(cor, sky_sarah).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Success = Model.Ask(Atom);
	Assert("PL 1: ", Success);
	Parser.ParseAtom("grandparent(cor, Q).", Atom);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.Ask(Atom, SubstitutionString);
	Assert("PL 2: " + SubstitutionString, SubstitutionString == "{ {Q=sky_sarah}{Q=lila_sophia} }");
}

void CTest::TestdMARS(void)
{
	CdMARSModel Model;
	CdMARSParser &Parser = Model.GetParser();
	bool Available;
	CPLAtom Belief;

	CLogger::GetLogger().SetLogFile("dMARS.log");

	LOG_DEBUG("1");
	// test 1:
	// - plan with simple trigger and body
	// - test if plan executes
	Parser.ParseAtom("rain(weather).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddBelief(Belief);

	Model.AddPlan(Parser.ParsePlan(
		"trigger: +rain(weather);" \
		"body: +cold(weather)."));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	// Process events
	Model.Update();
	// execute plan
	Model.Update();
	// check sentence in db
	Parser.ParseAtom("cold(weather).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 1", Available);

	LOG_DEBUG("2");
	// test 2:
	// trigger has 2 conditions
	// there is a context
	// body has a subgoal
	// the subgoal triggers a plan that creates the condition of the second subgoal
	// use of variables: in trigger, context, and body
	Model.AddPlan(Parser.ParsePlan(
		"trigger: +b(X);" \
		"context: rain(weather), a(X);" \
		"body: !c(X) -> ( +d(X) )."
		));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddPlan(Parser.ParsePlan(
		"trigger: !c(Y);" \
		"body: +c(Y)."
		));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Parser.ParseAtom("a(q).", Belief);
	Model.AddBelief(Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Parser.ParseAtom("b(q).", Belief);
	Model.AddBelief(Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	// Process events
	Model.Update();
	Model.Update();
	Model.Update();
	// execute 1st plan
	Model.Update();
	// process goal event
	Model.Update();
	// execute 2nd plan
	Model.Update();
	// process events
	Model.Update();
	// clear up intention
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	// check sentence in db
	Parser.ParseAtom("d(q).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 2", Available);

	LOG_DEBUG("3");
	// test 3:
	// negatives
	// trigger with retraction
	Model.AddPlan(Parser.ParsePlan(
		"trigger: -b(X);" \
		"context: NOT dry(weather);" 
		"body: -c(X)."
		));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Parser.ParseAtom("b(q).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.RemoveBelief(Belief);
	// process goal event
	Model.Update();
	// execute plan
	Model.Update();
	// check sentence in db
	Parser.ParseAtom("c(q).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 3", !Available);

	LOG_DEBUG("4");
	// test 4:
	// test a failing and a succeeding plan
	// test a test goal
	Model.AddPlan(Parser.ParsePlan(
		"trigger: +evening(X);" \
		"body: ?dark(X);" \
		"success: +success1(X);"
		"failure: +failed1(X)."
		));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddPlan(Parser.ParsePlan(
		"trigger: +red(X);" \
		"body: ?blue(X);" \
		"success: +success2(X);"
		"failure: +failed2(X)."
		));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Parser.ParseAtom("evening(now).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddBelief(Belief);
	Parser.ParseAtom("dark(now).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddBelief(Belief);
	Parser.ParseAtom("red(jacket).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddBelief(Belief);
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Model.Update();
	Parser.ParseAtom("success1(now).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 4a", Available);
	Parser.ParseAtom("failed1(now).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 4b", !Available);
	Parser.ParseAtom("success2(jacket).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 4c", !Available);
	Parser.ParseAtom("failed2(jacket).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Available = Model.HasBelief(Belief);
	Assert("dMARS test 4d", Available);

	LOG_DEBUG("5");
	// test 5:
	// add an external goal
	// no body
	// test the result of a subgoal should be substituted in the environment
	Model.AddPlan(Parser.ParsePlan(
		"trigger: !honger(X);" \
		"body: ?zoek_eten(X, E) -> ( +eet(aap, E) )." \
		));
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
		Parser.ParseAtom("zoek_eten(aap, banaan).", Belief);
	Assert("syntax error: "+Parser.GetError(), Parser.IsSuccessful());
	Model.AddBelief(Belief);
}

void CTest::TestAll(void)
{
	//_CrtSetBreakAlloc(62752);

    TestCase("String", &CTest::TestString);
	TestCase("HashTable", &CTest::TestHashTable);
    TestCase("Array", &CTest::TestArray);
    TestCase("Ring", &CTest::TestRing);
	TestCase("Stack", &CTest::TestStack);
	TestCase("TestBitPatterns", &CTest::TestBitPattern);
	TestCase("TestSmartPointer", &CTest::TestSmartPointer);

    TestCase("TestFuzzyCategory", &CTest::TestFuzzyCategory);
    TestCase("TestFuzzy", &CTest::TestFuzzy);
    TestCase("TestFuzzySet", &CTest::TestFuzzySet);
    TestCase("TestFuzzyOutputSet", &CTest::TestFuzzyOutputSet);
    TestCase("TestFuzzyOperator", &CTest::TestFuzzyOperator);
    TestCase("TestFuzzyRule", &CTest::TestFuzzyRule);
    TestCase("TestFuzzyModelFCLLoader", &CTest::TestFuzzyModelFCLLoader);
    TestCase("TestGeneticPopulation", &CTest::TestGeneticPopulation);
    TestCase("TestGeneticModel", &CTest::TestGeneticModel);
	TestCase("TestPL", &CTest::TestPL);
	TestCase("TestdMARS", &CTest::TestdMARS);
}

}
