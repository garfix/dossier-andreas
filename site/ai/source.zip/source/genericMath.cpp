#include <stdlib.h>
#include "genericMath.h"
#include "genericRing.h"

namespace generic
{

int CMath::GetRandomInt(int Min, int Max)
{
	return Min + rand() % (Max - Min + 1);
}

float CMath::GetRandomFloat(float Min, float Max)
{
	float Random, Part;

	Part = (rand() % 10001) / 10000.0f;
	Random = Min + Part * (Max - Min);
	return Random;
}

bool CMath::GetRandomBool(void)
{
	return ((rand() % 2) == 0);
}

/// Returns the probability of Value occurring in the set with mean Mean and standard deviation SD.
/// Normal or Gaussion distribution.
double CMath::GetGaussianProbability(double Mean, double SD, double Value)
{
	double pi = 3.1415926535;
	static double twoPiRoot = sqrt(2.0 * pi);
	double a, b, c, d;

	a = SD * twoPiRoot;
	b = -((Value - Mean) * (Value - Mean));
	c = 2.0 * SD * SD;
	d = exp(b / c) / a;

	return d;
}

/// Returns the x-axis value given its probability in a normal distribution
/// It's a combination of 
/// http://www.adug.org.au/MathsCorner/MathsCornerNDist2.htm
/// and http://www.pitt.edu/~wpilib/statfaq/gaussfaq.html
double CMath::GetInverseGaussianProbability(double Mean, double SD, double Probability)
{
	double P, X, T;
	
	const double c_0 = 2.515517;
	const double c_1 = 0.802853;
	const double c_2 = 0.010328;
	const double d_1 = 1.432788;
	const double d_2 = 0.189269;
	const double d_3 = 0.001308;

	// If you have p > 0.5, then apply the algorithm below to q = 1-p, 
	// and then negate the value for X obtained.
	if (Probability <= 0.5) P = Probability; else P = 1.0 - Probability;

	T = sqrt(-log(P*P));

	X = T -
		(c_0 + c_1*T + c_2*T*T) /
		(1.0 + d_1*T + d_2*T*T + d_3*T*T*T);

    if (Probability <= 0.5) return (Mean + X * SD); else return (Mean - X * SD);
}


}