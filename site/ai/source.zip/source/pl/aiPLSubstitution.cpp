#include "aiPLSubstitution.h"
#include "aiPLElements.h"

CPLSubstitution::CPLSubstitution()
{
}

CPLSubstitution::~CPLSubstitution()
{
}

const CPLSubstitution &CPLSubstitution::operator=(const CPLSubstitution &Substitution)
{
	// shallow copy
	Variables = Substitution.Variables;
	Values = Substitution.Values;

	return (*this);
}

bool CPLSubstitution::operator==(const CPLSubstitution &Substitution)
{
	if (Substitution.GetVariableCount() != this->GetVariableCount()) return false;
	for (int i=0; i < Substitution.GetVariableCount(); i++)
	{
		const CPLVariable *Variable = Substitution.GetVariable(i);
		if (this->Get(Variable) != Substitution.Get(Variable)) return false;
	}
	return true;
}

bool CPLSubstitution::operator!=(const CPLSubstitution &Substitution)
{
	return !operator==(Substitution);
}

const CPLElement *CPLSubstitution::Get(const CPLVariable *Variable) const
{
	for (int i=0; i < Variables.GetLength(); i++)
	{
		if (Variables.Get(i) == Variable) return Values.Get(i);
	}
	return 0;
}

void CPLSubstitution::Set(const CPLVariable *Variable, const CPLElement *Value)
{
	for (int i=0; i < Variables.GetLength(); i++)
	{
		if (Variables.Get(i) == 0) continue;
		if (Variables.Get(i) == Variable)
		{
			Values.Set(i, Value);
			return;
		}
	}
	// not found
	Variables.Add(Variable);
	Values.Add(Value);
}

/// Binds a question to an answer.
/// A variable X of QuestionSubstitution is looked up in AnswerSubstitution;
/// if variable X is also present in AnswerSubstitution, the value belonging to X
/// in AnswerSubstitution is bound to the variable X in QuestionSubstitution.
/// The resulting substitution is returned as a new object.
CPLSubstitution CPLSubstitution::Compose(const CPLSubstitution &AnswerSubstitution)
{
	CPLSubstitution Target = *this;

	for (int i=0; i < GetVariableCount(); i++)
	{
		const CPLVariable *Variable = GetVariable(i);
		const CPLElement *Value = AnswerSubstitution.Get(Variable);
		if (Value) Target.Set(Variable, Value);
	}
	return Target;
}

const CText CPLSubstitution::ToString(void) const
{
	CText String;

	String += "{";
	for (int i=0; i < Variables.GetLength(); i++)
	{
		String += Variables.Get(i)->GetName() + "=";
		if (Values.Get(i) == 0) String += "undefined";
		else String += Values.Get(i)->ToString();
		if (i < Variables.GetLength()-1) String += "; ";
	}
	String += "}";
	return String;
}