#include "aiPLModel.h"
#include "aiPLSubstitution.h"
#include "aiPLParser.h"

CPLPredicateConstant *CPLModel::PREDICATECONSTANT_EQUALS = 0;

CPLModel::CPLModel():
	FunctionConstants(1001), 
	PredicateConstants(1001), 
	ObjectConstants(1001),
	IndexOfAtoms(1001), 
	IndexOfAntecedents(1001), 
	IndexOfConsequents(1001)
{
	Parser = new CPLParser(this);
	
	// built-in predicates
	PREDICATECONSTANT_EQUALS = GetPredicateConstantForced("=");
}

CPLModel::~CPLModel()
{
	// predicate logic elements
	Facts.DeleteContents();
	ObjectConstants.DeleteValues();
	FunctionConstants.DeleteValues();
	PredicateConstants.DeleteValues();

	// index
	IndexOfAtoms.DeleteValues();
	IndexOfAntecedents.DeleteValues();
	IndexOfConsequents.DeleteValues();

	delete Parser;
}

/// Returns the object constant with the name Name.
/// If the object constant didn't exist, is is created.
CPLObjectConstant *CPLModel::GetObjectConstantForced(const CText &Name)
{
	CPLObjectConstant *ObjectConstant;
	bool Found;

	ObjectConstant = ObjectConstants.Get(Name.GetHashCode(), Name, Found);

	if (!Found)
	{
		ObjectConstant = new CPLObjectConstant();
		ObjectConstant->SetName(Name);
		ObjectConstants.Put(Name.GetHashCode(), Name, ObjectConstant);
	}
	return ObjectConstant;
}

/// Returns the function constant with the name FunctionSymbol.
/// If the function constant didn't exist, is is created.
CPLFunctionConstant *CPLModel::GetFunctionConstantForced(const CText &FunctionSymbol)
{
	CPLFunctionConstant *FunctionConstant;
	bool Found;
	
	FunctionConstant = FunctionConstants.Get(FunctionSymbol.GetHashCode(), FunctionSymbol, Found);

	if (!Found)
	{
		FunctionConstant = new CPLFunctionConstant();
		FunctionConstant->SetName(FunctionSymbol);
		FunctionConstants.Put(FunctionSymbol.GetHashCode(), FunctionSymbol, FunctionConstant);
	}
	return FunctionConstant;
}

/// Returns the predicate constant with the name PredicateSymbol.
/// If the predicate constant didn't exist, is is created.
CPLPredicateConstant *CPLModel::GetPredicateConstantForced(const CText &PredicateSymbol)
{
	CPLPredicateConstant *PredicateConstant;
	bool Found;
	
	PredicateConstant = PredicateConstants.Get(PredicateSymbol.GetHashCode(), PredicateSymbol, Found);

	if (!Found)
	{
		PredicateConstant = new CPLPredicateConstant();
		PredicateConstant->SetName(PredicateSymbol);
		PredicateConstants.Put(PredicateSymbol.GetHashCode(), PredicateSymbol, PredicateConstant);
	}
	return PredicateConstant;
}

/// Adds Element to the list of facts; but only if the Element wasn't available already.
/// ModelChanged: TRUE if the Element has been added
void CPLModel::Store(CPLElement *Element, bool &ModelChanged)
{
	ModelChanged = false;
	if (Element->GetType() == PLTYPE_ATOM)
	{
		if (!Find((CPLAtom *)Element))
		{
			Facts.Add(Element);
			ModelChanged = true;
		}
	} 
	else 
	{
		for (int i=0; i < Facts.GetLength(); i++)
		{
			if (Element->Equals(Facts.Get(i))) return;
		}
		Facts.Add(Element);
		ModelChanged = true;
		return;
	}
}

/// Indexes Element for quick lookup. Table-based.
void CPLModel::DoIndex(CPLElement *Element)
{
	bool Found;
	CRow<CPLAtom *> *Atoms;
	CRow<CPLRule *> *Rules;
	CPLRule *Rule;
	CPLAtom *Atom;
	CPLPredicateConstant *PredicateConstant;

	if (Element->GetType() == PLTYPE_ATOM)
	{
		Atom = (CPLAtom *)Element;
		PredicateConstant = Atom->GetPredicateConstant();
		Atoms = IndexOfAtoms.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
		if (!Found)
		{
			Atoms = new CRow<CPLAtom *>();
			IndexOfAtoms.Put(PredicateConstant->GetHashCode(), PredicateConstant, Atoms);
		}
		Atoms->Add(Atom);
	}
	else if (Element->GetType() == PLTYPE_RULE)
	{
		Rule = (CPLRule *)Element;
		for (int i=0; i < Rule->GetAntecedentCount(); i++)
		{
			Atom = (CPLAtom *)Rule->GetAntecedent(i);
			PredicateConstant = Atom->GetPredicateConstant();
			Rules = IndexOfAntecedents.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
			if (!Found)
			{
				Rules = new CRow<CPLRule *>();
				IndexOfAntecedents.Put(PredicateConstant->GetHashCode(), PredicateConstant, Rules);
			}
			Rules->Add(Rule);
		}
		for (int i=0; i < Rule->GetConsequentCount(); i++)
		{
			Atom = (CPLAtom *)Rule->GetConsequent(i);
			PredicateConstant = Atom->GetPredicateConstant();
			Rules = IndexOfConsequents.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
			if (!Found)
			{
				Rules = new CRow<CPLRule *>();
				IndexOfConsequents.Put(PredicateConstant->GetHashCode(), PredicateConstant, Rules);
			}
			Rules->Add(Rule);
		}
	}
}

/// Removes Element from its index.
void CPLModel::UnIndex(CPLElement *Element)
{
	bool Found;
	CRow<CPLAtom *> *Atoms;
	CRow<CPLRule *> *Rules;
	CPLRule *Rule;
	CPLAtom *Atom;
	CPLPredicateConstant *PredicateConstant;

	if (Element->GetType() == PLTYPE_ATOM)
	{
		Atom = (CPLAtom *)(CPLFormula *)Element;
		PredicateConstant = Atom->GetPredicateConstant();
		Atoms = IndexOfAtoms.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
		if (!Found) return;
		else Atoms->Remove(Atom);
	}
	else if (Element->GetType() == PLTYPE_RULE)
	{
		Rule = (CPLRule *)Element;
		for (int i=0; i < Rule->GetAntecedentCount(); i++)
		{
			Atom = (CPLAtom *)Rule->GetAntecedent(i);
			PredicateConstant = Atom->GetPredicateConstant();
			Rules = IndexOfAntecedents.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
			if (!Found) return;
			else Rules->Remove(Rule);
		}
		for (int i=0; i < Rule->GetConsequentCount(); i++)
		{
			Atom = (CPLAtom *)Rule->GetConsequent(i);
			PredicateConstant = Atom->GetPredicateConstant();
			Rules = IndexOfConsequents.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
			if (!Found) return;
			else Rules->Remove(Rule);
		}
	}
}

void CPLModel::UnifyVariable(const CPLVariable *Var, const CPLElement *X, CPLSubstitution &CurrentSubstitution, CPLSubstitution &NewSubstitution, bool &Success)
{
	const CPLElement *CurrentValue;

	CurrentValue = NewSubstitution.Get(Var);
	if (CurrentValue != 0)
	{
		// Var already has a binding; don't try to bind X
		UnifyInternal(CurrentValue, X, CurrentSubstitution, NewSubstitution, Success);
	}
	else 
	{
		if ((X->GetType() == PLTYPE_VARIABLE) &&
			((CurrentValue = NewSubstitution.Get((CPLVariable *)X)) != 0))
		{
			// X already has a binding (so X is a variable); now try to bind Var
			UnifyInternal(Var, CurrentValue, CurrentSubstitution, NewSubstitution, Success);
		}
		else 
		{
			NewSubstitution.Set(Var, X);
		}
	}
}

void CPLModel::UnifyInternal(const CPLElement *Q1, const CPLElement *Q2, CPLSubstitution &CurrentSubstitution, CPLSubstitution &NewSubstitution, bool &Success)
{
	if (Q1->IsVariable())
	{
		const CPLElement *SubQ1 = CurrentSubstitution.Get((CPLVariable *)Q1);
		if (SubQ1) Q1 = SubQ1;
	}
	if (Q2->IsVariable())
	{
		const CPLElement *SubQ2 = CurrentSubstitution.Get((CPLVariable *)Q2);
		if (SubQ2) Q2 = SubQ2;
	}

	if (Q1->Equals(Q2))
	{
		return;
	}
	else if (Q1->GetType() == PLTYPE_VARIABLE)
	{
		UnifyVariable((CPLVariable *)Q1, Q2, CurrentSubstitution, NewSubstitution, Success);
		return;
	}
	else if (Q2->GetType() == PLTYPE_VARIABLE)
	{
		UnifyVariable((CPLVariable *)Q2, Q1, CurrentSubstitution, NewSubstitution, Success);
		return;
	}
	else if ((Q1->GetType() == PLTYPE_ATOM) && (Q2->GetType() == PLTYPE_ATOM))
	{
		bool ArgumentSuccess = true;
		for (int i=0; i < ((CPLAtom *)Q1)->GetArgumentCount(); i++)
		{
			UnifyInternal(((CPLAtom *)Q1)->GetArgument(i), ((CPLAtom *)Q2)->GetArgument(i), CurrentSubstitution, NewSubstitution, ArgumentSuccess);
			if (!ArgumentSuccess) break;
		}
		Success = ArgumentSuccess;
		return;
	}

	Success = false;
	return;
}

/// Tries to unify Q1 with Q2.
/// Success is false if this fails.
CPLSubstitution CPLModel::Unify(const CPLElement *Q1, const CPLElement *Q2, CPLSubstitution &CurrentSubstitution, bool &Success)
{
	Success = true;
	//return UnifyInternal(Q1, Q2, CurrentSubstitution, Success);
/* !! */	CPLSubstitution NewSubstitution = CurrentSubstitution;
	UnifyInternal(Q1, Q2, CurrentSubstitution, NewSubstitution, Success);

    return NewSubstitution;
}

/// Returns a substitution to make Q1 and Q2 identical, if possible.
/// Currently does not handle compound formulas.
CPLSubstitution CPLModel::Unify(const CPLElement *Q1, const CPLElement *Q2, bool &Success)
{
	CPLSubstitution Substsitution;
	Success = true;
	UnifyInternal(Q1, Q2, CPLSubstitution(), Substsitution, Success);
	return Substsitution;
}

/// Attempts to unify Formula with the facts in this knowledge base.
/// If the attempt fails, Success is returned false;
/// otherwise Success is true and the substitution is returned.
CRow<CPLSubstitution> CPLModel::Unify(const CPLAtom &Atom, CPLSubstitution &CurrentSubstitution)
{
	return BackChain(Atom, CurrentSubstitution);
}

CRow<CPLSubstitution> CPLModel::Unify(CRow<const CPLAtom *> Atoms, CPLSubstitution &Substitution)
{
	return BackChainList(Atoms, Substitution);
}

/// Tries to locate an atom in the knowledge base that is equivalent to Atom; and returns it.
/// Returns 0 if none could be found.
CPLAtom *CPLModel::Find(CPLAtom *Atom)
{
	CPLPredicateConstant *PredicateConstant;
	CPLSubstitution Substitution;
	CRow<CPLAtom *> *Atoms;
	bool RowFound;
	bool AtomFound = false;

	PredicateConstant = Atom->GetPredicateConstant();
	Atoms = IndexOfAtoms.Get(PredicateConstant->GetHashCode(), PredicateConstant, RowFound);
	if (RowFound)
	{
		for (int i=0; i < Atoms->GetLength(); i++)
		{
			Unify(Atom, Atoms->Get(i), Substitution, AtomFound);
			if (AtomFound) return Atoms->Get(i);
		}
	}
	return 0;
}

/// \QList The antecedents of a rule, or (the latter) part of it
/// \QListIndex Only QList elements with index QListStartIndex and further need be processed
CRow<CPLSubstitution> CPLModel::BackChainList(
	const CRow<const CPLAtom *> &QList, 
	CPLSubstitution &CurrentSubstitution, 
	int QListIndex)
{
	CRow<CPLSubstitution> Answers;
	bool Found, Success;
//CText cursub = CurrentSubstitution.ToString();
	
	// check if the recursion is reached its full depth
	// (or the more simple case that QList is empty)
	if (QListIndex >= QList.GetLength())
	{
		// the given substitution is valid
		Answers.Add(CurrentSubstitution);
		return Answers;
	}

	// fetch current atom of the query
	CPLAtom *Q = (CPLAtom *)QList.Get(QListIndex);
//CText qq = Q->ToString();
	CPLPredicateConstant *PredicateConstant = Q->GetPredicateConstant();

	if (PredicateConstant == PREDICATECONSTANT_EQUALS) 
	{
		bool Equals = true;
		const CPLTerm *Arg1, *Arg2;
		for (int i=0; i < Q->GetArgumentCount()-1; i++)
		{
			Arg1 = Q->GetArgument(i);
			Arg2 = Q->GetArgument(i+1);
			if (Arg1->IsVariable()) Arg1 = (CPLTerm *)CurrentSubstitution.Get((CPLVariable *)Arg1);
			if (Arg2->IsVariable()) Arg2 = (CPLTerm *)CurrentSubstitution.Get((CPLVariable *)Arg2);
			if (!Arg1->Equals(Arg2)) Equals = false;
		}
		if (Equals) Answers.Add(CurrentSubstitution);
	}

	// find all atoms matching Q, and add the substitutions needed
	CRow<CPLAtom *> *Atoms = IndexOfAtoms.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
	if (Found)
	{
		for (int i=0; i < Atoms->GetLength(); i++)
		{
			CPLSubstitution Substitution = Unify(Atoms->Get(i), Q, CurrentSubstitution, Success);
			if (Success) Answers.Add(Substitution);
//CText sub = Substitution.ToString();
		}
	}

	// check all rules to see if they match
	CRow<CPLRule *> *Rules = IndexOfConsequents.Get(PredicateConstant->GetHashCode(), PredicateConstant, Found);
	if (Found)
	{
		for (int i=0; i < Rules->GetLength(); i++)
		{
			CPLRule *Rule = Rules->Get(i);
			// find the rule's consequent that matches Q
			const CPLAtom *Consequent = Rule->GetConsequent(PredicateConstant);
			CPLSubstitution Substitution = Unify(Consequent, Q, CurrentSubstitution, Success);
//CText s = Substitution.ToString();
			if (Success)
			{
				CRow<CPLSubstitution> Subs = BackChainList(Rule->GetAntecedents(), Substitution);
				for (int s=0; s < Subs.GetLength(); s++)
				{
//CText sub = Subs.Get(s).ToString();
					Answers.Add(Subs.Get(s));
				}
			}
		}
	}

	// handle negated atoms (i.e. NOT blue(sky) )
	// if Q is NOT blue(sky) and blue(sky) was not found, just skip this atom
	if (!Q->IsPositive() && Answers.IsEmpty())
	{
		Answers.Add(CurrentSubstitution);
		return Answers;
	}
	// if Q is NOT blue(sky) and blue(sky) was found, disregard all findings
	else if (!Q->IsPositive() && !Answers.IsEmpty())
	{
		Answers.Clear();
		return Answers;
	}

	// at this point we have found a number of substitutions for Q, the QListStartIndex-th
	// element of QList. we now proceed by checking these substitution on the rest of the QList.
	// We also make sure the results are returned only once (a union)
	CRow<CPLSubstitution> Union;
	for (int i=0; i < Answers.GetLength(); i++)
	{
//CText answ = Answers.Get(i).ToString();
		CRow<CPLSubstitution> SubstitutionList;
		SubstitutionList = BackChainList(QList, Answers.Get(i), QListIndex+1);
		for (int s=0; s < SubstitutionList.GetLength(); s++)
		{
			CPLSubstitution &Substitution = SubstitutionList.Get(s);
//			Substitution = CurrentSubstitution.Compose(Substitution);
			if (!Union.Contains(Substitution)) Union.Add(Substitution);
		}
	}
//CText u; for(int e=0; e<Union.GetLength(); e++) u+= Union.Get(e).ToString();
	return Union;
}

/// Returns all substitutions that bind Atom with the facts in the knowledge base.
/// It does this by checking the grounded facts and applying the knowledge base rules.
CRow<CPLSubstitution> CPLModel::BackChain(const CPLAtom &Atom, CPLSubstitution &CurrentSubstitution)
{
	CRow<const CPLAtom *> QList(1);
	QList.Set(0, &Atom);

	CRow<CPLSubstitution> Substitutions = BackChainList(QList, CurrentSubstitution);

// Temp: this code should not be necessary; it removes unwanted variables from the
// substitution
for (int i=0; i < Substitutions.GetLength(); i++)
{
	CPLSubstitution S = CurrentSubstitution.Compose(Substitutions.Get(i));
	Substitutions.Set(i, S);
}

	return Substitutions;
}

/// Atom is added to this Knowledge Base.
/// If there already was such an Atom available, ModelChanged will return FALSE.
void CPLModel::Tell(CPLAtom &Atom, bool &ModelChanged)
{
	// it is not allowed to tell negative facts!
	// (the absence of facts is their negation)
	assert(Atom.IsPositive());
	// copy the atom
	CPLAtom *Copy = new CPLAtom(Atom);
	// store the Atom
	Store(Copy, ModelChanged);
	if (ModelChanged)
	{
		// the Atom had not been stored before.
		// index the new Atom for quick lookup, using Ask()
		DoIndex(Copy);
	}
	else
	{
		delete Copy;
	}
}

/// Element is added to this Knowledge Base, if it wasn't available already.
void CPLModel::Tell(CPLAtom &Atom)
{ 
	bool ModelChanged; 
	return Tell(Atom, ModelChanged); 
}

void CPLModel::Tell(CPLRule *Rule)
{
	bool ModelChanged;

	// store the Rule
	Store(Rule, ModelChanged);
	if (ModelChanged)
	{
		DoIndex(Rule);
	}
}

bool CPLModel::Ask(CPLAtom &Atom, CRow<CPLSubstitution> &Substitutions)
{
	// create a substitution (with unbound variables) that contains all Atom's variables
	CPLSubstitution VariableList;
    Atom.ListVariables(VariableList);

	// find all substitutions to match Atom with the facts of the knowledge base
	Substitutions = BackChain(Atom, VariableList);

	// the the user asked for a negative, we return true if there were no results
	// otherwise, we return true if there was at least one result
	return !Substitutions.IsEmpty();
}

bool CPLModel::Ask(CPLAtom &Atom)
{
	CRow<CPLSubstitution> Substitutions;

	return Ask(Atom, Substitutions);
}

bool CPLModel::Ask(CPLAtom &Atom, CText &SubstitutionString)
{
	CRow<CPLSubstitution> Substitutions;
	bool SubstitutionsFound;

	SubstitutionsFound = Ask(Atom, Substitutions);
	SubstitutionString = "{ ";
	for (int i=0; i<Substitutions.GetLength(); i++)
	{
		SubstitutionString += Substitutions.Get(i).ToString();
	}
	SubstitutionString += " }";

	return SubstitutionsFound;
}

/// Element is removed from this Knowledge Base.
/// If there was no such element, ModelChanged will return FALSE.
void CPLModel::Retract(CPLAtom &Atom, bool &ModelChanged)
{
	CPLAtom *FoundAtom = Find(&Atom);
	if (FoundAtom)
	{
		// remove
		UnIndex(FoundAtom);
		Facts.Remove(FoundAtom);
		delete FoundAtom; 
	}
	ModelChanged = (FoundAtom != 0);
}

/// Atom is removed from this Knowledge Base.
void CPLModel::Retract(CPLAtom &Atom)
{
	bool ModelChanged;
	Retract(Atom, ModelChanged);
}
