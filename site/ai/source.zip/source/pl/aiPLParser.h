#ifndef _PLPARSER
#define _PLPARSER

#include "generic.h"
#include "aiPLElements.h"

using namespace generic;

class CPLModel;

class CPLParser: public CLoader
{
protected:
	CPLModel *Model;

	static const int PRECEDENCE_FUNCTION;
	static const int PRECEDENCE_ATOM;
	static const int PRECEDENCE_NOT;
	static const int PRECEDENCE_OR;
	static const int PRECEDENCE_AND;
	static const int PRECEDENCE_BRACKETS;
	static const int PRECEDENCE_RULE;
	static const int PRECEDENCE_DEFAULT;

	CPLElement *ParseElement(int ParentPrecedence, CHashTable<CText, const CPLVariable *> &Variables);

public:
	CPLParser(CPLModel *NewModel);
	~CPLParser();

	CPLElement *Parse(const CText &String);

	void ParseAtom(const CText &String, CPLAtom &Atom);
};

#endif
