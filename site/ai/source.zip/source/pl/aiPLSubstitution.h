#ifndef _PLSUBSTITUTION
#define _PLSUBSTITUTION

#include "generic.h"

using namespace generic;

class CPLVariable;
class CPLElement;

class CPLSubstitution: public CElement
{
protected:
	CRow<const CPLVariable *> Variables;
	CRow<const CPLElement *> Values;

public:
	CPLSubstitution();
	~CPLSubstitution();

	const CPLSubstitution &operator=(const CPLSubstitution &Substitution);
	bool operator==(const CPLSubstitution &Substitution);
	bool operator!=(const CPLSubstitution &Substitution);

	int GetVariableCount(void) const { return Variables.GetLength(); }
	const CPLVariable *GetVariable(int Index) const { return Variables.Get(Index); }
	const CPLElement *GetValue(int Index) const { return Values.Get(Index); }

	const CPLElement *Get(const CPLVariable *Variable) const;
	void Set(const CPLVariable *Variable, const CPLElement *Value);

	CPLSubstitution Compose(const CPLSubstitution &AnswerSubstitution);
	virtual const CText ToString(void) const;
};

#endif
