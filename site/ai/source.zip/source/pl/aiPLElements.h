#ifndef _PLELEMENTS
#define _PLELEMENTS

#include "generic.h"
#include "aiPLSubstitution.h"

using namespace generic;

enum EPLType
{
	PLTYPE_ELEMENT,
	PLTYPE_TERM,
	PLTYPE_OBJECTCONSTANT,
	PLTYPE_VARIABLE,
	PLTYPE_FUNCTION,
	PLTYPE_FORMULA,
	PLTYPE_ATOM,
	PLTYPE_COMPOUNDFORMULA,
	PLTYPE_FORMULA_AND,
	PLTYPE_FORMULA_OR,
	PLTYPE_FORMULA_NOT,
	PLTYPE_RULE,
	PLTYPE_CUT_OPERATOR
};

class CPLElement: public CElement
{
public:
	virtual EPLType GetType(void) const { return PLTYPE_ELEMENT; }
	virtual bool CanUnify(const CPLElement *Element) const { return false; }
	virtual bool Equals(const CPLElement *Element) const { return false; }
	virtual bool IsA(EPLType Type) const { return false; }
	bool IsVariable(void) const { return (GetType() == PLTYPE_VARIABLE); }
};

/* CONSTANTS */

/// Function constant: the name of the function (we leave out 'arity' for the moment)
class CPLFunctionConstant: public CPLElement
{
};

/// Predicate constant: the name of the atom (we leave out 'arity' for the moment)
class CPLPredicateConstant: public CPLElement
{
};

/* TERMS */

/// A term is a logical expression that refers to an object.
class CPLTerm: public CPLElement
{
public:
	virtual EPLType GetType(void) const { return PLTYPE_TERM; }
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_TERM); }
};

/// An object constant may be seen as a function with arity 0,
/// with the restriction that their may be only one object constant for any name.
/// To enforce this, and to save space, constants get an extra class.
class CPLObjectConstant: public CPLTerm
{
protected:
	bool Value;

public:
	void SetValue(bool NewValue){ Value = NewValue; }
	bool GetValue(void) const { return Value; }

	virtual EPLType GetType(void) const { return PLTYPE_OBJECTCONSTANT; }
	virtual const CText ToString(void) const;
	virtual bool CanUnify(const CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_OBJECTCONSTANT || CPLTerm::IsA(Type)); }
};

class CPLVariable: public CPLElement
{
protected:
	int RefCount;

public:
	CPLVariable();
	virtual EPLType GetType(void) const { return PLTYPE_VARIABLE; }
	virtual const CText ToString(void) const;
	virtual bool CanUnify(const CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_VARIABLE); }

	void IncRefCount(void){ RefCount++; }
	void DecRefCount(void){ RefCount--; if (RefCount == 0) delete this; }
};

/// Currently the function does not have a fixed arity.
class CPLFunction: public CPLTerm
{
protected:
	CPLFunctionConstant *FunctionConstant;
	CRow<CPLTerm *> Arguments;

public:
	CPLFunction(CPLFunctionConstant *NewFunctionConstant){ FunctionConstant = NewFunctionConstant; }
	virtual ~CPLFunction();

	void ListVariables(CPLSubstitution &Substitution) const;
	void Substitute(CPLSubstitution &Substitution);
	CPLFunction *Clone(void) const;
    
	void SetFunctionConstant(CPLFunctionConstant *NewFunctionConstant){ FunctionConstant = NewFunctionConstant; }
	CPLFunctionConstant *GetFunctionConstant(void) const { return FunctionConstant; }

	void AddArgument(CPLTerm *Term){ Arguments.Add(Term); }

	virtual EPLType GetType(void) const { return PLTYPE_FUNCTION; }
	virtual const CText ToString(void) const;
	virtual bool CanUnify(const CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_FUNCTION || CPLTerm::IsA(Type)); }
};

/* FORMULAS */

class CPLFormula: public CPLElement
{
protected:
	/// Positive: if false(!), this formula is spanned by a NOT operator
	bool Positive;

public:
	CPLFormula();

	virtual EPLType GetType(void) const { return PLTYPE_FORMULA; }

	void SetPositive(bool NewPositive){ Positive = NewPositive; }
	bool IsPositive(void) const { return Positive; }
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_FORMULA); }
};

/// Atom: simple formula
class CPLAtom: public CPLFormula
{
protected:
	CPLPredicateConstant *PredicateConstant;
	CRow<CPLTerm *> Arguments;

	void Clear();

public:
	CPLAtom(){}
	CPLAtom(const CPLAtom &Atom){ (*this) = Atom; };
	virtual ~CPLAtom();

	const CPLAtom &operator=(const CPLAtom &Atom);

	void Substitute(CPLSubstitution &Substitution);
	void ListVariables(CPLSubstitution &Substitution) const;

	void SetPredicateConstant(CPLPredicateConstant *NewPredicateConstant){ PredicateConstant = NewPredicateConstant; }
	CPLPredicateConstant *GetPredicateConstant(void) const { return PredicateConstant; }

	void AddArgument(CPLTerm *Term){ Arguments.Add(Term); }
	int GetArgumentCount(void) const { return Arguments.GetLength(); }
	CPLTerm *GetArgument(int Index) const { return Arguments.Get(Index); }

	virtual EPLType GetType(void) const { return PLTYPE_ATOM; }
	virtual const CText ToString(void) const;
	virtual bool CanUnify(const CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element, CPLSubstitution &Substitution) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_ATOM || CPLFormula::IsA(Type)); }
};

/// Formula containing multiple arguments.
class CPLCompoundFormula: public CPLFormula
{
protected:
	CRow<CPLFormula *> Arguments;

public:
	virtual ~CPLCompoundFormula();

	void AddArgument(CPLFormula *Formula){ Arguments.Add(Formula); }
	virtual EPLType GetType(void) const { return PLTYPE_COMPOUNDFORMULA; }

	int GetArgumentCount(void) const { return Arguments.GetLength(); }
	CPLFormula *GetArgument(int Index) const { return Arguments.Get(Index); }
	void RemoveArguments(void){ Arguments.Clear(); }
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_COMPOUNDFORMULA || CPLFormula::IsA(Type)); }
};

/// Logical AND
class CPLFormula_And: public CPLCompoundFormula
{
public:
	virtual EPLType GetType(void) const { return PLTYPE_FORMULA_AND; }
	virtual const CText ToString(void) const;
	virtual bool CanUnify(CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_FORMULA_AND || CPLCompoundFormula::IsA(Type)); }
};

/// Logical OR
class CPLFormula_Or: public CPLCompoundFormula
{
public:
	virtual EPLType GetType(void) const { return PLTYPE_FORMULA_OR; }
	virtual const CText ToString(void) const;
	virtual bool CanUnify(CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_FORMULA_OR || CPLCompoundFormula::IsA(Type)); }
};

/// Logical implication: a(x), b(x), ... <- c(x), d(x), ...
class CPLRule: public CPLCompoundFormula
{
protected:
	CRow<const CPLAtom *> Antecedents;
	CRow<const CPLAtom *> Consequents;
	CPairedRow<CText, const CPLVariable *> Variables;

public:
	CPLRule();
	virtual ~CPLRule();

	virtual EPLType GetType(void) const { return PLTYPE_RULE; }

	void AddVariable(const CText &Name, const CPLVariable *Variable);
	const CPLVariable *GetVariable(const CText &Name);

	void AddAntecedent(const CPLAtom *Atom){ Antecedents.Add(Atom); }
	const CPLAtom *GetAntecedent(int Index){ return Antecedents.Get(Index); }
	int GetAntecedentCount(void) const { return Antecedents.GetLength(); }
	const CRow<const CPLAtom *> &GetAntecedents(void) const { return Antecedents; }

	void AddConsequent(const CPLAtom *Atom){ Consequents.Add(Atom); }
	const CPLAtom *GetConsequent(int Index){ return Consequents.Get(Index); }
	int GetConsequentCount(void) const { return Consequents.GetLength(); }
	const CPLAtom *GetConsequent(CPLPredicateConstant *PredicateConstant) const;

	virtual const CText ToString(void) const;
	virtual bool CanUnify(CPLElement *Element) const;
	virtual bool Equals(const CPLElement *Element) const;
	virtual bool IsA(EPLType Type) const { return (Type == PLTYPE_RULE || CPLCompoundFormula::IsA(Type)); }
};

/// The cut operator (Prolog) tells the backtracking algorithm to stop searching for another match.
class CPLCutOperator: public CPLFormula
{
public:
	virtual EPLType GetType(void) const { return PLTYPE_CUT_OPERATOR; }
	virtual const CText ToString(void) const;
};

#endif
