#ifndef _PLMODEL
#define _PLMODEL

#include "generic.h"
#include "aiPLElements.h"
#include "aiPLParser.h"

using namespace generic;

class CPLSubstitution;

/// The Knowledge Base. It contains predicate logic Horn sentences.
///
/// Enter sentences by calling Tell(). Tell's syntax equals that of Prolog:
/// - variables: start with uppercase char or underscore
/// "pred(arg)" - an atom
/// "pred1(X, Z) :- pred2(X, _) & pred3(_, Z)"
/// see http://en.wikipedia.org/wiki/Prolog
///
/// From: Artificial Intelligence: A modern approach
///
/// - Closed World Assumption
///   (if a fact is not known to be true (or false), it is assumed to be false)
/// - uses Table-based indexing

class CPLModel: public CElement
{
	friend class CPLParser;

protected:
	static CPLPredicateConstant *PREDICATECONSTANT_EQUALS;

	CPLParser *Parser;
	// Facts: rules and ground functions
	CRow<CPLElement *> Facts;
	// constants
	CHashTable<CText, CPLObjectConstant *> ObjectConstants;
	// function constants
	CHashTable<CText, CPLFunctionConstant *> FunctionConstants;
	// predicate constants
	CHashTable<CText, CPLPredicateConstant *> PredicateConstants;
	// Index: the model uses Table-based indexing; this is the datastructure
	CHashTable<CPLPredicateConstant *, CRow<CPLAtom *> *> IndexOfAtoms;
	CHashTable<CPLPredicateConstant *, CRow<CPLRule *> *> IndexOfAntecedents;
	CHashTable<CPLPredicateConstant *, CRow<CPLRule *> *> IndexOfConsequents;

	CPLObjectConstant *GetObjectConstantForced(const CText &Name);
	CPLFunctionConstant *GetFunctionConstantForced(const CText &FunctionSymbol);
	CPLPredicateConstant *GetPredicateConstantForced(const CText &PredicateSymbol);

	void Store(CPLElement *Element, bool &ModelChanged);
	void UnIndex(CPLElement *Element);
	void DoIndex(CPLElement *Element);
	
	void UnifyVariable(const CPLVariable *Q1, const CPLElement *Q2, CPLSubstitution &CurrentSubstitution, CPLSubstitution &NewSubstitution, bool &Success);
	void UnifyInternal(const CPLElement *Q1, const CPLElement *Q2, CPLSubstitution &CurrentSubstitution, CPLSubstitution &NewSubstitution, bool &Success);
	CPLSubstitution Unify(const CPLElement *Q1, const CPLElement *Q2, bool &Success);
	CPLSubstitution Unify(const CPLElement *Q1, const CPLElement *Q2, CPLSubstitution &CurrentSubstitution, bool &Success);
	CPLSubstitution Compose(const CPLSubstitution &QuestionSubstitution, const CPLSubstitution &AnswerSubstitution);

	CRow<CPLSubstitution> BackChainList(const CRow<const CPLAtom *> &QList, CPLSubstitution &CurrentSubstitution, int QListStartIndex=0);
    CRow<CPLSubstitution> BackChain(const CPLAtom &Atom, CPLSubstitution &CurrentSubstitution = CPLSubstitution());

	CPLAtom *Find(CPLAtom *Atom);

public:

	CPLModel();
	~CPLModel();

	CPLParser &GetParser(void) const { return *Parser; }

	// general
	void Tell(CPLAtom &Atom, bool &ModelChanged);
	void Tell(CPLAtom &Atom);
	void Tell(CPLRule *Rule);
	void Retract(CPLAtom &Atom, bool &ModelChanged);
	void Retract(CPLAtom &Atom);
	
	bool Ask(CPLAtom &Atom);
	bool Ask(CPLAtom &Atom, CRow<CPLSubstitution> &Substitutions);
	bool Ask(CPLAtom &Atom, CText &SubstitutionString);

	// utility functions
	CRow<CPLSubstitution> Unify(const CPLAtom &Atom, CPLSubstitution &Substitution);
	CRow<CPLSubstitution> Unify(CRow<const CPLAtom *> Atoms, CPLSubstitution &Substitution);
	bool CanUnify(const CPLAtom &Atom, CPLSubstitution &Substitution){ return !Unify(Atom, Substitution).IsEmpty(); }
};

#endif
