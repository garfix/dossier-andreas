#include "aiPLElements.h"

const CText CPLObjectConstant::ToString(void) const
{
	return Name;
}

bool CPLObjectConstant::CanUnify(const CPLElement *Element) const
{
	return (Element == (CPLElement *)this);
}

bool CPLObjectConstant::Equals(const CPLElement *Element) const
{
	return (Element == (CPLElement *)this);
}

CPLVariable::CPLVariable()
{ 
	RefCount = 0; 
}

const CText CPLVariable::ToString(void) const
{
	return Name;
}

bool CPLVariable::CanUnify(const CPLElement *Element) const
{
	return true;
}

bool CPLVariable::Equals(const CPLElement *Element) const
{
	return (Element == (CPLElement *)this);
}

CPLFormula::CPLFormula()
{
//	Positive = true;
}

CPLFunction::~CPLFunction()
{
	CPLElement *Element;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		Element = Arguments.Get(i);

		if (Element->GetType() == PLTYPE_OBJECTCONSTANT) continue;
		if (Element->GetType() == PLTYPE_VARIABLE)
		{
			((CPLVariable *)Element)->DecRefCount();
			continue;
		}
		
		delete Element;
	}
}

CPLFunction *CPLFunction::Clone(void) const 
{
	CPLTerm *Term;
	CPLFunction *C = new CPLFunction(FunctionConstant);

	C->Arguments.SetLength(this->Arguments.GetLength());
    for (int i=0; i<this->Arguments.GetLength(); i++)
	{
		Term = this->Arguments.Get(i);
if (Term->GetType() == PLTYPE_FUNCTION) Term = ((CPLFunction *)Term)->Clone();
else if (Term->GetType() == PLTYPE_VARIABLE)
{
	((CPLVariable *)Term)->IncRefCount();
}
		C->Arguments.Set(i, Term);
	}
	return C;
}

const CText CPLFunction::ToString(void) const
{
	CText String;
	CPLTerm *Term;

	String = FunctionConstant->GetName();
	String += "(";
	for (int i=0; i < Arguments.GetLength(); i++)
	{
		Term = Arguments.Get(i);
		String += Term->ToString();
		if (i < Arguments.GetLength()-1) String += ", ";
	}
	String += ")";
	return String;
}

void CPLFunction::ListVariables(CPLSubstitution &Substitution) const
{
	CPLTerm *Term;

    for (int i=0; i<Arguments.GetLength(); i++)
	{
		Term = Arguments.Get(i);
		if (Term->GetType() == PLTYPE_FUNCTION) 
		{
			((CPLFunction *)Term)->ListVariables(Substitution);
		}
		else if (Term->IsVariable()) 
		{
			Substitution.Set((CPLVariable *)Term, 0);
		}
	}
}

void CPLFunction::Substitute(CPLSubstitution &Substitution)
{
	CPLTerm *Term;

    for (int i=0; i<Arguments.GetLength(); i++)
	{
		Term = Arguments.Get(i);
		if (Term->GetType() == PLTYPE_FUNCTION) 
		{
			((CPLFunction *)Term)->Substitute(Substitution);
		}
		else if (Term->IsVariable()) 
		{
			const CPLElement *Value = Substitution.Get((CPLVariable *)Term);
			if (Value) Arguments.Set(i, (CPLTerm *)Value);
		}
	}
}

bool CPLFunction::CanUnify(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLFunction *)Element)->GetFunctionConstant() != this->GetFunctionConstant()) return false;
	if (((CPLFunction *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		CPLTerm *Term1 = ((CPLFunction *)Element)->Arguments.Get(i);
		CPLTerm *Term2 = this->Arguments.Get(i);
		if (Term1->IsVariable() || Term2->IsVariable()) continue;
		if (!Term1->CanUnify(Term2)) return false;
	}
	return true;
}

bool CPLFunction::Equals(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLFunction *)Element)->GetFunctionConstant() != this->GetFunctionConstant()) return false;
	if (((CPLFunction *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		if (!((CPLFunction *)Element)->Arguments.Get(i)->Equals(this->Arguments.Get(i))) return false;
	}
	return true;
}

void CPLAtom::Clear()
{
	CPLElement *Element;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		Element = Arguments.Get(i);

		if (Element->GetType() == PLTYPE_OBJECTCONSTANT) continue;
//if (Element->GetType() == PLTYPE_VARIABLE) continue;
if (Element->GetType() == PLTYPE_VARIABLE)
{
	((CPLVariable *)Element)->DecRefCount();
	continue;
}
				
		delete Element;
	}
}

const CPLAtom &CPLAtom::operator=(const CPLAtom &Atom)
{
	CPLTerm *Term;

	// remove old contents
	Clear();

	PredicateConstant = Atom.PredicateConstant;
	Arguments.SetLength(Atom.Arguments.GetLength());
    for (int i=0; i<Atom.Arguments.GetLength(); i++)
	{
		Term = Atom.GetArgument(i);
if (Term->GetType() == PLTYPE_FUNCTION) Term = ((CPLFunction *)Term)->Clone();
else if (Term->GetType() == PLTYPE_VARIABLE) ((CPLVariable *)Term)->IncRefCount();
		Arguments.Set(i, Term);
	}
	return (*this);
}

CPLAtom::~CPLAtom()
{
	Clear();
}

/// Adds all its variables to Substitution.
void CPLAtom::ListVariables(CPLSubstitution &Substitution) const
{
	CPLTerm *Term;

	for (int i=0; i<Arguments.GetLength(); i++)
	{
		Term = Arguments.Get(i);
		if (Term->GetType() == PLTYPE_FUNCTION) 
		{
			((CPLFunction *)Term)->ListVariables(Substitution);
		}
		else if (Term->IsVariable()) 
		{
			Substitution.Set((CPLVariable *)Term, 0);
		}
	}
}

void CPLAtom::Substitute(CPLSubstitution &Substitution)
{
	CPLTerm *Term;

    for (int i=0; i<Arguments.GetLength(); i++)
	{
		Term = Arguments.Get(i);
		if (Term->GetType() == PLTYPE_FUNCTION) 
		{
			((CPLFunction *)Term)->Substitute(Substitution);
		}
		else if (Term->IsVariable()) 
		{
			const CPLElement *Value = Substitution.Get((CPLVariable *)Term);
			if (Value) 
			{
				if (Arguments.Get(i)->IsVariable()) ((CPLVariable *)Arguments.Get(i))->DecRefCount();
				Arguments.Set(i, (CPLTerm *)Value);
			}
		}
	}
}

const CText CPLAtom::ToString(void) const
{
	CText String;
	CPLTerm *Term;

	if (!Positive) String = "NOT ";
	String += PredicateConstant->GetName();
	String += "(";
	for (int i=0; i < Arguments.GetLength(); i++)
	{
		Term = Arguments.Get(i);
		String += Term->ToString();
		if (i < Arguments.GetLength()-1) String += ", ";
	}
	String += ")";
	return String;
}

bool CPLAtom::CanUnify(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLAtom *)Element)->GetPredicateConstant() != this->GetPredicateConstant()) return false;
	if (((CPLAtom *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		CPLTerm *Term1 = ((CPLAtom *)Element)->Arguments.Get(i);
		CPLTerm *Term2 = this->Arguments.Get(i);
		if (Term1->IsVariable() || Term2->IsVariable()) continue;
		if (!Term1->CanUnify(Term2)) return false;
	}
	return true;
	//return (((CPLAtom *)Element)->IsPositive() == Positive);
}

bool CPLAtom::Equals(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLAtom *)Element)->GetPredicateConstant() != this->GetPredicateConstant()) return false;
	if (((CPLAtom *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		if (!((CPLAtom *)Element)->Arguments.Get(i)->Equals(this->Arguments.Get(i))) return false;
	}
	return true;
}

bool CPLAtom::Equals(const CPLElement *Element, CPLSubstitution &Substitution) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLAtom *)Element)->GetPredicateConstant() != this->GetPredicateConstant()) return false;
	if (((CPLAtom *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		CPLTerm *Term1 = ((CPLAtom *)Element)->Arguments.Get(i);
		CPLTerm *Term2 = this->Arguments.Get(i);

		if (Term1->GetType() == PLTYPE_VARIABLE) Term1 = (CPLTerm *)Substitution.Get((CPLVariable *)Term1);
		else if (Term2->GetType() == PLTYPE_VARIABLE) Term2 = (CPLTerm *)Substitution.Get((CPLVariable *)Term2);
		
		if (!Term1->Equals(Term2)) return false;
	}
	return true;
}

CPLCompoundFormula::~CPLCompoundFormula()
{
	Arguments.DeleteContents();
}

const CText CPLFormula_And::ToString(void) const
{
	CText String;

	if (!Positive) String = "NOT ";
	String += "(";
	for (int i=0; i < Arguments.GetLength(); i++)
	{
		String += Arguments.Get(i)->ToString();
		if (i < Arguments.GetLength()-1) String += ", ";
	}
	String += ")";
	return String;
}

bool CPLFormula_And::CanUnify(CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLFormula_And *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		if (!((CPLFormula_And *)Element)->Arguments.Get(i)->CanUnify(this->Arguments.Get(i))) return false;
	}
	return true;
}

bool CPLFormula_And::Equals(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLFormula_And *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		if (!((CPLFormula_And *)Element)->Arguments.Get(i)->Equals(this->Arguments.Get(i))) return false;
	}
	return true;
}

const CText CPLFormula_Or::ToString(void) const
{
	CText String;

	if (!Positive) String = "NOT ";
	String += "(";
	for (int i=0; i < Arguments.GetLength(); i++)
	{
		String += Arguments.Get(i)->ToString();
		if (i < Arguments.GetLength()-1) String += " | ";
	}
	String += ")";
	return String;
}

bool CPLFormula_Or::CanUnify(CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLFormula_Or *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		if (!((CPLFormula_Or *)Element)->Arguments.Get(i)->CanUnify(this->Arguments.Get(i))) return false;
	}
	return true;
}

bool CPLFormula_Or::Equals(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLFormula_Or *)Element)->Arguments.GetLength() != this->Arguments.GetLength()) return false;

	for (int i=0; i < Arguments.GetLength(); i++)
	{
		if (!((CPLFormula_Or *)Element)->Arguments.Get(i)->Equals(this->Arguments.Get(i))) return false;
	}
	return true;
}

/*const CText CPLFormula_Not::ToString(void) const
{
	return "~" + Argument->ToString();
}*/

CPLRule::CPLRule()
{
	Antecedents = 0;
	Consequents = 0;
}

CPLRule::~CPLRule()
{
	Antecedents.DeleteContents();
	Consequents.DeleteContents();


	// variables are deleted last, because they are used by antecedents and consequents
//	Variables.DeleteContentsSeconds();
}

void CPLRule::AddVariable(const CText &Name, const CPLVariable *Variable)
{ 
	Variables.Add(Name, Variable);
}

const CPLVariable *CPLRule::GetVariable(const CText &Name)
{
	bool Found;
	const CPLVariable *&Variable = Variables.GetSecond(Name, Found);
	return (Found ? Variable : 0);
}

const CPLAtom *CPLRule::GetConsequent(CPLPredicateConstant *PredicateConstant) const
{
	for (int i=0; i < Consequents.GetLength(); i++)
	{
		if (Consequents.Get(i)->GetPredicateConstant() == PredicateConstant) return Consequents.Get(i);
	}
	return 0;
}

const CText CPLRule::ToString(void) const
{
	CText String;

	for (int i=0; i < Consequents.GetLength(); i++)
	{
		String += Consequents.Get(i)->ToString();
		if (i < Consequents.GetLength()-1) String += ", ";
	}
	String += " :- ";
	for (int i=0; i < Antecedents.GetLength(); i++)
	{
		String += Antecedents.Get(i)->ToString();
		if (i < Antecedents.GetLength()-1) String += ", ";
	}
	String += ".";
	return String;
}

bool CPLRule::CanUnify(CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLRule *)Element)->Antecedents.GetLength() != this->Antecedents.GetLength()) return false;
	if (((CPLRule *)Element)->Consequents.GetLength() != this->Consequents.GetLength()) return false;
	if (((CPLRule *)Element)->Variables.GetLength() != this->Variables.GetLength()) return false;

	for (int i=0; i < Antecedents.GetLength(); i++)
	{
		const CPLAtom *MyAntecedent = this->Antecedents.Get(i);
		const CPLAtom *HisAntecedent = ((CPLRule *)Element)->Antecedents.Get(i);
		if (!HisAntecedent->CanUnify(MyAntecedent)) return false;
		// check if the variables are used the same way in both rules.
		if ((MyAntecedent->GetType() == PLTYPE_VARIABLE) && (HisAntecedent->GetType() == PLTYPE_VARIABLE))
		{
			if (this->Variables.GetIndexSecond((CPLVariable *)MyAntecedent) != ((CPLRule *)Element)->Variables.GetIndexSecond((CPLVariable *)HisAntecedent)) return false;
		}
	}
	for (int i=0; i < Consequents.GetLength(); i++)
	{
		const CPLAtom *MyConsequent = this->Consequents.Get(i);
		const CPLAtom *HisConsequent = ((CPLRule *)Element)->Consequents.Get(i);
		if (!HisConsequent->CanUnify(MyConsequent)) return false;
		// check if the variables are used the same way in both rules.
		if ((MyConsequent->GetType() == PLTYPE_VARIABLE) && (HisConsequent->GetType() == PLTYPE_VARIABLE))
		{
			if (this->Variables.GetIndexSecond((CPLVariable *)MyConsequent) != ((CPLRule *)Element)->Variables.GetIndexSecond((CPLVariable *)HisConsequent)) return false;
		}
	}
	return true;
}

bool CPLRule::Equals(const CPLElement *Element) const
{
	if (Element->GetType() != this->GetType()) return false;
	if (((CPLRule *)Element)->Antecedents.GetLength() != this->Antecedents.GetLength()) return false;
	if (((CPLRule *)Element)->Consequents.GetLength() != this->Consequents.GetLength()) return false;
	if (((CPLRule *)Element)->Variables.GetLength() != this->Variables.GetLength()) return false;

	for (int i=0; i < Antecedents.GetLength(); i++)
	{
		const CPLAtom *MyAntecedent = this->Antecedents.Get(i);
		const CPLAtom *HisAntecedent = ((CPLRule *)Element)->Antecedents.Get(i);
		if (!HisAntecedent->Equals(MyAntecedent)) return false;
		// check if the variables are used the same way in both rules.
		if ((MyAntecedent->GetType() == PLTYPE_VARIABLE) && (HisAntecedent->GetType() == PLTYPE_VARIABLE))
		{
			if (this->Variables.GetIndexSecond((CPLVariable *)MyAntecedent) != ((CPLRule *)Element)->Variables.GetIndexSecond((CPLVariable *)HisAntecedent)) return false;
		}
	}
	for (int i=0; i < Consequents.GetLength(); i++)
	{
		const CPLAtom *MyConsequent = this->Consequents.Get(i);
		const CPLAtom *HisConsequent = ((CPLRule *)Element)->Consequents.Get(i);
		if (!HisConsequent->Equals(MyConsequent)) return false;
		// check if the variables are used the same way in both rules.
		if ((MyConsequent->GetType() == PLTYPE_VARIABLE) && (HisConsequent->GetType() == PLTYPE_VARIABLE))
		{
			if (this->Variables.GetIndexSecond((CPLVariable *)MyConsequent) != ((CPLRule *)Element)->Variables.GetIndexSecond((CPLVariable *)HisConsequent)) return false;
		}
	}
	return true;
}

const CText CPLCutOperator::ToString(void) const
{
	return "!";
}

