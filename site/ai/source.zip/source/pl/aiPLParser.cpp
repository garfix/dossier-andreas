#include "aiPLParser.h"
#include "aiPLModel.h"
#include <ctype.h>

const int CPLParser::PRECEDENCE_FUNCTION = 0;
const int CPLParser::PRECEDENCE_ATOM = 1;
const int CPLParser::PRECEDENCE_NOT = 2;
const int CPLParser::PRECEDENCE_OR = 3;
const int CPLParser::PRECEDENCE_AND = 4;
const int CPLParser::PRECEDENCE_BRACKETS = 10;
const int CPLParser::PRECEDENCE_RULE = 11;
const int CPLParser::PRECEDENCE_DEFAULT = 1000;

CPLParser::CPLParser(CPLModel *NewModel)
{
	Model = NewModel;

	SetPunctuationChars("(),|!");
	AddOperator(":-");
	AddOperator("NOT");
}

CPLParser::~CPLParser()
{
}

CPLElement *CPLParser::ParseElement(int ParentPrecedence, CHashTable<CText, const CPLVariable *> &Variables)
{
	CText Token;
	CPLElement *Element;
	bool Found;

	Token = NextToken();

	// parse simple formulae
	
	if (Token == "NOT")
	{
		// NOT
		Element = (CPLFormula *)ParseElement(PRECEDENCE_NOT, Variables);
		if (!Element) return 0;
		((CPLFormula *)Element)->SetPositive(false);
	}
	else if (Token == "(")
	{
		// Brackets
		Element = ParseElement(PRECEDENCE_BRACKETS, Variables);
		if (!Element) return 0;
		Token = NextToken();
		if (Token != ")") return 0;
	}
	else if (LookAhead() == "(")
	{
		// only when a clause starting with predicate has an atom as parent,
		// it is considered a function
		if (ParentPrecedence == PRECEDENCE_ATOM)
		{
			// function
			CPLFunctionConstant *FunctionConstant = Model->GetFunctionConstantForced(Token);
			CPLFunction *Function = new CPLFunction(FunctionConstant);
			Token = NextToken(); // "("
			if (LookAhead() != ")")
			{
				do 
				{
					CPLTerm *Argument = (CPLTerm *)ParseElement(PRECEDENCE_FUNCTION, Variables);
					if (!Argument) 
					{
						delete Function;
						return 0;
					}
					Function->AddArgument(Argument);
					Token = NextToken();
				}
				while (Token == ",");
			}
			if (Token != ")")
			{
				delete Function;
				return 0;
			}
			Element = Function;
		}
		else
		{
			// atom
			CPLPredicateConstant *PredicateConstant = Model->GetPredicateConstantForced(Token);
			CPLAtom *Formula = new CPLAtom();
			Formula->SetPredicateConstant(PredicateConstant);
			Token = NextToken(); // "("
			if (LookAhead() != ")")
			{
				do 
				{
					CPLTerm *Argument = (CPLTerm *)ParseElement(PRECEDENCE_ATOM, Variables);
					if (!Argument) 
					{
						delete Formula;
						return 0;
					}
					Formula->AddArgument(Argument);
					Token = NextToken();
				}
				while (Token == ",");
			}
			if (Token != ")")
			{
				delete Formula;
				return 0;
			}
			Element = Formula;
		}

	}
	else if (Token == "!")
	{
		Element = new CPLCutOperator();
	}
	else
	{
		if (isupper(Token.Get(0)) || (Token.Get(0) == '_'))
		{
			// variable
			CPLVariable *Variable = const_cast<CPLVariable *>(Variables.Get(Token.GetHashCode(), Token, Found));
			if (!Found)
			{
				Variable = new CPLVariable();
				Variable->SetName(Token);
				Variables.Put(Token.GetHashCode(), Token, Variable);
			}
			Element = Variable;
			Variable->IncRefCount();
		}
		else
		{
			// it is an object constant
			Element = Model->GetObjectConstantForced(Token);
		}
	}

	// parse complex formulae
	while (true)
	{
		if (LookAhead() == ":-")
		{
			// rule
			if (ParentPrecedence <= PRECEDENCE_RULE) break;
			NextToken();
			CPLFormula *Consequent = (CPLFormula *)Element;
			CPLFormula *Antecedent = (CPLFormula *)ParseElement(PRECEDENCE_RULE, Variables);
			if (!Antecedent) return 0;
			CPLRule *Rule = new CPLRule();
			// break up antecedents
			if (Antecedent->GetType() == PLTYPE_FORMULA_AND)
			{
				for (int i=0; i < ((CPLCompoundFormula*)Antecedent)->GetArgumentCount(); i++)
				{
					Rule->AddAntecedent((CPLAtom *)((CPLCompoundFormula*)Antecedent)->GetArgument(i));
				}
				((CPLCompoundFormula*)Antecedent)->RemoveArguments();
				delete Antecedent;
			}
			else
				Rule->AddAntecedent((CPLAtom *)Antecedent);

			// break up consequents
			if (Consequent->GetType() == PLTYPE_FORMULA_AND)
			{
				for (int i=0; i < ((CPLCompoundFormula *)Consequent)->GetArgumentCount(); i++)
				{
					Rule->AddConsequent((CPLAtom *)((CPLCompoundFormula*)Consequent)->GetArgument(i));
				}
				((CPLCompoundFormula*)Consequent)->RemoveArguments();
				delete Consequent;
			}
			else
				Rule->AddConsequent((CPLAtom *)Consequent);

            CText Name;
			const CPLVariable *Variable;

			// link the variables to the rule
			CHashTableIterator<CText, const CPLVariable *> Iter = Variables.GetIterator();
			while (Iter.GetNext(Name, Variable)) Rule->AddVariable(Name, Variable);

			Element = Rule;
		}
		else if (LookAhead() == ",")
		{
			// and
			if (ParentPrecedence <= PRECEDENCE_AND) break;
			NextToken();
			CPLFormula_And *Formula_And = new CPLFormula_And();
			Formula_And->AddArgument((CPLFormula *)Element);
			CPLFormula *Argument = (CPLFormula *)ParseElement(PRECEDENCE_AND, Variables);
			if (!Argument) 
			{
				delete Formula_And;
				return 0;
			}
			Formula_And->AddArgument(Argument);
			if (LookAhead() == ",")
			{
				NextToken();
				CPLFormula *Argument = (CPLFormula *)ParseElement(PRECEDENCE_AND, Variables);
				if (!Argument) 
				{
					delete Formula_And;
					return 0;
				}
				Formula_And->AddArgument(Argument);
			}

			Element = Formula_And;
		}
		else if (LookAhead() == "|")
		{
			// or
			if (ParentPrecedence <= PRECEDENCE_OR) break;
			NextToken();
			CPLFormula_Or *Formula_Or = new CPLFormula_Or();
			Formula_Or->AddArgument((CPLFormula *)Element);
			CPLFormula *Argument = (CPLFormula *)ParseElement(PRECEDENCE_OR, Variables);
			if (!Argument) 
			{
				delete Formula_Or;
				return 0;
			}
			Formula_Or->AddArgument(Argument);

			if (LookAhead() == "|")
			{
				NextToken();
				CPLFormula *Argument = (CPLFormula *)ParseElement(PRECEDENCE_OR, Variables);
				if (!Argument) 
				{
					delete Formula_Or;
					return 0;
				}
				Formula_Or->AddArgument(Argument);
			}

			Element = Formula_Or;
		}
		else break;
	}

	return Element;
}

/// Parses String and creates an object structure for it; this structure is returned.
/// If the parse failed, 0 is returned.
CPLElement *CPLParser::Parse(const CText &String)
{
	CHashTable<CText, const CPLVariable *> Variables(3);
	CPLElement *Element;
	
	// parse the string, create an object structure (in Element)
	this->ReadString(String);
	Element = ParseElement(PRECEDENCE_DEFAULT, Variables);

	// end with "."
	if (NextToken() != ".")
	{
		Error = "Forgot dot (.) at end of line.";
		delete Element;
		return 0;
	}

	return Element;
}

/// Parses String into an element; if this element is an atom, it is copied into Atom.
void CPLParser::ParseAtom(const CText &String, CPLAtom &Atom)
{
	CPLElement *Element = Parse(String);
	if (!Element || Element->GetType() != PLTYPE_ATOM)
	{
		Error = "Wrong element type.";
		return;
	}
	Atom = (*(CPLAtom *)Element);
	delete Element;
}
