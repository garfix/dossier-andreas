#ifndef _BITPATTERN
#define _BITPATTERN

#include "genericElement.h"
#include "genericRow.h"

namespace generic
{

/// An array of bits of any size. When constructed, the bit pattern is filled with 0's.

class CBitPattern: public CElement
{
protected:
	unsigned int *Bits;
	int BitCount;

	int GetIntCount(void) const { return (BitCount + 31) >> 5; }

public:
	CBitPattern();
	CBitPattern(int NewBitCount);
	CBitPattern(const CBitPattern &BitPattern);
	~CBitPattern();

	const CBitPattern &operator=(const CBitPattern &BitPattern);

	void SetBit(int Index, bool Value);
	bool GetBit(int Index) const;

	int GetBitCount(void) const { return BitCount; }
	int GetHammingDistance(const CBitPattern &Pattern) const;
	void Clear(void);

	void SetSize(int NewSize);
	static void CalculateMean(CRow<CBitPattern> &Patterns, CBitPattern &Mean);

	const CText ToString(void) const;
};

}

#endif
