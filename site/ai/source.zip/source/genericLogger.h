#ifndef _LOGGER
#define _LOGGER

#include <stdio.h>
#include "genericElement.h"
#include "genericText.h"

namespace generic
{

enum ELogLevel
{
	LOGLEVEL_OFF,
	LOGLEVEL_FATAL,
	LOGLEVEL_ERROR,
	LOGLEVEL_WARNING,
	LOGLEVEL_INFO,
	LOGLEVEL_DEBUG,
	LOGLEVEL_ALL
};

class CLogger: public CElement
{
protected:
	ELogLevel LogLevel;
	FILE *LogFile;
	bool ShouldFlush;

	CLogger();

public:

	virtual ~CLogger();

	static CLogger &GetLogger(void);

	// properties
	void SetLogFile(const CText &LogfileName);
	void SetLogLevel(ELogLevel NewLogLevel){ LogLevel = NewLogLevel; }
	ELogLevel GetLogLevel(void) const { return LogLevel; }

	void SetShouldFlush(bool NewShouldFlush){ ShouldFlush = NewShouldFlush; }
	bool GetShouldFlush(void) const { return ShouldFlush; }

	// normal use
	void Log(ELogLevel Level, const CText &Message);
};

#define LOG_FATAL(x) \
	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_FATAL){ CLogger::GetLogger().Log(LOGLEVEL_FATAL, x); }
#define LOG_ERROR(x) \
	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_ERROR){ CLogger::GetLogger().Log(LOGLEVEL_ERROR, x); }
#define LOG_WARNING(x) \
	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_WARNING){ CLogger::GetLogger().Log(LOGLEVEL_WARNING, x); }
#define LOG_INFO(x) \
	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_INFO){ CLogger::GetLogger().Log(LOGLEVEL_INFO, x); }
#define LOG_DEBUG(x) \
	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_DEBUG){ CLogger::GetLogger().Log(LOGLEVEL_DEBUG, x); }
}

#endif
