#ifndef _SDMSTORAGELOCATION
#define _SDMSTORAGELOCATION

#include "generic.h"

using namespace generic;

#define Counter char

/// At this location PoolCapacity words can be stored. They are not stored individually; the storage is
/// counter based. There are as many counters as there are bits in a word.
/// Whenever a new word is written to the storage location, PoolCount is increased and 
/// all counters for which the corresponding bit in the word is 1 are increased.

class CSDMStorageLocation
{
	friend class CSDMModel;

protected:
	/// Address: the (random) address of this storage location in memory
	CBitPattern Address;
	/// WordCount: the number of words stored at this location
	Counter WordCount;
	/// PoolCapacity: the number of words that may be stored maximally
	Counter PoolCapacity;
	/// Counters: there is one bit-counter for each bit of the words this location stores
	CRow<Counter> Counters;

	void RandomizeAddress(void);
	void Write(const CBitPattern &Word);
	const CRow<Counter> &Read(void) const;

public:
	CSDMStorageLocation(int NewBitCount, Counter NewPoolCapacity);
	virtual ~CSDMStorageLocation();

	const CBitPattern &GetAddress(void) const { return Address; }
	int GetWordCount(void) const { return WordCount; }

	virtual const CText ToString(void) const;
};

#endif
