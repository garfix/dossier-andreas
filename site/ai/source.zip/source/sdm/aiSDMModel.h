#ifndef _SDMMODEL
#define _SDMMODEL

#include "generic.h"
#include "aiSDMStorageLocation.h"

using namespace generic;

/// The main component of Sparse Distributed Memory.
/// It creates and manages all Hard Locations of memory.
/// SDM is based on Pentti Kanerva's book "Sparse Distributed Memory" (1988)
/// 
/// It allows two ways to use memory: 
/// - as a best-match mechanism (see chapter 7)
/// - as a sequence mechanism (see chapter 8)

class CSDMModel: public CElement
{
protected:
	/// BitCount: the number of bits in each storage location
	int BitCount;
	/// HardLocations: the actual storage locations in this memory
	CRow<CSDMStorageLocation *> HardLocations;
	/// AccessRadius: When accessing memory, all hard locations within the AccessRadius
	/// Hamming distance are involved.
	int AccessRadius;
	/// NumberOfWordsStored: Number of words stored by the application
	int NumberOfStoredWords;

	void Create(int NewBitCount, int NewHardLocationCount, Counter NewPoolCapacity);
	int CalculateNearestNeighbourDistance(int BitCount, int HardLocationCount);
	float CalculateCapacityFraction(int BitCount) const;
	void CreateArchetype(const CBitPattern &Address, CBitPattern &Archetype, bool &Success) const;

public:
	CSDMModel(int NewBitCount, int NewHardLocationCount, Counter NewPoolCapacity);
	CSDMModel(int NewBitCount, int NumberOfWordsToBeStored);
	virtual ~CSDMModel();

	void SetAccessRadius(int NewAccessRadius){ AccessRadius = NewAccessRadius; }
	int GetAccessRadius(void) const { return AccessRadius; }

	// using SDM as a best-match mechanism
	void Write(const CBitPattern &Word);
	void ReadIteratively(const CBitPattern &Address, CBitPattern &Value, bool &Found) const;

	// using SDM as a stored sequence mechanism / associative memory
	void Write(const CBitPattern &Address, const CBitPattern &Value);
	void Read(const CBitPattern &Address, CBitPattern &Value, bool &Found) const;

	// information about the memory
	int GetBitCount(void) const { return BitCount; }
	int GetHardLocationCount(void) const { return HardLocations.GetLength(); }
	float GetCapacity(void) const;
	int GetNumberOfStoredWords(void) const { return NumberOfStoredWords; }
	bool IsOverloaded(void) const;
};

#endif
