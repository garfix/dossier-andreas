#include "aiSDMStorageLocation.h"

CSDMStorageLocation::CSDMStorageLocation(int NewBitCount, Counter NewPoolCapacity):
	Counters(NewBitCount), Address(NewBitCount)
{
	PoolCapacity = NewPoolCapacity;
	WordCount = 0;

	// clear counters
	for (int i=0; i < Address.GetBitCount(); i++) Counters.Set(i, 0);
}

CSDMStorageLocation::~CSDMStorageLocation()
{
}

/// All bits of the address are given random values (0/1)
void CSDMStorageLocation::RandomizeAddress(void)
{
	for (int i=0; i < Address.GetBitCount(); i++)
		Address.SetBit(i, CMath::GetRandomBool());
}

/// This is a direct write to the storage location.
/// Counters and archetype are updated.
void CSDMStorageLocation::Write(const CBitPattern &Word)
{
	// if overflow is at hand, ignore the write
	if (WordCount == PoolCapacity) return;
	
	for (int i=0; i < Word.GetBitCount(); i++)
	{
		if (Word.GetBit(i)) this->Counters.Set(i, this->Counters.Get(i)+1);
	}

	WordCount++;
}

const CRow<Counter> &CSDMStorageLocation::Read(void) const
{
	return Counters;
}

const CText CSDMStorageLocation::ToString(void) const
{
	CText String;

	for (int i=0; i < Counters.GetLength(); i++)
	{
		String += (int)Counters.Get(i);
		if (i < Counters.GetLength()-1) String += ' ';
	}
	return String;
}
