#include "aiSDMModel.h"

/// The first constructor gives you control over the structure of the network
/// Use it only when you need this control and know its properties.
/// NewPoolCapacity: number of words per storage location
CSDMModel::CSDMModel(int NewBitCount, int NewHardLocationCount, Counter NewPoolCapacity)
{
	Create(NewBitCount, NewHardLocationCount, NewPoolCapacity);
}

/// The second constructor determines the number of hard-locations for you.
/// All you need to do is tell it how many bits in your word and how many
/// words you intend to store in it.
CSDMModel::CSDMModel(int NewBitCount, int NumberOfWordsToBeStored)
{
	int HardLocationCount;
	float CapacityFraction;

	// calculate a suitable number for hard-location-count
	CapacityFraction = CalculateCapacityFraction(NewBitCount);
	// the division calculates the amount of hard-locations needed to "fill up" the memory
	// this is multiplied by ten as not to overload the memory
	HardLocationCount = 10 * (int)((float)NumberOfWordsToBeStored / CapacityFraction);

	Create(NewBitCount, HardLocationCount, 10);
}

CSDMModel::~CSDMModel()
{
	HardLocations.DeleteContents();
}

void CSDMModel::Create(int NewBitCount, int NewHardLocationCount, Counter NewPoolCapacity)
{
	BitCount = NewBitCount;

	// init
	NumberOfStoredWords = 0;

	// create suitable number for access-radius:
	// the distance between two hard-location neighbours
	// (I pretend that there are 10 times less hard-locations to create overlap)
	AccessRadius = CalculateNearestNeighbourDistance(BitCount, NewHardLocationCount / 10);

	// create hard locations
	HardLocations.SetLength(NewHardLocationCount);
	for (int i=0; i < NewHardLocationCount; i++)
		HardLocations.Set(i, new CSDMStorageLocation(NewBitCount, NewPoolCapacity));

	// randomly initialize hard locations
	for (int i=0; i < NewHardLocationCount; i++)
		HardLocations.Get(i)->RandomizeAddress();
}

/// Calculates the mean distance between two direct hard-location heighbours.
/// Note: It is not an efficient implementation; this is due to my lack of
/// mathematical skills :(  But it works :)
int CSDMModel::CalculateNearestNeighbourDistance(int BitCount, int HardLocationCount)
{
	// RequiredPortion: the part that should be spanned
	double RequiredPortion = 1.0 / (double)HardLocationCount;
	// p : the part of N that is spanned using the current Radius
	double p;
	// N = the number of points in the space
	double N = pow(2.0, (double)BitCount);
	int Distance;
	double Surface;
	double Mean = (double)BitCount/2.0;
	double SD = sqrt((double)BitCount)/2.0;

	// We try out all distances, starting with the highest possible value, and counting down
	Distance = BitCount / 2;
    while (Distance > 0)
	{
		// Calculate the number of points in the BitCount-dimensional binary space that lay
		// in the circle with r = Radius bits.
		Surface = N * CMath::GetGaussianProbability(Mean, SD, Distance);
		// dividing immediately by N again is pretty silly, but I try to stay close to
		// the formulae in the book. The compiler should know how to deal with it.
		p = Surface / N;
		// see if the current part of space (with the circle with the current radius)
		// is about the required part
		if (p < RequiredPortion) break;
		// still to much, reduce it further
		Distance--;
	}

	return Distance;
}

/// Returns the capacity of a memory independent of hard-location-count 
/// (as a fraction between 0 and 1)
float CSDMModel::CalculateCapacityFraction(int BitCount) const
{
	double CapacityFraction;
	double Inverse;
	double H;

	Inverse = CMath::GetInverseGaussianProbability(
		0,   // Mean,
		1.0, // Standard Deviation
		pow(0.5, 1.0/(double)BitCount)
		);
	H = Inverse * Inverse;

	CapacityFraction = ((double)1.0 / H);

	return (float)CapacityFraction;
}

/// Creates an archetype (=mean) word into Archetype from reading Address.
/// If reading was unsuccessful, Success is FALSE.
void CSDMModel::CreateArchetype(const CBitPattern &Address, CBitPattern &Archetype, bool &Success) const
{
	int WordCount, HalfWordCount, Count;
	CSDMStorageLocation *Location;
	CRow<int> Counters(this->BitCount);

	// clear counters
	for (int BitIndex=0; BitIndex < this->BitCount; BitIndex++)
		Counters.Set(BitIndex, 0);

	// determine the total bitcount of all accessible locations for Word
	WordCount = 0;
	for (int i=0; i < this->HardLocations.GetLength(); i++)
	{
		Location = this->HardLocations.Get(i);
		if (Location->GetAddress().GetHammingDistance(Address) <= AccessRadius)
		{
			const CRow<Counter> &LocationCounters = Location->Read();
			for (int BitIndex=0; BitIndex < this->BitCount; BitIndex++)
			{
				Count = LocationCounters.Get(BitIndex);
				Counters.Set(BitIndex, Counters.Get(BitIndex) + Count);
			}
			WordCount += Location->GetWordCount();
		}
	}

	// check if no accessible locations could be found
	if (WordCount == 0)
	{
		Success = false;
		return;
	}

	// determine the number of words that needs to be available for a bit in the archetype to be 1
	// 1 is added for when WordCount = 1 -> HalfWordCount will then be 1;
	// this is necessary for the calculation below
	HalfWordCount = (WordCount+1) / 2; 

	// create the new word (= archetype)
	for (int BitIndex=0; BitIndex < this->BitCount; BitIndex++)
	{
		Count = Counters.Get(BitIndex);
		if (Count >= HalfWordCount) 
			Archetype.SetBit(BitIndex, true); 
		else 
			Archetype.SetBit(BitIndex, false);
	}

	Success = true;
	return;
}

/// Writes Word in all hard locations within an Hamming distance of AccessRadius from Word.
void CSDMModel::Write(const CBitPattern &Word)
{
	// write with Address=Word and Value=Word
	Write(Word, Word);
}

/// Writes Value in all hard locations within an Hamming distance of AccessRadius from Address.
void CSDMModel::Write(const CBitPattern &Address, const CBitPattern &Value)
{
	assert(Address.GetBitCount() == this->BitCount);
	assert(Value.GetBitCount() == this->BitCount);

	CSDMStorageLocation *Location;

	for (int i=0; i < HardLocations.GetLength(); i++)
	{
		Location = HardLocations.Get(i);
		if (Location->GetAddress().GetHammingDistance(Address) <= AccessRadius)
		{
			Location->Write(Value);
		}
	}

	// one more word is stored
	NumberOfStoredWords++;
}

/// Reads (noniteratively) from Address and creates an archetype (=mean) word. This word is returned in Value.
/// If no word could be found, Found is FALSE.
void CSDMModel::Read(const CBitPattern &Address, CBitPattern &Value, bool &Found) const
{
	CreateArchetype(Address, Value, Found);
}

/// Reads iteratively from Address and creates an archetype (=mean) word. This word is returned in Value.
/// If no word could be found, Found is FALSE.
void CSDMModel::ReadIteratively(const CBitPattern &Address, CBitPattern &Value, bool &Found) const
{
	assert(Address.GetBitCount() == this->BitCount);
	assert(Value.GetBitCount() == this->BitCount);

	bool Converging, WordFound, Success;
	int CurrentHammingDistance, PreviousHammingDistance;
	CBitPattern Archetype(this->BitCount);

	WordFound = false;
	Value = Address;
	PreviousHammingDistance = this->BitCount;

	Converging = true;
	while (Converging)
	{
		// create an archetype word into Archetype using Value as an address
		CreateArchetype(Value, Archetype, Success);
		if (!Success) break;

		// we found at least one word
		WordFound = true;

		// calculate the distance between the new archetype and the address
		CurrentHammingDistance = Address.GetHammingDistance(Archetype);

		// check if we're (still) converging
		if (CurrentHammingDistance < PreviousHammingDistance)
		{
			// the new archetype is better, so use it from now
			Value = Archetype;

			// save for next iteration
			PreviousHammingDistance = CurrentHammingDistance;
		}
		else
			Converging = false;
	}

	Found = WordFound;

	return;
}

/// Returns the number of words this memory can contain to be full.
float CSDMModel::GetCapacity(void) const
{
	return CalculateCapacityFraction(this->BitCount) * HardLocations.GetLength();
}

bool CSDMModel::IsOverloaded(void) const
{
	return (NumberOfStoredWords > GetCapacity());
}
