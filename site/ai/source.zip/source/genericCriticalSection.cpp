#include "genericCriticalSection.h"
#include <windows.h>

/// the windows-header is included in the implementation file, because it disturbed the rest of the 
/// application when it was included the header file.
/// This also meant that I had to work with a CRITICAL_SECTION pointer in stead of an object in the class.

namespace generic
{

CCriticalSection::CCriticalSection()
{
	// Set up a critical section
	CriticalSection = new CRITICAL_SECTION();
    InitializeCriticalSection((CRITICAL_SECTION *)CriticalSection);
}

CCriticalSection::~CCriticalSection()
{
	// Release resources used by the critical section object.
	DeleteCriticalSection((CRITICAL_SECTION *)CriticalSection);
	delete (CRITICAL_SECTION *)CriticalSection;
}

void CCriticalSection::Lock(void)
{
    EnterCriticalSection((CRITICAL_SECTION *)CriticalSection); 
}

void CCriticalSection::Unlock(void)
{
    LeaveCriticalSection((CRITICAL_SECTION *)CriticalSection); 
}

}
