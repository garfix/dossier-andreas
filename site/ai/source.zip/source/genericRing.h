#ifndef _RING
#define _RING

#include "genericRow.h"

namespace generic
{
	
/// A ring is a circular datastucture, which you fill like an array
/// an traverse with a single 'GetNext' method which always returns
/// the next element and restarts at the beginning when the end was reached

template <class TYPE>
class CRing: public CRow<TYPE>
{
protected:
	int CurrentIndex;

public:
	CRing(): CRow<TYPE>(0)
	{
		CurrentIndex = 0;
	}

	TYPE &GetNext(void)
	{
		int SavedIndex;

		assert(Length != 0);

		// check if an element has been removed, which would
		// invalidate current index
		if (CurrentIndex >= Length) CurrentIndex = Length-1;

		// save the index
		SavedIndex = CurrentIndex;

		// increase the index, wrap to begin, if necessary
		CurrentIndex++;
		if (CurrentIndex == Length) CurrentIndex = 0;

		return Values[SavedIndex];
	}

	void operator=(const CRow<TYPE> &NewArray)
	{
		CRow<TYPE>::operator=(NewArray);
	}

	// resets the index to the current value to 0
	void Reset(void)
	{
		CurrentIndex = 0;
	}
};

}

#endif