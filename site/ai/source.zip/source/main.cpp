#include "test.h"
#include "crtdbg.h"

using namespace generic;

// defined in 'appNecker.cpp'
void Necker(void);
// defined in 'appNQueens.cpp'
void NQueens(void);
// defined in 'appXor.cpp'
void Xor(void);
// defined in 'appSequential.cpp'
void Sequential(void);
// defined in 'appHopfield.cpp'
void Hopfield(void);
// defined in 'appInteractiveActivation.cpp'
void InteractiveActivation(void);
// defined in 'appAggressiveness.cpp'
void Aggressiveness(void);
// defined in 'appParser.cpp'
void Parse(void);
// defined in 'appConvert.cpp'
void Convert(void);
// defined in 'appDecisionTree.cpp'
void DecisionTree(void);
// defined in 'appBayes.cpp'
//void Bayes(void);
// defined in 'appFrames.cpp'
void Frames(void);
// defined in 'appSockets.cpp'
void Sockets(void);
// defined in 'appMaes.cpp'
void Maes(void);
// defined in 'appSDMBestMatch.cpp'
void SDMBestMatch();
// defined in 'appSDMSequencer.cpp'
void SDMSequencer();
// defined in 'appdMARS.cpp'
void dMARS();

int main(int argc, char* argv[])
{
	// general test
	CTest().TestAll();

/*
	// fuzzy logic 
	Aggressiveness();

	// genetic algorithms
	NQueens();

	// neural networks
	Necker();
	Xor();
	Sequential();
	Hopfield();
	InteractiveActivation();

	Convert();

	// natural language processing
	Parse();

	DecisionTree();
	//Bayes();
	//FSM();
	Frames();
	Sockets();
	Maes();
	SDMBestMatch();
	SDMSequencer();
*/
	dMARS();

	return 0;
}

