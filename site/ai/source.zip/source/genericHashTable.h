#ifndef _HASHTABLE
#define _HASHTABLE

#include "genericElement.h"
#include "genericRow.h"
#include "genericPairedRow.h"

namespace generic
{

template<class Key, class Value>
class CHashTableIterator;

/// A hashtable. 
/// You have to set its size (number of buckets) at creation time.
/// You should determine a hashcode for each Key. Determine it any way you like, as long as 
/// it varies widely between different keys, is nonnegative, and is the same one you 
/// use to look up the value with Get().
/// The hashtable automatically rehashes when an element is put into it and 
/// the ElementCount exceeds Capacity * LoadFactor.

template<class Key, class Value>
class CHashTable
{
	friend class CHashTableIterator;

protected:
	// Capacity is represented implicitly in KeyBuckets.GetLength().
	CRow< CRow< Key > *> KeyBuckets;
	CRow< CRow< Value > *> ValueBuckets;
	CRow< CRow< int > *> HashCodeBuckets;
	// The number of elements stored.
	int ElementCount;
	// When the HashTable is LoadFactor (in [0..1]) full, it rehashes
	float LoadFactor;

public:
	CHashTable(int Capacity):
	  KeyBuckets(Capacity), ValueBuckets(Capacity), HashCodeBuckets(Capacity)
	{
		KeyBuckets.Fill(0);
		ValueBuckets.Fill(0);
		HashCodeBuckets.Fill(0);
		ElementCount = 0;
		LoadFactor = 0.75;
	}
	~CHashTable()
	{
		KeyBuckets.DeleteContents();
		ValueBuckets.DeleteContents();
		HashCodeBuckets.DeleteContents();
	}

	/// Add (NewKey, NewValue) combination into the hashtable. HashCode is used
	/// to determine the position in the hashtable.
	void Put(int HashCode, const Key &NewKey, const Value &NewValue)
	{
		int Index = CMath::Abs(HashCode) % GetCapacity();
		CRow< Key > *KeyBucket = KeyBuckets.Get(Index);
		if (KeyBucket == 0)
		{
			KeyBuckets.Set(Index, new CRow< Key >());
			ValueBuckets.Set(Index, new CRow< Value >());
			HashCodeBuckets.Set(Index, new CRow<int>());
		}
		KeyBuckets.Get(Index)->Add(NewKey);
		ValueBuckets.Get(Index)->Add(NewValue);
		HashCodeBuckets.Get(Index)->Add(HashCode);
		ElementCount++;
		// if the hashtable crosses the LoadFactor
		if ((float)ElementCount > (float)GetCapacity()*LoadFactor) Rehash();
	}

	/// Like Put(), but only when the key is a CText. The hashcode is determined by 
	/// calling GetHashCode() on the Key.
	void Put(const CText &NewKey, const Value &NewValue)
	{
		Put(NewKey.GetHashCode(), dynamic_cast<const Key &>(NewKey), NewValue);
	}

	/// Retrieve the value belonging to NewKey from the hashtable. HashCode is the same
	/// that was used to Put() the (Key, Value) pair into the table.
	Value &Get(int HashCode, const Key &NewKey, bool &Found) const
	{
		static Value Dummy;
		
		// get the bucket
		int BucketIndex = CMath::Abs(HashCode) % GetCapacity();
		CRow< Key > *KeyBucket = KeyBuckets.Get(BucketIndex);
		if (KeyBucket != 0)
		{
			// check all items in the bucket if they exactly match the key
			for (int Index=0; Index < KeyBucket->GetLength(); Index++)
			{
				if (KeyBucket->Get(Index) == NewKey) 
				{
					// found one
					Found = true;
					return ValueBuckets.Get(BucketIndex)->Get(Index);
				}
			}
		}

		// did not find one
		Found = false;
		return Dummy;
	}

	/// Like Get(), but using the GetHashCode() function of the Key, to create a hash code.
	Value &Get(const CText &NewKey, bool &Found)
	{
		return Get(NewKey.GetHashCode(), dynamic_cast<const Key &>(NewKey), Found);
	}

	/// Removes the (first) key-value pair, if available;
	/// Does not remove buckets.
	void Remove(int HashCode, const Key &NewKey)
	{
		// get the bucket
		int BucketIndex = CMath::Abs(HashCode) % GetCapacity();
		CRow< Key > *KeyBucket = KeyBuckets.Get(BucketIndex);
		if (KeyBucket != 0)
		{
			// check all items in the bucket if they exactly match the key
			for (int Index=0; Index < KeyBucket->GetLength(); Index++)
			{
				if (KeyBucket->Get(Index) == NewKey) 
				{
					// found one
					KeyBucket->RemoveAt(Index);
					ValueBuckets.Get(BucketIndex)->RemoveAt(Index);
					ElementCount--;
					return;
				}
			}
		}

		// did not find one
	}

	/// Like Remove(), but using the GetHashCode() function of the Key, to create a hash code.
	Value &Remove(const CText &NewKey)
	{
		return Remove(NewKey.GetHashCode(), dynamic_cast<const Key &>(NewKey));
	}

	int GetElementCount(void) const 
	{ 
		return ElementCount; 
	}

	/// Removes all elements.
	void Clear(void)
	{
		KeyBuckets.DeleteContents();
		ValueBuckets.DeleteContents();
		HashCodeBuckets.DeleteContents();
		KeyBuckets.Fill(0);
		ValueBuckets.Fill(0);
		HashCodeBuckets.Fill(0);
		ElementCount = 0;
	}

	/// Calls 'delete' on all Values of the hashtable.
	void DeleteValues(void)
	{
		for (int Index=0; Index < ValueBuckets.GetLength(); Index++)
		{
			if (ValueBuckets.Get(Index))
				ValueBuckets.Get(Index)->DeleteContents();
		}
	}

	/// Sets new load factor; does not check if a rehash is necessary.
	void SetLoadFactor(float NewLoadFactor)
	{ 
		LoadFactor = NewLoadFactor; 
	}

	/// Sets the number of buckets to NewCapacity, and rehashes.
	void SetCapacity(int NewCapacity)
	{
		int OldCapacity = GetCapacity();

		// check if there's no need to rehash
		if (NewCapacity == OldCapacity) return;

		// make a shallow copy of bucket arrays (the buckets now have two arrays pointing to them)
		CRow< CRow< Key > *> OldKeyBuckets = KeyBuckets;
		CRow< CRow< Value > *> OldValueBuckets = ValueBuckets;
		CRow< CRow< int > *> OldHashCodeBuckets = HashCodeBuckets;
        
		// resize the buckets; initialize to 0
		// (the buckets are now only pointed to by the OldBucket arrays
		KeyBuckets.SetLength(NewCapacity);
		ValueBuckets.SetLength(NewCapacity); 
		HashCodeBuckets.SetLength(NewCapacity);
		KeyBuckets.Fill(0);
		ValueBuckets.Fill(0);
		HashCodeBuckets.Fill(0);

		// rehash all elements, because their indexes have changed
		for (int BucketIndex=0; BucketIndex < OldCapacity; BucketIndex++)
		{
			CRow<Key> *KeyBucket = OldKeyBuckets.Get(BucketIndex);
			if (KeyBucket != 0)
			{
				CRow<Value> *ValueBucket = OldValueBuckets.Get(BucketIndex);
				CRow<int> *HashCodeBucket = OldHashCodeBuckets.Get(BucketIndex);
				for (int i=0; i < KeyBucket->GetLength(); i++)
				{
					// rehash a single element
					Put(HashCodeBucket->Get(i), KeyBucket->Get(i), ValueBucket->Get(i));
				}
			}
		}

		// delete temporaries
		OldKeyBuckets.DeleteContents();
		OldValueBuckets.DeleteContents();
		OldHashCodeBuckets.DeleteContents();
	}

	/// Returns the number of buckets in the hashtable.
	int GetCapacity(void) const 
	{ 
		return KeyBuckets.GetLength(); 
	}

	/// Sets a new capacity (3 times the current number of elements),
	/// and rehashes all elements.
	void Rehash(void)
	{
		SetCapacity(ElementCount*3);
	}

	/// Places all keys and values in a paired row
	/// Do not use it do access all elements, use the iterator instead.
	void ToPairedRow(CPairedRow<Key, Value> &PairedRow)
	{
		for (int Index1=0; Index1 < GetCapacity(); Index1++)
		{
			CRow<Key> *KeyBucket = KeyBuckets.Get(Index1);
			CRow<Value> *ValueBucket = ValueBuckets.Get(Index1);
			if (KeyBucket)
			{
				for (int Index2=0; Index2 < KeyBucket->GetLength(); Index2++)
				{
					PairedRow.Add(KeyBucket->Get(Index2), ValueBucket->Get(Index2));
				}
			}
		}
	}

	/// Returns iterator for the hashtable; the iterator can only be used to read the elements of the table
	CHashTableIterator<Key, Value> GetIterator(void) const
	{
		return CHashTableIterator<Key, Value>(*this);
	}
};

/// The accompanying iterator

template<class Key, class Value>
class CHashTableIterator
{
protected:
	const CHashTable<Key, Value> &HashTable;
	int MainIndex, BucketIndex;

public:
	CHashTableIterator(const CHashTable<Key, Value> &NewHashTable):
	  HashTable(NewHashTable)
	{
		MainIndex = BucketIndex = 0;
	}

	/// Returns false if no other element could be found.
	/// Returns true if another element could be found; references are stored in K, V.
	bool GetNext(Key &K, Value &V)
	{
		bool Found = false;
		while (!Found)
		{
			if (MainIndex >= HashTable.GetCapacity()) return false;
			if (HashTable.KeyBuckets.Get(MainIndex) == 0)
			{
				MainIndex++;
				continue;
			}
			if (BucketIndex >= HashTable.KeyBuckets.Get(MainIndex)->GetLength()) 
			{
				BucketIndex = 0;
				MainIndex++;
				continue;
			}
			K = HashTable.KeyBuckets.Get(MainIndex)->Get(BucketIndex);
			V = HashTable.ValueBuckets.Get(MainIndex)->Get(BucketIndex);
			BucketIndex++;
			Found = true;
		}

		return true;
	}
};

}

#endif