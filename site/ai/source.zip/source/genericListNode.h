#ifndef _LISTNODE
#define _LISTNODE

namespace generic
{

template <class TYPE> class CLinkedList;

template <class TYPE>
class CListNode
{
protected:
	TYPE Value;
	CListNode *Previous;
	CListNode *Next;

public:
	CListNode()
	{
		Previous = 0;
		Next = 0;
	}

	CListNode(const TYPE &NewValue)
	{
		Value = NewValue;
		Previous = 0;
		Next = 0;
	}

	~CListNode()
	{
	}

	CListNode<TYPE> *GetNext(void) const
	{
		return Next;
	}

	CListNode<TYPE> *GetPrevious(void) const
	{
		return Previous;
	}

	void SetValue(const TYPE &NewValue){ Value = NewValue; }
	const TYPE &GetValue(void){ return Value; }

	friend class CLinkedList<TYPE>;
};

}


#endif