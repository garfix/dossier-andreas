#ifndef _SMARTPOINTER
#define _SMARTPOINTER

#include "generic.h"

using namespace generic;

// see http://www.codeguru.com/Cpp/Cpp/cpp_mfc/pointers/article.php/c857/

template <class TYPE>
class CSmartPointerResource
{
protected:
	TYPE *Pointer;
	int RefCount;

public:
	CSmartPointerResource(TYPE *NewPointer):
		Pointer(NewPointer)
	{
		RefCount = 0;
	}
	void IncreaseRefCount(void)
	{ 
		RefCount++; 
	}
	void DecreaseRefCount(void)
	{ 
		RefCount--; 
		if (RefCount == 0)
		{ 
			delete Pointer; 
			Pointer = 0; 
		} 
	}
	bool HasReferences(void) const
	{
		return (RefCount != 0);
	}
	TYPE *GetPointer(void) const
	{
		return Pointer;
	}
};

template <class TYPE>
class CSmartPointer
{
protected:
	CSmartPointerResource<TYPE> *Resource;

public:
	CSmartPointer(TYPE *NewPointer=0)
	{
		Resource = new CSmartPointerResource<TYPE>(NewPointer);
		Resource->IncreaseRefCount();
	}
	CSmartPointer(const CSmartPointer &SP)
	{
		Resource = SP.Resource;
		Resource->IncreaseRefCount();
	}
	virtual ~CSmartPointer()
	{
		Resource->DecreaseRefCount();
		if (!Resource->HasReferences()) delete Resource;
	}
	TYPE *GetPointer(void) const { return Resource->GetPointer(); }
	const CSmartPointer &operator=(const CSmartPointer &SP)
	{
		if (SP.Resource != this->Resource)
		{
			Resource->DecreaseRefCount();
			Resource = SP.Resource;
			Resource->IncreaseRefCount();
		}
		return (*this);
	}
	const CSmartPointer &operator=(const CSmartPointer *SP)
	{
		*this = *SP;
		return (*this);
	}
	// creates a new resource for NewPointer
	const CSmartPointer &operator=(TYPE *NewPointer)
	{
		Resource->DecreaseRefCount();
		Resource = new CSmartPointerResource<TYPE>(NewPointer);
		Resource->IncreaseRefCount();
		return (*this);
	}
	TYPE *operator->()
	{ 
		return Resource->GetPointer(); 
	}
	// disabled, because dangerous 
	//operator TYPE* ()
	//{ 
	//	return Resource->GetPointer(); 
	//}
	TYPE &operator*()
	{ 
		return *(Resource->GetPointer()); 
	}
	bool operator==(const CSmartPointer &SP)
	{ 
		return (SP.Resource == Resource); 
	}
};

#endif
