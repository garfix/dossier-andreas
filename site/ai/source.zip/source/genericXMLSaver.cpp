#include "genericXMLSaver.h"

namespace generic
{

CXMLSaver::CXMLSaver()
{
}

CXMLSaver::~CXMLSaver()
{
}

void CXMLSaver::Write(const CText &String)
{
	Append(String);
}

void CXMLSaver::EnterChild(const CText &ChildName)
{
	assert(!ChildName.Contains(' '));
	Append("<" + ChildName + ">");
}

void CXMLSaver::LeaveChild(const CText &ChildName)
{
	assert(!ChildName.Contains(' '));
	Append("</" + ChildName + ">");
}

/// Writes CData string as a CDATA section; if CDATA contains a "]]>"
/// character string, CData will be split up: the "]]" go to the end
/// of the first CDATA section, ">" goes to the second section.
/// This is because CDATA sections are delimited by "]]>"
void CXMLSaver::WriteCDataChild(const CText &Child, const CText &CData)
{
	CText Section;
	int Start, End;

	assert(!Child.Contains(' '));
	EnterChild(Child);

	Start = 0;
	do
	{
		Write("<![CDATA[");

		End = CData.GetIndex("]]>", Start);
		if (End == -1) Write(CData.Substring(Start, CData.GetLength()-1));
		else Write(CData.Substring(Start, End+1));

		Write("]]>");

		Start = End+2;
	}
	while (End != -1);

	LeaveChild(Child);
}

void CXMLSaver::WriteIntChild(const CText &Child, int Value)
{
	assert(!Child.Contains(' '));
	EnterChild(Child);
	Write(CText(Value));
	LeaveChild(Child);
}

void CXMLSaver::WriteBooleanChild(const CText &Child, bool Value)
{
	assert(!Child.Contains(' '));
	EnterChild(Child);
	Write(Value ? "true" : "false");
	LeaveChild(Child);
}

void CXMLSaver::WriteEmptyElement(const CText &Child)
{
	assert(!Child.Contains(' '));
	Write("<" + Child + "/>");
}

}
