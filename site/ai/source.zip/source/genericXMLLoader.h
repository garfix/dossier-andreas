#ifndef _XML_LOADER
#define _XML_LOADER

#include "genericLoader.h"
#include "genericStack.h"
#include "genericText.h"

namespace generic
{

class CXMLLoader;
class CXMLSaver;

/// Interface
class CXMLElement
{
public:
	virtual void Save(CXMLSaver &Saver)=0;
	virtual bool Load(CXMLLoader &Loader, const CText &Tag)=0;
};

/// This XML loader can be used to navigate through an XML (tree) structure.
/// Internally, no tree structure is created, however. Navigation happens within the source.

/// There are two ways to parse the structure

/// First method: entering and leaving
/// stack-like, DOM-like, flexible
/// Navigation makes use of a cursor in the XML structure. The cursor can enter
/// a child node, which lengthens the path, or can leave the child node, which
/// shortens the path.
/// Every entry of SourceIndexPath contains the Source Index of the start of the body 
/// of some element.

/// Second method: skipping
/// parsing-like, SAX-like, fast
/// Go through the source xml linearly. 
class CXMLLoader: public CLoader
{
protected:
	// Current path in the XML tree. Consists of indices in the XML string.
	CStack<int> SourceIndexPath;
	// A common repository needed by different types of element in the xml tree
	void *Context;
	bool Success;

	const CText ParseCharacterData(void);
	bool TryParseStartTag(CText &ChildName);
	void TrySkipBody(void);
	bool TrySkipEndTag(const CText &ChildName);
	bool TrySkipEndTag(void);
	bool TrySkipChild(void);

public:
	CXMLLoader();

	void SetContext(void *NewContext){ Context = NewContext; }
	void *GetContext(void) const { return Context; }

	bool GetSuccess(void) const { return Success; }

	// absolute addressing, more time-consuming
	bool EnterChild(const CText &Name, int Index=0);
	bool EnterChild(int Index);
	bool LeaveChild(void);
	const CText GetCharacterData(void);
	int GetInteger(void);
	int GetCurrentDepth(void);

	// relative addressing, fast
	bool SkipStart(CText &TagName);
	bool SkipEnd(void);
	const CText SkipCharacterData(void);
	bool SkipBoolean(void);
	int SkipInteger(void);

	void Load(CXMLElement &Element);
};

}

#endif