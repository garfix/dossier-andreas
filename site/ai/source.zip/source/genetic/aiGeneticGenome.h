#ifndef _GENETICGENOME
#define _GENETICGENOME

#include "generic.h"

using namespace generic;

/// The Genome interface that has to be implemented with domain-specific code.
class CGeneticGenome: public CElement
{
protected:
	/// Fitness should always be value in [0, 1] where 0 = completely unsuited
	/// and 1 = perfectly suited
	float Fitness;

public:
	/// Return Fitness
	float GetFitness(void){ return Fitness; }

	/// create a new genome, no randomization is required
	virtual CGeneticGenome *NewGenome()=0;

	/// create default (random) values for the genes
	virtual void Initialize()=0;

	/// set the length (i.e. the number of genes)
	virtual void SetLength(int NewLength)=0;

	/// return the length
	virtual int GetLength(void)=0;

	/// copy gene at position Pos to Child at pos ChildPos
	virtual void CopyGene(int Pos, CGeneticGenome *Child, int ChildPos)=0;

	/// is this genome equal to Genome
	virtual bool Equals(CGeneticGenome *Genome)=0;

	/// store a random value in the gene
	virtual void MutateGene(int GeneIndex)=0;

	/// a.k.a. The objective function\n
	/// calculate the fitness of this genome and place it in the member Fitness
	/// Fitness value should always be in the range [0, 1]
	virtual void CalculateFitness(void)=0;

	/// is the genome fit enough to stop evolving?
	virtual bool IsFitEnough(void)=0;
};

#endif