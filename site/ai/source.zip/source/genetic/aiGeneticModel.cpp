#include "aiGeneticModel.h"
#include "aiGeneticGenome.h"

CGeneticModel::CGeneticModel()
{
	PrototypeGenome = 0;

	Init();
}

CGeneticModel::CGeneticModel(CGeneticGenome *NewPrototypeGenome)
{
	PrototypeGenome = NewPrototypeGenome;

	Init();
}

/// Sets default parameters for the algorithm:\n
/// population size: 100; new parents per cycle: 10; new ones per cycle: 10;
/// mutation rate: 1.0f; parent selection types: roulette wheel;
/// crossover types: fixed length one point, fixed length two points;
/// mutation type: change gene
void CGeneticModel::Init(void)
{
	SetPopulationSize(100, 10, 10, -1);
	SetMutationRate(1.0f);
    AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
    AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
    AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
    AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
    AddParentSelectionType(PARENTSELECTIONTYPE_TOURNAMENT);
	AddCrossoverType(CROSSOVERTYPE_FIXEDLENGTH_ONEPOINT);
	AddMutationType(MUTATIONTYPE_CHANGEGENE);
}

/// Crossover strategy that takes two parents, Parent1 and Parent2,
/// that should have the same length, performs crossing over via a random gene,
/// and places the new genomes in the children, Child1 and Child2.
void CGeneticModel::CrossoverFixedLengthOnePoint(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2)
{
	int CrossoverPos;

	// both genomes need to be of same length
	assert(Parent1->GetLength() == Parent2->GetLength());

	// determine random crossover point
	CrossoverPos = CMath::GetRandomInt(1, Parent1->GetLength()-1);

	// first part
	for (int i=0; i<CrossoverPos; i++) 
	{
		Parent1->CopyGene(i, Child1, i);
		Parent2->CopyGene(i, Child2, i);
	}

	// second part
	for (int i=CrossoverPos; i<Parent1->GetLength(); i++) 
	{
		Parent1->CopyGene(i, Child2, i);
		Parent2->CopyGene(i, Child1, i);
	}
}

/// Crossover strategy that takes two parents, Parent1 and Parent2,
/// that should have the same length, performs crossing over via two random genes,
/// and places the new genomes in the children, Child1 and Child2.
void CGeneticModel::CrossoverFixedLengthTwoPoints(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2)
{
	int CrossoverPos1, CrossoverPos2;

	// both genomes need to be of same length
	assert(Parent1->GetLength() == Parent2->GetLength());

	// determine random crossover point
	CrossoverPos1 = CMath::GetRandomInt(1, Parent1->GetLength()-2);
	CrossoverPos2 = CMath::GetRandomInt(CrossoverPos1+1, Parent1->GetLength()-1);

	// first part
	for (int i=0; i<CrossoverPos1; i++) 
	{
		Parent1->CopyGene(i, Child1, i);
		Parent2->CopyGene(i, Child2, i);
	}

	// second part
	for (int i=CrossoverPos1; i<CrossoverPos2; i++) 
	{
		Parent1->CopyGene(i, Child2, i);
		Parent2->CopyGene(i, Child1, i);
	}

	// third part
	for (int i=CrossoverPos2; i<Parent1->GetLength(); i++) 
	{
		Parent1->CopyGene(i, Child1, i);
		Parent2->CopyGene(i, Child2, i);
	}
}

/// Mutation strategy whereby crossover may happen to any two genes
void CGeneticModel::CrossoverFixedLengthMultiple(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2)
{
	int Chance;

	// both genomes need to be of same length
	assert(Parent1->GetLength() == Parent2->GetLength());

	// first part
	for (int i=0; i<Parent1->GetLength(); i++) 
	{
		Chance = CMath::GetRandomInt(0, 1);
		if (Chance == 0)
		{
			Parent1->CopyGene(i, Child1, i);
			Parent2->CopyGene(i, Child2, i);
		}
		else
		{
			Parent1->CopyGene(i, Child2, i);
			Parent2->CopyGene(i, Child1, i);
		}
	}
}

/// Crossover strategy that takes two parents, Parent1 and Parent2,
/// that may or may not have different lengths, performs crossing over via a random gene,
/// and places the new genomes in the children, Child1 and Child2.
void CGeneticModel::CrossoverVariableLengthOnePoint(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2)
{
	int CrossoverPos1, CrossoverPos2;
	int Child1Length, Child2Length;

	// determine random crossover points
	// the position is in [1, length-2]
	CrossoverPos1 = CMath::GetRandomInt(1, Parent1->GetLength()-2);
	CrossoverPos2 = CMath::GetRandomInt(1, Parent2->GetLength()-2);

	Child1Length = CrossoverPos1 + (Parent2->GetLength() - CrossoverPos2);
	Child2Length = CrossoverPos2 + (Parent1->GetLength() - CrossoverPos1);

	Child1->SetLength(Child1Length);
	Child2->SetLength(Child2Length);

	// child 1, first part
	for (int i=0; i<CrossoverPos1; i++) 
	{
		Parent1->CopyGene(i, Child1, i);
	}
	// child 1, second part
	for (int i=0; i<(Parent2->GetLength()-CrossoverPos2); i++) 
	{
		Parent2->CopyGene(CrossoverPos2+i, Child1, CrossoverPos1+i);
	}
	// child 2, first part
	for (int i=0; i<CrossoverPos2; i++)
	{
		Parent2->CopyGene(i, Child2, i);
	}
	// child 2, second part
	for (int i=0; i<(Parent1->GetLength()-CrossoverPos1); i++) 
	{
		Parent2->CopyGene(CrossoverPos1+i, Child2, CrossoverPos2+i);
	}
}

/// Mutation strategy whereby a single gene changes value
/// \param The genome to be mutated
void CGeneticModel::MutationChangeGene(CGeneticGenome *Genome)
{
	int GeneIndex;

	GeneIndex = CMath::GetRandomInt(0,  Genome->GetLength()-1);
	Genome->MutateGene(GeneIndex);
}

/// Mutation strategy whereby a two genes swap
/// Note: uses the prototype to temporary store genes!
/// \param The genome to be mutated
void CGeneticModel::MutationSwapGenes(CGeneticGenome *Genome)
{
	int GeneIndex1, GeneIndex2;

	// select two different genes
	GeneIndex1 = CMath::GetRandomInt(0,  Genome->GetLength()-1);
	do
	{
		GeneIndex2 = CMath::GetRandomInt(0,  Genome->GetLength()-1);
	}
	while (GeneIndex1 == GeneIndex2);

	// uses the prototype as a swapper element
	Genome->CopyGene(GeneIndex1, PrototypeGenome, GeneIndex1);
	Genome->CopyGene(GeneIndex2, PrototypeGenome, GeneIndex2);

	PrototypeGenome->CopyGene(GeneIndex1, Genome, GeneIndex2);
	PrototypeGenome->CopyGene(GeneIndex2, Genome, GeneIndex1);
}

/// Returns the pointers of two parents, that are picked randomly from the first
/// ParentCount genomes in the population.
void CGeneticModel::Pick2Parents(CGeneticGenome *&Parent1, CGeneticGenome *&Parent2)
{
	int Parent1Index, Parent2Index;

	do
	{
		Parent1Index = CMath::GetRandomInt(0, ParentCount-1);
		Parent2Index = CMath::GetRandomInt(0, ParentCount-1);
	}
	while (Parent1Index == Parent2Index);

	Parent1 = Population.GetGenome(Parent1Index);
	Parent2 = Population.GetGenome(Parent2Index);
}

/// Selects ParentCount parents from the population and moves these to the
/// first Parentcount positions in the population, via the next parent
/// selection strategy.
void CGeneticModel::SelectParents(void)
{
	if (ParentSelectionTypes.IsEmpty()) return;

	switch (ParentSelectionTypes.GetNext())
	{
	case PARENTSELECTIONTYPE_RANK:
		// no action necessary
		break;
	case PARENTSELECTIONTYPE_ROULETTEWHEEL:
		Population.SelectParentsByRouletteWheel(ParentCount);
		break;
	case PARENTSELECTIONTYPE_TOURNAMENT:
		Population.SelectParentsByTournament(ParentCount);
		break;
	}
}

/// Recombines (through crossing over) the parent genes Parent1 and Parent2
/// to form Child1 and Child2, via the next crossing over strategy.
void CGeneticModel::Recombine(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2)
{
	// have any crossover types been selected?
	if (CrossoverTypes.IsEmpty()) return;

	switch (CrossoverTypes.GetNext())
	{
	case CROSSOVERTYPE_FIXEDLENGTH_ONEPOINT:
		CrossoverFixedLengthOnePoint(Parent1, Parent2, Child1, Child2);
		break;
	case CROSSOVERTYPE_FIXEDLENGTH_TWOPOINTS:
		CrossoverFixedLengthTwoPoints(Parent1, Parent2, Child1, Child2);
		break;
	case CROSSOVERTYPE_FIXEDLENGTH_MULTIPLE:
		CrossoverFixedLengthMultiple(Parent1, Parent2, Child1, Child2);
		break;
	case CROSSOVERTYPE_VARIABLELENGTH_ONEPOINT:
		CrossoverVariableLengthOnePoint(Parent1, Parent2, Child1, Child2);
		break;
	}
}

/// Mutates a genome via the next mutation strategy.
void CGeneticModel::Mutate(CGeneticGenome *Genome)
{
	int Chance;

	// have any mutation types been selected?
	if (MutationTypes.IsEmpty()) return;

	// mutate only
	Chance = (int)((1.0f / MutationRate) + 0.5f);
	if (CMath::GetRandomInt(0, Chance-1) != 0) return;

	switch (MutationTypes.GetNext())
	{
		case MUTATIONTYPE_CHANGEGENE:
			MutationChangeGene(Genome);
			break;
		case MUTATIONTYPE_SWAPGENES:
			MutationSwapGenes(Genome);
			break;
	}
}

/// NewPopulationSize should be an even number\n
/// NewParentCount, NewNewCount and NewRecombinedCount should add up to PopulationSize\n
/// Although NewRecombinedCount may be -1, which means, "the rest"of the population
/// \param NewPopulationSize The size of the Populations.
/// \param NewParentCount The number of best genomes taken from the previous Population in the Update() cycle.
/// \param NewNewCount The number of new random genomes taken in the Update() cycle.
/// \param NewRecombinedCount The number of genomes that were recombined from the best parents in the previous Population.
void CGeneticModel::SetPopulationSize(int NewPopulationSize, int NewParentCount, int NewNewCount, int NewRecombinedCount)
{ 
	// population size should be even, since it's much easier to use
	assert(NewPopulationSize == (NewPopulationSize / 2) * 2);

	PopulationSize = NewPopulationSize; 
	ParentCount = NewParentCount;
	NewCount = NewNewCount;
	if (NewRecombinedCount == -1)
	{
		RecombinedCount = PopulationSize - ParentCount - NewCount;
	}
	else
	{
		RecombinedCount = NewRecombinedCount;
	}

	// ParentCount, NewCount and RecombinedCount should add up to PopulationSize
	assert(PopulationSize == ParentCount + NewCount + RecombinedCount);
}

/// This method is to be called after the tweaking of the algorithm
/// and before calling Update();\n
/// It is called automatically by Evolve().
void CGeneticModel::Initialize(void)
{
	assert(PrototypeGenome != 0);

	// initialize population
	Population.Initialize(PopulationSize, PrototypeGenome);

	// initial fitness
	SetFitness(CFloat::GetMinimum());
}

/// Evolve an epoch (or cycle).
void CGeneticModel::Update(void)
{
	CGeneticGenome *Mom, *Dad, *Child1, *Child2;
	int ChildIndex;

	// select most fit parents
	SelectParents();

	// mate the best individuals and create new children
	ChildIndex = ParentCount;
	while (ChildIndex < ParentCount + RecombinedCount)
	{
		// pick two parents
		Pick2Parents(Mom, Dad);

		// sexually reproduce these parents to form two children
		Child1 = Population.GetGenome(ChildIndex);
		Child2 = Population.GetGenome(ChildIndex+1);
		Recombine(Mom, Dad, Child1, Child2);

		// mutate children
		Mutate(Child1);
		Mutate(Child2);

		// calculate new fitness
		Child1->CalculateFitness();
		Child2->CalculateFitness();

		ChildIndex += 2;
	}

	// add some new random genomes
	while (ChildIndex < PopulationSize)
	{
		// randomize
		Population.GetGenome(ChildIndex)->Initialize();

		// calculate fitness
		Population.GetGenome(ChildIndex)->CalculateFitness();

		ChildIndex++;
	}

	// sort the Population by fitness
	Population.SortByFitness();

	// determine fitness
	SetFitness(Population.GetGenome(0)->GetFitness());
}

/// Is the model done? That means, is there at least one genome in the population
/// which returns 'true' on invoking its 'IsFitEnough()' function?
bool CGeneticModel::IsFitEnough(void)
{ 
	return (Population.GetGenome(0)->IsFitEnough()); 
}

/// Initialize the model and update again and again until the model is fit enough.\n
/// Important: this method will finish if no fit enough genome can be found.\n
/// If this is unacceptable, use the combination of Initialize() and a repeated\n
/// call of Update() in stead.
void CGeneticModel::Evolve(void)
{
	// initialize initial population
	Initialize();

	// evolve population until it's fit enough
	while (!IsFitEnough())
	{
		Update();
	}
}