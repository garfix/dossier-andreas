#ifndef _GENETICMODEL
#define _GENETICMODEL

#include "aiGeneticPopulation.h"
#include "aiGeneticGenome.h"
#include "generic.h"

using namespace generic;

class CGeneticGenome;

enum EGenetic_ParentSelectionTypes
{
	PARENTSELECTIONTYPE_RANK,
	PARENTSELECTIONTYPE_ROULETTEWHEEL,
	PARENTSELECTIONTYPE_TOURNAMENT
};

enum EGenetic_CrossoverTypes
{
	CROSSOVERTYPE_FIXEDLENGTH_ONEPOINT,
	CROSSOVERTYPE_FIXEDLENGTH_TWOPOINTS,
	CROSSOVERTYPE_FIXEDLENGTH_MULTIPLE,
	CROSSOVERTYPE_VARIABLELENGTH_ONEPOINT
};

enum EGenetic_MutationTypes
{
	MUTATIONTYPE_CHANGEGENE,
	MUTATIONTYPE_SWAPGENES
};

/// The genetic model represents the genetic algorithm.
/// To use it, follow these steps:\n
/// - Create a subclass of CGeneticGenome representing the problem space of the
///   current problem.\n
/// - Create the model, passing an object of the genome class.\n
/// - Set the algorithm's properties (selection type, crossover type, mutation type,
///	  mutation rate, population size. All these are optional, because they
///   have suitable default values.\n
/// - Initialize() the model with these properties.\n
/// - Either call Evolve, which will Update() the model until it's fit enough
///   or repeatedly call Update() and IsFitEnough() to manualy evolve
///   the model one cycle. You can also use GetFitness() to determine the current
///   state of the model.\n\n
/// - Call GetGenome() and GetFittestGenome() to obtain certain genomes from
///   the population.\n
///
/// The selectiontypes, Crossovertypes, and mutationtypes are stored in a 
/// circular datastructure. Whenever a crossover, mutation, etc.  is made, 
/// the next one of the circular structure will be used.\n
/// An example: CrossoverTypes is by default filled with one element: CROSSOVERTYPE_FIXEDLENGTH_ONEPOINT
/// If you add another crossover type, like CROSSOVERTYPE_FIXEDLENGTH_TWOPOINTS,
/// both types will be used alternatingly.
class CGeneticModel: public CElement
{
protected:
	// what is the chance, in [0..1], of a genome being mutated in an update cycle?
	float MutationRate;
	// what is the composition of he next generation
	int PopulationSize, ParentCount, NewCount, RecombinedCount;
	// the population of genomes
	CGeneticPopulation Population;
	// the genome that is used to create the initial population
	CGeneticGenome *PrototypeGenome;
	// global fitness
	float Fitness;
	// parent selection types
	CRing<EGenetic_ParentSelectionTypes> ParentSelectionTypes;
	// crossover types
	CRing<EGenetic_CrossoverTypes> CrossoverTypes;
	// mutation types
	CRing<EGenetic_MutationTypes> MutationTypes;

	void Init(void);
	void SetFitness(float NewFitness){ Fitness = NewFitness; };
	
	// recombination strategies
	void CrossoverFixedLengthOnePoint(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2);
	void CrossoverFixedLengthTwoPoints(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2);
	void CrossoverFixedLengthMultiple(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2);
	void CrossoverVariableLengthOnePoint(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2);

	// mutation strategies
	void MutationChangeGene(CGeneticGenome *Genome);
	void MutationSwapGenes(CGeneticGenome *Genome);

	void Pick2Parents(CGeneticGenome *&Parent1, CGeneticGenome *&Parent2);
	void SelectParents(void);
	void Recombine(CGeneticGenome *Parent1, CGeneticGenome *Parent2, CGeneticGenome *Child1, CGeneticGenome *Child2);
	void Mutate(CGeneticGenome *Genome);

public:
	CGeneticModel();
	CGeneticModel(CGeneticGenome *NewPrototypeGenome);

	void SetPrototypeGenome(CGeneticGenome *NewPrototypeGenome){PrototypeGenome = NewPrototypeGenome; }
	void SetMutationRate(float NewMutationRate){ MutationRate = NewMutationRate; }
	void SetPopulationSize(int NewPopulationSize, int NewParentCount=10, int NewNewCount=10, int NewRecombinedCount=-1);
	
	void ClearParentSelectionTypes(void){ ParentSelectionTypes.Clear(); }
	void AddParentSelectionType(EGenetic_ParentSelectionTypes NewParentSelectionType){ ParentSelectionTypes.Add(NewParentSelectionType); }
	void ClearCrossoverTypes(void){ CrossoverTypes.Clear(); }
	void AddCrossoverType(EGenetic_CrossoverTypes NewCrossoverType){ CrossoverTypes.Add(NewCrossoverType); }
	void ClearMutationTypes(void){ MutationTypes.Clear(); }
	void AddMutationType(EGenetic_MutationTypes NewMutationType){ MutationTypes.Add(NewMutationType); }

	CGeneticGenome *GetGenome(int Index){ return Population.GetGenome(Index); }
	CGeneticGenome *GetFittestGenome(void){ return Population.GetGenome(0); }

	void Initialize(void);
	void Update(void);
	void Evolve(void); 
	bool IsFitEnough(void);
	float GetFitness(void){ return Fitness; }

	friend class CTest;
};

#endif