#ifndef _GENETICPOPULATION
#define _GENETICPOPULATION

#include "generic.h"

using namespace generic;

class CGeneticGenome;

/// Represents a population of genomes. Is used by the genetic model.
class CGeneticPopulation: public CElement
{
protected:
	CRow<CGeneticGenome *> Genomes;

	int SelectGenomeByRouletteWheel(int ParentIndex, float AccumulatedFitness);

public:
	CGeneticPopulation();
	~CGeneticPopulation();

	void Initialize(int PopulationSize, CGeneticGenome *PrototypeGenome);

	CGeneticGenome *GetGenome(int GenomeIndex){ return Genomes.Get(GenomeIndex); }
	void SortByFitness(void);
	float CalculateAccumulatedFitness(void);
	void SelectParentsByRouletteWheel(int ParentCount);
	void SelectParentsByTournament(int ParentCount);
};

#endif