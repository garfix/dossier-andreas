#include "aiGeneticPopulation.h"
#include "aiGeneticGenome.h"

CGeneticPopulation::CGeneticPopulation():
	Genomes(0)
{
}

CGeneticPopulation::~CGeneticPopulation()
{
	Genomes.DeleteContents();
}

/// Initializes the population with a certain size. It is populated with
/// clones of PrototypeGenome, by calling NewGenome on it. Initialize()
/// is called on the new genomes, followed by CalculateFitness(). 
/// The genomes are sorted by fitness.
void CGeneticPopulation::Initialize(int PopulationSize, CGeneticGenome *PrototypeGenome)
{
	CGeneticGenome *Genome;

	// clear old values
	Genomes.DeleteContents();

	// set the length of the genome array
	Genomes.SetLength(PopulationSize);

	// fill the genome array
	for (int i=0; i < PopulationSize; i++)
	{
		// create new genome
		Genome = PrototypeGenome->NewGenome();

		// initialize it
		Genome->Initialize();

		// calculate its fitness
		Genome->CalculateFitness();

		// add it to the generation
		Genomes.Set(i, Genome);
	}

	// sort the Population by fitness
	SortByFitness();
}

/// Helper function for SelectParentsByRouletteWheel and SelectParentsByTournament
/// \param ParentIndex The index of the genome that is the current parent
/// \param AccumulatedFitness The accumulated fitness less the accumulated fitness
/// of the parents up to the parent index
/// \return The index of the selected genome
int CGeneticPopulation::SelectGenomeByRouletteWheel(int ParentIndex, float AccumulatedFitness)
{
	float PartFitness;
	int GenomeIndex;
	float Chance;

	// by chance
	Chance = CMath::GetRandomFloat(0.0f, AccumulatedFitness);

	// accumulate genome fitness until it has exceeded Chance.
	// Since the parents are in the same population as their offspring,
	// care must be taken that they do not overlap
	GenomeIndex = ParentIndex;
	PartFitness = 0.0f;
	while (GenomeIndex < Genomes.GetLength())
	{
		// accumulate fitness
		PartFitness += GetGenome(GenomeIndex)->GetFitness();

		// if the partial accumulated fitness > chance value
		if (PartFitness >= Chance) return GenomeIndex;

		GenomeIndex++;
	}

	// some rounding problem, probably, return the last genome
	return Genomes.GetLength()-1;
}

/// performs bubble sort by fitness
void CGeneticPopulation::SortByFitness(void)
{
	CGeneticGenome *Genome1, *Genome2;

	for (int i=0; i < Genomes.GetLength()-1; i++)
	{
		for (int j=0; j < Genomes.GetLength()-1-i; j++)
		{
			Genome1 = Genomes.Get(j);
			Genome2 = Genomes.Get(j+1);
			if (Genome2->GetFitness() > Genome1->GetFitness())
			{
				Genomes.Set(j, Genome2);
				Genomes.Set(j+1, Genome1);
			}
		}
	}
}

/// Calculates and returns the sum of all genomes' fitness
float CGeneticPopulation::CalculateAccumulatedFitness(void)
{
	float AccumulatedFitness = 0.0f;

	for (int i=0; i<Genomes.GetLength(); i++)
	{
		AccumulatedFitness += Genomes.Get(i)->GetFitness();
	}

	return AccumulatedFitness;
}

/// Uses the roulette wheel selection strategy to select ParentCount
/// genomes from the population, and moves these to the beginning of
/// the population.
void CGeneticPopulation::SelectParentsByRouletteWheel(int ParentCount)
{
	float AccumulatedFitness;
	int ParentIndex, GenomeIndex;
	CGeneticGenome *Swapper;
	
	// calculate the accumulated fitness value
	AccumulatedFitness = CalculateAccumulatedFitness();

	// select ParentCount parents
	for (ParentIndex=0; ParentIndex<ParentCount; ParentIndex++)
	{
		// select a genome by roulette wheel from the genomes starting
		// with the one following the current parent
		GenomeIndex = SelectGenomeByRouletteWheel(ParentIndex, AccumulatedFitness);

		// swap the genome at parentposition i with the genome
		// at position GenomeIndex
		Swapper = Genomes.Get(ParentIndex);
		Genomes.Set(ParentIndex, GetGenome(GenomeIndex));
		Genomes.Set(GenomeIndex, Swapper);

		// since we will not select the same parent twice, the accumulated
		// fitness will decrease
		AccumulatedFitness -= GetGenome(ParentIndex)->GetFitness();
	}
}

/// Uses the roulette tournament strategy to select ParentCount
/// genomes from the population, and moves these to the beginning of
/// the population.
void CGeneticPopulation::SelectParentsByTournament(int ParentCount)
{
	float AccumulatedFitness;
	int ParentIndex, GenomeIndex, GenomeIndex1, GenomeIndex2;
	CGeneticGenome *Swapper;
	
	// calculate the accumulated fitness value
	AccumulatedFitness = CalculateAccumulatedFitness();

	// select ParentCount parents
	for (ParentIndex=0; ParentIndex<ParentCount; ParentIndex++)
	{
		// select two genome by roulette wheel from the genomes starting
		// with the one following the current parent
		GenomeIndex1 = SelectGenomeByRouletteWheel(ParentIndex, AccumulatedFitness);
		GenomeIndex2 = SelectGenomeByRouletteWheel(ParentIndex, AccumulatedFitness);

		// select the fittest of the two genomes
		if (Genomes.Get(GenomeIndex1)->GetFitness() > Genomes.Get(GenomeIndex2)->GetFitness())
		{
			GenomeIndex = GenomeIndex1;
		}
		else
		{
			GenomeIndex = GenomeIndex2;
		}

		// swap the genome at parentposition i with the genome
		// at position GenomeIndex
		Swapper = Genomes.Get(ParentIndex);
		Genomes.Set(ParentIndex, GetGenome(GenomeIndex));
		Genomes.Set(GenomeIndex, Swapper);
		
		// since we will not select the same parent twice, the accumulated
		// fitness will decrease
		AccumulatedFitness -= GetGenome(ParentIndex)->GetFitness();
	}
}




