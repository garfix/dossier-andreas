#include "genericStopwatch.h"

namespace generic
{
	
CStopwatch::CStopwatch()
{
	Reset();
}

const CStopwatch &CStopwatch::Start(void)
{
	StartTime = clock();

	return (*this);
}

const CStopwatch &CStopwatch::Stop(void)
{
	clock_t CurrentTime = clock();

	Duration += (double)(CurrentTime - StartTime) / CLOCKS_PER_SEC;

	return (*this);
}

// resets the start time
const CStopwatch &CStopwatch::Reset(void)
{
	Duration = 0.0;

	return (*this);
}

// prints duration 
const CStopwatch &CStopwatch::Print(void) const
{
	printf("%2.2f\n", Duration);

	return (*this);
}

}
