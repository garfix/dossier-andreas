#ifndef _PAIR
#define _PAIR

#include "genericElement.h"

namespace generic
{
	
template <class TYPE1, class TYPE2>
class CPair
{
protected:
	TYPE1 First;
	TYPE2 Second;

public:
	CPair(){}
	
	CPair(TYPE1 NewFirst, TYPE2 NewSecond)
	{
		First = NewFirst;
		Second = NewSecond;
	}
	
	const TYPE1 &GetFirst(void) const { return First; }
	const TYPE2 &GetSecond(void) const { return Second; }

	void operator=(const CPair<TYPE1, TYPE2> &NewPair)
	{
		First = NewPair.First;
		Second = NewPair.Second;
	}
};

}

#endif