#ifndef _STACK
#define _STACK

#include "genericRow.h"

namespace generic
{
	
template <class TYPE>
class CStack: public CRow<TYPE>
{
protected:
	//int TopIndex;

public:
	CStack(int NewLength): CRow<TYPE>(0, NewLength)
	{
		//TopIndex = 0;
	}

	void Push(const TYPE &Item)
	{
		//assert(TopIndex < Length);

		//Set(TopIndex, Item);
		Add(Item);
		//TopIndex++;
	}

	/// Removes the topmost element off the stack and returns it
	const TYPE &Pop(void)
	{
		//assert(TopIndex >= Count);

		//TopIndex -= Count;
		//for (int i=0; i < Count; i++) RemoveAt(Length-1);
		Length --;
		return Values[Length];
	}

	const TYPE &Peek(int Depth=0)
	{
		//assert(Depth < TopIndex);

		return Values[Length - 1 - Depth];
	}

	void PopAll(void)
	{
		//TopIndex = 0;
		Clear();
	}

	int GetDepth(void){ return Length; } //TopIndex; }
};

}

#endif