#include "genericXMLLoader.h"

namespace generic
{
	
CXMLLoader::CXMLLoader():
	SourceIndexPath(100)
{
	SetCaseSensitive(true);
	SetPunctuationChars("<>/]-!");
	SetWhitespaceChars("\t\n ");
	AddOperator("<![CDATA[");
	AddOperator("]]>");
	AddCommentInfo(SCommentInfo("<!--", "-->", false));

	// start path: start of Source
	SourceIndexPath.Push(0);

	// assume no errors
	Success = true;
}

/// Parses literal data up to the first '<' character.
/// Assumes the SourceIndex is at the start of this character data element.
/// \return The parsed character data
const CText CXMLLoader::ParseCharacterData(void)
{
	CText CharacterData;

	// child consists of character data, parse until '<' is found
	while (!Done && (LookAhead() != "<"))
	{
		CharacterData += NextToken();
	}

	// check for errors
	if (Done) Success = false;

	return CharacterData;
}

/// Tries to parse '<TagName>' in the Source. If this succeeds, the TagName
/// will be copied into ChildName, SourceIndex will be updated, and SourceIndexPath
/// will be extended with the current SourceIndex.
/// If it fails, SourceIndex will be unaffected.
/// \return Succeeded?
bool CXMLLoader::TryParseStartTag(CText &ChildName)
{
	int SavedSourceIndex;
	bool SuccessLocal = true;

	SavedSourceIndex = SourceIndex;

	NextToken();
	if (Token != "<") SuccessLocal = false;
	else
	{
		NextToken();
		if (Token == "/") SuccessLocal = false;
		else
		{
			ChildName = Token;
			NextToken();
			if (Token == "/") 
			{
				// empty element
				NextToken();
				if (Token != ">") SuccessLocal = false;
			}
			else
			{
				if (Token != ">") SuccessLocal = false;
				else
				{
					// extend path
					SourceIndexPath.Push(SourceIndex);
				}
			}
		}
	}

	if (!SuccessLocal)
	{
		// reset source index
		SourceIndex = SavedSourceIndex;
	}

	return SuccessLocal;
}

/// Parses (skips) all children on this level in the XML tree.
void CXMLLoader::TrySkipBody(void)
{
	// parse all children
	while (TrySkipChild());
}

/// Tries to parse '</TagName>' in the Source. If this succeeds, 
/// SourceIndex will be updated, and the latest SourceIndex will be
/// removed from SourceIndexPath.
/// If it fails, SourceIndex will be unaffected.
/// \ChildName The string that should be present in the end tag;
/// \return Succeeded?
bool CXMLLoader::TrySkipEndTag(const CText &ChildName)
{
	int SavedSourceIndex;
	bool SuccessLocal = true;

	SavedSourceIndex = SourceIndex;

	NextToken();
	if (Token != "<") SuccessLocal = false;
	else
	{
		NextToken();
		if (Token != "/") SuccessLocal = false;
		else
		{
			NextToken();
			if (ChildName != "")
			{
				if (Token != ChildName) SuccessLocal = false;
			}
			NextToken();
			if (Token != ">") SuccessLocal = false;
		}
	}

	if (SuccessLocal)
	{
		// shorten path
		SourceIndexPath.Pop();
	}
	else
	{
		// reset source index
		SourceIndex = SavedSourceIndex;
	}

	return SuccessLocal;
}

bool CXMLLoader::TrySkipEndTag(void)
{
	int SavedSourceIndex;
	bool SuccessLocal = true;

	SavedSourceIndex = SourceIndex;

	NextToken();
	if (Token != "<") SuccessLocal = false;
	else
	{
		NextToken();
		if (Token != "/") SuccessLocal = false;
		else
		{
			// tagname:
			NextToken(); 
			NextToken();
			if (Token != ">") SuccessLocal = false;
		}
	}

	if (SuccessLocal)
	{
		// shorten path
		SourceIndexPath.Pop();
	}
	else
	{
		// reset source index
		SourceIndex = SavedSourceIndex;
	}

	return SuccessLocal;
}

/// Skips next child element in the source.
/// A child element can consist of a start tag, body and end tag in the source,
/// but also of some character data.
/// Assumes Source Index is at the start of some element.
/// \return Returns false if we've passed the last child
bool CXMLLoader::TrySkipChild(void)
{
	bool SuccessLocal;
	CText DummyTagName;

	// see if there is a start tag
	SuccessLocal = TryParseStartTag(DummyTagName);
	if (SuccessLocal) 
	{
		// child consists of start tag, body, end tag

		// body
		TrySkipBody();

		// end tag
		SuccessLocal = TrySkipEndTag(DummyTagName);
	}
	else
	{
		// see if there is an end tag, which means we're passed behind the last child already
		ParseWhitespace();
		if ((Source.Get(SourceIndex) == '<') && (Source.Get(SourceIndex+1) == '/'))
		{
			SuccessLocal = false;
		}
		else
		{
			// child consists of only character data, no tags

			// parse character data
			ParseCharacterData();
		}
	}

	return SuccessLocal;
}

/// Position the XML cursor into the ChildNameIndex-th child with name
/// ChildName. Extends SourceIndexPath. Updates SourceIndex.
/// \return Entering child element succeeded/failed.
bool CXMLLoader::EnterChild(const CText &ChildName, int ChildNameIndex)
{
	CText TagName;
	int ChildNameCount = 0;
	bool SuccessLocal;
	bool Found = false;
	
	// reset SourceIndex to start of level
	SourceIndex = SourceIndexPath.Peek(0);

	// skip children until the one with the name ChildName is found
	do
	{
		// try the start tag of the next element
		SuccessLocal = TryParseStartTag(TagName);

		if (SuccessLocal)
		{
			// found a start tag. is its name ChildName?
			if (TagName == ChildName)
			{
				// is it is ChildNameIndex_th occurrance of this tag?
				if (ChildNameCount == ChildNameIndex) Found = true;
				ChildNameCount++;
			}
		}
		if (SuccessLocal && !Found)
		{
			// not the right child, skip the rest of the element
			TrySkipBody();
			TrySkipEndTag(TagName);
		}
	}
	while (SuccessLocal && !Found);

	// adapt global success
	Success &= SuccessLocal;

	return Found;
}

/// Position the XML cursor into the ChildNameIndex-th child. 
/// Extends SourceIndexPath. Updates SourceIndex.
/// \return Entering child element succeeded/failed.
bool CXMLLoader::EnterChild(int ChildIndex)
{
	CText TagName;
	int ChildNameCount = 0;
	bool SuccessLocal;
	bool Found = false;

	// skip ChildIndex-1 children
	for (int Index=0; Index<ChildIndex-1; Index++)
	{
		SuccessLocal = TrySkipChild();
		if (!SuccessLocal) return false;
	}

	// enter ChildIndex_th child
	SuccessLocal = TryParseStartTag(TagName);

	// adapt global success
	Success &= SuccessLocal;
	
	return SuccessLocal;
}

/// Position XML cursor one level back, into its parent element.
/// Extends SourceIndexPath. Updates SourceIndex.
/// \return Entering parent element succeeded/failed.
bool CXMLLoader::LeaveChild(void)
{
	// no parent
	if (GetCurrentDepth() == 0) return false;

	SourceIndex = SourceIndexPath.Pop();
	return true;
}

/// Assumes this element consists only of character data, and 
/// returns this.
/// Source index is left unaffected.
/// \return Fetching of character data succeeded/failed.
const CText CXMLLoader::GetCharacterData(void)
{
	int SavedSourceIndex = SourceIndex;
	CText CharacterData;

	CharacterData = ParseCharacterData();

	SourceIndex = SavedSourceIndex;

	return CharacterData;
}

/// Parses the next token and returns it as an integer.
/// Source index is left unaffected.
int CXMLLoader::GetInteger(void)
{
	return GetCharacterData().ToInteger();
}

/// Returns the current level of the cursor, or the length of the path
int CXMLLoader::GetCurrentDepth(void)
{
	return SourceIndexPath.GetLength();
}

/// Parses the next start tag at the SourceIndex. The name of the tag found is returned.
/// If no tag is found, or if the tag is an end tag, false is returned.
/// \TagName The tagname of the next element (output!)
/// \return Possible?
bool CXMLLoader::SkipStart(CText &TagName)
{
	bool SuccessLocal;

	SuccessLocal = TryParseStartTag(TagName);

	return SuccessLocal;
}

/// Parses the next end tag at the SourceIndex. If the next tag is a start tag
/// or if no tag could be found, false is returned and Success is false.
bool CXMLLoader::SkipEnd(void)
{
	bool SuccessLocal;

	SuccessLocal = TrySkipEndTag();
	Success &= SuccessLocal;

	return SuccessLocal;
}

/// The next tag is treated as raw text data.
/// Parses zero, one, or more adjoining CDATA sections.
const CText CXMLLoader::SkipCharacterData(void)
{
	CText CData;
	CText Next;
	int EndCData;

	while (LookAhead() == "<![CDATA[")
	{
		// parse start CDATA
		NextToken();

		// find end
		EndCData = Source.GetIndex("]]>", SourceIndex);
		if (EndCData == -1) 
		{
			// corrupt file, must return something
			Success = false;
			return ""; 
		}

		if (EndCData > SourceIndex) // empty string
			CData += Source.Substring(SourceIndex, EndCData-1);

		// skip ]]>
		SourceIndex = EndCData+3;
	}

	return CData;
}

/// Parses the next token and returns it as a boolean.
/// "true" (case in-sensitive) and 1 are taken to be TRUE
/// any other value is taken to be false
/// Source index is left unaffected.
bool CXMLLoader::SkipBoolean(void)
{
	CText Token = NextToken().ToLowercase();

	if ((Token == "1") || (Token == "true")) return true;
	if ((Token == "0") || (Token == "false")) return false;

	Success = false;
	return false;
}

/// Parses the next token and returns it as an integer.
/// Source index is left unaffected.
int CXMLLoader::SkipInteger(void)
{
	return NextToken().ToInteger();
}

void CXMLLoader::Load(CXMLElement &Element)
{
	CText TagName;
	int PathLengthBefore, PathLengthAfter;

	PathLengthBefore = SourceIndexPath.GetDepth();
	while (GetSuccess() && SkipStart(TagName))
	{
		Element.Load(*this, TagName);
		
		PathLengthAfter = SourceIndexPath.GetDepth();
		if (PathLengthAfter > PathLengthBefore)
		{
			// SkipStart has entered the element (it was not empty, as is <Open/> ),
			// therefore we must leave the element
			SkipEnd();
		}
	}
}

}
