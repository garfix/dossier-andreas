#include <conio.h>
#include "generic.h"
#include "AI.h"

/// Interactive Activation model for word recognition
///
/// from "Explorations in Parallel Distributed Processing" (chapter 7)
/// by McClelland & Rumelhart

// presence, absence
#define MODIFIER_COUNT 2
// letter positions
#define POSITION_COUNT 4
// Rumelhart-Siple features of letters
#define FEATURE_COUNT 14
// letters of english alphabet
#define LETTER_COUNT 26
// 4 letter words from Kucera and Francis
#define WORD_COUNT 1179

// frequency scale parameter (scales activation resting level)
#define FGAIN 0.05f

/* feature indices:
      
  --2------
 |\   |   /|
 1 10 7 11 3
 |  \ | /  |
  -6-- --8- 
 |  / | \  |
 0 13 9 12 4
 |/   |   \|
  ------5--
 
*/

int Features[LETTER_COUNT][FEATURE_COUNT] = {
	{1,1,1,1,1,0,1,0,1,0,0,0,0,0},  /* A */
	{0,0,1,1,1,1,0,1,1,1,0,0,0,0},  /* B */
	{1,1,1,0,0,1,0,0,0,0,0,0,0,0},  /* C */
	{0,0,1,1,1,1,0,1,0,1,0,0,0,0},  /* D */
	{1,1,1,0,0,1,1,0,0,0,0,0,0,0},  /* E */
	{1,1,1,0,0,0,1,0,0,0,0,0,0,0},  /* F */
	{1,1,1,0,1,1,0,0,1,0,0,0,0,0},  /* G */
	{1,1,0,1,1,0,1,0,1,0,0,0,0,0},  /* H */
	{0,0,1,0,0,1,0,1,0,1,0,0,0,0},  /* I */
	{1,0,0,1,1,1,0,0,0,0,0,0,0,0},  /* J */
	{1,1,0,0,0,0,1,0,0,0,0,1,1,0},  /* K */
	{1,1,0,0,0,1,0,0,0,0,0,0,0,0},  /* L */
	{1,1,0,1,1,0,0,0,0,0,1,1,0,0},  /* M */
	{1,1,0,1,1,0,0,0,0,0,1,0,1,0},  /* N */
	{1,1,1,1,1,1,0,0,0,0,0,0,0,0},  /* O */
	{1,1,1,1,0,0,1,0,1,0,0,0,0,0},  /* P */
	{1,1,1,1,1,1,0,0,0,0,0,0,1,0},  /* Q */
	{1,1,1,1,0,0,1,0,1,0,0,0,1,0},  /* R */
	{0,1,1,0,1,1,1,0,1,0,0,0,0,0},  /* S */
	{0,0,1,0,0,0,0,1,0,1,0,0,0,0},  /* T */
	{1,1,0,1,1,1,0,0,0,0,0,0,0,0},  /* U */
	{1,1,0,0,0,0,0,0,0,0,0,1,0,1},  /* V */
	{1,1,0,1,1,0,0,0,0,0,0,0,1,1},  /* W */
	{0,0,0,0,0,0,0,0,0,0,1,1,1,1},  /* X */
	{0,0,0,0,0,0,0,0,0,1,1,1,0,0},  /* Y */
	{0,0,1,0,0,1,0,0,0,0,0,1,0,1}   /* Z */
};

int Mask[FEATURE_COUNT] = {1,1,1,1,1,1,0,0,0,0,1,1,1,1}; /* X superimposed on O */

/// Simplifies the creation of a pattern for the feature pool
class CFeaturePattern
{
protected:
	CRow<float> Pattern;

public:
	/// The starting point of the feature is a four character string
    CFeaturePattern(const CText &Word)
	{
		char Char;
		bool Present;

		assert(Word.GetLength() == POSITION_COUNT);

		Pattern.SetLength(MODIFIER_COUNT * FEATURE_COUNT * POSITION_COUNT);

		// fill pattern
		for (int Pos=0; Pos<POSITION_COUNT; Pos++)
		{
			Char = Word.Get(Pos);
			switch (Char)
			{
			case '#':
				// the mask character (the letter X superimposed on the letter O)
				SetFeatures(Pos, Mask);
				break;
			case '?':
				// random features
				for (int i=0; i<FEATURE_COUNT; i++)
				{
					Present = CMath::GetRandomBool();
					SetFeature(Pos, i, Present, !Present);
				}
				break;
			case '_':
				// blank: all features are neither absent nor present (i.e. unknown)
				for (int i=0; i<FEATURE_COUNT; i++)
				{
					SetFeature(Pos, i, false, false);
				}
				break;
			case '.':
				// absence: all features are positively absent
				for (int i=0; i<FEATURE_COUNT; i++)
				{
					SetFeature(Pos, i, false, true);
				}
				break;
			default:
				// assume lowercase letter
				SetFeatures(Pos, Features[Char - 'a']);
			}
		}
	}

	/// Sets all 14 features of one letter position
	void SetFeatures(int Position, int *FeatureArray)
	{
		for (int i=0; i<FEATURE_COUNT; i++)
		{
			SetFeature(Position, i, FeatureArray[i] == 1, FeatureArray[i] == 0);
		}
	}

	/// Sets the absent and present modifiers of one features
	void SetFeature(int Position, int FeatureIndex, bool Present, bool Absent)
	{
		int Index = Position * (MODIFIER_COUNT * FEATURE_COUNT) + FeatureIndex * MODIFIER_COUNT;

		Pattern.Set(Index, (Present ? 1.0f : 0.0f));
		Pattern.Set(Index+1, (Absent ? 1.0f : 0.0f));
	}

	/// Returns the float array
	const CRow<float> &Get(void) const { return Pattern; }
};

/// Prints all activated word units (units with a positive output value)
void PrintActiveWords(CNNModel &Model)
{
	CNNPool *WordPool = Model.GetPool("words");
	CNNUnit *Unit;

	for (int i=0; i<WordPool->GetUnitCount(); i++)
	{
		Unit = WordPool->GetUnit(i);

		if (Unit->GetOutput() > 0)
		{
			printf ("%s ", Unit->GetName().GetBuffer());
		}
	}
}

void TestPattern(CNNModel &Model, const CFeaturePattern &FeaturePattern, const CText &DesiredWord)
{
	// reset to zero activation
	Model.Reset();
	
	// set activation pattern to feature pool
	Model.GetPool("features")->SetOutputPattern(FeaturePattern.Get());
	
	CStopwatch Stopwatch;
	Stopwatch.Start();
    
	// update until a word is recognized
	for (int i=0; i<50; i++)
	{
		Model.Update();

		printf("%3d] ", Model.GetCycleCount());
		PrintActiveWords(Model);
		printf("\n");
	}

	Stopwatch.Stop().Print();
}

void InteractiveActivation(void)
{
	CNNModel IAModel;
	CNNPool *FeaturePool, *WordPool;
	CNNPool *LetterPools[POSITION_COUNT];
	CNNPoolConnection *F2LConnection[POSITION_COUNT];
	CNNPoolConnection *L2WConnection[POSITION_COUNT]; 
	CNNPoolConnection *W2LConnection[POSITION_COUNT]; 
	CNNPoolConnection *W2WConnection;



	/* create pools */

	// word pool: 
	// word0, word1, word2, ...
	WordPool = IAModel.AddPool("words", WORD_COUNT);
	WordPool->SetPoolType(POOLTYPE_OUTPUT);

	WordPool->SetDecay(0.07f);
	WordPool->SetMaximum(1.0f);
	WordPool->SetMinimum(-0.2f);
	WordPool->SetThresholdActive(true);
	WordPool->SetThreshold(0.0f);

	// letter pools: each pool represents one position
	// letter0, letter1, ...
	for (int i=0; i<POSITION_COUNT; i++)
	{
		LetterPools[i] = IAModel.AddPool(CText("letters_") + i, LETTER_COUNT);
		LetterPools[i]->SetPoolType(POOLTYPE_HIDDEN);

		LetterPools[i]->SetDecay(0.07f);
		LetterPools[i]->SetMaximum(1.0f);
		LetterPools[i]->SetMinimum(-0.2f);
		LetterPools[i]->SetThresholdActive(true);
		LetterPools[i]->SetThreshold(0.0f);
	}

	// feature pool:
	// mod0_feat0_pos0, mod1_feat0_pos0, mod0_feat1_pos0, ...
	FeaturePool = IAModel.AddPool("features", MODIFIER_COUNT * FEATURE_COUNT * POSITION_COUNT);
	FeaturePool->SetPoolType(POOLTYPE_INPUT);



	/* pool connections */

	// feature to letter 
	for (int i=0; i<POSITION_COUNT; i++)
	{
		F2LConnection[i] = IAModel.AddPoolConnection(FeaturePool, LetterPools[i]);
		F2LConnection[i]->SetAlpha(0.005f);
		F2LConnection[i]->SetGamma(0.15f);
	}
	// letter to word
	for (int i=0; i<POSITION_COUNT; i++)
	{
		L2WConnection[i] = IAModel.AddPoolConnection(LetterPools[i], WordPool);
		L2WConnection[i]->SetAlpha(0.07f);
		L2WConnection[i]->SetGamma(0.04f);
	}
	// word to letter
	for (int i=0; i<POSITION_COUNT; i++)
	{
		W2LConnection[i] = IAModel.AddPoolConnection(WordPool, LetterPools[i]);
		W2LConnection[i]->SetAlpha(0.30f);
		W2LConnection[i]->SetGamma(0.0f);
	}
	// within word (inhibit all other words)
	W2WConnection = IAModel.AddPoolConnection(WordPool, WordPool, POOLCONNECTIONTYPE_INHIBITORY);
	W2WConnection->SetGamma(0.21f);



	/* populate pools and connections */

	// read words and word resting levels
	CLoader Loader;
	CText Token;
	Loader.SetWhitespaceChars(" \t\n");
	Loader.ReadFile("resources/IA_Words.txt");
	for (int i=0; i<WORD_COUNT; i++)
	{
		Token = Loader.NextToken();
		WordPool->GetUnit(i)->SetName(Token);
		Token = Loader.NextToken();
		WordPool->GetUnit(i)->SetRest(FGAIN * (float)atof(Token.GetBuffer()));
	}

	// give names to letters
	for (int i=0; i<POSITION_COUNT; i++)
	{
		for (int j=0; j<LETTER_COUNT; j++)
		{
			LetterPools[i]->GetUnit(j)->SetName(CText((char)('a' + j)));
		}
	}

	// set letter <--> word weights
	CText Word;
	int CharIndex;
	float Weight;
	for (int WordIndex=0; WordIndex<WORD_COUNT; WordIndex++)
	{
		Word = WordPool->GetUnit(WordIndex)->GetName();

		for (int Pos=0; Pos<POSITION_COUNT; Pos++)
		{
			CharIndex = Word.Get(Pos) - 'a';
			for (int LetterIndex=0; LetterIndex<LETTER_COUNT; LetterIndex++)
			{
				if (LetterIndex == CharIndex) Weight = 1; else Weight = -1;
				W2LConnection[Pos]->SetWeight(WordIndex, LetterIndex, Weight);
				L2WConnection[Pos]->SetWeight(LetterIndex, WordIndex, Weight);
			}
		}
	}

	// set feature -> letter weights
	for (int Pos=0; Pos<POSITION_COUNT; Pos++)
	{
		for (int LetterIndex=0; LetterIndex<LETTER_COUNT; LetterIndex++)
		{
			for (int FeatureIndex=0; FeatureIndex<FEATURE_COUNT; FeatureIndex++)
			{
				Weight = ((Features[LetterIndex][FeatureIndex] == 1) ? 1.0f : -1.0f);

				// presence
				F2LConnection[Pos]->SetWeight(
					Pos*(MODIFIER_COUNT*FEATURE_COUNT) + FeatureIndex*MODIFIER_COUNT, LetterIndex, Weight);
				// absense
				F2LConnection[Pos]->SetWeight(
					Pos*(MODIFIER_COUNT*FEATURE_COUNT) + FeatureIndex*MODIFIER_COUNT + 1, LetterIndex, -Weight);
			}
		}
	}



	/* test the model */

	IAModel.SetUpdateOrder(UPDATEORDER_OUTPUT_HIDDEN);

	// present "wark", expect "work"
	TestPattern(IAModel, CFeaturePattern("wark"), "work");

	// present "able", expect "able"
	TestPattern(IAModel, CFeaturePattern("able"), "able");

	// present "back?", expect "back"
	TestPattern(IAModel, CFeaturePattern("bac?"), "back");

	// present "t_ke", expect "take"
	TestPattern(IAModel, CFeaturePattern("t_ke"), "take");
}