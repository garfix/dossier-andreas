#include <stdio.h>
#include "AI.h"

/// Demonstrating the chart parsing algorithm as described in chapter 23 of
/// Artificial Intelligence: A Modern Approach; by Stuart Russell and Peter Norvig.

void PrintParseTrees(CNLPParseForest &ParseForest)
{
	for (int Index=0; Index<ParseForest.GetParseTreeCount(); Index++)
	{
		CNLPParseTree *ParseTree = ParseForest.GetParseTree(Index);
		printf("%s\n\n", ParseTree->ToString().GetBuffer());
	}
}

void Parse(void)
{
	CNLPModel Model;
	CNLPParseForest ParseForest;

	// load a grammar
	Model.AddGrammarRules("resources/grammar_english_thoughtreasure.txt");

	// load a lexicon
	Model.AddLexicalEntries("resources/lexicon_english_nouns.txt", "Noun");
	Model.AddLexicalEntries("resources/lexicon_english_articles.txt", "Article");
	Model.AddLexicalEntries("resources/lexicon_english_pronouns.txt", "Pronoun");
	Model.AddLexicalEntries("resources/lexicon_english_verbs.txt", "Verb");
	Model.AddLexicalEntries("resources/lexicon_english_adverbs.txt", "Adverb");
	Model.AddLexicalEntries("resources/lexicon_english_adjectives.txt", "Adjective");
	Model.AddLexicalEntries("resources/lexicon_english_determiners.txt", "Det");
	Model.AddLexicalEntries("resources/lexicon_english_conjunctions.txt", "Conjunction");

	// parse sentences and create and print the parse trees
/*	Model.Parse("I feel a breeze.", ParseForest);
	PrintParseTrees(ParseForest);

	Model.Parse("fall leaves fall and spring leaves spring.", ParseForest);
	PrintParseTrees(ParseForest);
*/
	Model.Parse("I think therefore I am.", ParseForest);
	PrintParseTrees(ParseForest);
}
