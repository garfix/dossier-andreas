#include "AI.h"

/// Implements a k-fold predication mechanism (k=3) using
/// Pentti Kanerva's Sparse Distributed Memory
/// 
/// This mechanism predicts the next pattern from the previous 3 values.
/// The proces requires 4 different memories: 3 j-step memories, and a best-match memory.
/// 
/// First the best-match memory is instructed with the possible patterns,
/// then all j-step transitions are taught to the resprective n-fold memories.
/// To predict the next pattern from a sequence of patterns, the patterns from the
/// sequence are read from the different n-fold memories. This yields 3 patterns.
/// The mean of these patterns is calculated. This mean is then fed to the best-match
/// memory to retrieve the pattern that actually forms the predication for the next
/// pattern in the sequence.

namespace SDM2
{

#define WIDTH 10
#define HEIGHT 10
#define PATTERN_COUNT 6
#define WORD_LENGTH WIDTH*HEIGHT
#define NUMBER_OF_EXPOSURES 10
#define WORD_COUNT PATTERN_COUNT*NUMBER_OF_EXPOSURES

const char *Patterns[PATTERN_COUNT][HEIGHT] = 
	{ { "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O"  },

      { "OO  OO  OO",
        "OO  OO  OO",
        "  OO  OO  ",
        "  OO  OO  ",
        "OO  OO  OO",
        "OO  OO  OO",
        "  OO  OO  ",
        "  OO  OO  ",
        "OO  OO  OO",
        "OO  OO  OO"  },

      { "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO"  },

      { "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O"  },

      { "OOOOOOOOOO",
        "O        O",
        "O OOOOOO O",
        "O O    O O",
        "O O OO O O",
        "O O OO O O",
        "O O    O O",
        "O OOOOOO O",
        "O        O",
        "OOOOOOOOOO"  },

      { "   OOOO   ",
        " OO    OO ",
        "O        O",
        "O        O",
        "O        O",
        "O        O",
        "O        O",
        "O        O",
        " OO    OO ",
        "   OOOO   "  }	};

void StringToBitPattern(const char *Pattern[HEIGHT], CBitPattern &BitPattern)
{
	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			char Char = Pattern[y][x];
			BitPattern.SetBit(y * WIDTH + x, Char == 'O');
		}
	}
}

void PrintPattern(CBitPattern &BitPattern)
{
	bool Bit;

	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			Bit = BitPattern.GetBit(y * WIDTH + x);
			printf("%c", (Bit ? 'O': ' '));
		}
		printf("\n");
	}
	printf("\n");
}

/// Swaps Percentage of BitPattern's bits from 1 to 0 or the other way round.
void Distort(CBitPattern &BitPattern, float Percentage)
{
	bool Bit;

	for (int BitIndex=0; BitIndex < WORD_LENGTH; BitIndex++)
	{
		if (CMath::GetRandomFloat(0.0f, 1.0f) <= Percentage)
		{
			Bit = BitPattern.GetBit(BitIndex);
			BitPattern.SetBit(BitIndex, !Bit);
		}
	}
}
}

using namespace SDM2;

void Learn(const char **Sequence[HEIGHT], int SequenceLength, CSDMModel &FirstFold, CSDMModel &SecondFold, CSDMModel &ThirdFold)
{
	CBitPattern BitPattern1(WORD_LENGTH);
	CBitPattern BitPattern2(WORD_LENGTH);

	// learn 1-step transitions (first fold)
	for (int i=0; i < SequenceLength-1; i++)
	{
		StringToBitPattern(Sequence[i], BitPattern1);
		StringToBitPattern(Sequence[i+1], BitPattern2);
		FirstFold.Write(BitPattern1, BitPattern2);
	}
	// learn 2-step transitions (second fold)
	for (int i=0; i < SequenceLength-2; i++)
	{
		StringToBitPattern(Sequence[i], BitPattern1);
		StringToBitPattern(Sequence[i+2], BitPattern2);
		SecondFold.Write(BitPattern1, BitPattern2);
	}
	// learn 3-step transitions (third fold)
	for (int i=0; i < SequenceLength-3; i++)
	{
		StringToBitPattern(Sequence[i], BitPattern1);
		StringToBitPattern(Sequence[i+3], BitPattern2);
		ThirdFold.Write(BitPattern1, BitPattern2);
	}
}

void Predict(const char **Sequence[HEIGHT], int SequenceLength, CSDMModel &BestMatch, CSDMModel &FirstFold, CSDMModel &SecondFold, CSDMModel &ThirdFold, CBitPattern &Prediction)
{
	CRow<CBitPattern> Patterns;
	CBitPattern Address(WORD_LENGTH);
	CBitPattern Value(WORD_LENGTH);
	CBitPattern Mean(WORD_LENGTH);
	bool Found; // ignored

	// read the prediction for the last character from first fold
	if (SequenceLength > 0)
	{
		StringToBitPattern(Sequence[SequenceLength-1], Address);
		FirstFold.Read(Address, Value, Found);
		Patterns.Add(Value);
	}
	// read the prediction for the before-last character from second fold
	if (SequenceLength > 1)
	{
		StringToBitPattern(Sequence[SequenceLength-2], Address);
		SecondFold.Read(Address, Value, Found);
		Patterns.Add(Value);
	}
	// read the prediction for the before-before-last character from third fold
	if (SequenceLength > 2)
	{
		StringToBitPattern(Sequence[SequenceLength-3], Address);
		ThirdFold.Read(Address, Value, Found);
		Patterns.Add(Value);
	}
	// the prediction for the following word: the mean of these predictions
	CBitPattern::CalculateMean(Patterns, Mean);
	// use the best-match memory to retrieve the archetype pattern that matches this mean
	BestMatch.ReadIteratively(Mean, Prediction, Found);
}

void SDMSequencer(void)
{
	CSDMModel BestMatch(WORD_LENGTH, WORD_COUNT);
	CSDMModel FirstFold(WORD_LENGTH, WORD_COUNT);
	CSDMModel SecondFold(WORD_LENGTH, WORD_COUNT);
	CSDMModel ThirdFold(WORD_LENGTH, WORD_COUNT);

	CBitPattern Address(WORD_LENGTH);
	CBitPattern Prediction(WORD_LENGTH);

	#define A Patterns[0]
	#define B Patterns[1]
	#define C Patterns[2]
	#define D Patterns[3]
	#define E Patterns[4]
	#define F Patterns[5]

	const char **Sequence1[HEIGHT] = { A, B, C, D };
	const char **Sequence2[HEIGHT] = { E, B, C, F };
	const char **Sequence3[HEIGHT] = { A, B, C };
	const char **Sequence4[HEIGHT] = { E, B, C };

	// use a simple best-match memory to learn the patterns
	for (int i=0; i < PATTERN_COUNT; i++)
	{
		StringToBitPattern(Patterns[i], Address);
		BestMatch.Write(Address);
	}

	// write all patterns several times
	for (int i=0; i < NUMBER_OF_EXPOSURES; i++)
	{
		Learn(Sequence1, 4, FirstFold, SecondFold, ThirdFold);
		Learn(Sequence2, 4, FirstFold, SecondFold, ThirdFold);
	}

	// based on the sequence <A, B, C> what do you predict?
	Predict(Sequence3, 3, BestMatch, FirstFold, SecondFold, ThirdFold, Prediction);
	printf("After <A, B, C> follows:\n");
	PrintPattern(Prediction);

	// based on the sequence <E, B, C> what do you predict?
	Predict(Sequence4, 3, BestMatch, FirstFold, SecondFold, ThirdFold, Prediction);
	printf("After <E, B, C> follows:\n");
	PrintPattern(Prediction);
}