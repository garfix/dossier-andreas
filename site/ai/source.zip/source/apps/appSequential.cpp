#include <conio.h>
#include "generic.h"
#include "AI.h"

#define EPOCHCOUNT 1500
#define PATTERNCOUNT 8
#define HALF (PATTERNCOUNT / 2)
// error criterion
#define ECRIT (PATTERNCOUNT * 0.1f * 0.1f)
// factor of previous activation to used in current activation
#define MU 0.5f

/// Jordan (1986)
///
/// Sequential network. After it is trained, and you feed some fixed input
/// to the network, the output will change in successive updates.\n
///
/// Here the input pattern "1 0 1 0" leads to the following output patterns:
/// "1 0 0 0", "0 1 0 0", "0 0 1 0", "0 0 0 1", followed by random values. \n
/// The input pattern "0 1 0 1" leads to the following output patterns:
/// "0 0 0 1", "0 0 1 0", "0 1 0 0", "1 0 0 0", followed by random values. \n
///
/// from "Explorations in Parallel Distributed Processing" (chapter 5)
/// by McClelland & Rumelhart
///
/// Note: it still has problems: sometimes it works, sometimes it does not;
/// seems to depend only on the seed value of the random generator.

void Sequential(void)
{
	CNNModel SequentialModel;
	CNNPoolConnection *P2HConnection;
	CNNPoolConnection *C2HConnection;
	CNNPoolConnection *H2OConnection;
	CNNPoolConnection *O2CConnection;
	CNNPoolConnection *C2CConnection;

	CRow<float> PlanPatterns[2];
	CRow<float> TargetPatterns[PATTERNCOUNT];
	CRow<float> NullPattern;
	float TotalSumOfSquares = 1.0f;
	int EpochIndex;

	// initialize plan patterns
	PlanPatterns[0].Add(1).Add(0).Add(1).Add(0);
	PlanPatterns[1].Add(0).Add(1).Add(0).Add(1);

	// initialize target patterns
	TargetPatterns[0].Add(1).Add(0).Add(0).Add(0);
	TargetPatterns[1].Add(0).Add(1).Add(0).Add(0);
	TargetPatterns[2].Add(0).Add(0).Add(1).Add(0);
	TargetPatterns[3].Add(0).Add(0).Add(0).Add(1);

	TargetPatterns[HALF+0].Add(0).Add(0).Add(0).Add(1);
	TargetPatterns[HALF+1].Add(0).Add(0).Add(1).Add(0);
	TargetPatterns[HALF+2].Add(0).Add(1).Add(0).Add(0);
	TargetPatterns[HALF+3].Add(1).Add(0).Add(0).Add(0);

	// initialize starting current state pattern
	NullPattern.Add(0).Add(0).Add(0).Add(0);

	// create pools
	CNNPool *Plans = SequentialModel.AddPool("Plan", 4);
	CNNPool *Hiddens = SequentialModel.AddPool("Hidden", 4);
	CNNPool *Outputs = SequentialModel.AddPool("Output", 4);
	CNNPool *CurrentStates = SequentialModel.AddPool("CurrentState", 4);

	// set pool types
	Plans->SetPoolType(POOLTYPE_INPUT);
	Hiddens->SetPoolType(POOLTYPE_HIDDEN);
	Outputs->SetPoolType(POOLTYPE_OUTPUT);
	CurrentStates->SetPoolType(POOLTYPE_AUXILIARY);

	// pool parameters
	Hiddens->SetUpdateMethod(UPDATEMETHOD_CONTINUOUS_SIGMOID);
	Outputs->SetUpdateMethod(UPDATEMETHOD_CONTINUOUS_SIGMOID);
	CurrentStates->SetUpdateMethod(UPDATEMETHOD_LINEAR);

	// create connections between the units of one pool to all units of another pool
	P2HConnection = SequentialModel.AddPoolConnection(Plans, Hiddens);
	C2HConnection = SequentialModel.AddPoolConnection(CurrentStates, Hiddens);
	H2OConnection = SequentialModel.AddPoolConnection(Hiddens, Outputs);
	O2CConnection = SequentialModel.AddPoolConnection(Outputs, CurrentStates);
	C2CConnection = SequentialModel.AddPoolConnection(CurrentStates, CurrentStates);
	
	// create recurrent connections to CurrentState pool
	for (int i=0; i<CurrentStates->GetUnitCount(); i++)
	{
		// add self as input
		C2CConnection->SetWeight(i, i, MU);

		// add corresponding output as input
		O2CConnection->SetWeight(i, i, 1.0f);
	}

	// randomize weights and biases (to break symmetry)
	P2HConnection->RandomizeWeights();
	C2HConnection->RandomizeWeights();
	H2OConnection->RandomizeWeights();
	Hiddens->RandomizeBiases();
	Outputs->RandomizeBiases();

	// train the model
	SequentialModel.SetTrainingMethod(TRAININGMETHOD_GENERALIZED_DELTA);
	SequentialModel.SetLearningRate(0.5f);
	for (EpochIndex=0; EpochIndex<EPOCHCOUNT; EpochIndex++)
	{
		// initialize error criterion
		TotalSumOfSquares = 0.0f;

		for (int PatternIndex=0; PatternIndex<PATTERNCOUNT; PatternIndex++)
		{
			// set current state pattern
			if (PatternIndex % HALF == 0) 
			{
				// start each pattern with a series of 0
				CurrentStates->SetOutputPattern(NullPattern);
			}
			else
			{
				// update current state for new training update
				CurrentStates->Update();
			}
			// set plan pattern
			Plans->SetOutputPattern(PlanPatterns[PatternIndex / HALF]);

			// set target pattern
			Outputs->SetTargetPattern(TargetPatterns[PatternIndex]);

			// train pattern
			SequentialModel.TrainPattern();

			// calculate error criterion
			TotalSumOfSquares += Outputs->GetPatternSumOfSquares();
		}

		// total error below error criterion?
		if (TotalSumOfSquares < ECRIT) break;
	}
	printf("Epochs used (needed): %d\n\n", EpochIndex+1);

	// check the results
	SequentialModel.SetUpdateOrder(UPDATEORDER_HIDDEN_OUTPUT_AUXILIARY);
	for (int PatternIndex=0; PatternIndex<2; PatternIndex++)
	{
		// set input pattern
		Plans->SetOutputPattern(PlanPatterns[PatternIndex]);
		CurrentStates->SetOutputPattern(NullPattern);

		for (int RepeatIndex=0; RepeatIndex<8; RepeatIndex++)
		{
			// update hidden, output, and auxiliary pools
			SequentialModel.Update();

			// print results
			printf("pattern: %d, repeat: %d | %d %d %d %d => %d %d %d %d\n",
				PatternIndex, 
				RepeatIndex,
				(int)PlanPatterns[PatternIndex].Get(0),
				(int)PlanPatterns[PatternIndex].Get(1),
				(int)PlanPatterns[PatternIndex].Get(2),
				(int)PlanPatterns[PatternIndex].Get(3),
				(int)(Outputs->GetUnit(0)->GetOutput()+0.5f),
				(int)(Outputs->GetUnit(1)->GetOutput()+0.5f),
				(int)(Outputs->GetUnit(2)->GetOutput()+0.5f),
				(int)(Outputs->GetUnit(3)->GetOutput()+0.5f)
			);
		}
	}
}