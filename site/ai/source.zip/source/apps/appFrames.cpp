#include "AI.h"

/// A semantic network, build from objects and relations.
/// The objects are frames that have 'typical' values.
///
/// The example with Opus, Bill and Pat is taken from chapter 10 (page 318) of 
/// Artificial Intelligence: A Modern Approach; by Stuart Russell and Peter Norvig.

void Frames(void)
{
	CFSModel Model;
	CFSRelation *Relation;
	CRow<CFSRelation *> Relations;
	CRow<CFSBinding> Bindings;
	bool Exists;
	int Value;
	CFSRule *Rule;

    /* classes */
	CFSObjectType *Animal = new CFSObjectType("Animal");
    CFSObjectType *Bird = new CFSObjectType("Bird");
    CFSObjectType *Mammal = new CFSObjectType("Mammal");
    CFSObjectType *Penguin = new CFSObjectType("Penguin");
    CFSObjectType *Cat = new CFSObjectType("Cat");
    CFSObjectType *Bat = new CFSObjectType("Bat");

	/* objects */
    CFSObject *Opus = new CFSObject("Opus");
    CFSObject *Bill = new CFSObject("Bill");
    CFSObject *Pat = new CFSObject("Pat");
	CFSObject *Magnum = new CFSObject("Magnum");
	CFSObject *Two = new CFSObjectNumber(2);
	CFSObject *Four = new CFSObjectNumber(4);
	CFSObjectVariable *X = new CFSObjectVariable("X");
	CFSObjectVariable *Y = new CFSObjectVariable("Y");
	CFSObjectVariable *Z = new CFSObjectVariable("Z");

	/* type relations */
	Bird->AddType(Animal);
	Mammal->AddType(Animal);
	Penguin->AddType(Bird);
	Cat->AddType(Mammal);
	Bat->AddType(Bird);

	Opus->AddType(Penguin);
	Magnum->AddType(Penguin);
	Bill->AddType(Cat);
	Pat->AddType(Bat);

	Model.Add(Animal);
	Model.Add(Bird);
	Model.Add(Mammal);
	Model.Add(Penguin);
	Model.Add(Cat);
	Model.Add(Bat);

	Model.Add(Opus);
	Model.Add(Magnum);
	Model.Add(Bill);
	Model.Add(Pat);

	// relation types
	CFSRelationType *CanFly = new CFSRelationType("can fly");
	CanFly->AddRole("subject");
	Model.Add(CanFly);

	CFSRelationType *LegCount = new CFSRelationType("number of legs");
	LegCount->AddRole("subject");
	LegCount->AddRole("count");
	Model.Add(LegCount);

	CFSRelationType *Friend = new CFSRelationType("friend");
	Friend->AddRole("subject1");
	Friend->AddRole("subject2");
	Model.Add(Friend);

	CFSRelationType *Knows = new CFSRelationType("knows");
	Knows->AddRole("subject1");
	Knows->AddRole("subject2");
	Model.Add(Knows);

	CFSRelationType *Father = new CFSRelationType("father");
	Father->AddRole("subject1");
	Father->AddRole("subject2");
	Model.Add(Father);

	CFSRelationType *Child = new CFSRelationType("child");
	Child->AddRole("subject1");
	Child->AddRole("subject2");
	Model.Add(Child);

	CFSRelationType *Parent = new CFSRelationType("parent");
	Parent->AddRole("subject1");
	Parent->AddRole("subject2");
	Model.Add(Parent);


	/* relation type subclassing */

	// a friend is always someone you know
	Friend->AddType(Knows);


	/* relation instances */

	// a typical animal does not fly
	Relation = new CFSRelation(CanFly);
	Relation->SetRoleValue("subject", Animal);
	Relation->SetTruth(false);
	Model.Add(Relation);

	// a typical bird flies
	Relation = new CFSRelation(CanFly);
	Relation->SetRoleValue("subject", Bird);
	Relation->SetTruth(true);
	Model.Add(Relation);

	// a penguin does not fly
	Relation = new CFSRelation(CanFly);
	Relation->SetRoleValue("subject", Penguin);
	Relation->SetTruth(false);
	Model.Add(Relation);

	// a bat flies
	Relation = new CFSRelation(CanFly);
	Relation->SetRoleValue("subject", Bat);
	Relation->SetTruth(true);
	Model.Add(Relation);

	// a typical bird has 2 legs
	Relation = new CFSRelation(LegCount);
	Relation->SetRoleValue("subject", Bird);
	Relation->SetRoleValue("count", Two);
	Model.Add(Relation);

	// a typical mammal has 4 legs
	Relation = new CFSRelation(LegCount);
	Relation->SetRoleValue("subject", Mammal);
	Relation->SetRoleValue("count", Four);
	Model.Add(Relation);

	// a bat has 2 legs
	Relation = new CFSRelation(LegCount);
	Relation->SetRoleValue("subject", Bat);
	Relation->SetRoleValue("count", Two);
	Model.Add(Relation);

	// Opus is Bill's friend
	Relation = new CFSRelation(Friend);
	Relation->SetRoleValue("subject1", Opus);
	Relation->SetRoleValue("subject2", Bill);
	Model.Add(Relation);

	// Bill is Opus' friend
	Relation = new CFSRelation(Friend);
	Relation->SetRoleValue("subject1", Bill);
	Relation->SetRoleValue("subject2", Opus);
	Model.Add(Relation);

	// Bill is Magnum's friend
	Relation = new CFSRelation(Friend);
	Relation->SetRoleValue("subject1", Bill);
	Relation->SetRoleValue("subject2", Magnum);
	Model.Add(Relation);

	// Opus is Pat's friend
	Relation = new CFSRelation(Friend);
	Relation->SetRoleValue("subject1", Opus);
	Relation->SetRoleValue("subject2", Pat);
	Model.Add(Relation);

	// Opus is Bill's father
	Relation = new CFSRelation(Father);
	Relation->SetRoleValue("subject1", Opus);
	Relation->SetRoleValue("subject2", Bill);
	Model.Add(Relation);

	// Opus is Pat's father
	Relation = new CFSRelation(Father);
	Relation->SetRoleValue("subject1", Opus);
	Relation->SetRoleValue("subject2", Pat);
	Model.Add(Relation);


	/* rules */

	// a father is a parent
	// parent(x, y) :- father(x, y).
	Relation = new CFSRelation(Parent);
	Relation->SetRoleValue("subject1", X);
	Relation->SetRoleValue("subject2", Y);
	Rule = new CFSRule(Relation);
	Model.Add(Rule);
	Relation = new CFSRelation(Father);
	Relation->SetRoleValue("subject1", X);
	Relation->SetRoleValue("subject2", Y);
	Rule->AddCondition(Relation);	

	// if a is b's parent; b is a's child
	// child(x, y) :- parent(y, x).
	Relation = new CFSRelation(Child);
	Relation->SetRoleValue("subject1", X);
	Relation->SetRoleValue("subject2", Y);
	Rule = new CFSRule(Relation);
	Model.Add(Rule);
	Relation = new CFSRelation(Parent);
	Relation->SetRoleValue("subject1", Y);
	Relation->SetRoleValue("subject2", X);
	Rule->AddCondition(Relation);


	/* queries */

	// we said that
	// 1) Opus is a penguin (type)
	// 2) A penguin is a bird (type)
	// 3) Birds typically have 2 legs (relation)
	// How many legs has Opus?
	CFSRelation Query1(LegCount);
	Query1.SetRoleValue("subject", Opus);
	Query1.SetRoleValue("count", X);
	Bindings = Model.Ask(&Query1);
	assert(Bindings.GetLength() > 0);
	// the number of legs is taken from the first relation found (a LegCount)
	// it's taken from its 'count' role
	Value = (int)(((CFSObjectNumber *)Bindings.Get(0).GetValue(X))->GetFloat());
	printf("Opus has %d legs.\n", Value);

	// we said that
	// 1) Opus is a penguin (type)
	// 2) A penguin can't fly (relation)
	// 3) A penguin is a bird (type)
	// 4) Birds fly (relation)
	// can Opus fly?
	CFSRelation Query2(CanFly);
	Query2.SetRoleValue("subject", Opus);
	Query2.SetTruth(false);
	Exists = Model.AskExists(&Query2);
	if (Exists)	printf("Opus can't fly.\n"); else printf("Opus can fly.\n");

	// we said that 
	// 1) to be a friend of someone is to know him (relation type)
	// 2) Bill is Opus' friend (relation)
	// does Opus know Bill?
	CFSRelation Query3(Knows);
	Query3.SetRoleValue("subject1", Opus);
	Query3.SetRoleValue("subject2", Bill);
	Exists = Model.AskExists(&Query3);
	if (Exists) printf("Opus knows Bill.\n"); 
	else printf("Opus doesn't know Bill.\n");
	
	// we said
	// 1) a friend of a friend is always a friend (rule)
	// 2) Bill is Opus' friend (relation)
	// 3) Opus is Pat's friend (relation)
	// is Bill Pat's friend?
	CFSRelation Query4(Friend);
	Query4.SetRoleValue("subject1", Bill);
	Query4.SetRoleValue("subject2", Pat);
	Exists = Model.AskExists(&Query4);
	if (Exists) printf("Bill is Pat's friend\n"); 
	else printf("Bill is not Pat's friend\n");

	// given
	// 1) Opus is Bill's father
	// 2) Opus is Pat's father
	// 3) A father is a parent
	// 4) If a is parent of b, b is child of a
	// How many animals can say they are Opus' child? - or -
	// how many children has Opus?
	CFSRelation Query5(Child);
	Query5.SetRoleValue("subject1", X);
	Query5.SetRoleValue("subject2", Opus);
	Bindings = Model.Ask(&Query5);
	printf("Opus has %d children: ", Bindings.GetLength());
	for (int Index=0; Index < Bindings.GetLength(); Index++)
	{
		printf("%s ", Bindings.Get(Index).GetValue(X)->ToString().GetBuffer());
	}
	printf("\n");
}
	