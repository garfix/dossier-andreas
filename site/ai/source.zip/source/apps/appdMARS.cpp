#include "generic.h"
#include "AI.h"

/// A dMARS test app.
/// Initially:
/// - The robot is in lane b.
/// - There is waste in lane b.
/// - The waste bin is in lane d.
/// The robot's job is to pick up the waste, move to lane d, and drop it in the waste bin.

void dMARS(void)
{
	CdMARSModel Model;
	CdMARSParser &Parser = Model.GetParser();
	CPLAtom Belief;
	CdMARSPlan *Plan;

	CLogger::GetLogger().SetLogFile("dMARS.log");

	// if you see waste in your current lane, move to the lane with the bin, and drop it there.
	Plan = Parser.ParsePlan(
		"trigger: +location(waste, X);" \
		"context: location(robot, X), location(bin, Y);" \
		"body: pick(waste) -> (!location(robot, Y) -> ( drop(waste) ) )."
	);
	Plan->SetName("TopLevel Plan.");
	assert(Parser.IsSuccessful());
	Model.AddPlan(Plan);

	// if you should go to lane Y, and you are in lane X, and X and Y are adjacent,
	// then move to lane Y
	Plan = Parser.ParsePlan(
		"trigger: !location(robot, Y);" \
		"context: location(robot, X), adjacent(X, Y);" \
		"body: move(X, Y);" \
		"success: +location(robot, Y), -location(robot, X)."
		);
	Plan->SetName("Move 1 lane.");
	Model.AddPlan(Plan);
	assert(Parser.IsSuccessful());

	// if you should go to lane Z, and you are in lane X (which is not Z),
	// and lane X is adjacent to lane Y, then move to lane Y (except when there is a car at Y)
	Plan = Parser.ParsePlan(
		"trigger: !location(robot, Z);" \
		"context: location(robot, X), adjacent(X, Y), adjacent(Y, Z), NOT =(X, Z), NOT location(car, Y);" \
		"body: !location(robot, Y) -> (!location(robot, Z))."
		);
	Plan->SetName("Move to intermediate lane.");
	Model.AddPlan(Plan);
	assert(Parser.IsSuccessful());

	Parser.ParseAtom("adjacent(a, b).", Belief);
	assert(Parser.IsSuccessful());
	Model.AddBelief(Belief);

	Parser.ParseAtom("adjacent(b, c).", Belief);
	assert(Parser.IsSuccessful());
	Model.AddBelief(Belief);

	Parser.ParseAtom("adjacent(c, d).", Belief);
	assert(Parser.IsSuccessful());
	Model.AddBelief(Belief);

	Parser.ParseAtom("location(robot, b).", Belief);
	assert(Parser.IsSuccessful());
	Model.AddBelief(Belief);

	Parser.ParseAtom("location(waste, b).", Belief);
	assert(Parser.IsSuccessful());
	Model.AddBelief(Belief);

	Parser.ParseAtom("location(bin, d).", Belief);
	assert(Parser.IsSuccessful());
	Model.AddBelief(Belief);

	for (int i=0; i<50; i++)
	{
		Model.Update();
	}
}
