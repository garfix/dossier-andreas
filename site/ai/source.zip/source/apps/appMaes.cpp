#include "AI.h"

void Maes(void)
{
	CMBNModel Model;
	CMBNCompetenceModule *Module;

	// propositions
	CMBNProposition *PropSprayerSomewhere = Model.AddProposition("SPRAYER_SOMEWHERE", true);
	CMBNProposition *PropSprayerInHand = Model.AddProposition("SPRAYER-IN-HAND", false);
	CMBNProposition *PropSanderSomewhere = Model.AddProposition("SANDER-SOMEWHERE", true);
	CMBNProposition *PropSanderInHand = Model.AddProposition("SANDER-IN-HAND", false);
	CMBNProposition *PropBoardSomewhere = Model.AddProposition("BOARD-SOMEWHERE", true);
	CMBNProposition *PropBoardInHand = Model.AddProposition("BOARD-IN-HAND", false);
	CMBNProposition *PropBoardSanded = Model.AddProposition("BOARD-SANDED", false);
	CMBNProposition *PropBoardInVise = Model.AddProposition("BOARD-IN-VISE", false);
	CMBNProposition *PropOperational = Model.AddProposition("OPERATIONAL", true);
	CMBNProposition *PropSelfPainted = Model.AddProposition("SELF-PAINTED", false);

	// special propositions: both are identical, and hence stored in the same object
	// The 'count' property of the proposition object will be set to 2.
	CMBNProposition *PropHandIsEmpty = Model.AddProposition("HAND-IS-EMPTY", true);
	                 PropHandIsEmpty = Model.AddProposition("HAND-IS-EMPTY", true);

	// goals
	Model.SetOnceOnlyGoal(PropBoardSanded);
	Model.SetOnceOnlyGoal(PropSelfPainted);

	// competence modules
	Module = Model.AddCompetenceModule("PICK-UP-SPRAYER");
	Module->AddPrecondition(PropSprayerSomewhere);
	Module->AddPrecondition(PropHandIsEmpty);
	Module->AddToAddList(PropSprayerInHand);
	Module->AddToDeleteList(PropSprayerSomewhere);
	Module->AddToDeleteList(PropHandIsEmpty);

	Module = Model.AddCompetenceModule("PICK-UP-SANDER");
	Module->AddPrecondition(PropSanderSomewhere);
	Module->AddPrecondition(PropHandIsEmpty);
	Module->AddToAddList(PropSanderInHand);
	Module->AddToDeleteList(PropSanderSomewhere);
	Module->AddToDeleteList(PropHandIsEmpty);

	Module = Model.AddCompetenceModule("PICK-UP-BOARD");
	Module->AddPrecondition(PropBoardSomewhere);
	Module->AddPrecondition(PropHandIsEmpty);
	Module->AddToAddList(PropBoardInHand);
	Module->AddToDeleteList(PropBoardSomewhere);
	Module->AddToDeleteList(PropHandIsEmpty);

	Module = Model.AddCompetenceModule("PUT-DOWN-SPRAYER");
	Module->AddPrecondition(PropSprayerInHand);
	Module->AddToAddList(PropSprayerSomewhere);
	Module->AddToAddList(PropHandIsEmpty);
	Module->AddToDeleteList(PropSprayerInHand);

	Module = Model.AddCompetenceModule("PUT-DOWN-SANDER");
	Module->AddPrecondition(PropSanderInHand);
	Module->AddToAddList(PropSanderSomewhere);
	Module->AddToAddList(PropHandIsEmpty);
	Module->AddToDeleteList(PropSanderInHand);

	Module = Model.AddCompetenceModule("PUT-DOWN-BOARD");
	Module->AddPrecondition(PropBoardInHand);
	Module->AddToAddList(PropBoardSomewhere);
	Module->AddToAddList(PropHandIsEmpty);
	Module->AddToDeleteList(PropBoardInHand);

	Module = Model.AddCompetenceModule("SAND-BOARD-IN-HAND");
	Module->AddPrecondition(PropOperational);
	Module->AddPrecondition(PropBoardInHand);
	Module->AddPrecondition(PropSanderInHand);
	Module->AddToAddList(PropBoardSanded);

	Module = Model.AddCompetenceModule("SAND-BOARD-IN-VISE");
	Module->AddPrecondition(PropOperational);
	Module->AddPrecondition(PropBoardInVise);
	Module->AddPrecondition(PropSanderInHand);
	Module->AddToAddList(PropBoardSanded);

	Module = Model.AddCompetenceModule("SPRAY-PAINT-SELF");
	Module->AddPrecondition(PropOperational);
	Module->AddPrecondition(PropSprayerInHand);
	Module->AddToAddList(PropSelfPainted);
	Module->AddToDeleteList(PropOperational);

	Module = Model.AddCompetenceModule("PLACE-BOARD-IN-VISE");
	Module->AddPrecondition(PropBoardInHand);
	Module->AddToAddList(PropHandIsEmpty);
	Module->AddToAddList(PropBoardInVise);
	Module->AddToDeleteList(PropBoardInHand);

	// global parameters
	Model.SetThreshold(45.0f);
	Model.SetPropositionEnergy(20.0f);
	Model.SetGoalEnergy(70.0f);
	Model.SetProtectedGoalEnergy(50.0f);
	Model.SetMeanLevelOfActivation(20.0f);

	// use hacks if getting the article's activation values is more important to you
	// than the correct implementation of the network.
	Model.SetUseHacks(true);

	CLogger::GetLogger().SetLogFile("Maes.log");
	CLogger::GetLogger().SetLogLevel(LOGLEVEL_DEBUG);

	Model.Start();
	while (!Model.OnceOnlyGoalsAreMet())
	{
		Model.Update();
	}
}
