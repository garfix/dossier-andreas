#include <assert.h>
#include "generic.h"

using namespace generic;

/// This is collection of conversion utilities.

void ConvertWordsWithAppendix(const CText &SourceFile, const CText &TargetFile, bool Append)
{
	CLoader SourceLoader, WordLoader;
	CSaver TargetSaver;
	CText Token, Word, Appendix;

	// loader settings
	SourceLoader.SetWhitespaceChars(" \t\n");
	WordLoader.SetWhitespaceChars(".");

	// read entire file
	assert(SourceLoader.ReadFile(SourceFile));

	// loop through all file's tokens
	while (SourceLoader.HasNext())
	{
		// fetch next token
		Token = SourceLoader.NextToken();

		// put token into word loader
		WordLoader.ReadString(Token);
		
		// fetch word (is always there)
		Word = WordLoader.NextToken();

		// save to target (temporary storage)
		TargetSaver.Append(Word + "\n");
	}

	// save target to file
	TargetSaver.SaveToFile(TargetFile, Append);
}

void Convert(void)
{
	/*
	// adjectives
	ConvertWordsWithAppendix("data/words/words.adj.1", "resources/lexicon_english_adjectives.txt", false);
	ConvertWordsWithAppendix("data/words/words.adj.2", "resources/lexicon_english_adjectives.txt", true);
	ConvertWordsWithAppendix("data/words/words.adj.3", "resources/lexicon_english_adjectives.txt", true);
	*/

	/*
	// adverbs
	//ConvertWordsWithAppendix("data/words/words.adv.1", "resources/lexicon_english_adverbs.txt", false);
	//ConvertWordsWithAppendix("data/words/words.adv.2", "resources/lexicon_english_adverbs.txt", true);
	//ConvertWordsWithAppendix("data/words/words.adv.3", "resources/lexicon_english_adverbs.txt", true);
	*/

	/*
	// nouns
	ConvertWordsWithAppendix("data/words/words.n.1", "resources/lexicon_english_nouns.txt", false);
	ConvertWordsWithAppendix("data/words/words.n.2.s", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.2.x", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.3", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.4", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.c.1", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.c.2", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.p", "resources/lexicon_english_nouns.txt", true);
	ConvertWordsWithAppendix("data/words/words.n.t", "resources/lexicon_english_nouns.txt", true);
	*/

	/*
	// verbs
	ConvertWordsWithAppendix("data/words/words.v.1.1", "resources/lexicon_english_verbs.txt", false);
	ConvertWordsWithAppendix("data/words/words.v.1.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.1.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.1.4", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.2.1", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.2.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.2.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.2.4", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.2.5", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.4.1", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.4.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.4.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.4.4", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.4.5", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.5.1", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.5.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.5.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.5.4", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.6.1", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.6.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.6.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.6.4", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.6.5", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.8.1", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.8.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.8.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.8.4", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.8.5", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.10.1", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.10.2", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.10.3", "resources/lexicon_english_verbs.txt", true);
	ConvertWordsWithAppendix("data/words/words.v.10.4", "resources/lexicon_english_verbs.txt", true);
	*/
}
