#include "AI.h"

/// This program doesn't really do anything. I thought it was a good idea to implement
/// Paul Jay Lucas' microwave example. But just the definition of the device is a lot of
/// work. at least it shows how to use the Finite State Machine.

class CMicrowave: public CFSMModel
{
protected:
	bool LightSwitchedOn;

	CFSMState *Activate;
	CFSMState *Mode;
	CFSMState *ModeDisabled;
	CFSMState *ModeOperational;
	CFSMState *ModeOperationalSetTime;
	CFSMState *ModeOperationalSetTimeSetting;
	CFSMState *ModeOperationalSetTimeError;
	CFSMState *ModeOperationalIdle;
	CFSMState *ModeOperationalProgram;
	CFSMState *ModeOperationalProgramSetting;
	CFSMState *ModeOperationalProgramPower;
	CFSMState *ModeOperationalCook;
	CFSMState *ModeOperationalCookRealCook;
	CFSMState *Display;
	CFSMState *DisplayTime;
	CFSMState *DisplayNotTime;
	CFSMState *DisplayNotTimeCounter;
	CFSMState *DisplayNotTimeError;
	CFSMState *DisplayNotTimePower;
	CFSMState *Light;
	CFSMState *LightOff;
	CFSMState *LightOn;

	CFSMTransition *ModeDisabled_ModeOperational;
	CFSMTransition *ModeOperational_ModeDisabled;
	CFSMTransition *ModeOperationalSetTime_ModeOperationalIdle;
	CFSMTransition *ModeOperationalIdle_ModeOperationalSetTime;
	CFSMTransition *ModeOperationalIdle_ModeOperationalProgram;
	CFSMTransition *ModeOperationalProgram_ModeOperationalIdle;
	CFSMTransition *ModeOperationalProgram_ModeOperationalCook;
	CFSMTransition *ModeOperationalCook_ModeOperationalProgram;
	CFSMTransition *ModeOperationalIdle_ModeOperationalCook;
	CFSMTransition *ModeOperationalCook_ModeOperationalIdle;
	CFSMTransition *ModeOperationalSetTime_ModeOperationalIdle2;
	CFSMTransition *DisplayTime_DisplayNotTimeCounter;
	CFSMTransition *DisplayNotTime_DisplayTime;
	CFSMTransition *DisplayTime_DisplayNotTimeError;
	CFSMTransition *DisplayNotTimeCounter_DisplayNotTimePower;
	CFSMTransition *DisplayNotTimePower_DisplayNotTimeCounter;
	CFSMTransition *LightOff_LightOn;
	CFSMTransition *LightOn_LightOff;
	CFSMTransition *ModeOperationalProgramSetting_ModeOperationalProgramPower;
	CFSMTransition *ModeOperationalProgramPower_ModeOperationalProgramSetting;
	CFSMTransition *ModeOperationalProgramSetting_ModeOperationalProgramSetting;
	CFSMTransition *ModeOperationalSetTimeSetting_ModeOperationalSetTimeError;
	CFSMTransition *ModeOperationalSetTimeSetting_ModeOperationalSetTimeSetting;
	CFSMTransition *ModeOperationalCookRealCook_ModeOperationalCookRealCook;

	CFSMTransition *Activate_ModeDisplayLight;

public:
	CMicrowave()
	{
		// create states
		Activate = AddState("Activate");
		Mode = AddState("Mode");
		ModeDisabled = AddState("ModeDisabled", Mode);
		ModeOperational = AddState("ModeOperational", Mode);
		ModeOperationalSetTime = AddState("ModeOperationalSetTime", ModeOperational);
		ModeOperationalSetTimeSetting = AddState("ModeOperationalSetTimeSetting", ModeOperationalSetTime);
		ModeOperationalSetTimeError = AddState("ModeOperationalSetTimeError", ModeOperationalSetTime);
		ModeOperationalIdle = AddState("ModeOperationalIdle", ModeOperational);
		ModeOperationalProgram = AddState("ModeOperationalProgram", ModeOperational);
		ModeOperationalProgramSetting = AddState("ModeOperationalProgramSetting", ModeOperationalProgram);
		ModeOperationalProgramPower = AddState("ModeOperationalProgramPower", ModeOperationalProgram);
		ModeOperationalCook = AddState("ModeOperationalCook", ModeOperational);
		ModeOperationalCookRealCook = AddState("ModeOperationalCookRealCook", ModeOperationalCook);
		Display = AddState("Display");
		DisplayTime = AddState("DisplayTime", Display);
		DisplayNotTime = AddState("DisplayNotTime", Display);
		DisplayNotTimeCounter = AddState("DisplayNotTimeCounter", DisplayNotTime);
		DisplayNotTimeError = AddState("DisplayNotTimeError", DisplayNotTime);
		DisplayNotTimePower = AddState("DisplayNotTimePower", DisplayNotTime);
		Light = AddState("Light");
		LightOff = AddState("LightOff", Light);
		LightOn = AddState("LightOn", Light);

		// create transitions
		ModeDisabled_ModeOperational = AddTransition(ModeDisabled, ModeOperational, "close");
		ModeOperational_ModeDisabled = AddTransition(ModeOperational, ModeDisabled, "open");
		ModeOperationalSetTime_ModeOperationalIdle = AddTransition(ModeOperationalSetTime, ModeOperationalIdle, "stop");
		ModeOperationalIdle_ModeOperationalSetTime = AddTransition(ModeOperationalIdle, ModeOperationalSetTime, "clock");
		ModeOperationalIdle_ModeOperationalProgram = AddTransition(ModeOperationalIdle, ModeOperationalProgram, "digit");
		ModeOperationalProgram_ModeOperationalIdle = AddTransition(ModeOperationalProgram, ModeOperationalIdle, "stop");
		ModeOperationalProgram_ModeOperationalCook = AddTransition(ModeOperationalProgram, ModeOperationalCook, "start");
		ModeOperationalCook_ModeOperationalProgram = AddTransition(ModeOperationalCook, ModeOperationalProgram, "stop");
		ModeOperationalIdle_ModeOperationalCook = AddTransition(ModeOperationalIdle, ModeOperationalCook, "minute");
		ModeOperationalCook_ModeOperationalIdle = AddTransition(ModeOperationalCook, ModeOperationalIdle, "done");
		ModeOperationalSetTime_ModeOperationalIdle2 = AddTransition(ModeOperationalSetTime, ModeOperationalIdle, "clock");
		DisplayTime_DisplayNotTimeCounter = AddTransition(DisplayTime, DisplayNotTimeCounter, "en(program)");
		DisplayNotTime_DisplayTime = AddTransition(DisplayNotTime, DisplayTime, "en(idle)");
		DisplayTime_DisplayNotTimeError = AddTransition(DisplayTime, DisplayNotTimeError, "en(Set-Time.Error)");
		DisplayNotTimeCounter_DisplayNotTimePower = AddTransition(DisplayNotTimeCounter, DisplayNotTimePower, "power");
		DisplayNotTimePower_DisplayNotTimeCounter = AddTransition(DisplayNotTimePower, DisplayNotTimeCounter, "digit");
		LightOff_LightOn = AddTransition(LightOff, LightOn, "en(Cook)");
		LightOn_LightOff = AddTransition(LightOn, LightOff, "ex(Cook)");
		ModeOperationalProgramSetting_ModeOperationalProgramPower = AddTransition(ModeOperationalProgramSetting, ModeOperationalProgramPower, "power");
		ModeOperationalProgramPower_ModeOperationalProgramSetting = AddTransition(ModeOperationalProgramPower, ModeOperationalProgramSetting, "digit");
		ModeOperationalProgramSetting_ModeOperationalProgramSetting = AddTransition(ModeOperationalProgramSetting, ModeOperationalProgramSetting, "digit");
		ModeOperationalSetTimeSetting_ModeOperationalSetTimeError = AddTransition(ModeOperationalSetTimeSetting, ModeOperationalSetTimeError, "clock");
		ModeOperationalSetTimeSetting_ModeOperationalSetTimeSetting = AddTransition(ModeOperationalSetTimeSetting, ModeOperationalSetTimeSetting, "digit");
		ModeOperationalCookRealCook_ModeOperationalCookRealCook = AddTransition(ModeOperationalCookRealCook, ModeOperationalCookRealCook, "minute");

		// create complex transitions
		Activate_ModeDisplayLight = AddTransition();
		Activate_ModeDisplayLight->AddSourceState(Activate);
		Activate_ModeDisplayLight->AddTargetState(Mode);
		Activate_ModeDisplayLight->AddTargetState(Display);
		Activate_ModeDisplayLight->AddTargetState(LightOn);

		// initialization
		LightSwitchedOn = false;
		// top level
		GetRootState()->SetInitialSubState(Activate);
		// lower levels
		Mode->SetInitialSubState(ModeOperational);
		ModeOperational->SetInitialSubState(ModeOperationalIdle);
		Display->SetInitialSubState(DisplayTime);
		Light->SetInitialSubState(LightOff);
		ModeOperationalProgram->SetInitialSubState(ModeOperationalProgramSetting);
		ModeOperationalSetTime->SetInitialSubState(ModeOperationalSetTimeSetting);
		ModeOperationalCook->SetInitialSubState(ModeOperationalCookRealCook);

		// history states
		ModeOperational->SetHistory(FSMHISTORY_SHALLOW);
		ModeOperationalProgram->SetHistory(FSMHISTORY_SHALLOW);
	}
	virtual void UpdateState(CFSMState *State)
	{
		printf("State \"%s\" Updates.\n", State->GetName().GetBuffer());
	}
	virtual void EnterState(CFSMState *State)
	{
		printf("State \"%s\" Entered.\n", State->GetName().GetBuffer());
	}
	virtual void ExitState(CFSMState *State)
	{
		printf("State \"%s\" Exited.\n", State->GetName().GetBuffer());
	}
    virtual bool ShouldFire(CFSMTransition *Transition)
	{
		return true;
	}
	virtual void Fire(CFSMTransition *Transition)
	{
		if (Transition == LightOff_LightOn) LightSwitchedOn = true;
		else if (Transition == LightOn_LightOff) LightSwitchedOn = false;

		printf("Transition \"%s\" Fires.\n", Transition->GetName().GetBuffer());
	}
};

void FSM(void)
{
	CMicrowave Microwave;

	printf("--- start ---\n");
	Microwave.Start();

	printf("--- update ---\n");
	Microwave.Update();

	printf("%s", Microwave.ToString().GetBuffer());

	printf("--- update ---\n");
	Microwave.Update();

	printf("--- stop ---\n");
	Microwave.Stop();

	printf("%s", Microwave.ToString().GetBuffer());
}
