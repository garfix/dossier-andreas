#include "Network.h"

bool Error(CSocket &Socket)
{
    if (!Socket.IsWorking()){
		printf("Error: %s\n", Socket.GetError().GetBuffer());
		return true;
	}
	return false;
}

void FetchHTMLPage(void)
{
	CText Page;
	//CSocket Socket("www.dossier-andreas.net", 80);
	CSocket Socket("frontpage.fok.nl", 80);

	// fetch html page
	if (Error(Socket)) return;

	//Socket.Send("GET /index.html HTTP/1.0\n\n");
	Socket.Send("GET / HTTP/1.0\n\n");
	if (Error(Socket)) return;
	
	Page = Socket.Receive();
	if (Error(Socket)) return;

	printf("%s", Page.GetBuffer());
}

void SendEMail(void)
{
	CEMail EMail;
	CSMTP SMTP("smtp.zonnet.nl");

	if (Error(SMTP)) return;

	// create email
	EMail.SetSender("obelix@uderzo.fr");
	EMail.AddRecipient("garfix@zonnet.nl");
	EMail.SetSubject("zonder controle 2");
	EMail.SetMessage("Message line.");

	// send email
	//SMTP.SendMail(EMail);
	//if (Error(SMTP)) return;

	// send email
	//EMail.SetMessage("<h1>SMTP Is Cool!</h1>");
	EMail.SetMessage(".alleen n.\nalleen r:\r.beide: \r\n.punt aan het begin");
	//EMail.AddBlindCarbonCopyRecipient("garfix@zonnet.nl");
	//EMail.SetContentType(EMAILCONTENTTYPE_TEXT_HTML);
	SMTP.SendMail(EMail);
	if (Error(SMTP)) return;
}

void Sockets(void)
{
	FetchHTMLPage();
	//SendEMail();
}
