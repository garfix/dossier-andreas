#include <time.h>
#include "generic.h"
#include "AI.h"

/// The so called n-queens problem is how to position n queens on an n by n chess
/// board so that they cannot attack an another.

// The N in N-queens
#define N 25

class CQueenGenome: public CGeneticGenome
{
protected:
	int n;
	int *y;

public:
	CQueenGenome(int new_n)
	{ 
		n = new_n; 
		y = new int[n];
	}

	~CQueenGenome(){ delete[] y; }

	/// create a new genome, no randomization is required
	virtual CGeneticGenome *NewGenome(){ return new CQueenGenome(n); }

	/// create default (random) values for the genes
	virtual void Initialize()
	{
		for (int i=0; i<n; i++) MutateGene(i);
	}

	/// set the length (i.e. the number of genes)
	virtual void SetLength(int NewLength){}

	/// return the length
	virtual int GetLength(void){ return n; }

	/// copy gene at position Pos to Child at pos ChildPos
	virtual void CopyGene(int Pos, CGeneticGenome *Child, int ChildPos)
	{
		((CQueenGenome *)Child)->y[ChildPos] = y[Pos];
	}

	/// is this genome equal to Genome
	virtual bool Equals(CGeneticGenome *Genome)
	{
		for (int i=0; i<n; i++) if (y[i] != ((CQueenGenome *)Genome)->y[i]) return false;
		return true;
	}

	/// store a random value in the gene
	virtual void MutateGene(int GeneIndex)
	{
		int old_y, new_y;
		
		old_y = y[GeneIndex];

		do
		{
			new_y = CMath::GetRandomInt(0, n-1);
		} 
		while (new_y == old_y);

		y[GeneIndex] = new_y;
	}

	/// calculate and return the fitness of this genome
	virtual void CalculateFitness(void)
	{
		int piece, piece_x, piece_y, pos_x, pos_y;
		Fitness = 0.0f;

		for(piece=0; piece<n; piece++)
		{
			piece_x = piece;
			piece_y = y[piece];

			// horizontal right
			for(pos_x = piece_x+1, pos_y = piece_y; pos_x < n; pos_x++)
			{ 
				if (y[pos_x] == pos_y){ Fitness--; } 
			}
			// horizontal left
			for(pos_x = piece_x-1, pos_y = piece_y; pos_x >= 0; pos_x--)
			{ 
				if (y[pos_x] == pos_y){ Fitness--; } 
			}
			// right up
			for(pos_x = piece_x+1, pos_y = piece_y+1; (pos_y < n) && (pos_x < n); pos_y++, pos_x++)
			{ 
				if (y[pos_x] == pos_y){ Fitness--; } 
			}
			// right down
			for(pos_x = piece_x+1, pos_y = piece_y-1; (pos_y >= 0) && (pos_x < n); pos_y--, pos_x++)
			{ 
				if (y[pos_x] == pos_y){ Fitness--; } 
			}
			// left up
			for(pos_x = piece_x-1, pos_y = piece_y+1; (pos_y < n) && (pos_x >= 0); pos_y++, pos_x--)
			{ 
				if (y[pos_x] == pos_y){ Fitness--; } 
			}
			// left down
			for(pos_x = piece_x-1, pos_y = piece_y-1; (pos_y >= 0) && (pos_x >= 0); pos_y--, pos_x--)
			{ 
				if (y[pos_x] == pos_y){ Fitness--; } 
			}
		}

		Fitness = 1.0f + (Fitness / (2 * n));

		if (Fitness < 0.0) Fitness = 0.0f;
	}

	/// is the genome fit enough to stop evolving?
	virtual bool IsFitEnough(void)
	{
		return (Fitness == 1.0f);
	}

	virtual const CText ToString(void) const
	{
		CText String;

		for (int i=0; i<n; i++)
		{
			String += y[i];
			String += ' ';
		}
		return String;
	}
};

void NQueens(void)
{
	double Duration;
	float Fitness;
	CStopwatch Stopwatch;
	CQueenGenome QueenGenome(N);
	CGeneticModel GeneticModel(&QueenGenome);

	// the parameters for the algorithm
	GeneticModel.ClearParentSelectionTypes();
	GeneticModel.AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
	GeneticModel.AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
	GeneticModel.AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
	GeneticModel.AddParentSelectionType(PARENTSELECTIONTYPE_RANK);
	GeneticModel.AddParentSelectionType(PARENTSELECTIONTYPE_TOURNAMENT);
	GeneticModel.ClearCrossoverTypes();
	GeneticModel.AddCrossoverType(CROSSOVERTYPE_FIXEDLENGTH_ONEPOINT);
	GeneticModel.ClearMutationTypes();
	GeneticModel.AddMutationType(MUTATIONTYPE_CHANGEGENE);
	GeneticModel.SetPopulationSize(100, 10, 10, -1);
	GeneticModel.SetMutationRate(1.0f);
	GeneticModel.Initialize();

	Fitness = -10000;

	Stopwatch.Start();
	while (!GeneticModel.IsFitEnough())
	{
		// try again
		GeneticModel.Update();

		// has the fitness of the model improved?
		if (GeneticModel.GetFitness() > Fitness)
		{
			Stopwatch.Stop();
			Duration = Stopwatch.GetDuration();
			Fitness = GeneticModel.GetFitness();
			printf("time: %2.2f, \tfitness: %f\n", 
				Duration,
				Fitness);
			Stopwatch.Start();
		}
	}

	// done, print results
	CQueenGenome *FittestGenome = (CQueenGenome *)GeneticModel.GetFittestGenome();
	printf("\ntime: %2.2f\tfittest: %s\n", 
		Duration, 
		FittestGenome->ToString().GetBuffer());
}
