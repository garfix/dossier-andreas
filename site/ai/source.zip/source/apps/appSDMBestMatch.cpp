#include "AI.h"

/// Implements a best-match mechanism using
/// Pentti Kanerva's Sparse Distributed Memory
///
/// 5 Patterns are stored in memory, each 10 times, each time with a different 10% distortion.
/// Then all patterns are read again, this time using again a 10% distortion.

namespace SDM1
{

#define WIDTH 10
#define HEIGHT 10
#define PATTERN_COUNT 5
#define WORD_LENGTH WIDTH*HEIGHT
#define NUMBER_OF_EXPOSURES 10
#define WORD_COUNT PATTERN_COUNT*NUMBER_OF_EXPOSURES

const char *Patterns[PATTERN_COUNT][HEIGHT] = 
	{ { "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O"  },

      { "OO  OO  OO",
        "OO  OO  OO",
        "  OO  OO  ",
        "  OO  OO  ",
        "OO  OO  OO",
        "OO  OO  OO",
        "  OO  OO  ",
        "  OO  OO  ",
        "OO  OO  OO",
        "OO  OO  OO"  },

      { "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO"  },

      { "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O"  },

      { "OOOOOOOOOO",
        "O        O",
        "O OOOOOO O",
        "O O    O O",
        "O O OO O O",
        "O O OO O O",
        "O O    O O",
        "O OOOOOO O",
        "O        O",
        "OOOOOOOOOO"  } };

void StringToBitPattern(const char *Pattern[HEIGHT], CBitPattern &BitPattern)
{
	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			char Char = Pattern[y][x];
			BitPattern.SetBit(y * WIDTH + x, Char == 'O');
		}
	}
}

void PrintPattern(CBitPattern &BitPattern)
{
	bool Bit;

	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			Bit = BitPattern.GetBit(y * WIDTH + x);
			printf("%c", (Bit ? 'O': ' '));
		}
		printf("\n");
	}
	printf("\n");
}

/// Swaps Percentage of BitPattern's bits from 1 to 0 or the other way round.
void Distort(CBitPattern &BitPattern, float Percentage)
{
	bool Bit;

	for (int BitIndex=0; BitIndex < WORD_LENGTH; BitIndex++)
	{
		if (CMath::GetRandomFloat(0.0f, 1.0f) <= Percentage)
		{
			Bit = BitPattern.GetBit(BitIndex);
			BitPattern.SetBit(BitIndex, !Bit);
		}
	}
}

}

using namespace SDM1;

void SDMBestMatch(void)
{
	CSDMModel Model(WORD_LENGTH, WORD_COUNT);
	CBitPattern BitPattern(WORD_LENGTH), ResultPattern(WORD_LENGTH);
	bool Found;

	// write all patterns several times, each with a small distortion
	for (int i=0; i < NUMBER_OF_EXPOSURES; i++)
	{
		for (int PatternIndex=0; PatternIndex < PATTERN_COUNT; PatternIndex++)
		{
			// create a bitpattern
			StringToBitPattern(Patterns[PatternIndex], BitPattern);

			// distort the pattern 10%
			Distort(BitPattern, 0.1f);

			// store the bitpattern
			Model.Write(BitPattern);
		}
	}

	// read all patterns
	for (int PatternIndex=0; PatternIndex < PATTERN_COUNT; PatternIndex++)
	{
		// get a bitpattern
		StringToBitPattern(Patterns[PatternIndex], BitPattern);

		// distort the address 10%
		Distort(BitPattern, 0.1f);

		// read from memory
		printf("Input:\n");
		PrintPattern(BitPattern);
		Model.ReadIteratively(BitPattern, ResultPattern, Found);

		printf("Output:\n");
		if (!Found)
			printf("Not Found.\n");
		else
		{
			// print it
			PrintPattern(ResultPattern);
		}
		printf("\n");
	}

	// print some info
	printf("Bitcount:\t%d\n", Model.GetBitCount());
	printf("Access Radius:\t%d\n", Model.GetAccessRadius());
	printf("Hard Locations:\t%d\n", Model.GetHardLocationCount());
	printf("Stored words:\t%d\n", Model.GetNumberOfStoredWords());
	printf("Capacity:\t%f\n", Model.GetCapacity());
}
