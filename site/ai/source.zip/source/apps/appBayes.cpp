#include "aiBNModel.h"

#define FALSE 0
#define TRUE 1

void Bayes(void)
{
	CBNModel ModelAlarm;
	CBNVariable *Burglary, *EarthQuake, *Alarm, *JohnCalls, *MaryCalls;
	CBNVariableDomain *Booleans;

	int CondPropFor1Parent[2][1] = 
	{
		{TRUE},
		{FALSE}
	};

	int CondPropFor2Parents[4][2] = 
	{
		{TRUE, TRUE},
		{TRUE, FALSE},
		{FALSE, TRUE},
		{FALSE, FALSE}
	};

	// add variable domains to model
	Booleans = new CBNVariableDomain();
	Booleans->AddValue(new CBNVariableValue("false"));
	Booleans->AddValue(new CBNVariableValue("true"));
	ModelAlarm.AddVariableDomain(Booleans);
	
	// create variables
	Burglary = new CBNVariable("Burglary", Booleans);
	EarthQuake = new CBNVariable("EarthQuake", Booleans);
	Alarm = new CBNVariable("Alarm", Booleans);
	JohnCalls = new CBNVariable("JohnCalls", Booleans);
	MaryCalls = new CBNVariable("MaryCalls", Booleans);

	// add variables to model
	ModelAlarm.AddVariable(Burglary);
	ModelAlarm.AddVariable(EarthQuake);
	ModelAlarm.AddVariable(Alarm);
	ModelAlarm.AddVariable(JohnCalls);
	ModelAlarm.AddVariable(MaryCalls);

	// add dependecies between variables
	Alarm->AddParent(Burglary);
	Alarm->AddParent(EarthQuake);
	JohnCalls->AddParent(Alarm);
	MaryCalls->AddParent(Alarm);

	// fill conditional probability tables
//	Burglary->SetConditionalProbability(TRUE, 0, 0.001f);
//	Burglary->SetConditionalProbability(FALSE, 0, 1.0f - 0.001f);

//	EarthQuake->SetConditionalProbability(TRUE, 0, 0.002f);
//	EarthQuake->SetConditionalProbability(FALSE, 0, 1.0f - 0.002f);

//	Alarm->SetConditionalProbability(TRUE, CondPropFor2Parents[0], 0.95f);
//	Alarm->SetConditionalProbability(TRUE, CondPropFor2Parents[1], 0.94f);
//	Alarm->SetConditionalProbability(TRUE, CondPropFor2Parents[2], 0.29f);
//	Alarm->SetConditionalProbability(TRUE, CondPropFor2Parents[3], 0.001f);
//	Alarm->SetConditionalProbability(FALSE, CondPropFor2Parents[0], 1.0f - 0.95f);
//	Alarm->SetConditionalProbability(FALSE, CondPropFor2Parents[1], 1.0f - 0.94f);
//	Alarm->SetConditionalProbability(FALSE, CondPropFor2Parents[2], 1.0f - 0.29f);
/*	Alarm->SetConditionalProbability(FALSE, CondPropFor2Parents[3], 1.0f - 0.001f);

	JohnCalls->SetConditionalProbability(TRUE, CondPropFor1Parent[0], 0.90f);
	JohnCalls->SetConditionalProbability(TRUE, CondPropFor1Parent[1], 0.05f);
	JohnCalls->SetConditionalProbability(FALSE, CondPropFor1Parent[0], 1.0f - 0.90f);
	JohnCalls->SetConditionalProbability(FALSE, CondPropFor1Parent[1], 1.0f - 0.05f);

	MaryCalls->SetConditionalProbability(TRUE, CondPropFor1Parent[0], 0.70f);
	MaryCalls->SetConditionalProbability(TRUE, CondPropFor1Parent[1], 0.01f);
	MaryCalls->SetConditionalProbability(FALSE, CondPropFor1Parent[0], 1.0f - 0.70f);
	MaryCalls->SetConditionalProbability(FALSE, CondPropFor1Parent[1], 1.0f - 0.01f);
*/
	// request the probability of an alarm ringing given that John Calls and there is not an earthquake.
//	ModelAlarm.SetEvidence("JohnCalls", "true");
//	ModelAlarm.SetEvidence("EarthQuake", "false");
//	printf("The probability of an alarm ringing given that John Calls and there is not an earthquake: %.2f\n", 
//		ModelAlarm.GetProbability("Alarm", "true"));

	//ModelAlarm.GetProbability("Alarm | JohnCalls=true && EarthQuake=false");

	// request the unconditional probability of an alarm ringing
//	ModelAlarm.GetMarginalProbability("Alarm=true");
}
