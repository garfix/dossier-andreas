#include <stdio.h>
#include "AI.h"

static const int ATTRIBUTE_COUNT = 10;
static const int EXAMPLE_COUNT = 12;

/// The decision tree algorithm and example are taken from chapter 18 of
/// Artificial Intelligence: A Modern Approach; by Stuart Russell and Peter Norvig.

enum Choices { YES, NO };
enum Patrons { NONE, SOME, FULL };
enum Price { CHEAP, REASONABLE, EXPENSIVE};
enum Type { FRENCH, THAI, BURGER, ITALIAN };
enum WaitEstimate { _0_10, _10_30, _30_60, _OVER_60 };

/// utility method
CDTObject *CreateObject(int *ExampleValues)
{
	CDTObject *NewObject;

	NewObject = new CDTObject(ATTRIBUTE_COUNT);
	
	// set attributes
	for (int Index=0; Index < ATTRIBUTE_COUNT; Index++)
	{
		NewObject->SetAttributeValue(Index, ExampleValues[Index]);
	}

	return NewObject;
}

void DecisionTree(void)
{
	int ObjectValues[EXAMPLE_COUNT][ATTRIBUTE_COUNT] = {
		{YES, NO,  NO,  YES, SOME, EXPENSIVE,  NO,  YES, FRENCH,  _0_10   },
		{YES, NO,  NO,  YES, FULL, CHEAP,      NO,  NO,  THAI,    _30_60  },
		{NO,  YES, NO,  NO,  SOME, CHEAP,      NO,  NO,  BURGER,  _0_10   },
		{YES, NO,  YES, YES, FULL, CHEAP,      NO,  NO,  THAI,    _10_30  },
		{YES, NO,  YES, NO,  FULL, EXPENSIVE,  NO,  YES, FRENCH,  _OVER_60},
		{NO,  YES, NO,  YES, SOME, REASONABLE, YES, YES, ITALIAN, _0_10   },
		{NO,  YES, NO,  NO,  NONE, CHEAP,      YES, NO,  BURGER,  _0_10   },
		{NO,  NO,  NO,  YES, SOME, REASONABLE, YES, YES, THAI,    _0_10   },
		{NO,  YES, YES, NO,  FULL, CHEAP,      YES, NO,  BURGER,  _OVER_60},
		{YES, YES, YES, YES, FULL, EXPENSIVE,  NO,  YES, ITALIAN, _10_30  },
		{NO,  NO,  NO,  NO,  NONE, CHEAP,      NO,  NO,  THAI,    _0_10   },
		{YES, YES, YES, YES, FULL, CHEAP,      NO,  NO,  BURGER,  _30_60  }
	};
	bool WillWait[EXAMPLE_COUNT] = { true, false, true, true, false, true, false, true, false, false, false, true };
	int SampleObjectValues[ATTRIBUTE_COUNT] =
		{YES, NO,  NO,  YES, SOME, EXPENSIVE,  NO,  YES, FRENCH,  _0_10   };

	CDTModel DecisionTreeModel(ATTRIBUTE_COUNT);
	CDTDecisionTree *DecisionTree;
	CDTObject *Object;
	CDTObject *SampleObject;
	CDTAttribute *Attribute;
	int DecisionValue;

	// first add the attributes
	Attribute = new CDTAttribute("Is there an alternative restaurant nearby?");
	Attribute->AddValue(YES, "Yes");
	Attribute->AddValue(NO, "No");
	DecisionTreeModel.SetAttribute(0, Attribute);

	Attribute = new CDTAttribute("Does the restaurant have a comfortable bar?");
	Attribute->AddValue(YES, "Yes");
	Attribute->AddValue(NO, "No");
	DecisionTreeModel.SetAttribute(1, Attribute);

	Attribute = new CDTAttribute("Is it either Friday or Saturday?");
	Attribute->AddValue(YES, "Yes");
	Attribute->AddValue(NO, "No");
	DecisionTreeModel.SetAttribute(2, Attribute);

	Attribute = new CDTAttribute("Are we hungry?");
	Attribute->AddValue(YES, "Yes");
	Attribute->AddValue(NO, "No");
	DecisionTreeModel.SetAttribute(3, Attribute);

	Attribute = new CDTAttribute("How many people are in the restaurant?");
	Attribute->AddValue(NONE, "None");
	Attribute->AddValue(SOME, "Some");
	Attribute->AddValue(FULL, "Full");
	DecisionTreeModel.SetAttribute(4, Attribute);

	Attribute = new CDTAttribute("What is the restaurant's price range?");
	Attribute->AddValue(CHEAP, "$");
	Attribute->AddValue(REASONABLE, "$$");
	Attribute->AddValue(EXPENSIVE, "$$$");
	DecisionTreeModel.SetAttribute(5, Attribute);

	Attribute = new CDTAttribute("Is it raining?");
	Attribute->AddValue(YES, "Yes");
	Attribute->AddValue(NO, "No");
	DecisionTreeModel.SetAttribute(6, Attribute);

	Attribute = new CDTAttribute("Did we make a reservation?");
	Attribute->AddValue(YES, "Yes");
	Attribute->AddValue(NO, "No");
	DecisionTreeModel.SetAttribute(7, Attribute);

	Attribute = new CDTAttribute("Type of restaurant");
	Attribute->AddValue(FRENCH, "French");
	Attribute->AddValue(THAI, "Thai");
	Attribute->AddValue(BURGER, "Burger");
	Attribute->AddValue(ITALIAN, "Italian");
	DecisionTreeModel.SetAttribute(8, Attribute);

	Attribute = new CDTAttribute("The wait estimated by the host");
	Attribute->AddValue(_0_10, "Less than 10 minutes");
	Attribute->AddValue(_10_30, "10 to 30 minutes");
	Attribute->AddValue(_30_60, "30 to 60 minutes");
	Attribute->AddValue(_OVER_60, "Over an hour");
	DecisionTreeModel.SetAttribute(9, Attribute);

	// fill the model with examples
	for (int Index=0; Index < EXAMPLE_COUNT; Index++)
	{
		// create object from attribute values
		Object = CreateObject(ObjectValues[Index]);

		// let model manage object
		DecisionTreeModel.AddObject(Object);

		// add example to decision tree
		DecisionTreeModel.AddExample(Object, WillWait[Index]);
	}

	// create sample object
	SampleObject = CreateObject(SampleObjectValues);

	// learn the decision tree
	DecisionTree = DecisionTreeModel.CreateDecisionTree();

	// ask the decision tree to decide if we should wait in a certain situation
	DecisionValue = DecisionTree->MakeDecision(*SampleObject);

	// print the decision tree
	printf("%s\n", DecisionTree->ToString().GetBuffer());

	// remove data
	delete DecisionTree;
	delete SampleObject;
}