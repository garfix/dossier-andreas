#include "AI.h"

void Aggressiveness(void)
{
	float Crisp;
	CFuzzyModel FuzzyModel;
	FuzzyModel.Load("resources/example.fcl");

	FuzzyModel.GetVariable("Our_Health")->SetValue(25);
	FuzzyModel.GetVariable("Enemy_Health")->SetValue(75);
	FuzzyModel.Update();
	Crisp = FuzzyModel.GetVariable("Aggressiveness")->GetValue();
	printf("agressiveness 25 & 75: %f (should be 1)\n", Crisp);

	FuzzyModel.GetVariable("Our_Health")->SetValue(75);
	FuzzyModel.GetVariable("Enemy_Health")->SetValue(25);
	FuzzyModel.Update();
	Crisp = FuzzyModel.GetVariable("Aggressiveness")->GetValue();
	printf("agressiveness 75 & 25: %f (should be 3)\n", Crisp);

	printf("model %s\n", FuzzyModel.ToString().GetBuffer());
}