#include <conio.h>
#include "AI.h"

/// from "Explorations in Parallel Distributed Processing" (chapter 3)
/// by McClelland & Rumelhart

void PrintCubes(CNNModel *NeckerModel)
{
	float A_BUL = NeckerModel->GetPool("pool")->GetUnit("A_BUL")->GetOutput();
	float A_BUR = NeckerModel->GetPool("pool")->GetUnit("A_BUR")->GetOutput();
	float A_FUL = NeckerModel->GetPool("pool")->GetUnit("A_FUL")->GetOutput();
	float A_FUR = NeckerModel->GetPool("pool")->GetUnit("A_FUR")->GetOutput();
	float A_BLL = NeckerModel->GetPool("pool")->GetUnit("A_BLL")->GetOutput();
	float A_BLR = NeckerModel->GetPool("pool")->GetUnit("A_BLR")->GetOutput();
	float A_FLL = NeckerModel->GetPool("pool")->GetUnit("A_FLL")->GetOutput();
	float A_FLR = NeckerModel->GetPool("pool")->GetUnit("A_FLR")->GetOutput();

	float B_BUL = NeckerModel->GetPool("pool")->GetUnit("B_BUL")->GetOutput();
	float B_BUR = NeckerModel->GetPool("pool")->GetUnit("B_BUR")->GetOutput();
	float B_FUL = NeckerModel->GetPool("pool")->GetUnit("B_FUL")->GetOutput();
	float B_FUR = NeckerModel->GetPool("pool")->GetUnit("B_FUR")->GetOutput();
	float B_BLL = NeckerModel->GetPool("pool")->GetUnit("B_BLL")->GetOutput();
	float B_BLR = NeckerModel->GetPool("pool")->GetUnit("B_BLR")->GetOutput();
	float B_FLL = NeckerModel->GetPool("pool")->GetUnit("B_FLL")->GetOutput();
	float B_FLR = NeckerModel->GetPool("pool")->GetUnit("B_FLR")->GetOutput();

	printf("\n");
	printf("          %2.2f----------%2.2f\t          %2.2f----------%2.2f\n", A_BUL, A_BUR, B_FUL, B_FUR);
	printf("          /             /|    \t          /|             |    \n");
	printf("         /             / |    \t         / |             |    \n");
	printf("        /             /  |    \t        /  |             |    \n");
	printf("      %2.2f----------%2.2f |  \t      %2.2f |        %2.2f |  \n", A_FUL, A_FUR, B_BUL, B_BUR);
	printf("       |             |   |    \t       |   |             |    \n");
	printf("       |             |   |    \t       |   |             |    \n");
	printf("       |   %2.2f------|--%2.2f\t       |   %2.2f---------%2.2f\n", A_BLL, A_BLR, B_FLL, B_FLR);
	printf("       |   /         |  /     \t       |   /            /     \n");
	printf("       |  /          | /      \t       |  /            /      \n");
	printf("       | /           |/       \t       | /            /       \n");
	printf("      %2.2f----------%2.2f\t      %2.2f----------%2.2f\n\n", A_FLL, A_FLR, B_BLL, B_BLR);
}

void Necker(void)
{
	char Key;

	char Names[][8] = {"BUL", "BUR", "FUL", "FUR", "BLL", "BLR", "FLL", "FLR"};
						
	float Weights[16][16] = {
		{ 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0, 0.0},
		{ 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0},
		{ 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0, 0.0},
		{ 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0},
		{ 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0},
		{ 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5},
		{ 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0},
		{ 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5},
		{-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0},
		{ 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0},
		{-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0},
		{ 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0}, 
		{ 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0}, 
		{ 0.0, 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0}, 
		{ 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 0.0, 0.0, 1.0}, 
		{ 0.0, 0.0, 0.0, 0.0, 0.0,-1.5, 0.0,-1.5, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 0.0}
	};
 
	CNNModel NeckerModel;
    
	CNNPool *Pool = NeckerModel.AddPool("pool", 16);
	CNNPoolConnection *Connection = NeckerModel.AddPoolConnection(Pool, Pool);

	// pool parameters
	Pool->SetUpdateMethod(UPDATEMETHOD_STOCHASTIC);
	Pool->SetUpdateRandomized(true);
	Pool->SetEStr(0.4f);
	Pool->SetIStr(0.4f);

	// name units
	for (int i=0; i<Pool->GetUnitCount()/2; i++) 
	{
		Pool->GetUnit(i)->SetName(CText("A_") + Names[i]);
		Pool->GetUnit(8 + i)->SetName(CText("B_") + Names[i]);
	}

	// parametrize units
	for (int i=0; i<Pool->GetUnitCount(); i++)
	{
		CNNUnit *Unit = Pool->GetUnit(i);
		Unit->SetBias(0.5f);
	}

	// create connections
	for (int y=0; y<16; y++)
	{
		for (int x=0; x<16; x++)
		{
			Connection->SetWeight(x, y, Weights[x][y]);
		}
	}

	// update and print results, repeatedly
	do
	{
		NeckerModel.Update();
	    PrintCubes(&NeckerModel);
		printf("Cycles: %d \t Goodness: %.2f \t Temperature: %.2f \n", 
			NeckerModel.GetCycleCount(),
			NeckerModel.GetGoodness(),
			NeckerModel.GetTemperature());

	    printf("Press 's' to stop. Any other key to continue.\n");
		while (!_kbhit()); Key = _getch();
	}
	while (Key != 's');

	// goodness A should be 11.20; goodness B should be 0.0
}