#include <conio.h>
#include "generic.h"
#include "AI.h"

// Hopfield model (1982)
// thanx to Karsten Kutza
// from http://www.geocities.com/CapeCanaveral/1624/hopfield.html
// simple autoassociative model, using hebbian learning

#define WIDTH 10
#define HEIGHT 10
#define PATTERN_COUNT 5

const char *Pattern[PATTERN_COUNT][HEIGHT] = 
	{ { "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O"  },

      { "OO  OO  OO",
        "OO  OO  OO",
        "  OO  OO  ",
        "  OO  OO  ",
        "OO  OO  OO",
        "OO  OO  OO",
        "  OO  OO  ",
        "  OO  OO  ",
        "OO  OO  OO",
        "OO  OO  OO"  },

      { "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "OOOOO     ",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO",
        "     OOOOO"  },

      { "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O",
        " O  O  O  ",
        "  O  O  O ",
        "O  O  O  O"  },

      { "OOOOOOOOOO",
        "O        O",
        "O OOOOOO O",
        "O O    O O",
        "O O OO O O",
        "O O OO O O",
        "O O    O O",
        "O OOOOOO O",
        "O        O",
        "OOOOOOOOOO"  } };

const char *TestPattern[PATTERN_COUNT][HEIGHT] = 
	{ { "          ",
        "          ",
        "          ",
        "          ",
        "          ",
        " O O O O O",
        "O O O O O ",
        " O O O O O",
        "O O O O O ",
        " O O O O O"  },

	  { "OOO O    O",
		" O  OOO OO",
		"  O O OO O",
		" OOO   O  ",
		"OO  O  OOO",
		" O OOO   O",
		"O OO  O  O",
		"   O OOO  ",
		"OO OOO  O ",
		" O  O  OOO"  },

	  { "OOOOO     ",
		"O   O OOO ",
		"O   O OOO ",
		"O   O OOO ",
		"OOOOO     ",
		"     OOOOO",
		" OOO O   O",
		" OOO O   O",
		" OOO O   O",
		"     OOOOO"  },

	  { "O  OOOO  O",
		"OO  OOOO  ",
		"OOO  OOOO ",
		"OOOO  OOOO",
		" OOOO  OOO",
		"  OOOO  OO",
		"O  OOOO  O",
		"OO  OOOO  ",
		"OOO  OOOO ",
		"OOOO  OOOO"  },

	  { "OOOOOOOOOO",
		"O        O",
		"O        O",
		"O        O",
		"O   OO   O",
		"O   OO   O",
		"O        O",
		"O        O",
		"O        O",
		"OOOOOOOOOO"  } };

/// Converts one of the fancy patterns above into a float array of +1 and -1 values.
void TransformPattern(const char *RawArray[PATTERN_COUNT][HEIGHT], int PatternIndex, CRow<float> &Pattern)
{
	char Char;

	// create pattern
	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			Char = RawArray[PatternIndex][y][x];
			Pattern.Set(y*WIDTH + x, ((Char == 'O') ? +1.0f : -1.0f));
		}
	}
}

/// Prints Pattern and the output pattern of Model next to eachother
/// on the screen. Negative Values respresented by ' ', positive values by 'O'.
void PrintPatterns(CRow<float> &Pattern, CNNPool *Pool)
{
	float Output;

	for (int y=0; y<HEIGHT; y++)
	{
		for (int x=0; x<WIDTH; x++)
		{
			Output = Pattern.Get(y * WIDTH + x);
			printf("%c", (Output > 0.0f ? 'O': ' '));
		}
		printf("\t");
		for (int x=0; x<WIDTH; x++)
		{
			Output = Pool->GetUnit(y*WIDTH + x)->GetOutput();
			printf("%c", (Output > 0.0f ? 'O': ' '));
		}
		printf("\n");
	}
	printf("\n");
}

void Hopfield(void)
{
	CNNModel HopfieldModel;
	CNNPool *Pool;
	CRow<float> InputPattern(WIDTH*HEIGHT);

	// create pool
	Pool = HopfieldModel.AddPool("pool", WIDTH*HEIGHT);

	// connect all units to each other
	HopfieldModel.AddPoolConnection(Pool, Pool);

	// set parameters
	Pool->SetUpdateMethod(UPDATEMETHOD_LINEARTHRESHOLD);
	Pool->SetMinimum(-1.0f);
	Pool->SetMaximum(+1.0f);

	// train the network
	HopfieldModel.SetTrainingMethod(TRAININGMETHOD_HEBB);
	HopfieldModel.SetLearningRate(1.0f);
	for (int PatternIndex=0; PatternIndex<PATTERN_COUNT; PatternIndex++)
	{
		// force pattern in obligatory data structure
		TransformPattern(Pattern, PatternIndex, InputPattern);

		// present training pattern
		Pool->SetOutputPattern(InputPattern);

		// train pattern
		HopfieldModel.TrainPattern();
	}

	// test the network
	for (int PatternIndex=0; PatternIndex<PATTERN_COUNT; PatternIndex++)
	{
		// force pattern in obligatory data structure
		TransformPattern(TestPattern, PatternIndex, InputPattern);

		// present test pattern
		Pool->SetOutputPattern(InputPattern);

		// update all units
		HopfieldModel.Update();

		// print the results
		PrintPatterns(InputPattern, Pool);
	}
}