#include "aiMBNProposition.h"

CMBNProposition::CMBNProposition(const CText &NewName, bool NewValue)
{
	Name = NewName;
	Count = 1;
	TrueCount = (NewValue ? 1 : 0);
}

CMBNProposition::~CMBNProposition()
{
}
