#ifndef _MBNMODEL
#define _MBNMODEL

#include "generic.h"
#include "aiMBNProposition.h"
#include "aiMBNCompetenceModule.h"

using namespace generic;

/// Maes' behavior network, an action-selection mechanism useful for complex dynamic environments!
/// as defined in:
/// "How to do the right thing" (Pattie Maes, 1989)
///
/// When you add a proposition or competence module to the model, the model takes over the resposibility
/// to clean them up, when they are no longer needed.
///
/// Running the model:
/// - Create the propositions
/// - Create the Competence Modules (cm's)
/// - Call Start() to let the model link up the cm's
/// - Call Update() as often as you like

class CMBNModel: public CElement
{
protected:
	/// All propositions describing the world
	CRow<CMBNProposition *> Propositions;
	/// Permanent goals are a subset of propositions; permanent goals should stay when achieved
	CRow<CMBNProposition *> PermanentGoals;
	/// Once only goals are a subset of propositions; once-only goals are deleted when achieved
	CRow<CMBNProposition *> OnceOnlyGoals;
	/// Active goals: should still be achieved (permanent goals and unachieved once-only goals)
	CRow<CMBNProposition *> ActiveGoals;
	/// Competence Modules: means to reach goals
	CRow<CMBNCompetenceModule *> CompetenceModules;
	/// The threshold of activation; only cm's with activations above this value are selectable
	float Threshold;
	/// Like threshold, but it may be lowered at runtime
	float ActiveThreshold;
	/// The amount of energy injected by the state per true proposition
	float PropositionEnergy;
	/// The amount of energy injected by the goals per goal
	float GoalEnergy;
	/// The amount of energy injected by the protected goals per protected goal
	float ProtectedGoalEnergy;
	/// MeanLevelOfActivation: After t=0, the mean activation of all cm's should be this number
	float MeanLevelOfActivation;
	/// Time (number of cycles up to now)
	int Time;
	/// Use hacks: use hacks to get closer to the activation values in Maes' article
	bool UseHacks;

	/// A hash that relates propositions to the amount of cm's that use it as a precondition
	CHashTable<CMBNProposition *, int> PreconditionUseHash;
	/// A hash that relates propositions to the amount of cm's that use it in the add-list
	CHashTable<CMBNProposition *, int> AddListUseHash;
	/// A hash that relates propositions to the amount of cm's that use it the delete-list
	CHashTable<CMBNProposition *, int> DeleteListUseHash;

	// Start() helpers
	void CreateLinks();
	void HashPropositionUse();

	// Update() helpers
	CMBNCompetenceModule *GetActiveCompetenceModule(CRow<float> &CurrentActivation) const;
	void ActivateCompetenceModule(CMBNCompetenceModule *CompetenceModule);

public:
	CMBNModel();
	~CMBNModel();

	CMBNProposition *AddProposition(const CText &NewName, bool NewValue=false);
	CMBNProposition *GetProposition(const CText &Name);

	void SetUseHacks(bool NewUseHacks){ UseHacks = NewUseHacks; }

	/// Uses Proposition as a goal; proposition must have been added already.
	void SetOnceOnlyGoal(CMBNProposition *Proposition){ OnceOnlyGoals.Add(Proposition); }
	void SetPermanentGoal(CMBNProposition *Proposition){ PermanentGoals.Add(Proposition); }

	void AddCompetenceModule(CMBNCompetenceModule *CompetenceModule){ CompetenceModules.Add(CompetenceModule); }
	CMBNCompetenceModule *AddCompetenceModule(const CText &Name);
	CMBNCompetenceModule *GetCompetenceModule(const CText &Name);

	void SetThreshold(float NewThreshold){ Threshold = NewThreshold; }
	void SetPropositionEnergy(float NewPropositionEnergy){ PropositionEnergy = NewPropositionEnergy; }
	void SetGoalEnergy(float NewGoalEnergy){ GoalEnergy = NewGoalEnergy; }
	void SetProtectedGoalEnergy(float NewProtectedGoalEnergy){ ProtectedGoalEnergy = NewProtectedGoalEnergy; }
	void SetMeanLevelOfActivation(float NewMeanLevelOfActivation){ MeanLevelOfActivation = NewMeanLevelOfActivation; }

	int GetCountUsedInPreconditions(CMBNProposition *Proposition);
	int GetCountUsedInAddLists(CMBNProposition *Proposition);
	int GetCountUsedInDeleteLists(CMBNProposition *Proposition);

	bool IsActiveGoal(CMBNProposition *Proposition){ return ActiveGoals.Contains(Proposition); }
	bool OnceOnlyGoalsAreMet(void) const;

	void Start(void);
	void Update(void);
	void Run(void);
	void Reset(void);
	void Clear(void);
};

#endif
