#ifndef _MBNLINK
#define _MBNLINK

#include "generic.h"

using namespace generic;

class CMBNCompetenceModule;
class CMBNProposition;

/// A unidirectional link (successor, predecessor, or conflictor) from one Competence Module to another.
///
/// Note: this class represents all links between one cm and another. That means, if there are 
/// multiple links of the same type between two cm's, only one link object will implement these.
/// This is because it is computationally easier to use in CMNNModel::Update().

class CMBNLink: public CElement
{
protected:
	CMBNCompetenceModule *TargetCompetenceModule;
	/// CommonPropositions: the propositions that are common in both competence modules list, 
	/// causing this link
	CRow<CMBNProposition *> CommonPropositions;

public:
	CMBNLink(CMBNCompetenceModule *NewTargetCompetenceModule);
	~CMBNLink();

	void AddCommonProposition(CMBNProposition *NewCommonProposition){ CommonPropositions.Add(NewCommonProposition); }
	int GetCommonPropositionCount(void) const { return CommonPropositions.GetLength(); }
	CMBNProposition *GetCommonProposition(int Index){ return CommonPropositions.Get(Index); }

	CMBNCompetenceModule *GetTargetCompetenceModule(void){ return TargetCompetenceModule; }
};

#endif
