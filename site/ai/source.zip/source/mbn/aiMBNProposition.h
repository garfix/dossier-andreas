#ifndef _MBNPROPOSITION
#define _MBNPROPOSITION

#include "generic.h"

using namespace generic;

/// An object that may represent one or more identical propositions.
/// In Maes' example the only use for this would be the
/// 'hand-is-empty' proposition, which occurs twice. Both propositions
/// mean the same thing and are _not_ bound to any specific robot hand.

class CMBNProposition: public CElement
{
protected:
	/// Count: the number of propositions this object represents
	int Count;
	/// TrueCount: the number of true propositions
	int TrueCount;

public:
	CMBNProposition(const CText &NewName, bool NewValue=false);
	~CMBNProposition();

	void IncreaseCount(void){ Count++; }
	int GetCount(void) const { return Count; }

	void IncreaseTrueCount(int Inc=1){ if (TrueCount+Inc <= Count) TrueCount += Inc; }
	void DecreaseTrueCount(int Dec=1){ if (TrueCount-Dec >= 0) TrueCount -= Dec; }
	int GetTrueCount(void) const { return TrueCount; }
	bool IsTrue(void) const { return (TrueCount > 0); }
};

#endif
