#ifndef _MBNCOMPETENCEMODULE
#define _MBNCOMPETENCEMODULE

#include "generic.h"

class CMBNProposition;
class CMBNLink;

using namespace generic;

/// A competence module is a unit of activity. It determines what propositions to make true
/// (the Add List) and make false (the Delete List). The Preconditions form the necessary
/// (but not only) requirement for execution.

class CMBNCompetenceModule: public CElement
{
	friend class CMBNModel;

protected:
	/// this is the core contents of the Competence Module:
	CRow<CMBNProposition *> Preconditions;
	CRow<CMBNProposition *> AddList;
	CRow<CMBNProposition *> DeleteList;
	float Activation;

	/// these links are stored here only for computational convenience

	/// A successor link is a link to another cm whose precondition is on this cm's add-list
	CRow<CMBNLink *> SuccessorLinks;
	CRow<CMBNLink *> PredecessorLinks;
	/// A conflictee link is a link to another cm that is in conflict with this cm's preconditions
	/// (because they are part of his delete-list)
	CRow<CMBNLink *> ConflicteeLinks;

	void AddSuccessorLink(CMBNLink *NewLink){SuccessorLinks.Add(NewLink); }
	void AddPredecessorLink(CMBNLink *NewLink){PredecessorLinks.Add(NewLink); }
	void AddConflicteeLink(CMBNLink *NewLink){ConflicteeLinks.Add(NewLink); }
	void DeleteAllLinks(void);

public:
	CMBNCompetenceModule();
	CMBNCompetenceModule(const CText &NewName);
	~CMBNCompetenceModule();

	void AddPrecondition(CMBNProposition *Proposition){ Preconditions.Add(Proposition); }
	void AddToAddList(CMBNProposition *Proposition){ AddList.Add(Proposition); }
	void AddToDeleteList(CMBNProposition *Proposition){ DeleteList.Add(Proposition); }

	void SetActivation(float NewActivation){ Activation = NewActivation; }

	bool IsExecutable(void) const;
	float GetActivation(void) const { return Activation; }
	bool ThereExistsAnActiveConflicteeLink(CMBNCompetenceModule *TargetComptenceModule) const;

	void Activate(void);
	void Reset();
};

#endif
