#include "aiMBNLink.h"

CMBNLink::CMBNLink(CMBNCompetenceModule *NewTargetCompetenceModule)
{
	TargetCompetenceModule = NewTargetCompetenceModule;
}

CMBNLink::~CMBNLink()
{
}
