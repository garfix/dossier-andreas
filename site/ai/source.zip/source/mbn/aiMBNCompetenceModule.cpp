#include "aiMBNCompetenceModule.h"
#include "aiMBNProposition.h"
#include "aiMBNLink.h"

CMBNCompetenceModule::CMBNCompetenceModule()
{
	Reset();
}

CMBNCompetenceModule::CMBNCompetenceModule(const CText &NewName)
{
	Name = NewName;
	Reset();
}

CMBNCompetenceModule::~CMBNCompetenceModule()
{
	DeleteAllLinks();
}

void CMBNCompetenceModule::DeleteAllLinks(void)
{
	SuccessorLinks.DeleteContents();
	PredecessorLinks.DeleteContents();
	ConflicteeLinks.DeleteContents();
}

/// A competence module is executable when all of its preconditions are true.
bool CMBNCompetenceModule::IsExecutable(void) const
{
	for (int i=0; i < Preconditions.GetLength(); i++)
	{
		if (!Preconditions.Get(i)->IsTrue()) return false;
	}
	return true;
}

/// Checks if the cm contains a conflictee link whose propositions are all true
bool CMBNCompetenceModule::ThereExistsAnActiveConflicteeLink(CMBNCompetenceModule *TargetComptenceModule) const
{
	CMBNLink *Link;
	bool LinkExists;

	// go through all conflictor links
	for (int i=0; i < ConflicteeLinks.GetLength(); i++)
	{
		// check if the target of the link matches
		Link = ConflicteeLinks.Get(i);
		if (Link->GetTargetCompetenceModule() != TargetComptenceModule) continue;

		// check if at least one of its propositions is active
		LinkExists = false;
		for (int PropIndex=0; PropIndex < Link->GetCommonPropositionCount(); PropIndex++)
		{
			if (Link->GetCommonProposition(PropIndex)->IsTrue()) LinkExists = true;
		}

		if (LinkExists) return true;
	}

	return false;
}

/// Sets all propositions in the add-list to true, and all propositions in the delete-list to false
void CMBNCompetenceModule::Activate(void)
{
	for (int i=0; i < AddList.GetLength(); i++)
		AddList.Get(i)->IncreaseTrueCount();

	for (int i=0; i < DeleteList.GetLength(); i++)
		DeleteList.Get(i)->DecreaseTrueCount();
}

/// Resets the activation level
void CMBNCompetenceModule::Reset()
{
	Activation = 0.0f;
}

