#include "aiMBNModel.h"
#include "aiMBNLink.h"

// disable compiler warnings about explicit casting of pointers to integers
#pragma warning ( disable : 4311 )

CMBNModel::CMBNModel(): 
	PreconditionUseHash(0), AddListUseHash(0), DeleteListUseHash(0)
{
	UseHacks = false;
}

CMBNModel::~CMBNModel()
{
	Clear();
}

/// Adds a proposition to the list of propositions.
/// If the list already contained a proposition by that name,
/// the new proposition will be housed under the existing proposition object.
CMBNProposition *CMBNModel::AddProposition(const CText &NewName, bool NewValue)
{
	CMBNProposition *Proposition = GetProposition(NewName);

	if (Proposition)
	{
		// an instance of the proposition existed already
		Proposition->IncreaseCount();
		if (NewValue) Proposition->IncreaseTrueCount(1);
	}
	else
	{
		Proposition = new CMBNProposition(NewName, NewValue);
		Propositions.Add(Proposition);
	}

	return Proposition;
}

CMBNProposition *CMBNModel::GetProposition(const CText &Name)
{
	for (int i=0; i < Propositions.GetLength(); i++)
	{
		if (Propositions.Get(i)->GetName() == Name) return Propositions.Get(i);
	}
	return 0;
}

CMBNCompetenceModule *CMBNModel::AddCompetenceModule(const CText &NewName)
{
	CMBNCompetenceModule *CompetenceModule = new CMBNCompetenceModule(NewName);

	this->AddCompetenceModule(CompetenceModule);
	return CompetenceModule;
}

/// Returns the competence module with the name Name; or 0 if there is none.
CMBNCompetenceModule *CMBNModel::GetCompetenceModule(const CText &Name)
{
	for (int i=0; i< CompetenceModules.GetLength(); i++)
	{
		if (CompetenceModules.Get(i)->GetName() == Name) return CompetenceModules.Get(i);
	}
	return 0;
}

/// Creates the links between the competence modules.
void CMBNModel::CreateLinks(void)
{
	CMBNCompetenceModule *Primary, *Secundary;
	CMBNProposition *Precondition, *AddProposition, *DeleteProposition;
	CMBNLink *SuccessorLink, *PredecessorLink, *ConflicteeLink;

	// reset variables
	ActiveThreshold = Threshold;
	
	// create links
	for (int i=0; i < CompetenceModules.GetLength(); i++)
	{
		Primary = CompetenceModules.Get(i);
		for (int j=0; j < CompetenceModules.GetLength(); j++)
		{
			Secundary = CompetenceModules.Get(j);
			SuccessorLink = 0;
			PredecessorLink = 0;
			ConflicteeLink = 0;

			// check successor/predecessor links
			for (int AddIndex=0; AddIndex < Primary->AddList.GetLength(); AddIndex++)
			{
				AddProposition = Primary->AddList.Get(AddIndex);
				for (int PreIndex=0; PreIndex < Secundary->Preconditions.GetLength(); PreIndex++)
				{
					Precondition = Secundary->Preconditions.Get(PreIndex);
					if (AddProposition == Precondition) 
					{
						// all matching propositions share the same link object
						if (!SuccessorLink) 
						{
							SuccessorLink = new CMBNLink(Secundary);
							Primary->AddSuccessorLink(SuccessorLink);
							PredecessorLink = new CMBNLink(Primary);
							Secundary->AddPredecessorLink(PredecessorLink);
						}
						
						// add the matching proposition to the links
						SuccessorLink->AddCommonProposition(AddProposition);
						PredecessorLink->AddCommonProposition(AddProposition);
					}
				}
			}

			// check conflictor links
			for (int PreIndex=0; PreIndex < Primary->Preconditions.GetLength(); PreIndex++)
			{
				Precondition = Primary->Preconditions.Get(PreIndex);
				for (int DeleteIndex=0; DeleteIndex < Secundary->DeleteList.GetLength(); DeleteIndex++)
				{
					DeleteProposition = Secundary->DeleteList.Get(DeleteIndex);
					if (DeleteProposition == Precondition)
					{
						// all matching propositions share the same link object
						if (!ConflicteeLink)
						{
							// Secondary conflicts with Primary,
							// but we create a conflictor link from Secundary to Primary,
							// because this more useful for our calculations in Update()
							ConflicteeLink = new CMBNLink(Primary);
							Secundary->AddConflicteeLink(ConflicteeLink);
						}
						// add the matching proposition to the link
						ConflicteeLink->AddCommonProposition(DeleteProposition);
					}
				}
			}
		}
	}
}

/// Fills the hashes PreconditionUseHash, AddListUseHash, and DeleteListUseHash
/// with data concerning the amount of times a proposition has occurred as part of a
/// competence module's list
void CMBNModel::HashPropositionUse(void)
{
	CMBNCompetenceModule* CompetenceModule;
	CMBNProposition *Proposition;
	bool Found;
	int Amount;

	// resize the hashtables
	PreconditionUseHash.SetCapacity(Propositions.GetLength() * 2);
	AddListUseHash.SetCapacity(Propositions.GetLength() * 2);
	DeleteListUseHash.SetCapacity(Propositions.GetLength() * 2);

	for (int i=0; i < CompetenceModules.GetLength(); i++)
	{
		CompetenceModule = CompetenceModules.Get(i);

		// propositions used as preconditions
		for (int PropIndex=0; PropIndex < CompetenceModule->Preconditions.GetLength(); PropIndex++)
		{
			Proposition = CompetenceModule->Preconditions.Get(PropIndex);
			Amount = PreconditionUseHash.Get((int)Proposition, Proposition, Found);
			if (!Found) Amount = 0; else PreconditionUseHash.Remove((int)Proposition, Proposition);
			Amount++;
			PreconditionUseHash.Put((int)Proposition, Proposition, Amount);
		}

		// propositions used in add-lists
		for (int PropIndex=0; PropIndex < CompetenceModule->AddList.GetLength(); PropIndex++)
		{
			Proposition = CompetenceModule->AddList.Get(PropIndex);
			Amount = AddListUseHash.Get((int)Proposition, Proposition, Found);
			if (!Found) Amount = 0; else AddListUseHash.Remove((int)Proposition, Proposition);
			Amount++;
			AddListUseHash.Put((int)Proposition, Proposition, Amount);
		}

		// propositions used in delete-lists
		for (int PropIndex=0; PropIndex < CompetenceModule->DeleteList.GetLength(); PropIndex++)
		{
			Proposition = CompetenceModule->DeleteList.Get(PropIndex);
			Amount = DeleteListUseHash.Get((int)Proposition, Proposition, Found);
			if (!Found) Amount = 0; else DeleteListUseHash.Remove((int)Proposition, Proposition);
			Amount++;
			DeleteListUseHash.Put((int)Proposition, Proposition, Amount);
		}
	}
}

/// Returns the 'active' competence module; or 0 if there is none.
/// A cm is active when it's activation is above (current) threshold,
/// it is executable (all preconditions are fulfilled) and
/// it has the highest activation value of all cm's.
/// If multiple cm's have the highest activation value, the first one is chosen.
/// In 'Index' the index of the active cm is returned, or -1 if none was found
CMBNCompetenceModule *CMBNModel::GetActiveCompetenceModule(CRow<float> &CurrentActivation) const
{
	CMBNCompetenceModule *CompetenceModule;
	float Activation, HighestActivation = 0.0f;
	CMBNCompetenceModule *ActiveCompetenceModule = 0;

	for (int i=0; i < CompetenceModules.GetLength(); i++)
	{
		CompetenceModule = CompetenceModules.Get(i);
		Activation = CurrentActivation.Get(i);

		if (Activation < ActiveThreshold) continue;
		if (!CompetenceModule->IsExecutable()) continue;
		if (Activation > HighestActivation)
		{
			ActiveCompetenceModule = CompetenceModule;
			HighestActivation = Activation;
		}
	}

	return ActiveCompetenceModule;
}

/// Performs Activate on the cm
/// Also removes any attained once-only goals from the active-goals list
void CMBNModel::ActivateCompetenceModule(CMBNCompetenceModule *CompetenceModule)
{
	CMBNProposition *Goal;

	CompetenceModule->Activate();

	// if a once-only goal is achieved, it should be removed fom the active goal list
	for (int i=0; i < OnceOnlyGoals.GetLength(); i++)
	{
		Goal = OnceOnlyGoals.Get(i);
		if (Goal->IsTrue()) ActiveGoals.Remove(Goal);
	}
}

/// Returns the number of times Proposition is used in one of the preconditions of competence modules.
/// Corresponds to M(j) in Maes' paper.
/// It presumes 'HashPropositionUse()' has been run.
int CMBNModel::GetCountUsedInPreconditions(CMBNProposition *Proposition)
{
	bool Found;
	int Amount = PreconditionUseHash.Get((int)Proposition, Proposition, Found);
	return (Found ? Amount : 0);
}

/// Returns the number of times Proposition is used in one of the add-lists of competence modules.
/// Corresponds to A(j) in Maes' paper.
/// It presumes 'HashPropositionUse()' has been run.
int CMBNModel::GetCountUsedInAddLists(CMBNProposition *Proposition)
{
	bool Found;
	int Amount = AddListUseHash.Get((int)Proposition, Proposition, Found);
	return (Found ? Amount : 0);
}

/// Returns the number of times Proposition is used in one of the delete-lists of competence modules.
/// Corresponds to U(j) in Maes' paper.
/// It presumes 'HashPropositionUse()' has been run.
int CMBNModel::GetCountUsedInDeleteLists(CMBNProposition *Proposition)
{
	bool Found;
	int Amount = DeleteListUseHash.Get((int)Proposition, Proposition, Found);
	return (Found ? Amount : 0);
}

/// Returns true if all once only goal propositions are true; 
/// returns true if there are no goals.
bool CMBNModel::OnceOnlyGoalsAreMet(void) const
{
	// there are no once-only goals in the active-goals list
	return (ActiveGoals.GetLength() == PermanentGoals.GetLength());
}

/// To be called after the network is set up; the model prepares itself for action.
void CMBNModel::Start(void)
{
	// Creates the links between the competence modules.
	CreateLinks();

	// Create hashes between propositions and amounts
	HashPropositionUse();

	// Reset number of cycles
	Time = 0;

	// fill the list with active goals
	ActiveGoals.Clear();
	for (int i=0; i < PermanentGoals.GetLength(); i++)
		ActiveGoals.Add(PermanentGoals.Get(i));
	for (int i=0; i < OnceOnlyGoals.GetLength(); i++)
		ActiveGoals.Add(OnceOnlyGoals.Get(i));
}

void CMBNModel::Update(void)
{
	CMBNCompetenceModule *CompetenceModule, *Successor, *Predecessor, *Conflictee;
	CMBNCompetenceModule *ActiveCompetenceModule;
	float Activation, TotalActivation;
	int PreconditionCount, AddCount, DeleteCount;
	int CountUsedInDeleteLists;
	float InputFromState, InputFromGoals, TakenAwayByProtectedGoals;
	float SpreadsBackward, SpreadsForward, TakesAway;
	CMBNLink *Link;
	CMBNProposition *Proposition;
	float Amount, Factor;
	CText LogText;

	// increase cycle count
	Time++;

	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_DEBUG)
	{
		LOG_DEBUG(CText("TIME: ") + Time);
		LOG_DEBUG("");
		
		LogText = "state of the environment: ( ";
		for (int k=0; k < Propositions.GetLength(); k++)
		{
			for (int l=0; l < Propositions.Get(k)->GetTrueCount(); l++)
			{
				LogText += Propositions.Get(k)->GetName() + " ";
			}
		}
		LogText += ")";
		LOG_DEBUG(LogText);

		LogText = "goals of the environment: ( ";
		for (int k=0; k < ActiveGoals.GetLength(); k++)
		{
			if (!ActiveGoals.Get(k)->IsTrue()) LogText += ActiveGoals.Get(k)->GetName() + " ";
		}
		LogText += ")";
		LOG_DEBUG(LogText);

		LogText = "protected goals of the environment: ( ";
		for (int k=0; k < ActiveGoals.GetLength(); k++)
		{
			if (ActiveGoals.Get(k)->IsTrue()) LogText += ActiveGoals.Get(k)->GetName() + " ";
		}
		LogText += ")";
		LOG_DEBUG(LogText);
	}

	CRow<float> CurrentActivation(CompetenceModules.GetLength());
    	
	for (int i=0; i<CompetenceModules.GetLength(); i++)
	{
		CompetenceModule = CompetenceModules.Get(i);
		Activation = 0.0f;

		// input from state
		InputFromState = 0.0f;
		PreconditionCount = CompetenceModule->Preconditions.GetLength();
		for (int PreIndex=0; PreIndex < PreconditionCount; PreIndex++)
		{
			Proposition = CompetenceModule->Preconditions.Get(PreIndex);
			// check if the state proposition holds
			if (Proposition->IsTrue())
			{
				Amount = 
					PropositionEnergy /
					(this->GetCountUsedInPreconditions(Proposition) * (float)PreconditionCount);
				InputFromState += Amount;
				
				if (Amount > 0.0f) LOG_DEBUG("state gives " + CompetenceModule->GetName() + " an extra activation of " + Amount);
			}
		}
			
		// input from goals
		InputFromGoals = 0.0f;
		AddCount = CompetenceModule->AddList.GetLength();
		for (int AddIndex=0; AddIndex < AddCount; AddIndex++)
		{
			Proposition = CompetenceModule->AddList.Get(AddIndex);
			// check if the add-list proposition establishes a goal
			if (this->IsActiveGoal(Proposition))
			{
				Amount = 
					GoalEnergy /
					(this->GetCountUsedInAddLists(Proposition) * (float)AddCount);
				InputFromGoals += Amount;
				
				if (Amount > 0.0f) LOG_DEBUG("goals gives " + CompetenceModule->GetName() + " an extra activation of " + Amount);
			}
		}

		// taken away by protected goals
		TakenAwayByProtectedGoals = 0.0f;
		DeleteCount = CompetenceModule->DeleteList.GetLength();
		for (int DeleteIndex=0; DeleteIndex < DeleteCount; DeleteIndex++)
		{
			Proposition = CompetenceModule->DeleteList.Get(DeleteIndex);
			// check if the delete-list proposition undoes an established goal
			if (this->IsActiveGoal(Proposition) && Proposition->IsTrue())
			{
				Amount = 
					ProtectedGoalEnergy /
					(this->GetCountUsedInDeleteLists(Proposition) * (float)DeleteCount);
				TakenAwayByProtectedGoals += Amount;
				
				if (Amount > 0.0f) 
					LOG_DEBUG("protected goals take away from " + CompetenceModule->GetName() + " an activation of " + Amount);
			}
		}

		// activation spreaded backward by successor modules
		SpreadsBackward = 0.0f;
		for (int SuccessorIndex=0; SuccessorIndex < CompetenceModule->SuccessorLinks.GetLength(); SuccessorIndex++)
		{
			Link = CompetenceModule->SuccessorLinks.Get(SuccessorIndex);
			Successor = Link->GetTargetCompetenceModule();
			if (!Successor->IsExecutable())
			{
				AddCount = CompetenceModule->AddList.GetLength(); 

				for (int PropIndex=0; PropIndex < Link->GetCommonPropositionCount(); PropIndex++)
				{
					Proposition = Link->GetCommonProposition(PropIndex);
					if (!Proposition->IsTrue())
					{
						Amount = Successor->GetActivation() /
							(this->GetCountUsedInAddLists(Proposition) * (float)AddCount);
						SpreadsBackward += Amount;
						
						if (Amount > 0.0f) LOG_DEBUG(Successor->GetName() + " spreads " + Amount + " backward to " + CompetenceModule->GetName() + " for " + Link->GetCommonProposition(PropIndex)->GetName());
					}
				}
			}
		}

		// activation spreaded forward by predecessor modules
		SpreadsForward = 0.0f;
		for (int PredecessorIndex=0; PredecessorIndex < CompetenceModule->PredecessorLinks.GetLength(); PredecessorIndex++)
		{
			Link = CompetenceModule->PredecessorLinks.Get(PredecessorIndex);
			Predecessor = Link->GetTargetCompetenceModule();
			if (Predecessor->IsExecutable())
			{
				PreconditionCount = CompetenceModule->Preconditions.GetLength();

				for (int PropIndex=0; PropIndex < Link->GetCommonPropositionCount(); PropIndex++)
				{
					Proposition = Link->GetCommonProposition(PropIndex);
					if (!Proposition->IsTrue())
					{
						Amount = (PropositionEnergy / GoalEnergy) * 
							(Predecessor->GetActivation() /
							(this->GetCountUsedInPreconditions(Proposition) * (float)PreconditionCount));
						SpreadsForward += Amount;

						if (Amount > 0.0f) LOG_DEBUG(Predecessor->GetName() + " spreads " + Amount + " forward to " + CompetenceModule->GetName() + " for " + Link->GetCommonProposition(PropIndex)->GetName());
					}					
				}
			}
		}

		// activation taken away from conflicting modules
		TakesAway = 0.0f;
		for (int ConflicteeIndex=0; ConflicteeIndex < CompetenceModule->ConflicteeLinks.GetLength(); ConflicteeIndex++)
		{
			Link = CompetenceModule->ConflicteeLinks.Get(ConflicteeIndex);
			Conflictee = Link->GetTargetCompetenceModule();

			// the competence module should not take away activity from itself
			if (Conflictee == CompetenceModule) continue;

			if ((Conflictee->GetActivation() <= CompetenceModule->GetActivation()) &&
				(Conflictee->ThereExistsAnActiveConflicteeLink(CompetenceModule)))
			{
				// no action
			}
			else
			{
				Amount = 0.0f;
				DeleteCount = CompetenceModule->DeleteList.GetLength();
				for (int PropIndex=0; PropIndex < Link->GetCommonPropositionCount(); PropIndex++)
				{
					Proposition = Link->GetCommonProposition(PropIndex);
					CountUsedInDeleteLists = this->GetCountUsedInDeleteLists(Proposition);
					if (UseHacks)
					{
						if (Proposition->GetName() == "HAND-IS-EMPTY") 
						{
							CountUsedInDeleteLists = 2;
						}
					}
					if (Proposition->IsTrue())
					{
						Amount += (ProtectedGoalEnergy / GoalEnergy) * 
							(Conflictee->GetActivation() /
							((float)CountUsedInDeleteLists * (float)DeleteCount));
					}
				}

				// This code would follow from Maes' specification; however the resulting activation values
				// show it wasn't really used:
				// Amount = CMath::Max(Amount, CompetenceModule->GetActivation());

				if (Amount > 0.0f) LOG_DEBUG(Conflictee->GetName() + " decreases (inhibits) " + CompetenceModule->GetName() + CText(" with ") + CText(Amount));
				TakesAway += Amount;
			}
		}

		// calculate new activation value (in steps)
		Activation = CompetenceModule->GetActivation();
		Activation += InputFromState;
		Activation += InputFromGoals;
		Activation -= TakenAwayByProtectedGoals; 
		if (Activation < 0.0f) Activation = 0.0f;
		Activation -= TakesAway; 
		if (Activation < 0.0f) Activation = 0.0f;
		Activation += SpreadsBackward; 
		Activation += SpreadsForward; 

		// store it a temporary array
		CurrentActivation.Set(i, Activation);
	}

	// decay the activation values of all competence modules
	// first we calculate the total activation
	TotalActivation = 0.0f;
	for (int i=0; i < CompetenceModules.GetLength(); i++) TotalActivation += CurrentActivation.Get(i);

	// This line is only included to match Maes' activation values as much as possible;
	// other than that its just silly.
	if (!UseHacks || (Time >= 2))
	{
		// special cases: no cm's or no activation at all
		if (!CompetenceModules.IsEmpty() && (TotalActivation != 0.0f))
		{
			// then we determine the factor with which to multiply all activation values
			Factor = MeanLevelOfActivation / (TotalActivation / CompetenceModules.GetLength());
			// then decay all activation values
			for (int i=0; i < CompetenceModules.GetLength(); i++) 
				CurrentActivation.Set(i, CurrentActivation.Get(i) * Factor);
		}
	}

	// copy the activation values into the cm's
	for (int i=0; i < CompetenceModules.GetLength(); i++) 
		CompetenceModules.Get(i)->SetActivation(CurrentActivation.Get(i));

	// determine the 'active' cm
	ActiveCompetenceModule = GetActiveCompetenceModule(CurrentActivation);
	if (ActiveCompetenceModule)
	{
		// activate the active cm
		ActivateCompetenceModule(ActiveCompetenceModule);
		
		// if the threshold was lowered, it is now reset
		ActiveThreshold = Threshold;
		LOG_DEBUG("");
		LOG_DEBUG("module becoming active:" + ActiveCompetenceModule->GetName());
		LOG_DEBUG("");
	}
	else
	{
		// no active cm found; we lower the threshold by 10%
		ActiveThreshold *= 0.9f;

		LOG_DEBUG("");
		LOG_DEBUG("NO MODULE becoming active");
		LOG_DEBUG(CText("threshold is lowered to ") + ActiveThreshold);
		LOG_DEBUG("");
	}

	if (CLogger::GetLogger().GetLogLevel() >= LOGLEVEL_DEBUG)
	{
		LOG_DEBUG("activation-levels of modules after decay:");
		for (int i=0; i < CompetenceModules.GetLength(); i++) 
			LOG_DEBUG("activation-level " + CompetenceModules.Get(i)->GetName() + ": " + CompetenceModules.Get(i)->GetActivation());
		LOG_DEBUG("");
	}

	// reset the activation-value of the activated module
	if (ActiveCompetenceModule) ActiveCompetenceModule->SetActivation(0.0);

}

/// Performs Start(), and runs Update() until OnceOnlyGoalsAreMet() returns true
void CMBNModel::Run()
{
	Start();
	while (!OnceOnlyGoalsAreMet()) Update();
}

/// Resets all cm's: activation is reset to 0.
void CMBNModel::Reset(void)
{
	for (int i=0; i < CompetenceModules.GetLength(); i++)
		CompetenceModules.Get(i)->Reset();

	Time = 0;
}

/// Removes all competence modules (and thus all links between them) and propositions
void CMBNModel::Clear(void)
{
	CompetenceModules.DeleteContents();
	Propositions.DeleteContents();
	OnceOnlyGoals.Clear();
	PermanentGoals.Clear();
	ActiveGoals.Clear();
}
