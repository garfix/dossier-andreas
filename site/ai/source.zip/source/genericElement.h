#ifndef _ELEMENT
#define _ELEMENT

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <typeinfo.h>

#include "genericMath.h"
#include "genericText.h"

// RTTI (real-time type information):
// the base class needs at least one virtual function to enable RTTI
// Use /GR for the compiler to enable RTTI
// (Project / Properties / C/C++ / Language / Enable Runtime Type Info)

namespace generic
{

class CElement
{
protected:
	CText Name;

public:
	CElement(){};
	virtual ~CElement(){};

	void SetName(const CText &NewName){ Name = NewName; };
	const CText &GetName(void) const { return Name; }

	virtual int GetHashCode(void) const;
	virtual const CText ToString(void) const;
};

}

#endif