#include "aidMARSParser.h"
#include "../pl/aiPLModel.h"
#include "../pl/aiPLElements.h"
#include "aidMARSAction.h"
#include "aidMARSEvent.h"
#include "aidMARSPlan.h"
#include "aidMARSFork.h"

CdMARSParser::CdMARSParser(CPLModel *NewModel):
	CPLParser(NewModel)
{
	this->SetPunctuationChars("():;.-+!?,|");
	this->AddOperator("->");
	this->AddOperator("NOT");
}

CdMARSParser::~CdMARSParser()
{
}

void CdMARSParser::ParseEvent(CHashTable<CText, const CPLVariable *> &Variables, CdMARSPlan *Plan)
{
	CText Token;
	CdMARSGoal *Goal;
	CdMARSEvent *Event;
	CPLAtom *Belief;

	Token = LookAhead();
	if ((Token == "!") || (Token == "?"))
	{
		// goal
		Goal = ParseGoal(Variables);
		if (!Goal) 
		{
			Error = "Error in trigger's goal.";
			return;
		}
		Event = new CdMARSGoalEvent(Goal->GetGoalType(), Goal->GetAtom());
		delete Goal;
	}
	else if (Token == "+")
	{
		// add belief
		NextToken(); // skip +
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief)
		{
			Error = "Error in trigger's add belief.";
			return;
		}
		Event = new CdMARSAddBeliefEvent(*Belief);
		delete Belief;
	}
	else if (Token == "-")
	{
		// remove belief
		NextToken(); // skip -
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief)
		{
			Error = "Error in trigger's add belief.";
			return;
		}
		Event = new CdMARSRemoveBeliefEvent(*Belief);
		delete Belief;
	}
	else 
	{
		// syntax error
		Error = "Error in trigger.";
		return;
	}

	Plan->SetTriggerEvent(Event);
}

void CdMARSParser::ParseContext(CHashTable<CText, const CPLVariable *> &Variables, CdMARSPlan *Plan)
{
	CPLAtom *Belief;
	CText Token;

	do
	{
		// belief
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief)
		{
			Error = "Error in context belief.";
			return;
		}
		Plan->AddToContext(Belief);

		Token = LookAhead();
		if (Token == ",") NextToken(); // skip ,
	}
	while (Token == ",");
}

void CdMARSParser::ParseMaintenance(CHashTable<CText, const CPLVariable *> &Variables, CdMARSPlan *Plan)
{
	CPLAtom *Belief;
	CText Token;

	do
	{
		// belief
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief)
		{
			Error = "Error in context belief.";
			return;
		}
		Plan->AddToMaintenance(Belief);

		Token = LookAhead();
		if (Token == ",") NextToken(); // skip ,
	}
	while (Token == ",");
}

void CdMARSParser::ParseActions(CHashTable<CText, const CPLVariable *> &Variables, CRow<CdMARSInternalAction *> &Actions)
{
	CdMARSAction *Action;
	CText Token;

	do
	{
		Action = ParseAction(Variables);
		if (!Action)
		{
			Error = "Error in success/failure action.";
			return;
		}
		if (Action->GetType() != dMARSACTIONTYPE_INTERNAL)
		{
			Error = "Error in success/failure action: action is not internal.";
			delete Action;
			return;
		}
		Actions.Add((CdMARSInternalAction *)Action);

		Token = LookAhead();
		if (Token == ",") NextToken();
	}
	while (Token == ",");
}

void CdMARSParser::ParseFork(CHashTable<CText, const CPLVariable *> &Variables, CdMARSFork *Fork)
{
	CdMARSAction *Action;
	CdMARSFork *SubFork;
	CText Token;

	do
	{
		Action = ParseAction(Variables);
		if (!Action)
		{
			Error = "Error in ParseFork's action.";
			return;
		}
		SubFork = new CdMARSFork();
		Fork->AddBranch(Action, SubFork);
		Token = LookAhead();
		if (Token == "|")
		{
			// skip |
			NextToken();
			continue;
		}
		else if (Token == "->")
		{
			// target fork not empty
			Token = NextToken(); // skip ->
			Token = NextToken();
			if (Token != "(") 
			{
				Error = "Missing ( in fork.";
				return;
			}

			ParseFork(Variables, SubFork);

			Token = NextToken();
			if (Token != ")")
			{
				Error = "Missing ( in fork.";
				return;
			}
		}
		else
		{
			// we're done
			break;
		}

		Token = LookAhead();
		if (Token == "|") NextToken(); // skip |
	}
	while (Token == "|");
}

CdMARSGoal *CdMARSParser::ParseGoal(CHashTable<CText, const CPLVariable *> &Variables)
{
	CdMARSGoal *Goal;
	CPLAtom *EventAtom;
	EdMARSGoalType Type;
	CText Token;

	Token = NextToken();
	if (Token == "!") Type = dMARSGOALTYPE_ACHIEVEMENT;
	else if (Token == "?")Type = dMARSGOALTYPE_TEST;
	else return 0;

	EventAtom = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
	if (!EventAtom) return 0;

	Goal = new CdMARSGoal();
	Goal->SetAtom(*EventAtom);
	delete EventAtom;
	Goal->SetGoalType(Type);

	return Goal;
}

CdMARSAction *CdMARSParser::ParseAction(CHashTable<CText, const CPLVariable *> &Variables)
{
	CText Token;
	CdMARSAction *Action;
	CPLAtom *Belief;
    
	Token = LookAhead();
	if ((Token == "!") || (Token == "?"))
	{
		// goal
		Action = ParseGoal(Variables);
	}
	else if (Token == "+")
	{
		NextToken();
		// add belief action
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief) 
		{
			Error = "Error in action's belief.";
			return 0;
		}
		Action = new CdMARSInternalAction(dMARSINTERNALACTIONTYPE_ADD, *Belief);
		delete Belief;
	}
	else if (Token == "-")
	{
		NextToken();
		// remove belief action
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief)
		{
			Error = "Error in action's belief.";
			return 0;
		}
		Action = new CdMARSInternalAction(dMARSINTERNALACTIONTYPE_REMOVE, *Belief);
		delete Belief;
	}
	else 
	{
		// external action
		Belief = (CPLAtom *)CPLParser::ParseElement(CPLParser::PRECEDENCE_OR, Variables);
		if (!Belief)
		{
			Error = "Error in action's belief.";
			return 0;
		}
		Action = new CdMARSExternalAction(*Belief);
		delete Belief;
	}

	return Action;
}

CdMARSPlan *CdMARSParser::ParsePlan(const CText &Text)
{
	CText Token;
	CdMARSPlan *Plan;

	this->ReadString(Text);

	// this is a plan
	Plan = new CdMARSPlan();
	CHashTable<CText, const CPLVariable *> Variables(3);

	do
	{
		Token = NextToken();
		if (NextToken() != ":") return 0;

		if (Token == "trigger")
		{
			ParseEvent(Variables, Plan);
			if (!IsSuccessful()) break;
		}
		else if (Token == "context")
		{
			ParseContext(Variables, Plan);
			if (!IsSuccessful()) break;
		}
		else if (Token == "body")
		{
			ParseFork(Variables, Plan->GetBody());
			if (!IsSuccessful()) break;
		}
		else if (Token == "maintenance")
		{
			ParseMaintenance(Variables, Plan);
			if (!IsSuccessful()) break;
		}
		else if (Token == "success")
		{
			ParseActions(Variables, Plan->SucceedActions);
			if (!IsSuccessful()) break;
		}
		else if (Token == "failure")
		{
			ParseActions(Variables, Plan->FailActions);
			if (!IsSuccessful()) break;
		}
		Token = NextToken(); // ";" or "."
	}
	while (Token == ";");

	if (!IsSuccessful())
	{
		delete Plan;
		return 0;
	}

	if (Token != ".") 
	{
		delete Plan;
		return 0;
	}

	return Plan;
}

CdMARSGoal *CdMARSParser::ParseGoal(const CText &Text)
{
	CText Token;
	CdMARSGoal *Goal;
	CHashTable<CText, const CPLVariable *> Variables(3);

	this->ReadString(Text);

	Goal = ParseGoal(Variables);

	Token = NextToken();
	if (Token != ".") 
	{
		delete Goal;
		return 0;
	}

	return Goal;
}