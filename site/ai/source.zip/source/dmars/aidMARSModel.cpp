#include "aidMARSModel.h"
#include "aidMARSEvent.h"
#include "aidMARSPlan.h"
#include "aidMARSPlanInstance.h"
#include "aidMARSAction.h"
#include "aidMARSParser.h"
#include "../pl/aiPLSubstitution.h"

CdMARSModel::CdMARSModel()
{
	Parser = new CdMARSParser(&Beliefs);
}

CdMARSModel::~CdMARSModel()
{
	// delete plan instances
	for (int i=0; i < Intentions.GetLength(); i++)
		Intentions.Get(i)->DeleteContents();

	// delete intentions
	Intentions.DeleteContents();

	// delete plans
	PlanLibrary.DeleteContents();

	// delete pending events
	EventQueue.DeleteContents();

	delete Parser;
}

/// Default implementation of dMARS' SelectEvent function:
/// In this implementation the event is simply the first event in the queue.
/// Selects and removes an event from the event queue, or 0 if there is none
CdMARSEvent *CdMARSModel::SelectEvent(CLinkedList<CdMARSEvent *> &EventQueue)
{
	if (EventQueue.IsEmpty()) return 0;
	return EventQueue.RemoveFirst();
}

/// Default implementation of dMARS' SelectApplicable function:
/// Returns the first applicable plan available, or 0 if there is none
bool CdMARSModel::SelectApplicablePlan(CRow<CdMARSPlan *> &ApplicablePlans, CRow<CPLSubstitution> &ApplicableSubstitutions, CdMARSPlan *&SelectedPlan, CPLSubstitution &SelectedSubstitution)
{
	if (ApplicablePlans.IsEmpty()) return false;
	else
	{
		SelectedPlan = ApplicablePlans.Get(0);
		SelectedSubstitution = ApplicableSubstitutions.Get(0);
		return true;
	}
}

/// Default implementation of dMARS' SelectIntention function:
/// Returns the plan instance on top op the first intention stack.
/// Returns 0 if no intention is available or if the first intention is empty.
CdMARSPlanInstance *CdMARSModel::SelectIntention(CRow<CStack<CdMARSPlanInstance *> *> &Intentions)
{
	if (Intentions.IsEmpty()) return 0;
	if (Intentions.Get(0)->IsEmpty()) return 0;
	return (Intentions.Get(0)->Peek());
}

/// This function places all plans that are triggered by Event in the array RelevantPlans;
/// The relevant plans are returned in RelevantPlans.
/// Note: this function does not return an array of "plan/substitution" pairs,
/// as specified in the formal specification. This is because of performance: we don't want
/// to create unnecessary object structures.
void CdMARSModel::GenerateRelevantPlans(CdMARSEvent *Event, CRow<CdMARSPlan *> &RelevantPlans, CRow<CPLSubstitution> &RelevantSubstitutions)
{
	bool Success;
	CPLSubstitution	Substitution;
	CdMARSEvent *TriggerEvent;

	for (int i=0; i<PlanLibrary.GetLength(); i++)
	{
		CdMARSPlan *Plan = PlanLibrary.Get(i);
		TriggerEvent = Plan->GetTriggerEvent();

		// check to see if the event type matches this plan's trigger
		if (Event->GetType() != TriggerEvent->GetType()) continue;
		// check if the plan can unify with the event (check on atom structure)
		if (!Event->CanUnify(Plan->GetTriggerEvent())) continue;

		// if the plan is a subgoal, the current environment should be applied as a substitution first.
		// the new substitution contains a binding for all variables in TriggerEvent's atom.
		if (Event->IsInternal())
			Substitution = Event->CreateSubstitution(TriggerEvent->GetAtom());

		// try to unify the event with the plan's trigger event
		// since the structure has been checked, this unification is only about the 
		// arguments of the atoms. Also, a new substitution is created.
		Substitution = TriggerEvent->Unify(Event->GetAtom(), Substitution, Success);
		if (Success)
		{
			RelevantPlans.Add(Plan);
			RelevantSubstitutions.Add(Substitution);
		}
	}
}

/// Selects the applicable plans from a set of relevant plans.
/// A plan is applicable when it relevant and the atoms in its context match with the set of Beliefs.
void CdMARSModel::GenerateApplicablePlans(CRow<CdMARSPlan *> &RelevantPlans, CRow<CPLSubstitution> &RelevantSubstitutions, CRow<CdMARSPlan *> &ApplicablePlans, CRow<CPLSubstitution> &ApplicableSubstitutions)
{
	for (int i=0; i < RelevantPlans.GetLength(); i++)
	{
		CdMARSPlan *RelevantPlan = RelevantPlans.Get(i);
		CPLSubstitution	Substitution = RelevantSubstitutions.Get(i);
		CRow<CPLSubstitution> Substitutions;

		Substitutions = Beliefs.Unify(RelevantPlan->GetContext(), Substitution);
		// if there are multiple possible substitutions, they are all added as
		// different applicable plans
		for (int s=0; s < Substitutions.GetLength(); s++)
		{
			ApplicablePlans.Add(RelevantPlan);
			ApplicableSubstitutions.Add(Substitutions.Get(s));
		}
	}
}

/// Adds Event to the list of pending events.
/// The method is synchronized; several threads may access it asynchonously.
void CdMARSModel::PostEvent(CdMARSEvent *Event)
{
    CriticalSectionPostEvent.Lock();
	{
		EventQueue.Add(Event);
		LOG_DEBUG("Event posted: " + Event->ToString());
	}
	CriticalSectionPostEvent.Unlock();
}

/// Selects an applicable plan for this event, creates a plan instance for this plan
/// and adds it to the list of intentions.
void CdMARSModel::ProcessEvent(CdMARSEvent *Event)
{
	CRow<CdMARSPlan *> RelevantPlans;
	CRow<CPLSubstitution> RelevantSubstitutions;
	CRow<CdMARSPlan *> ApplicablePlans;
	CRow<CPLSubstitution> ApplicableSubstitutions;
	CdMARSPlan *IntendedMeans;
	CdMARSPlanInstance *PlanInstance;
	CPLSubstitution Substitution;
	bool Available;

	// generates a list (RelevantPlans) of all plans that are triggered by Event
	// Substitutions will contain  the variable substitutions for the TriggerEvent variables.
	GenerateRelevantPlans(Event, RelevantPlans, RelevantSubstitutions);

	// generates a list (ApplicablePlans) of all plans with the right context
	GenerateApplicablePlans(RelevantPlans, RelevantSubstitutions, ApplicablePlans, ApplicableSubstitutions);

	// select a plan from the list of applicable plans (may be 0)
	Available = SelectApplicablePlan(ApplicablePlans, ApplicableSubstitutions, IntendedMeans, Substitution);
	if (Available)
	{
		LOG_DEBUG("Plan selected: " + IntendedMeans->ToString());

		// create a plan instance for the intended means
		PlanInstance = CreatePlanInstance(IntendedMeans, Substitution);

		if (Event->IsInternal())
		{
			// the goal is created by some plan instance
			AddPlanInstanceToIntention(Event->GetPlanInstance(), PlanInstance);
		}
		else
		{
			// the goal was added from outside
			AddIntention(PlanInstance);
			// update the event (according to spec. Is this necessary?)
			Event->SetPlanInstance(PlanInstance);
		}
	}
	else
		LOG_DEBUG("No plan selected.");
}

CdMARSPlanInstance *CdMARSModel::CreatePlanInstance(CdMARSPlan *Plan, CPLSubstitution &Substitution)
{
	CdMARSPlanInstance *PlanInstance;

	PlanInstance = new CdMARSPlanInstance(Plan, Substitution);

	return PlanInstance;
}

/// Returns the intention of which PlanInstance is the topmost frame.
CStack<CdMARSPlanInstance *> *CdMARSModel::FindIntention(CdMARSPlanInstance *PlanInstance)
{
	// find the intention stack of the plan instance PlanInstance belong to
	for (int i=0; i < Intentions.GetLength(); i++)
	{
		CStack<CdMARSPlanInstance *> *Intention = Intentions.Get(i);
		if (!Intention->IsEmpty() && Intention->Peek() == PlanInstance)
		{
			return Intention;
		}
	}
	return 0;
}

/// Pushes SubPlanInstance to the intention stack of which PlanInstance is the topmost element.
void CdMARSModel::AddPlanInstanceToIntention(CdMARSPlanInstance *PlanInstance, CdMARSPlanInstance *SubPlanInstance)
{
	FindIntention(PlanInstance)->Add(SubPlanInstance);
}

/// Creates a new intention stack and adds it to the array of intentions.
/// PlanInsrance is made the top-level plan instance of the intention.
void CdMARSModel::AddIntention(CdMARSPlanInstance *PlanInstance)
{
	CStack<CdMARSPlanInstance *> *Intention;

	Intention = new CStack<CdMARSPlanInstance *>(10);
	Intention->Push(PlanInstance);

	Intentions.Add(Intention);
}

/// Executes the current branch of the ExecutingPlan.
void CdMARSModel::ExecuteIntention(CdMARSPlanInstance *ExecutingPlan)
{
	const CdMARSAction *ExecutingBranch;

	// body may be empty
	if (!ExecutingPlan->HasExecutingBranches())
	{
		PerformPlanSucceeds(ExecutingPlan);
		return;
	}
		
	ExecutingBranch = ExecutingPlan->GetExecutingBranch();
	switch (ExecutingBranch->GetType())
	{
	case dMARSACTIONTYPE_EXTERNAL:
		this->PerformExternalAction((CdMARSExternalAction *)ExecutingBranch, ExecutingPlan->GetEnvironment());
		// follow this branch to the next state (fork)
		ExecutingPlan->PerformBranchSucceed();
		break;
	case dMARSACTIONTYPE_INTERNAL:
		// perform the internal action (add/remove a belief)
		PerformInternalAction((CdMARSInternalAction *)ExecutingBranch, ExecutingPlan->GetEnvironment());
		// follow this branch to the next state (fork)
		ExecutingPlan->PerformBranchSucceed();
		break;
	case dMARSACTIONTYPE_GOAL:
		CdMARSGoal *Goal = (CdMARSGoal *)ExecutingBranch;
		switch (Goal->GetGoalType())
		{
		case dMARSGOALTYPE_TEST:
			// try to unify this goal with current beliefs
			// if this succeeds, we may move directly to the next fork
			if (Beliefs.CanUnify(Goal->GetAtom(), ExecutingPlan->GetEnvironment()))
			{
				// follow this branch to the next state (fork)
				ExecutingPlan->PerformBranchSucceed();
			}
			else
			{
				// this branch fail, continue with the next
				ExecutingPlan->PerformBranchFailed();
				// must check immediately if the plan instance failed
				if (ExecutingPlan->HasFailed())
				{
					PerformPlanFailed(ExecutingPlan);
					return;
				}
			}
			break;
		case dMARSGOALTYPE_ACHIEVEMENT:
			// try to unify this goal with current beliefs

			// if this succeeds, we may move directly to the next fork
			if (Beliefs.CanUnify(Goal->GetAtom(), ExecutingPlan->GetEnvironment()))
			{
				// follow this branch to the next state (fork)
				ExecutingPlan->PerformBranchSucceed();
			}
			else
			{
				// post the new subgoal
				CdMARSGoal *Goal = (CdMARSGoal *)ExecutingBranch;
				PostEvent(new CdMARSGoalEvent(Goal->GetGoalType(), Goal->GetAtom(), ExecutingPlan, ExecutingPlan->GetEnvironment()));
				// suspend the current executing plan
				ExecutingPlan->Suspend();
			}
			break;
		}
		break;
	}

	if (ExecutingPlan->IsInEndState())
	{
		PerformPlanSucceeds(ExecutingPlan);
	}
}

/// ExecutingPlan has succeeded completely; it is popped off the intention stack.
/// The plan's succeed-actions are performed
void CdMARSModel::PerformPlanSucceeds(CdMARSPlanInstance *ExecutingPlan)
{
	CStack<CdMARSPlanInstance *> *Intention = FindIntention(ExecutingPlan);
	CPLSubstitution ExecutingPlanEnvironment = ExecutingPlan->GetEnvironment();

	// execute all succeed actions
	const CdMARSPlan *Plan = ExecutingPlan->GetPlan();
	for (int i=0; i<Plan->GetSucceedActionCount(); i++)
	{
		PerformInternalAction(Plan->GetSucceedAction(i), ExecutingPlan->GetEnvironment());
	}

	// pop the successful plan instance off the intention stack
	delete Intention->Pop();

	if (Intention->IsEmpty())
	{
		// the intention has been completed: remove it from the list
		Intentions.Remove(Intention);
		delete Intention;
	}
	else
	{
		// reactivate the new topmost plan instance
		// compose its environment with this instance's environment
		CdMARSPlanInstance *TopmostPlanInstance = Intention->Peek();
		TopmostPlanInstance->Activate();
	}
}

/// ExecutingPlan failed completely; this intention must be dismantled completely
/// The plan's fail-actions are performed
void CdMARSModel::PerformPlanFailed(CdMARSPlanInstance *ExecutingPlan)
{
	CStack<CdMARSPlanInstance *> *Intention = FindIntention(ExecutingPlan);

	// execute all fail actions
	const CdMARSPlan *Plan = ExecutingPlan->GetPlan();
	for (int i=0; i<Plan->GetFailActionCount(); i++)
	{
		PerformInternalAction(Plan->GetFailAction(i), ExecutingPlan->GetEnvironment());
	}

	// remove all plan instances from the intention
	Intention->DeleteContents();

	// remove the intention off the intention stack
	Intentions.Remove(Intention);
	delete Intention;
}

/// Executes an internal action of adding/removing a belief 
/// and sending a notification to confirm this.
void CdMARSModel::PerformInternalAction(CdMARSInternalAction *InternalAction, CPLSubstitution &CurrentSubstitution)
{
	bool BeliefChange;
	EdMARSInternalActionType InternalActionType = InternalAction->GetInternalActionType();

	// create a grounded belief
	CPLAtom Belief(InternalAction->GetAtom());
	Belief.Substitute(CurrentSubstitution);

	if (InternalActionType == dMARSINTERNALACTIONTYPE_ADD) 
	{
		Beliefs.Tell(Belief, BeliefChange);
		if (BeliefChange) PostEvent(new CdMARSAddBeliefEvent(Belief));
	}
	else if (InternalActionType == dMARSINTERNALACTIONTYPE_REMOVE)
	{
		Beliefs.Retract(Belief, BeliefChange);
		if (BeliefChange) PostEvent(new CdMARSRemoveBeliefEvent(Belief));
	}
}

void CdMARSModel::AddPlan(CdMARSPlan *Plan)
{
	PlanLibrary.Add(Plan);
}

/// Adds Goal to the set of goals.
/// dMARS wil clear up the goal later.
void CdMARSModel::AddGoal(CdMARSGoal *Goal)
{
	// add goal
	Goals.Add(Goal);

	// inform the agent
	PostEvent(new CdMARSGoalEvent(Goal->GetGoalType(), Goal->GetAtom()));
}

/// If possible, adds Belief to the set of beliefs and sends a notification event.
/// dMARS wil clear up the Belief later.
void CdMARSModel::AddBelief(CPLAtom &Belief)
{
	bool ModelChanged;

	// add the belief
	Beliefs.Tell(Belief, ModelChanged);
	if (ModelChanged)
	{
		// inform the agent
		PostEvent(new CdMARSAddBeliefEvent(Belief));
	}
}

/// If possible, removes belief from the set of beliefs, and sends a notification event.
void CdMARSModel::RemoveBelief(CPLAtom &Belief)
{
	bool ModelChanged;

	Beliefs.Retract(Belief, ModelChanged);
	if (ModelChanged)
	{
		// inform the agent
		PostEvent(new CdMARSRemoveBeliefEvent(Belief));
	}
}

bool CdMARSModel::HasBelief(CPLAtom &Belief)
{
	return Beliefs.Ask(Belief);
}

void CdMARSModel::PerformExternalAction(CdMARSExternalAction *Action, const CPLSubstitution &Substitution)
{
	CText a = Action->ToString();
	LOG_DEBUG("Performing external action " + Action->ToString() + " with " + Substitution.ToString());
}

void CdMARSModel::Update(void)
{
	CdMARSEvent *Event;
	CdMARSPlanInstance *PlanInstance;

	if (!EventQueue.IsEmpty())
	{
		LOG_DEBUG("-- Update: Process event");
		// select an event from the queue
		Event = SelectEvent(EventQueue);
		// process this event
		ProcessEvent(Event);
		// and delete it
		delete Event;
	}
	else
	{
		LOG_DEBUG("-- Update: Execute intention");
		// select an intention (or rather, a plan instance)
		PlanInstance = SelectIntention(Intentions);

		if (PlanInstance)
		{
			// execute this intention
			ExecuteIntention(PlanInstance);
		}
	}
}
