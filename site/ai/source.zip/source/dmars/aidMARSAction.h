#ifndef _DMARSACTION
#define _DMARSACTION

#include "generic.h"
#include "../pl/aiPLModel.h"

using namespace generic;

class CPLTerm;
class CPLFormula;
class CPLAtom;

// This file contains all actions the BDI agent can perform.

enum EdMARSGoalType
{
	dMARSGOALTYPE_ACHIEVEMENT,
	dMARSGOALTYPE_TEST
};

enum EdMARSActionType
{
	dMARSACTIONTYPE_INTERNAL,
	dMARSACTIONTYPE_EXTERNAL,
	dMARSACTIONTYPE_GOAL
};

enum EdMARSInternalActionType
{
	dMARSINTERNALACTIONTYPE_ADD,
	dMARSINTERNALACTIONTYPE_REMOVE
};

class CdMARSAction: public CElement
{
public:
	virtual EdMARSActionType GetType(void) const=0;
};

/// Internal action: an action that affects only the agent's beliefs.
class CdMARSInternalAction: public CdMARSAction
{
protected:
	CPLAtom Atom;
	EdMARSInternalActionType InternalActionType;

public:
	CdMARSInternalAction(EdMARSInternalActionType NewInternalActionType, CPLAtom &NewAtom);

	const CPLAtom &GetAtom(void) const { return Atom; }
	EdMARSInternalActionType GetInternalActionType(void) const { return InternalActionType; }
	virtual EdMARSActionType GetType(void) const { return dMARSACTIONTYPE_INTERNAL; }
	virtual const CText ToString(void) const;
};

/// External action: an action that affects the agents environment.
/// It is passed to the model's PerformExternalAction method.
class CdMARSExternalAction: public CdMARSAction
{
protected:
	CPLAtom Atom;

public:
	CdMARSExternalAction(CPLAtom &NewAtom);

	virtual EdMARSActionType GetType(void) const { return dMARSACTIONTYPE_EXTERNAL; }
	virtual const CText ToString(void) const;
};

/// Goal event: sets a new goal for the agent.
class CdMARSGoal: public CdMARSAction
{
protected:
	CPLAtom Atom;
	EdMARSGoalType GoalType;

public:
	void SetGoalType(EdMARSGoalType NewGoalType){ GoalType = NewGoalType; }
	EdMARSGoalType GetGoalType(void) const { return GoalType; }

	void SetAtom(CPLAtom &NewAtom){ Atom = NewAtom; }
	const CPLAtom &GetAtom(void) const { return Atom; }

	bool CanUnify(CdMARSGoal *Goal) const;
	virtual EdMARSActionType GetType(void) const { return dMARSACTIONTYPE_GOAL; }
};

#endif
