#include "aidMARSFork.h"
#include "aidMARSAction.h"

CdMARSFork::CdMARSFork()
{
}

CdMARSFork::~CdMARSFork()
{
	BranchActions.DeleteContents();
	BranchTargets.DeleteContents();
}

void CdMARSFork::AddBranch(CdMARSAction *Action, CdMARSFork *Target)
{
	BranchActions.Add(Action);
	BranchTargets.Add(Target);
}
