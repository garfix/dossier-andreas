#ifndef _DMARSPLAN
#define _DMARSPLAN

#include "generic.h"
#include "aidMARSEvent.h"
#include "aidMARSPlan.h"
#include "../pl/aiPLModel.h"

class CPLFormula;
class CdMARSFork;
class CdMARSInternalAction;

using namespace generic;

class CdMARSPlan: public CElement
{
	friend class CdMARSParser;

protected:
	/// TriggerEvent: the event that triggers this plan (may contain variables)
	CdMARSEvent *TriggerEvent;
	/// Context: preconditions; what beliefs must the agent have for this plan to be executable
	///   it is a situation formula
	CRow<const CPLAtom *> Context;
	/// Maintenance: what must be true for the plan to keep executing
	///   it is a situation formula
	CRow<const CPLAtom *> Maintenance;
	/// Body: a tree of actions to perform
	CdMARSFork *Body;
	/// SucceedActions: actions to be performed when the plan succeeds
	CRow<CdMARSInternalAction *> SucceedActions;
	/// FailActions: actions to be performed when the plan fails
	CRow<CdMARSInternalAction *> FailActions;

public:
	CdMARSPlan();
	virtual ~CdMARSPlan();

	void SetTriggerEvent(CdMARSEvent *Event){ TriggerEvent = Event; }
	CdMARSEvent *GetTriggerEvent(void) const { return TriggerEvent; }

	void AddToContext(CPLAtom *Atom){ Context.Add(Atom); }
	CRow<const CPLAtom *> &GetContext(void) { return Context; }

	void AddSucceedAction(CdMARSInternalAction *Action){ SucceedActions.Add(Action); }
	int GetSucceedActionCount(void) const { return SucceedActions.GetLength(); }
	CdMARSInternalAction *GetSucceedAction(int Index) const { return SucceedActions.Get(Index); }

	void AddFailAction(CdMARSInternalAction *Action){ FailActions.Add(Action); }
	int GetFailActionCount(void) const { return FailActions.GetLength(); }
	CdMARSInternalAction *GetFailAction(int Index) const { return FailActions.Get(Index); }

	void AddToMaintenance(CPLAtom *Atom){ Maintenance.Add(Atom); }

	CdMARSFork *GetBody(void) const { return Body; }
};

#endif
