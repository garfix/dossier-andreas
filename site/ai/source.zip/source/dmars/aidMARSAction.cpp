#include "aidMARSAction.h"
#include "../pl/aiPLElements.h"

CdMARSInternalAction::CdMARSInternalAction(EdMARSInternalActionType NewInternalActionType, CPLAtom &NewAtom)
{
	InternalActionType = NewInternalActionType;
	Atom = NewAtom;
}

const CText CdMARSInternalAction::ToString(void) const
{
	CText String;

	String += (InternalActionType ? "+" : "-");
	String += Atom.ToString();
	return String;
}

CdMARSExternalAction::CdMARSExternalAction(CPLAtom &NewAtom)
{ 
	Atom=NewAtom; 
}

const CText CdMARSExternalAction::ToString(void) const
{
	CText String;

	String += Atom.ToString();
	return String;
}

bool CdMARSGoal::CanUnify(CdMARSGoal *Goal) const
{
	if (Goal->GetGoalType() != this->GetGoalType()) return false;
	return (Goal->Atom.CanUnify(&Atom));
}
