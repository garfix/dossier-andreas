#ifndef _DMARSMODEL
#define _DMARSMODEL

#include "generic.h"
#include "../pl/aiPLModel.h"
#include "aidMARSPlan.h"
#include "aidMARSParser.h"

class CdMARSEvent;
class CdMARSGoal;
class CdMARSPlan;
class CdMARSPlanInstance;
class CdMARSEvent;
class CPLSubstitution;
class CdMARSInternalAction;
class CdMARSExternalAction;
class CdMARSParser;

using namespace generic;


/// The main class of the distributed Multi-Agent Reasoning System (dMARS),
/// an implementation of the Belief-Desire-Intention architecture,
/// as specified in:
/// "A formal specification of dMARS"
/// see: http://www.ecs.soton.ac.uk/~mml/papers/atal97.pdf
/// and
/// AgentSpeak(L): BDI Agents speak out in a logical computable language
/// see http://www.cs.mu.oz.au/682/agentspeak.pdf
///
/// The class has been named "model", to keep in line with my naming convention;
/// it represents dMARS' "Interpreter".

class CdMARSModel: public CElement
{
protected:
	// the four main components of a BDI agent
	// Beliefs: Predicate Logic formulae, restricted to "b(t)", "~b(t)"
	CPLModel Beliefs;
	CRow<CdMARSGoal *> Goals;
	CRow<CStack<CdMARSPlanInstance *> *> Intentions;
	CRow<CdMARSPlan *> PlanLibrary;

	/// synchronization object
	CCriticalSection CriticalSectionPostEvent;
	/// event queue	
	CLinkedList<CdMARSEvent *> EventQueue;
	/// Parser
	CdMARSParser *Parser;

	// the selectors
	// they have been given simple default implementations
	virtual CdMARSEvent *SelectEvent(CLinkedList<CdMARSEvent *> &EventQueue);
	virtual bool SelectApplicablePlan(CRow<CdMARSPlan *> &ApplicablePlans, CRow<CPLSubstitution> &ApplicableSubstitutions, CdMARSPlan *&SelectedPlan, CPLSubstitution &SelectedSubstitution);
	virtual CdMARSPlanInstance *SelectIntention(CRow<CStack<CdMARSPlanInstance *> *> &Intentions);

	void PostEvent(CdMARSEvent *Event);
	void ProcessEvent(CdMARSEvent *Event);

	void GenerateRelevantPlans(CdMARSEvent *Event, CRow<CdMARSPlan *> &RelevantPlans, CRow<CPLSubstitution> &RelevantSubstitutions);
	void GenerateApplicablePlans(CRow<CdMARSPlan *> &RelevantPlans, CRow<CPLSubstitution> &RelevantSubstitutions, CRow<CdMARSPlan *> &ApplicablePlans, CRow<CPLSubstitution> &ApplicableSubstitutions);

	CdMARSPlanInstance *CreatePlanInstance(CdMARSPlan *Plan, CPLSubstitution &Substitution);
	CStack<CdMARSPlanInstance *> *FindIntention(CdMARSPlanInstance *PlanInstance);

	void AddPlanInstanceToIntention(CdMARSPlanInstance *PlanInstance, CdMARSPlanInstance *SubPlanInstance);
	void AddIntention(CdMARSPlanInstance *PlanInstance);
	void ExecuteIntention(CdMARSPlanInstance *ExecutingPlan);
	void PerformPlanSucceeds(CdMARSPlanInstance *ExecutingPlan);
	void PerformPlanFailed(CdMARSPlanInstance *ExecutingPlan);

	void PerformInternalAction(CdMARSInternalAction *InternalAction, CPLSubstitution &CurrentSubstitution);
	
public:
	CdMARSModel();
	virtual ~CdMARSModel();

	CdMARSParser &GetParser(void) const { return *Parser; }

	// configuration
	void AddPlan(CdMARSPlan *Plan);
	void AddGoal(CdMARSGoal *Goal);

	// input
	void AddBelief(CPLAtom &Belief);
	void RemoveBelief(CPLAtom &Belief);

	// queries
	bool HasBelief(CPLAtom &Belief);

	// output
	virtual void PerformExternalAction(CdMARSExternalAction *Action, const CPLSubstitution &Substitution);

	// command
	void Update(void);
};

#endif
