#ifndef _DMARSPLANINSTANCE
#define _DMARSPLANINSTANCE

#include "generic.h"
#include "../pl/aiPLSubstitution.h"

using namespace generic;

class CdMARSPlan;
class CdMARSFork;
class CdMARSAction;

enum EdMARSPlanInstanceStatus
{
	dMARSPLANINSTANCESTATUS_ACTIVE,
	dMARSPLANINSTANCESTATUS_SUSPENDED,
	dMARSPLANINSTANCESTATUS_FAILED
};

class CdMARSPlanInstance: public CElement
{
protected:
	CdMARSPlan *Plan;
	CPLSubstitution Environment;
	/// CurrentFork; in the article called State
	CdMARSFork *CurrentFork;
	/// CurrentBranchIndex: implements 'nextbranches' and 'branch'
	int CurrentBranchIndex;
	/// Status
	EdMARSPlanInstanceStatus Status;

public:
	CdMARSPlanInstance(CdMARSPlan *NewPlan, CPLSubstitution &NewEnvironment);
	virtual ~CdMARSPlanInstance();

	const CdMARSPlan *GetPlan(void) const { return Plan; }
	const CdMARSAction *GetExecutingBranch(void) const;
	bool HasExecutingBranches(void) const;

	void SetEnvironment(CPLSubstitution &NewEnvironment){ Environment = NewEnvironment; }
	CPLSubstitution &GetEnvironment(void) { return Environment; }
    
	void PerformBranchSucceed(void);
	void PerformBranchFailed(void);

	void Suspend(void){ Status = dMARSPLANINSTANCESTATUS_SUSPENDED; }
	void Activate(void){ Status = dMARSPLANINSTANCESTATUS_ACTIVE; }
	bool IsActive(void) const { return (Status == dMARSPLANINSTANCESTATUS_ACTIVE); }

	bool IsInEndState(void) const;
	bool HasFailed(void) const;
};

#endif
