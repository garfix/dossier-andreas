#include "aidMARSPlan.h"
#include "aidMARSFork.h"
#include "../pl/aiPLSubstitution.h"

CdMARSPlan::CdMARSPlan()
{
	TriggerEvent = 0;
	Body = new CdMARSFork();
}

CdMARSPlan::~CdMARSPlan()
{
	delete TriggerEvent;
	Context.DeleteContents();
	Maintenance.DeleteContents();
	delete Body;
	SucceedActions.DeleteContents();
	FailActions.DeleteContents();
}
