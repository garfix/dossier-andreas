#include "aidMARSBeliefFormula.h"

CdMARSBeliefFormula::CdMARSBeliefFormula()
{
}

CdMARSBeliefFormula::~CdMARSBeliefFormula()
{
}
