#ifndef _DMARSBELIEFFORMULA
#define _DMARSBELIEFFORMULA

#include "generic.h"

using namespace generic;

class CdMARSBeliefFormula: public CElement
{
protected:
public:
	CdMARSBeliefFormula();
	~CdMARSBeliefFormula();
};

#endif
