#include "aidMARSGoal.h"
#include "../pl/aiPLElements.h"

CdMARSGoal::CdMARSGoal()
{
}

CdMARSGoal::~CdMARSGoal()
{
}

bool CdMARSGoal::CanUnify(CdMARSGoal *Goal) const
{
	if (Goal->GetGoalType() != this->GetGoalType()) return false;
	return (Goal->Atom->CanUnify(this->Atom));
}
