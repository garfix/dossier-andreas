#ifndef _DMARSGOAL
#define _DMARSGOAL

#include "generic.h"
#include "aidMARSAction.h"

using namespace generic;

class CPLAtom;

enum EdMARSGoalType
{
	dMARSGOALTYPE_ACHIEVEMENT,
	dMARSGOALTYPE_TEST
};

class CdMARSGoal: public CdMARSAction
{
protected:
	CPLAtom *Atom;
	EdMARSGoalType GoalType;

public:
	CdMARSGoal();
	virtual ~CdMARSGoal();

	void SetGoalType(EdMARSGoalType NewGoalType){ GoalType = NewGoalType; }
	EdMARSGoalType GetGoalType(void) const { return GoalType; }

	void SetAtom(CPLAtom *NewAtom){ Atom = NewAtom; }
	CPLAtom *GetAtom(void) const { return Atom; }

	bool CanUnify(CdMARSGoal *Goal) const;
};

#endif
