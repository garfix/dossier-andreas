#ifndef _DMARSSTATE
#define _DMARSSTATE

#include "genericElement.h"

class CdMARSState: public CElement
{
protected:
	CRow<> Branches;

public:
	CdMARSState();
	~CdMARSState();
};

#endif
