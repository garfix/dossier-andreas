#include "aidMARSState.h"

CdMARSState::CdMARSState()
{
}

CdMARSState::~CdMARSState()
{
}
