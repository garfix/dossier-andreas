#include "aidMARSEvent.h"
#include "aidMARSAction.h"

CdMARSEvent::CdMARSEvent()
{
	PlanInstance = 0;
}

CdMARSEvent::~CdMARSEvent()
{
}

/// Creates a substitution that binds all variables of NewAtom to the values of
/// this event's atom (or the bindings of its variables).
/// The function presupposes that this event's atom and NewAtom can unify (have the same structure).
CPLSubstitution CdMARSEvent::CreateSubstitution(const CPLAtom &NewAtom)
{
	CPLSubstitution NewSubstitution;

	for (int i=0; i < NewAtom.GetArgumentCount(); i++)
	{
		if (NewAtom.GetArgument(i)->GetType() == PLTYPE_VARIABLE)
		{
			const CPLVariable *Variable = (CPLVariable *)NewAtom.GetArgument(i);
			const CPLElement *Value = this->Atom.GetArgument(i);
			if (Value->GetType() == PLTYPE_VARIABLE) Value = this->Environment.Get((CPLVariable *)Value);
			NewSubstitution.Set(Variable, Value);
		}
	}
	return NewSubstitution;
}

/// Creates a substitution that binds all variables of this event's atom to the values of
/// this NewAtom (using its Substitution).
/// The function presupposes that this event's atom and NewAtom can unify (have the same structure).
CPLSubstitution CdMARSEvent::Unify(const CPLAtom &NewAtom, CPLSubstitution &Substitution, bool &Success)
{
	CPLSubstitution NewSubstitution = Substitution;
	
	// check structure
	if (!NewAtom.CanUnify(&Atom))
	{
		Success = false;
		return NewSubstitution;
	}

	// check argument values and create a substitution
	for (int i=0; i < Atom.GetArgumentCount(); i++)
	{
		// if the arguments are the same, unification is successful
		if (Atom.GetArgument(i)->Equals(NewAtom.GetArgument(i))) continue;

		// if the argument is a variable, make a binding
		if (Atom.GetArgument(i)->GetType() == PLTYPE_VARIABLE)
		{
			// check if there already is a binding
			const CPLVariable *Variable = (CPLVariable *)Atom.GetArgument(i);
			const CPLElement *Value = Substitution.Get(Variable);
			if (!Value)
			{
				Value = NewAtom.GetArgument(i);
			}
			//if (Value->GetType() == PLTYPE_VARIABLE) Value = Substitution.Get((CPLVariable *)Value);
			NewSubstitution.Set(Variable, Value);
		}
	}
	Success = true;
	return NewSubstitution;
}

const CText CdMARSEvent::ToString(void) const
{
	CText String;

	String += Atom.ToString();
	if (PlanInstance) 
	{
		String += " internal, environment=";
		String += Environment.ToString();
	}

	return String;
}

bool CdMARSAddBeliefEvent::CanUnify(CdMARSEvent *Event) const
{
	if (Event->GetType() != this->GetType()) return false;
	return ((CdMARSAddBeliefEvent *)Event)->GetAtom().CanUnify(&Atom);
}

const CText CdMARSAddBeliefEvent::ToString(void) const
{
	return "+" + CdMARSEvent::ToString();
}

bool CdMARSRemoveBeliefEvent::CanUnify(CdMARSEvent *Event) const
{
	if (Event->GetType() != this->GetType()) return false;
	return ((CdMARSRemoveBeliefEvent *)Event)->GetAtom().CanUnify(&Atom);
}

const CText CdMARSRemoveBeliefEvent::ToString(void) const
{
	return "-" + CdMARSEvent::ToString();
}

bool CdMARSToldEvent::CanUnify(CdMARSEvent *Event) const
{
	if (Event->GetType() != this->GetType()) return false;
	return ((CdMARSToldEvent *)Event)->GetAtom().CanUnify(&Atom);
}

CdMARSGoalEvent::CdMARSGoalEvent(EdMARSGoalType NewGoalType, const CPLAtom &NewAtom, CdMARSPlanInstance *NewPlanInstance, CPLSubstitution &NewEnvironment)
{ 
	GoalType = NewGoalType;
	Atom = NewAtom;
	PlanInstance = NewPlanInstance; 
	Environment = NewEnvironment;
}

bool CdMARSGoalEvent::CanUnify(CdMARSEvent *Event) const
{
	if (Event->GetType() != this->GetType()) return false;
	if (((CdMARSGoalEvent *)Event)->GetGoalType() != this->GetGoalType()) return false;
	return ((CdMARSGoalEvent *)Event)->GetAtom().CanUnify(&Atom);
}

const CText CdMARSGoalEvent::ToString(void) const
{
	return "!" + CdMARSEvent::ToString();
}
