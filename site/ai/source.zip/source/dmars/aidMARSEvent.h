#ifndef _DMARSEVENT
#define _DMARSEVENT

#include "generic.h"
#include "../pl/aiPLElements.h"
#include "../pl/aiPLSubstitution.h"
#include "aidMARSAction.h"

using namespace generic;

class CPLAtom;
class CdMARSPlanInstance;
class CdMARSPlan;

enum EdMARSEventType
{
	dMARSEVENTTYPE_BASE,
	dMARSEVENTTYPE_ADD_BELIEF,
	dMARSEVENTTYPE_REMOVE_BELIEF,
	dMARSEVENTTYPE_TOLD,
	dMARSEVENTTYPE_GOAL
};

class CdMARSEvent: public CElement
{
protected:
	/// EventType
	EdMARSEventType EventType;
	/// The belief associated with the event
	CPLAtom Atom;

	// Members used when the event is created by a plan instance:

	/// PlanInstance: the PlanInstance that created this event
	/// (if it is 0, the event was external, added from outside the agent,
	/// not part of a plan instance)
	CdMARSPlanInstance *PlanInstance;
	/// Environment: the environment the plan instance uses
	CPLSubstitution Environment;
	/// Plans that have been tried and may not be tried again.
	CRow<CdMARSPlan *> FailedPlans;

public:
	CdMARSEvent();
	virtual ~CdMARSEvent();

	const CPLAtom &GetAtom(void) const { return Atom; }

	void SetPlanInstance(CdMARSPlanInstance *NewPlanInstance){ PlanInstance = NewPlanInstance; }
	CdMARSPlanInstance *GetPlanInstance(void) const { return PlanInstance; }
	bool IsInternal(void){ return (PlanInstance != 0); }

	virtual EdMARSEventType GetType(void) const { return dMARSEVENTTYPE_BASE; }
	virtual bool CanUnify(CdMARSEvent *Event) const=0;
	virtual const CText ToString(void) const;

	// utility
	CPLSubstitution CreateSubstitution(const CPLAtom &Atom);
	CPLSubstitution Unify(const CPLAtom &Atom, CPLSubstitution &Substitution, bool &Success);
};

/// A notification that a belief was added.
class CdMARSAddBeliefEvent: public CdMARSEvent
{
public:
	CdMARSAddBeliefEvent(CPLAtom &NewAtom){Atom = NewAtom; }
	virtual ~CdMARSAddBeliefEvent(){}

	virtual EdMARSEventType GetType(void) const { return dMARSEVENTTYPE_ADD_BELIEF; }
	virtual bool CanUnify(CdMARSEvent *Event) const;
	virtual const CText ToString(void) const;
};

/// A notification that a belief was removed.
class CdMARSRemoveBeliefEvent: public CdMARSEvent
{
public:
	CdMARSRemoveBeliefEvent(CPLAtom &NewAtom){Atom = NewAtom; }
	virtual ~CdMARSRemoveBeliefEvent(){}

	virtual EdMARSEventType GetType(void) const { return dMARSEVENTTYPE_REMOVE_BELIEF; }
	virtual bool CanUnify(CdMARSEvent *Event) const;
	virtual const CText ToString(void) const;
};

/// A notification that a message was received.
class CdMARSToldEvent: public CdMARSEvent
{
public:
	CdMARSToldEvent(CPLAtom &NewAtom){Atom = NewAtom; }
	virtual ~CdMARSToldEvent(){}

	virtual EdMARSEventType GetType(void) const { return dMARSEVENTTYPE_TOLD; }
	virtual bool CanUnify(CdMARSEvent *Event) const;
};

/// A notification that a (sub)goal was created.
class CdMARSGoalEvent: public CdMARSEvent
{
protected:
	EdMARSGoalType GoalType;

public:
	CdMARSGoalEvent(EdMARSGoalType NewGoalType, const CPLAtom &NewAtom, CdMARSPlanInstance *NewPlanInstance=0, CPLSubstitution &NewEnvironment=CPLSubstitution());
	virtual ~CdMARSGoalEvent(){}

	void SetGoalType(EdMARSGoalType NewGoalType){ GoalType = NewGoalType; }
	EdMARSGoalType GetGoalType(void) const { return GoalType; }

	virtual EdMARSEventType GetType(void) const { return dMARSEVENTTYPE_GOAL; }
	virtual bool CanUnify(CdMARSEvent *Event) const;
	virtual const CText ToString(void) const;
};

#endif
