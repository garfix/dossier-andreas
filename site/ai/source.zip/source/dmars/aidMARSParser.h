#ifndef _DMARSPARSER
#define _DMARSPARSER

#include "generic.h"
#include "../pl/aiPLParser.h"

using namespace generic;

class CdMARSPlan;
class CPLVariable;
class CdMARSGoal;
class CdMARSFork;
class CdMARSAction;
class CdMARSInternalAction;

class CdMARSParser: public CPLParser
{
protected:
	void ParseEvent(CHashTable<CText, const CPLVariable *> &Variables, CdMARSPlan *Plan);
	void ParseContext(CHashTable<CText, const CPLVariable *> &Variables, CdMARSPlan *Plan);
	void ParseMaintenance(CHashTable<CText, const CPLVariable *> &Variables, CdMARSPlan *Plan);
	void ParseActions(CHashTable<CText, const CPLVariable *> &Variables, CRow<CdMARSInternalAction *> &Actions);
	void ParseFork(CHashTable<CText, const CPLVariable *> &Variables, CdMARSFork *Fork);

	CdMARSGoal *ParseGoal(CHashTable<CText, const CPLVariable *> &Variables);
	CdMARSAction *ParseAction(CHashTable<CText, const CPLVariable *> &Variables);

public:
	CdMARSParser(CPLModel *NewModel);
	~CdMARSParser();

	CdMARSPlan *ParsePlan(const CText &Text);
	CdMARSGoal *ParseGoal(const CText &Text);
};

#endif
