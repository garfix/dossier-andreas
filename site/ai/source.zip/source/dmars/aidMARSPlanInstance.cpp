#include "aidMARSPlanInstance.h"
#include "aidMARSPlan.h"
#include "aidMARSFork.h"

CdMARSPlanInstance::CdMARSPlanInstance(CdMARSPlan *NewPlan, CPLSubstitution &NewEnvironment)
{
	Plan = NewPlan;
	Environment = NewEnvironment;
	CurrentFork = Plan->GetBody();
	CurrentBranchIndex = 0;
	Status = dMARSPLANINSTANCESTATUS_ACTIVE;
}

CdMARSPlanInstance::~CdMARSPlanInstance()
{
}

const CdMARSAction *CdMARSPlanInstance::GetExecutingBranch(void) const
{
	return CurrentFork->GetBranchAction(CurrentBranchIndex);
}

bool CdMARSPlanInstance::HasExecutingBranches(void) const
{
	return (CurrentFork->GetBranchCount() != 0);
}

/// A branch is successful: proceed with it to its target state (fork)
void CdMARSPlanInstance::PerformBranchSucceed(void)
{
	CurrentFork = CurrentFork->GetBranchTarget(CurrentBranchIndex);
}

/// A branch is failed: proceed to the next branch
void CdMARSPlanInstance::PerformBranchFailed(void)
{
	CurrentBranchIndex++;
	if (CurrentBranchIndex >= CurrentFork->GetBranchCount()) 
	{
		Status = dMARSPLANINSTANCESTATUS_FAILED;
	}
}

bool CdMARSPlanInstance::IsInEndState(void) const 
{ 
	return (CurrentFork->GetBranchCount() == 0); 
}

bool CdMARSPlanInstance::HasFailed(void) const
{
	return (Status == dMARSPLANINSTANCESTATUS_FAILED);
}
