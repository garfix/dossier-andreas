#ifndef _DMARSFORK
#define _DMARSFORK

#include "generic.h"

using namespace generic;

class CdMARSAction;
class CdMARSFork;

/// This class combines the notions of Branch and State.

class CdMARSFork: public CElement
{
protected:
	// branches
	CRow<CdMARSAction *> BranchActions;
	CRow<CdMARSFork *> BranchTargets;

public:
	CdMARSFork();
	virtual ~CdMARSFork();

	void AddBranch(CdMARSAction *Action, CdMARSFork *Target);

	int GetBranchCount(void) const { return BranchTargets.GetLength(); }
	CdMARSAction *GetBranchAction(int Index){ return BranchActions.Get(Index); }
	CdMARSFork *GetBranchTarget(int Index){ return BranchTargets.Get(Index); }
};

#endif
