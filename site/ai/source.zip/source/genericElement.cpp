#include "genericElement.h"
#include "genericFloat.h"

namespace generic
{

	/// Returns a hash code based on the address
int CElement::GetHashCode(void) const
{
	return (int)(__int64)this;
}

/// default implementation; yields the string
/// 'name (class classname)'
const CText CElement::ToString(void) const
{ 
	CText String;

	String += GetName();
	String += " (";
	String += CText((char *)typeid(*this).name()); 
	String += ")";

	return String;
}

}