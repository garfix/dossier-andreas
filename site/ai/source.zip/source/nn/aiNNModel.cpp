#include "aiNNModel.h"
#include "aiNNPoolConnection.h"

#define NNMODEL_STARTTEMPERATURE 2.00f
#define NNMODEL_ENDTEMPERATURE 0.05f
#define NNMODEL_TEMPERATURE_CYCLE_COUNT 20

CNNModel::CNNModel()
{
	// default settings
	SetUpdateOrder(UPDATEORDER_BYDEFINITION);
	SetTrainingMethod(TRAININGMETHOD_HEBB);

	Initialize();
	Reset();
}

CNNModel::~CNNModel()
{
	Pools.DeleteContents();
	PoolConnections.DeleteContents();
}

void CNNModel::Initialize(void)
{
	CRow<float> TemperatureSchedule(20);

	// set temperature at each cycle
	for (int i=0; i<20; i++)
	{
		TemperatureSchedule.Get(i) = 
			NNMODEL_STARTTEMPERATURE - 
			i * (
					(NNMODEL_STARTTEMPERATURE - NNMODEL_ENDTEMPERATURE) /
					NNMODEL_TEMPERATURE_CYCLE_COUNT
				);
	}
	SetTemperatureSchedule(TemperatureSchedule);
}

void CNNModel::UpdateByDefinition(void)
{
	// update pools
	for (int i=0; i<Pools.GetLength(); i++) Pools.Get(i)->Update();
}

void CNNModel::UpdateHidden(void)
{
	for (int i=0; i<Pools.GetLength(); i++)
		if (Pools.Get(i)->GetPoolType() == POOLTYPE_HIDDEN) Pools.Get(i)->Update();
}

void CNNModel::UpdateOutput(void)
{
	for (int i=0; i<Pools.GetLength(); i++)
		if (Pools.Get(i)->GetPoolType() == POOLTYPE_OUTPUT) Pools.Get(i)->Update();
}

void CNNModel::UpdateAuxiliary(void)
{
	for (int i=0; i<Pools.GetLength(); i++)
		if (Pools.Get(i)->GetPoolType() == POOLTYPE_AUXILIARY) Pools.Get(i)->Update();
}

void CNNModel::TrainPatternHebb(void)
{
	for (int i=0; i<Pools.GetLength(); i++)
	{
		Pools.Get(i)->Hebb_ChangeWeights();
	}
}

void CNNModel::TrainPatternGeneralizedDelta(void)
{
	CNNPool *Pool;

	// hidden and output pools: update
	UpdateHidden();
	UpdateOutput();

	// hidden pools: reset error values
	// output pools: update error values
	for (int i=0; i<Pools.GetLength(); i++)
	{
		Pool = Pools.Get(i);
		if (Pool->GetPoolType() == POOLTYPE_HIDDEN)
		{
			Pool->BackPropagation_ResetError();
		}
		else if (Pool->GetPoolType() == POOLTYPE_OUTPUT)
		{
			Pool->BackPropagation_UpdateError();
		}
	}

	// output and hidden pools: propagate error back
	// notice the direction: last to first!
	for (int i=Pools.GetLength()-1; i>=0; i--)
	{
		Pool = Pools.Get(i);
		if ((Pool->GetPoolType() == POOLTYPE_HIDDEN) || (Pool->GetPoolType() == POOLTYPE_OUTPUT))
		{
			Pool->BackPropagation_PropagateBack();
		}
	}

	// hidden and output pools: calculate weights
	for (int i=0; i<Pools.GetLength(); i++)
	{
		Pool = Pools.Get(i);
		if ((Pool->GetPoolType() == POOLTYPE_HIDDEN) || (Pool->GetPoolType() == POOLTYPE_OUTPUT))
		{
			Pool->BackPropagation_ChangeWeights();
		}
	}
}

/// Adds a unit pool to the model\n
/// Note: the order in which the pools are added is used in those cases where
///		pool order is an issue, like in the updating of backpropagation learning.
///		Basically, the pools are updated in the order in which they are added.
/// \Name The name of the pool
/// \UnitCount The number of units for this pool
/// \return The new pool
CNNPool *CNNModel::AddPool(const CText &Name, int UnitCount)
{
	CNNPool *Pool;

	// create pool with name
	Pool = new CNNPool(this, UnitCount);
	Pool->SetName(Name);
	Pools.Add(Pool);

	return Pool;
}

/// The weights are set to 0.0f.
/// \param ConnectAll use all units of FromPool as inputs to all units of ToPool?
/// \param CreateSelfConnections If FromPool equals ToPool, and ConnectAll is true,
/// \param NewPoolConnectionType type of connection (concerns performance)
/// should each unit also get a connection to itself?
CNNPoolConnection *CNNModel::AddPoolConnection(CNNPool *FromPool, CNNPool *ToPool, ENNPoolConnectionTypes NewPoolConnectionType)
{
	CNNPoolConnection *PoolConnection;

	// create the connection
	PoolConnection = new CNNPoolConnection(FromPool, ToPool, NewPoolConnectionType);
	PoolConnections.Add(PoolConnection);
	ToPool->AddInputPoolConnection(PoolConnection);

	return PoolConnection;
}

/// Returns the pool with the specified name, or NULL if none was found.
CNNPool *CNNModel::GetPool(const CText &Name) const
{
	for(int i=0; i<Pools.GetLength(); i++)
	{
		if (Pools.Get(i)->GetName() == Name) return Pools.Get(i);
	}

	return 0;
}

void CNNModel::SetLearningRate(float NewLearningRate)
{
	for (int i=0; i<Pools.GetLength(); i++)
	{
		Pools.Get(i)->SetLearningRate(NewLearningRate);
	}

	for (int i=0; i<PoolConnections.GetLength(); i++)
	{
		PoolConnections.Get(i)->SetLearningRate(NewLearningRate);
	}
}

/// Updates all units\n
/// If RandomizedUpdate is false, all units are updated in the order they were
/// added to the model.\n
/// If RandomizedUpdate is true (default), all units are updated in random order,
/// all units are guaranteed to be updated in a single cycle.
void CNNModel::Update(void)
{
	// set current temperature
	if (!TemperatureSchedule.IsEmpty())
		Temperature = TemperatureSchedule.Get(CMath::Min(CycleCount, TemperatureSchedule.GetLength()-1));

	switch (UpdateOrder)
	{
	case UPDATEORDER_BYDEFINITION:
		UpdateByDefinition();
		break;
	case UPDATEORDER_HIDDEN_OUTPUT:
		UpdateHidden();
		UpdateOutput();
		break;
	case UPDATEORDER_OUTPUT_HIDDEN:
		UpdateOutput();
		UpdateHidden();
		break;
	case UPDATEORDER_HIDDEN_OUTPUT_AUXILIARY:
		UpdateHidden();
		UpdateOutput();
		UpdateAuxiliary();
		break;
	}
	
	// increase cycle count
	CycleCount++;
}

/// Trains the model with a single pattern. One trial.
/// Basically, the pools are updated in the order in which they were added.
void CNNModel::TrainPattern(void)
{
	switch (TrainingMethod)
	{
	case TRAININGMETHOD_HEBB:
		TrainPatternHebb();
		break;
	case TRAININGMETHOD_GENERALIZED_DELTA:
		TrainPatternGeneralizedDelta();
		break;
	}
}

void CNNModel::Reset(void)
{
	// reset temperature
	Temperature = 0.0f;

	// reset cycle count
	CycleCount = 0;

	for (int i=0; i<Pools.GetLength(); i++)
	{
		Pools.Get(i)->Reset();
	}
}

/// Returns the summed goodness of all pools
float CNNModel::GetGoodness(void) const
{
	float Goodness = 0.0f;

	for (int i=0; i<Pools.GetLength(); i++)
	{
		Goodness += Pools.Get(i)->GetGoodness();
	}

	return Goodness;
}

const CText CNNModel::ToString(void) const
{
	CText String;

	String += GetName() + ":\n";
	String += "{\n";

	for (int i=0; i < Pools.GetLength(); i++)
	{
		String += Pools.Get(i)->ToString();
	}

	String += "}\n";

	return String;
}
