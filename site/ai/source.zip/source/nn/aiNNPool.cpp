#include "aiNNPool.h"
#include "aiNNModel.h"

CNNPool::CNNPool(CNNModel *NewModel, int NewUnitCount)
{
	Model = NewModel;

	SetPoolType(POOLTYPE_UNDEFINED);
	SetUpdateMethod(UPDATEMETHOD_GROSSBERG);
	SetUpdateRandomized(false);

	Decay = 0.0f;
	Maximum = 1.0f;
	Minimum = 0.0f;
	Threshold = 0.0f;
	ThresholdActive = false;
	EStr = 1.0f;
	IStr = 1.0f;
	Momentum = 0.9f;

	SummedOutput = 0.0f;

	Units.SetLength(NewUnitCount);

	// add units
	for (int i=0; i<NewUnitCount; i++)
	{
		// set indices
		Units.Get(i).SetPool(this);
		Units.Get(i).SetPoolIndex(i);
	}
}

/// Returns the unit with the specified name, or NULL if none was found
CNNUnit *CNNPool::GetUnit(const CText &Name) const
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		if (Units.Get(i).GetName() == Name) return &Units.Get(i);
	}

	return 0;
}

/// Sets an input pattern for the units (copied into ExternalInput fields)
void CNNPool::SetOutputPattern(const CRow<float> &NewActivationPattern)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).SetOutput(NewActivationPattern.Get(i));
	}
}

void CNNPool::GetOutputPattern(CRow<float> &OutputPattern) const
{
	// OutputPattern should have the right length
	assert(OutputPattern.GetLength() == Units.GetLength());

	for (int i=0; i<Units.GetLength(); i++)
	{
		OutputPattern.Set(i, Units.Get(i).GetOutput());
	}
}

/// Sets a target pattern for the units (copied into Target fields)
void CNNPool::SetTargetPattern(CRow<float> &NewTargetPattern)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).SetTarget(NewTargetPattern.Get(i));
	}
}

void CNNPool::RandomizeBiases(void)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).SetBias(CMath::GetRandomFloat(Minimum, Maximum));
	}
}

void CNNPool::SetLearningRate(float NewLearningRate)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).SetBiasEpsilon(NewLearningRate);
	}
}
/// Returns the sum of all outputs
float CNNPool::GetSummedOutput(void) const
{
	return SummedOutput;
}

void CNNPool::Reset(void)
{
	// reset summed output
	SetSummedOutput(0);

	// reset all activation and output
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).Reset();
	}
}

void CNNPool::Update(void)
{
	float SummedOutput;

	// randomize the order of units to update?
	if (UpdateRandomized)
	{
		CRow<int> Indices(Units.GetLength());

		// create an index array
		for (int i=0; i<Units.GetLength(); i++) Indices.Get(i) = i;
	
		// randomize index array
		Indices.Randomize();

		// update all units according to index array
		for (int i=0; i<Units.GetLength(); i++)
		{
			Units.Get(Indices.Get(i)).Update();
		}
	}
	else
	{
		// update all units
		for (int i=0; i<Units.GetLength(); i++)
		{
			Units.Get(i).Update();
		}
	}

	// calculate the sum of all output values
	SummedOutput = 0.0f;
	for (int i=0; i<Units.GetLength(); i++)
	{
		SummedOutput += Units.Get(i).GetOutput();
	}

	SetSummedOutput(SummedOutput);
}

void CNNPool::BackPropagation_ResetError(void)
{
	// update all the pool's units
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).BackPropagation_ResetError();
	}
}

void CNNPool::BackPropagation_UpdateError(void)
{
	// update all the pool's units' error
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).BackPropagation_UpdateError();
	}
}

void CNNPool::BackPropagation_PropagateBack(void)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).BackPropagation_PropagateBack();
	}
}

void CNNPool::BackPropagation_ChangeWeights(void)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).BackPropagation_ChangeWeights();
	}
}

void CNNPool::Hebb_ChangeWeights(void)
{
	for (int i=0; i<Units.GetLength(); i++)
	{
		Units.Get(i).Hebb_ChangeWeights();
	}
}

/// Returns the summed goodness of all units
float CNNPool::GetGoodness(void) const
{
	float Goodness = 0.0f;

	for (int i=0; i<Units.GetLength(); i++)
	{
		Goodness += Units.Get(i).GetGoodness();
	}

	return Goodness;
}

float CNNPool::GetTemperature(void) const 
{ 
	return Model->GetTemperature(); 
}

/// After training one pattern, returns the sum of squares (PSS),\n
/// which means: the sum of the squares of the difference between target and activation,
/// of all units. Only applies to output pools.
float CNNPool::GetPatternSumOfSquares(void) const
{
	float PSS = 0.0f;
	float Difference, Square;

	for (int i=0; i<Units.GetLength(); i++)
	{
		CNNUnit &Unit = Units.Get(i);
		Difference = Unit.GetTarget() - Unit.GetOutput();
		Square = Difference * Difference;
		PSS += Square;
	}

	return PSS;
}

const CText CNNPool::ToString(void) const
{
	CText String;

	String += "\t";
	String += GetName() + ":\n";
	String += "\t{\n";

	for (int i=0; i < Units.GetLength(); i++)
	{
		String += "\t" + Units.Get(i).ToString();
	}

	String += "\t}\n";

	return String;
}



