#ifndef _NNMODEL
#define _NNMODEL

#include "aiNNPool.h"
#include "aiNNPoolConnection.h"
#include "generic.h"

using namespace generic;

enum ENNUpdateOrders
{
	/// Updates the pools in the order they were added to the network
	UPDATEORDER_BYDEFINITION,
	/// Updates hidden and output pools, in that order
	UPDATEORDER_HIDDEN_OUTPUT,
	/// Updates hidden and output pools, in that order
	UPDATEORDER_OUTPUT_HIDDEN,
	/// Updates hidden, output, and auxiliary pools, in that order
	UPDATEORDER_HIDDEN_OUTPUT_AUXILIARY
};

enum ENNTrainingMethods
{
	// Changing weights though association of activations
	TRAININGMETHOD_HEBB,
	// Backpropagation of error, via delta
	TRAININGMETHOD_GENERALIZED_DELTA
};

class CNNModel: public CElement
{
protected:
	CRow<CNNPool *> Pools;
	CRow<CNNPoolConnection *> PoolConnections;

	ENNUpdateOrders UpdateOrder;
	ENNTrainingMethods TrainingMethod;
	int CycleCount;
	float Temperature;
	CRow<float> TemperatureSchedule;

	void Initialize(void);

	void UpdateByDefinition(void);
	void UpdateHidden(void);
	void UpdateOutput(void);
	void UpdateAuxiliary(void);

	void TrainPatternHebb(void);
	void TrainPatternGeneralizedDelta(void);

public:
	CNNModel();
	~CNNModel();

	/* network structure */
	CNNPool *AddPool(const CText &Name, int UnitCount);
	CNNPoolConnection *AddPoolConnection(CNNPool *FromPool, CNNPool *ToPool, ENNPoolConnectionTypes NewPoolConnectionType=POOLCONNECTIONTYPE_FULL);
	/// retrieve the number of pools
	int GetPoolCount(void) const { return Pools.GetLength(); }
	/// retrieve pool by name
	CNNPool *GetPool(const CText &Name) const;
	/// retrieve pool by index
	CNNPool *GetPool(int Index) const { return Pools.Get(Index); }
        
	/* network parameters */
	/// should Update select random units or update from inputs, via hiddens to outputs?
	void SetUpdateOrder(ENNUpdateOrders NewUpdateOrder){ UpdateOrder = NewUpdateOrder; }
	/// training methods
	void SetTrainingMethod(ENNTrainingMethods NewTrainingMethod){ TrainingMethod = NewTrainingMethod; }
	ENNTrainingMethods GetTrainingMethod (void) const { return TrainingMethod; }
	/// set learning rate for all units (Epsilon and BiasEpsilon)
	void SetLearningRate(float NewLearningRate);
	/// what temperature at what cycle?\n 
	/// Only used with UPDATEMETHOD_STOCHASTIC.
	void SetTemperatureSchedule(CRow<float> &NewTemperatureSchedule){ TemperatureSchedule = NewTemperatureSchedule; }

	/* network activity */
	void Update(void);
	void TrainPattern(void);
	void Reset(void);

	/* network queries */
	float GetGoodness(void) const;
	float GetTemperature(void) const { return Temperature; }
	int GetCycleCount(void) const { return CycleCount; }
	virtual const CText ToString(void) const;
};

#endif