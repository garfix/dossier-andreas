#ifndef _NNUNIT
#define _NNUNIT

#include "generic.h"

using namespace generic;

class CNNPool;

class CNNUnit: public CElement
{
protected:
	/// The unit's pool and its index in that pool
	CNNPool *Pool;
	int PoolIndex;
	/// Rest: the value to which activation returns after some decay
	float Rest;
	/// BiasEpsilon: learning rate for the bias (0 = unmodifiable)
	float BiasEpsilon;
	/// Activation: the current value of the unit
	float Activation;
	/// Output: the modified Activation, as it can be accessed by others
	float Output;
	/// ExternalInput: the value that is externally clamped to the unit
	float ExternalInput;
	/// Bias: activation's base value
	float Bias;
	/// Target: the value activation should be
	float Target;
	/// Error: The difference between Target and Activation
	float Error, Delta, DeltaBias;

protected:
	void SetPool(CNNPool *NewPool){ Pool = NewPool; }
	void SetPoolIndex(int NewPoolIndex){ PoolIndex = NewPoolIndex; }

	float CalculateNetInput(void) const;

	void UpdateLinear(void);
	void UpdateLinearThreshold(void);
	void UpdateGrossberg(void);
	void UpdateStochastic(float Temperature);
	void UpdateContinuousSigmoid(void);

	float Logistic(float NetInput, float Temperature=1.0f) const;
	void SetActivation(float NewActivation){Activation = NewActivation;}
	void SetOutput(float NewOutput){Output = NewOutput;}

public:
	CNNUnit();

	/* unit structure */
	CNNPool *GetPool(void) const { return Pool; }
	int GetPoolIndex(void) const { return PoolIndex; }

	/* unit parameters */
	void SetRest(float NewRest){ Rest = NewRest; };
	float GetRest(void) const { return Rest; }
	void SetExternalInput(float NewExternalInput){ ExternalInput = NewExternalInput; };
	float GetExternalInput(void) const { return ExternalInput; }
	void SetBias(float NewBias){ Bias = NewBias; };
	float GetBias(void) const { return Bias; }
	void SetBiasEpsilon(float NewBiasEpsilon){ BiasEpsilon = NewBiasEpsilon; };
	float GetBiasEpsilon(void) const { return BiasEpsilon; }

	/* activity */
	void Reset(void);
	void Update(void);

	/* training */
	void SetTarget(float NewTarget){ Target = NewTarget; }
	float GetTarget(void) const { return Target; }
	void SetError(float NewError){ Error = NewError; }
	float GetError(void) const { return Error; }

	/* training: backpropagation */
	void BackPropagation_ResetError(void){ Error = 0.0f; };
	void BackPropagation_UpdateError(void);
	void BackPropagation_PropagateBack(void);
	void BackPropagation_ChangeWeights(void);

	/* training: Hebbian */
	void Hebb_ChangeWeights(void);

	/* query state */
	float GetOutput(void) const { return Output; }
	float GetGoodness(void) const;
	virtual const CText ToString(void) const;

	friend class CNNModel;
	friend class CNNPool;
    friend class CNNPoolConnection;
};

#endif