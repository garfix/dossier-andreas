#ifndef _NNPOOLCONNECTION
#define _NNPOOLCONNECTION

#include "generic.h"

using namespace generic;

class CNNUnit;
class CNNPool;

enum ENNPoolConnectionTypes
{
	// contains weigths, etc,  between the pools
	POOLCONNECTIONTYPE_FULL,
	// contains only inhibitory -1 weights, can not be modified
	POOLCONNECTIONTYPE_INHIBITORY
};

/// This class represents the directed connection between two pools.
/// It contains information that all UnitConnections share.
/// To improve performance, different types of pool connection
/// are implemented.

class CNNPoolConnection: public CElement
{
protected:
	/// The pool that is the source of this connection
	CNNPool *FromPool;
	/// The pool that is the destination of this connection
	CNNPool *ToPool;
	/// PoolConnectionType: The way the connection is implemented
	ENNPoolConnectionTypes PoolConnectionType;
	/// Alpha: positive factor applied to all positive weights
	float Alpha;
	/// Gamma: positive factor applied to all negative weights
	float Gamma;
	/// Weights: array of weights between units of both pools
	float *Weights;
	/// Epsilons: array of epsilons between units of both pools
	float *Epsilons;
	/// DeltaWeights: array of deltaWeights between units of both pools
	float *DeltaWeights;

	void Initialize(void);

public:
	CNNPoolConnection(CNNPool *NewFromPool, CNNPool *NewToPool, ENNPoolConnectionTypes NewPoolConnectionType=POOLCONNECTIONTYPE_FULL);
	~CNNPoolConnection();

	CNNPool *GetFromPool(void) const { return FromPool; }
	CNNPool *GetToPool(void) const { return ToPool; }

	/* parameters */
	void SetAlpha(float NewAlpha){ Alpha = NewAlpha; }
	float GetAlpha(void) const { return Alpha; }
	void SetGamma(float NewGamma){ Gamma = NewGamma; }
	float GetGamma(void) const { return Gamma; }

	/* unit-to-unit connections */
	void SetWeight(int FromPoolIndex, int ToPoolIndex, float NewWeight);
	float GetWeight(int FromPoolIndex, int ToPoolIndex) const;
	void SetEpsilon(int FromPoolIndex, int ToPoolIndex, float NewEpsilon);
	float GetEpsilon(int FromPoolIndex, int ToPoolIndex) const;
	void SetDeltaWeight(int FromPoolIndex, int ToPoolIndex, float NewDeltaWeight);
	float GetDeltaWeight(int FromPoolIndex, int ToPoolIndex) const;

	/* convenience methods */
	float GetSummedInput(int ToPoolIndex);
	void SetLearningRate(float LearningRate);
	void RandomizeWeights(void);

	/* training: backpropagation */
	void BackPropagation_PropagateBack(int ToPoolIndex, float Delta);
	void BackPropagation_ChangeWeights(int ToPoolIndex, float Delta, float Momentum);
	
	/* training: hebbian */
	void Hebb_ChangeWeights(int ToPoolIndex, float Activation);
};

#endif