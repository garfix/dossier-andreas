#include "aiNNUnit.h"
#include "aiNNPool.h"
#include "aiNNPoolConnection.h"
#include <math.h>

CNNUnit::CNNUnit()
{
	Rest = 0.0f;
	Activation = 0.0f;
	Output = 0.0;

	ExternalInput = 0.0f;
	Target = 0.0f;
	Error = 0.0f;
	Delta = 0.0f;
	DeltaBias = 0.0;

	Bias = 0.0f;
	BiasEpsilon = 0.25f;
}

float CNNUnit::CalculateNetInput(void) const
{
	float NetInput;
	float SummedInput = 0;

	// internal input
	for (int i=0; i<Pool->GetInputPoolConnectionCount(); i++)
	{
		SummedInput += Pool->GetInputPoolConnection(i)->GetSummedInput(PoolIndex);
	}
	NetInput = Pool->GetIStr() * (Bias + SummedInput);

	// external input
	NetInput += Pool->GetEStr() * ExternalInput;

	return NetInput;
}

/// Activation equals net input
void CNNUnit::UpdateLinear(void)
{
	Activation = CalculateNetInput();
}

/// Activation is set to Maximum if net input exceeds 0, and to Minimum if it doesn't
void CNNUnit::UpdateLinearThreshold(void)
{
	if (CalculateNetInput() > 0.0f) Activation = Pool->GetMaximum(); 
	else Activation = Pool->GetMinimum();
}

/// Standard activation method
void CNNUnit::UpdateGrossberg(void) 
{
	float Change;
	float NewActivation;
	float NetInput;

	// calculate change in activation
	NetInput = CalculateNetInput();
	if (NetInput > 0)
	{
		Change = (Pool->GetMaximum() - Activation) * NetInput - 
			Pool->GetDecay() * (Activation - Rest);
	}
	else
	{
		Change = (Activation - Pool->GetMinimum()) * NetInput - 
			Pool->GetDecay() * (Activation - Rest);
	}

	// apply change
	NewActivation = Activation + Change;

	// limit activation
	if (NewActivation > Pool->GetMaximum()) NewActivation = Pool->GetMaximum();
	if (NewActivation < Pool->GetMinimum()) NewActivation = Pool->GetMinimum();

	Activation = NewActivation;
}

/// Calculates activation according to Boltzmann
void CNNUnit::UpdateStochastic(float Temperature) 
{
	float NetInput = CalculateNetInput();
	float Log = Logistic(NetInput, Temperature);
	float Random = CMath::GetRandomFloat(0.0f, 1.0f);

	if (Random < Log) Activation = 1.0f; else Activation = 0.0f;
}

void CNNUnit::UpdateContinuousSigmoid(void)
{
	Activation = Logistic(CalculateNetInput());
}

/// The so called 'Logistic' function. Don't know exactly why all the
/// exceptions are made, but I'm sure they have good reasons.
/// In the default case (1.0), temperature is meaningless.
float CNNUnit::Logistic(float NetInput, float Temperature) const
{
	float Helper;
	float Log;

	if (Temperature <= 0.0f)
	{
		if (NetInput > 0.0f) return 1.0f; else return 0.0f;
	}

	Helper = NetInput / Temperature;

	// handle out of range cases
	if (Helper > 11.5129f) return .99999f;
	else if (Helper < -11.5129f) return .00001f;

	// the actual formula
	Log = 1.0f / (1.0f + expf(-1.0f * Helper));

	// handle out of range case
	if (Log > 1.0e-37f) return Log; else return 0.0f;
}

void CNNUnit::Reset(void)
{
	Activation = 0.0f;
	Output = 0.0f;
}

void CNNUnit::Update(void)
{
	switch (Pool->GetUpdateMethod())
	{
	case UPDATEMETHOD_LINEAR:
		UpdateLinear();
		break;
	case UPDATEMETHOD_LINEARTHRESHOLD:
		UpdateLinearThreshold();
		break;
	case UPDATEMETHOD_GROSSBERG:
		UpdateGrossberg();
		break;
	case UPDATEMETHOD_STOCHASTIC:
		UpdateStochastic(Pool->GetTemperature());
		break;
	case UPDATEMETHOD_CONTINUOUS_SIGMOID:
		UpdateContinuousSigmoid();
		break;
	}

	if (!Pool->IsThresholdActive()) 
	{
		Output = Activation;
	}
	else
	{
		// output equals activation - threshold
		Output = Activation - Pool->GetThreshold();
		
		// if output < 0, return 0
		if (Output < 0.0f) Output = 0.0f;
	}
}

/// Returns the goodness value
float CNNUnit::GetGoodness(void) const
{
	// net input has to be recalculated here;
	// no good to store it in Update() and use that value here
	return (CalculateNetInput() * Activation);
}

/// Backpropagation.\n
/// Updates the Error value.\n
/// Note: The source code in M&R states that Error may not be < 0 (only code, not so in book).
void CNNUnit::BackPropagation_UpdateError(void)
{ 
	Error = Target - Activation; 
}

/// Backpropagation.\n
/// Propagates the error found in training back to the input units.
void CNNUnit::BackPropagation_PropagateBack(void)
{
	// Update Delta
	Delta = Error * Activation * (1.0f - Activation);

	// Update Error in input units
	for (int i=0; i<Pool->GetInputPoolConnectionCount(); i++)
	{
		Pool->GetInputPoolConnection(i)->BackPropagation_PropagateBack(PoolIndex, Delta);
	}
}

/// Backpropagation.\n
/// Calculates the (bias and weight) error derivatives and changes weights accordingly.
/// Thus, the weights and bias are changed after training each pattern; they are
/// _not_ accumulated for an entire epoch.
void CNNUnit::BackPropagation_ChangeWeights(void)
{
	float BiasErrorDerivative;

	for (int i=0; i<Pool->GetInputPoolConnectionCount(); i++)
	{
		Pool->GetInputPoolConnection(i)->BackPropagation_ChangeWeights(PoolIndex, Delta, Pool->GetMomentum());
	}


	// calculate the derivative of the bias error
	BiasErrorDerivative = Delta;

	// update delta bias
	DeltaBias = BiasEpsilon * BiasErrorDerivative + Pool->GetMomentum() * DeltaBias;

	// update bias
	Bias += DeltaBias;
}

void CNNUnit::Hebb_ChangeWeights(void)
{
	for (int i=0; i<Pool->GetInputPoolConnectionCount(); i++)
	{
		Pool->GetInputPoolConnection(i)->Hebb_ChangeWeights(PoolIndex, Activation);
	}
}

const CText CNNUnit::ToString(void) const
{
	CText String("\t");

	String += " Bias=";
	String += Bias;

	String += " Activation=";
	String += Activation;

	String += " Delta=";
	String += Delta;

	String += " DeltaBias=";
	String += DeltaBias;

	String += " Error=";
	String += Error;

	String += " ExternalInput=";
	String += ExternalInput;

	String += " Target=";
	String += Target;

	String += '\n';

	return String;
}

