#include "aiNNPoolConnection.h"
#include "aiNNUnit.h"

#include "aiNNPool.h"

CNNPoolConnection::CNNPoolConnection(CNNPool *NewFromPool, CNNPool *NewToPool, ENNPoolConnectionTypes NewPoolConnectionType)
{ 
	FromPool = NewFromPool; 
	ToPool = NewToPool; 
	PoolConnectionType = NewPoolConnectionType;

	// inhibitory connection only within the same pool
	assert(
		// inhibitory?
		(NewPoolConnectionType == POOLCONNECTIONTYPE_INHIBITORY) ? 
		// then there should be just one pool
		(FromPool == ToPool) :
		// if not, then it's ok
		true		
	);

	Initialize();
}

CNNPoolConnection::~CNNPoolConnection()
{
	if (PoolConnectionType == POOLCONNECTIONTYPE_FULL)
	{
		delete[] Weights;
		delete[] Epsilons;
		delete[] DeltaWeights;
	}
}

void CNNPoolConnection::Initialize(void)
{
	int UnitCountProduct;
	
	Alpha = 1.0f;
	Gamma = 1.0f;

	switch (PoolConnectionType)
	{
	case POOLCONNECTIONTYPE_FULL:
		// create connection arrays
		UnitCountProduct = FromPool->GetUnitCount() * ToPool->GetUnitCount();
		Weights = new float[UnitCountProduct];
		Epsilons = new float[UnitCountProduct];
		DeltaWeights = new float[UnitCountProduct];

		// initialize connection arrays
		for (int i=0; i<UnitCountProduct; i++) Weights[i] = 0.0f;
		for (int i=0; i<UnitCountProduct; i++) Epsilons[i] = 0.25f;
		for (int i=0; i<UnitCountProduct; i++) DeltaWeights[i] = 0.0f;
		break;
	}
}

void CNNPoolConnection::SetWeight(int FromPoolIndex, int ToPoolIndex, float NewWeight)
{
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	Weights[ToPoolIndex * FromPool->GetUnitCount() + FromPoolIndex] = NewWeight;
}

float CNNPoolConnection::GetWeight(int FromPoolIndex, int ToPoolIndex) const
{
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	return Weights[ToPoolIndex * FromPool->GetUnitCount() + FromPoolIndex];
}

void CNNPoolConnection::SetEpsilon(int FromPoolIndex, int ToPoolIndex, float NewEpsilon)
{
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	Epsilons[ToPoolIndex * FromPool->GetUnitCount() + FromPoolIndex] = NewEpsilon;
}

float CNNPoolConnection::GetEpsilon(int FromPoolIndex, int ToPoolIndex) const
{
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	return Epsilons[ToPoolIndex * FromPool->GetUnitCount() + FromPoolIndex];
}

void CNNPoolConnection::SetDeltaWeight(int FromPoolIndex, int ToPoolIndex, float NewDeltaWeight)
{
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	DeltaWeights[ToPoolIndex * FromPool->GetUnitCount() + FromPoolIndex] = NewDeltaWeight;
}

float CNNPoolConnection::GetDeltaWeight(int FromPoolIndex, int ToPoolIndex) const
{
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	return DeltaWeights[ToPoolIndex * FromPool->GetUnitCount() + FromPoolIndex];
}

/// Returns sum of the weighted outputs of all units that serve as input to the
/// specified unit.\n
/// \param ToPoolUnitIndex The pool index of the unit.
float CNNPoolConnection::GetSummedInput(int ToPoolIndex)
{
	int FromPoolCount;
	int Offset;
	float Excitation;
	float Inhibition;
	float WeightedInput;
	float Weight;

	switch (PoolConnectionType)
	{
	case POOLCONNECTIONTYPE_FULL:
		// preparation
		FromPoolCount = FromPool->GetUnitCount();
		Offset = ToPoolIndex * FromPoolCount;

		Excitation = Inhibition = 0.0f;
		for (int FromPoolIndex=0; FromPoolIndex<FromPoolCount; FromPoolIndex++, Offset++)
		{
			Weight = Weights[Offset];
			if (Weight == 0.0f) continue;
			WeightedInput = Weight * FromPool->GetUnit(FromPoolIndex)->GetOutput();

			if (WeightedInput >= 0) Excitation += WeightedInput;
			else Inhibition += WeightedInput;
		}
		break;
	case POOLCONNECTIONTYPE_INHIBITORY:
		Excitation = 0.0f;
		Inhibition = -(FromPool->GetSummedOutput() - FromPool->GetUnit(ToPoolIndex)->GetOutput());
		break;
	}

	return (Excitation * Alpha) + (Inhibition * Gamma);
}

void CNNPoolConnection::SetLearningRate(float LearningRate)
{
	int UnitCountProduct;
	
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	UnitCountProduct = FromPool->GetUnitCount() * ToPool->GetUnitCount();

	for (int i=0; i<UnitCountProduct; i++) Epsilons[i] = LearningRate;
}

void CNNPoolConnection::RandomizeWeights(void)
{
	int UnitCountProduct;
	
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	UnitCountProduct = FromPool->GetUnitCount() * ToPool->GetUnitCount();

	for (int i=0; i<UnitCountProduct; i++) Weights[i] = CMath::GetRandomFloat(-1.0f, 1.0f);
}

void CNNPoolConnection::BackPropagation_PropagateBack(int ToPoolIndex, float Delta)
{
	int FromPoolCount;
	int Offset;
	float Weight;
	CNNUnit *FromUnit;
	
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);

	// preparation
	FromPoolCount = FromPool->GetUnitCount();
	Offset = ToPoolIndex * FromPoolCount;

	for (int FromPoolIndex=0; FromPoolIndex<FromPoolCount; FromPoolIndex++, Offset++)
	{
		FromUnit = FromPool->GetUnit(FromPoolIndex);
		Weight = Weights[Offset];
		FromUnit->SetError(FromUnit->GetError() + Delta * Weight);
	}
}

void CNNPoolConnection::BackPropagation_ChangeWeights(int ToPoolIndex, float Delta, float Momentum)
{
	int FromPoolCount;
	int Offset;
	CNNUnit *FromUnit;
	float WeightErrorDerivative, DeltaWeight;
	
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);
    
	// preparation
	FromPoolCount = FromPool->GetUnitCount();
	Offset = ToPoolIndex * FromPoolCount;

	for (int FromPoolIndex=0; FromPoolIndex<FromPoolCount; FromPoolIndex++, Offset++)
	{
		// preparation
		FromUnit = FromPool->GetUnit(FromPoolIndex);

		// calculate the derivative of the weight error
		WeightErrorDerivative = Delta * FromUnit->GetOutput();

		// update delta weight
		DeltaWeight = Epsilons[Offset] * WeightErrorDerivative +
			Momentum * DeltaWeights[Offset];
		DeltaWeights[Offset] = DeltaWeight;

		// update weight
		Weights[Offset] += DeltaWeight;
	}
}

void CNNPoolConnection::Hebb_ChangeWeights(int ToPoolIndex, float Activation)
{
	int FromPoolCount;
	CNNUnit *FromUnit;
	int Offset;
	
	// this method can only be performed on the full implementation
	assert(PoolConnectionType == POOLCONNECTIONTYPE_FULL);
    
	// preparation
	FromPoolCount = FromPool->GetUnitCount();
	Offset = ToPoolIndex * FromPoolCount;

	for (int FromPoolIndex=0; FromPoolIndex<FromPoolCount; FromPoolIndex++, Offset++)
	{
		// preparation
		FromUnit = FromPool->GetUnit(FromPoolIndex);

		Weights[Offset] += Epsilons[Offset] * Activation * FromUnit->GetOutput();
	}
}
