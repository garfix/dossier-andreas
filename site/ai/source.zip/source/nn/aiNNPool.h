#ifndef _NNPOOL
#define _NNPOOL

#include "aiNNUnit.h"
#include "generic.h"

using namespace generic;

enum ENNPoolTypes
{
	POOLTYPE_UNDEFINED,
	/// Input pools are not updated in training updates;
	/// the application should set its activation pattern.
	POOLTYPE_INPUT,
	/// Output pools should have a target pattern set in a training session.
	POOLTYPE_OUTPUT,
	/// Hidden pools are the remaining pools that are used in training.
	POOLTYPE_HIDDEN,
	/// Auxiliary pools (my term!) are not modified by a learning procedure,
	/// but they are updated anyway, since they affect the other pools.
	POOLTYPE_AUXILIARY
};

enum ENNUpdateMethods
{
	UPDATEMETHOD_LINEAR,
	UPDATEMETHOD_LINEARTHRESHOLD,
	UPDATEMETHOD_GROSSBERG,
	UPDATEMETHOD_STOCHASTIC,
	UPDATEMETHOD_CONTINUOUS_SIGMOID
};

class CNNModel;

/// A pool is a collection of units.

class CNNPool: public CElement
{
protected:
	/// the pool's model
	CNNModel *Model;
	/// the pool's type
	ENNPoolTypes PoolType;
	/// the update method
	ENNUpdateMethods UpdateMethod;
	/// update in randomi order?
	bool UpdateRandomized;
	/// array of units
	CRow<CNNUnit> Units;
	/// array of connections that serve as input to this pool
	CRow<CNNPoolConnection *> InputPoolConnections;

	/// Decay: the rate with which activcation decays to Rest
	float Decay;
	///	Maximum: maximum activation value
	float Maximum;
	///	Minimum: minimum activation value
	float Minimum;
	/// Threshold: the value that is subtracted from the activation to get the output;
	/// if activation < threshold, output = 0 (see also: ThresholdActive)
	float Threshold;
	/// ThresholdActive: should the Threshold value be used in calculating output?\n
	/// default: false
	bool ThresholdActive;
	/// EStr; factor applied to the external input
	float EStr;
	/// IStr: factor applied to the internal input (inputs from input units)
	float IStr;
	/// Momentum: the effect of past weight changes on the current movement
	/// in weight space
	float Momentum;
	/// The sum of all output values (needed for within-pool inhibition)
	float SummedOutput;

	void SetSummedOutput(float NewSummedOutput){ SummedOutput = NewSummedOutput; }

public:
	CNNPool(CNNModel *NewModel, int NewUnitCount);

	/* pool structure*/
	// units
	int GetUnitCount(void) const { return Units.GetLength(); }
	CNNUnit *GetUnit(int Index) const { return &Units.Get(Index); }
	CNNUnit *GetUnit(const CText &Name) const;
	// pool connections
	void AddInputPoolConnection(CNNPoolConnection *NewInputPoolConnection){ InputPoolConnections.Add(NewInputPoolConnection); }
	int GetInputPoolConnectionCount(void) const { return InputPoolConnections.GetLength(); }
	CNNPoolConnection *GetInputPoolConnection(int Index) const { return InputPoolConnections.Get(Index); }
	// pool type
	void SetPoolType(ENNPoolTypes NewPoolType){ PoolType = NewPoolType; }
	ENNPoolTypes GetPoolType(void) const { return PoolType; }

	/* parameters */
	void SetUpdateMethod(ENNUpdateMethods NewUpdateMethod){ UpdateMethod = NewUpdateMethod; }
	ENNUpdateMethods GetUpdateMethod(void) const { return UpdateMethod; }
	void SetUpdateRandomized(bool NewUpdateRandomized){ UpdateRandomized = NewUpdateRandomized; }
	bool IsUpdateRandomized(void) const { return UpdateRandomized; }
	void SetDecay(float NewDecay){ Decay = NewDecay; };
	float GetDecay(void) const { return Decay; }
	void SetMinimum(float NewMinimum){ Minimum = NewMinimum; };
	float GetMinimum(void) const { return Minimum; }
	void SetMaximum(float NewMaximum){ Maximum = NewMaximum; };
	float GetMaximum(void) const { return Maximum; }
	void SetThreshold(float NewThreshold){ Threshold = NewThreshold; };
	float GetThreshold(void) const { return Threshold; }
	void SetThresholdActive(bool NewThresholdActive){ ThresholdActive = NewThresholdActive; };
	bool IsThresholdActive(void) const { return ThresholdActive; }
	void SetEStr(float NewEStr){ EStr = NewEStr; }
	float GetEStr(void) const { return EStr; }
	void SetIStr(float NewIStr){ IStr = NewIStr; }
	float GetIStr(void) const { return IStr; }
	void SetMomentum(float NewMomentum){ Momentum = NewMomentum; }
	float GetMomentum(void) const { return Momentum; }

	/* convenience methods */
	void SetOutputPattern(const CRow<float> &NewActivationPattern);
	void GetOutputPattern(CRow<float> &OutputPattern) const;
	void SetTargetPattern(CRow<float> &NewTargetPattern);
	void RandomizeBiases(void);
	void SetLearningRate(float NewLearningRate);
	float GetSummedOutput(void) const;

	/* activity */
	void Reset(void);
	void Update(void);

	/* backpropagation training */
	void BackPropagation_ResetError(void);
	void BackPropagation_UpdateError(void);
	void BackPropagation_PropagateBack(void);
	void BackPropagation_ChangeWeights(void);

	/* hebbian training */
	void Hebb_ChangeWeights(void);

	/* state queries */
	float GetGoodness(void) const;
	float GetTemperature(void) const;
	float GetPatternSumOfSquares(void) const;
	virtual const CText ToString(void) const;

	friend class CNNModel;
	friend class CNNPoolConnection;
};

#endif