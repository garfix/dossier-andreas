#ifndef _ARRAY2
#define _ARRAY2

#include <assert.h>

/// 2 dimensional array

namespace generic
{

template <class TYPE>
class CArray2
{
protected:
	int Width;
	int Height;
	TYPE *Values;

	void Init(int NewWidth, int NewHeight, TYPE* NewValues=0)
	{
		int Size;

		Width = NewWidth;
		Height = NewHeight;
		Size = Width * Height;

		if (Size == 0)
			Values = 0;
		else
		{
			Values = new TYPE[Size];
			if (NewValues != 0) memcpy(Values, NewValues, Size*sizeof(TYPE));
		}
	}

public:
	/// Creates an empty 2D array
	CArray2()
	{
		Init(0, 0);
	}

	/// Creates NewWidth x NewHeight array 
	CArray2(int NewWidth, int NewHeight)
	{
		Init(NewWidth, NewHeight);
	}

	/// Initializes Width x Height array, copying NewValues into it
	/// Make sure NewValues contains NewWidth*NewHeight values
	CArray2(int NewWidth, int NewHeight, TYPE* NewValues)
	{
		Init(NewWidth, NewHeight, NewValues);
	}

	~CArray2()
	{
		delete[] Values;
	}

	/// Set element
	void Set(int X, int Y, const TYPE &Value){ Values[Y*Width + X] = Value; }
	
	/// Get element
	TYPE &Get(int X, int Y) const { return Values[Y*Width + X]; }

	/// Get dimensions
	int GetWidth(void) const { return Width; }
	int GetHeight(void) const { return Height; }

	/// Redimensions the 2D array. Destroys old contents.
	void SetDimension(int NewWidth, int NewHeight)
	{
		delete[] Values;

		Init(NewWidth, NewHeight);
	}

	/// Add n rows to the 2D array. Copies old contents.
	void AddRows(int RowCount)
	{
		TYPE *OldValues = Values;

		Init(Width, Height+RowCount, OldValues);
		delete[] OldValues;
	}
};

}

#endif