#include "genericBitPattern.h"

namespace generic
{

/// only for array initializations
CBitPattern::CBitPattern()
{
	Bits = 0;
	BitCount = -1;
}

CBitPattern::CBitPattern(int NewBitCount)
{
	Bits = 0;
	SetSize(NewBitCount);
}

CBitPattern::CBitPattern(const CBitPattern &BitPattern)
{
	Bits = 0;
	(*this) = BitPattern;
}

CBitPattern::~CBitPattern()
{
	free(Bits);
}

const CBitPattern &CBitPattern::operator=(const CBitPattern &BitPattern)
{
	int IntCount;

	BitCount = BitPattern.BitCount;
	IntCount = GetIntCount();
	// dealloc previous value
	free(Bits);
	// alloc new space
	Bits = (unsigned int *)malloc(IntCount * sizeof(unsigned int));
	// copy values
	for (int i=0; i < IntCount; i++) Bits[i] = BitPattern.Bits[i];

	return (*this);
}

void CBitPattern::SetBit(int Index, bool Value)
{
	assert(BitCount > 0);

	int IntIndex = Index >> 5;
	int BitIndex = Index & (int)0x1F;
	unsigned int Mask = 1 << BitIndex;
	if (Value) Bits[IntIndex] |= Mask;
	else Bits[IntIndex] &= ~Mask;
}

bool CBitPattern::GetBit(int Index) const
{
	assert(BitCount > 0);

	int IntIndex = Index >> 5;
	int BitIndex = Index & (int)0x1F;
	unsigned int Mask = 1 << BitIndex;
	return ((Bits[IntIndex] & Mask) != 0);
}

/// Returns the number of bits in this pattern and Pattern, that are different.
int CBitPattern::GetHammingDistance(const CBitPattern &Pattern) const
{
	assert(this->GetBitCount() == Pattern.GetBitCount());

	unsigned int First, Second, DifferentBits, Mask;
	int DifferentBitCount = 0;
	int IntCount = GetIntCount();

	// check every integer of the pattern
	for (int IntIndex = 0; IntIndex < IntCount; IntIndex++)
	{
		First = Bits[IntIndex];
		Second = Pattern.Bits[IntIndex];

		// quick check, saves time
		if (First == Second) continue;

		// count the different bits of the integer
		DifferentBits = First ^ Second;
		Mask = 1;
		for (int BitIndex=0; BitIndex < 32; BitIndex++)
		{
			if ((DifferentBits & Mask) != 0) DifferentBitCount++;
			Mask <<= 1;
		}
	}

	return DifferentBitCount;
}

void CBitPattern::Clear(void)
{
	assert(BitCount > 0);

	int IntCount = GetIntCount();
	for (int i=0; i < IntCount; i++) Bits[i] = 0;
}

void CBitPattern::SetSize(int NewBitCount)
{
	BitCount = NewBitCount;

	// deallocate previous space
	free(Bits);
	// allocate space for these integers
	Bits = (unsigned int *)calloc(GetIntCount(), sizeof(unsigned int));
}

/// Calculates the mean of the Patterns and returns it in Mean.
/// When a bit is the mean of an equal number of 1's and 0's, 1 is chosen.
void CBitPattern::CalculateMean(CRow<CBitPattern> &Patterns, CBitPattern &Mean)
{
	int BitCount;
	int Count;
	int PatternCount = Patterns.GetLength();
	int Threshold = ((PatternCount+1) / 2);

	if (PatternCount == 0) return;
	BitCount = Patterns.Get(0).GetBitCount();
	
	for (int i=0; i < BitCount; i++)
	{
		Count = 0;
		for (int PatternIndex=0; PatternIndex < PatternCount; PatternIndex++)
		{
			if (Patterns.Get(PatternIndex).GetBit(i)) Count++;
		}
		Mean.SetBit(i, Count >= Threshold);
	}
}

const CText CBitPattern::ToString(void) const
{
	CText String;

	for (int i=0; i < BitCount; i++)
	{
		String += (GetBit(i) ? '1' : '0');
	}
	return String;
}

}
