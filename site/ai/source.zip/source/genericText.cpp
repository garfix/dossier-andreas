#include "genericText.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "genericMath.h"

namespace generic
{

CText operator+(const CText &NewString1, const CText &NewString2)
{
	CText AddString;
	
	AddString.Allocate(NewString1.Capacity + NewString2.Capacity);
	AddString += NewString1;
	AddString += NewString2;

	return AddString;
}

CText operator+(const char *NewCharArray, const CText &NewString)
{
	CText AddString;
	
	AddString.Allocate((int)strlen(NewCharArray) + NewString.Capacity);
	AddString += NewCharArray;
	AddString += NewString.CharArray;

	return AddString;
}

CText operator+(const CText &NewString1, int NewInteger)
{
	return operator+(NewString1, CText(NewInteger));
}

CText operator+(const CText &NewString1, unsigned int NewInteger)
{
	return operator+(NewString1, CText(NewInteger));
}

CText operator+(const CText &NewString1, float NewFloat)
{
	return operator+(NewString1, CText(NewFloat));
}

CText::CText()
{
	Init(0, 0);
}

CText::CText(const CText &NewString)
{
	Init(NewString.CharArray, NewString.Length);
}

CText::CText(const CText &NewString, int Count)
{
	Init(0, 0);

	for (int Index=0; Index < Count; Index++) Append(NewString);
}

CText::CText(const char *NewCharArray)
{
	Init(NewCharArray, (int)strlen(NewCharArray));
}

CText::CText(const char NewChar)
{
	Init(0, 1);
	Length = 1;
	Set(0, NewChar);
	Set(1, '\0');
}

CText::CText(int NewInteger)
{
	char Buffer[150];
	
	itoa(NewInteger, Buffer, 10);
	Init(Buffer, (int)strlen(Buffer));
}

CText::CText(unsigned int NewInteger)
{
	char Buffer[150];
	
	itoa(NewInteger, Buffer, 10);
	Init(Buffer, (int)strlen(Buffer));
}

/// Note: NewFloat is represented with 3 digits after the decimal point
CText::CText(float NewFloat)
{
	char Buffer[150];

	sprintf(Buffer, "% .3f", NewFloat);
	Init(Buffer, (int)strlen(Buffer));
}

CText::~CText()
{
	delete[] CharArray;
}

/// Initializes the string by copying the contents of NewCharArray
/// and reserving NewCapacity characters.\n
/// The old contents of the string is _not_ properly deallocated.
void CText::Init(const char *NewCharArray, int NewCapacity)
{
	// warning: do not delete old char array here

	Capacity = NewCapacity;
	if (Capacity != 0) 
	{
		// allocate empty space on the heap
		CharArray = new char[Capacity+1];
	}
	else
	{
		// no need to allocate space, only make sure the pointer is null
		CharArray = 0;
	}
	
	if ((NewCharArray != 0) && (Capacity != 0))
	{
		// copy new data into new space
		strncpy(CharArray, NewCharArray, Capacity);
		// set the end index to the end of the char array
		Length = Capacity; 
		// add 0
		CharArray[Length] = '\0';
	}
	else 
	{
		// set the end index to the start of the buffer
		Length = 0;
	}
}

/// Appends NewString to String
void CText::Append(const CText &NewString)
{
	char *OldCharArray;
	int OldLength;
	int NewCapacity = Length + NewString.Length;

	// if NewString is empty, return
	if (NewString.Length == 0) return;

	if ((Capacity != 0) && (NewCapacity != 0) && (NewCapacity <= Capacity))
	{
		// append in existing character buffer
		strcpy(CharArray+Length, NewString.CharArray);
	}
	else
	{
		// keep track of old char array
		OldCharArray = CharArray;
		OldLength = Length;
		// allocate space for new char array
		Init(OldCharArray, NewCapacity);
		// copy data to new array
		if (NewCapacity != 0)
		{
			if (NewString.CharArray != 0) strcpy(CharArray+OldLength, NewString.CharArray);
		}
		// delete old char array
		delete OldCharArray;
	}
	Length = NewCapacity;
}

/// Allocate NewLength characters.
void CText::Allocate(int NewCapacity)
{
	delete CharArray;
	Init(0, NewCapacity);
}

/// Clears the contents of the string, but does not reallocate
void CText::Clear(void)
{
	if (Capacity > 0)
	{
		Length = 0;
		CharArray[0] = '\0';
	}
}

/// If necessary, creates a string of NewLength (undefined) characters. 
/// Ends the string at index NewLength with \0.
/// Destroys the contents of the string, if is needs reallocation
void CText::SetLength(int NewLength)
{
	if (NewLength > Capacity) Allocate(NewLength);
	Length = NewLength;
	Set(NewLength, '\0');
}

const CText &CText::operator=(const CText &NewString)
{
	if (&NewString == this) return (*this);

	delete CharArray;
	Init(NewString.CharArray, NewString.Length);

	return (*this);
}

const CText &CText::operator=(const char *NewCharArray)
{
	if (NewCharArray == CharArray) return (*this);

	delete CharArray;
	Init(NewCharArray, (int)strlen(NewCharArray));

	return (*this);
}

void CText::Set(int Index, char Char)
{
	assert(Index >= 0);
	assert((Index < Length) || ((Index == Length) && (Char == '\0') ));

	CharArray[Index] = Char;
	if (Index > Length) 
	{
		if (Char == '\0') Length = Index;
		else Length = Index+1;
	}
}

char CText::Get(int Index) const
{
	assert(Index >= 0);
	assert(Index <= Length);

	return CharArray[Index];
}

void CText::operator+=(const CText &NewString)
{
	Append(NewString);
}

void CText::operator+=(const char *NewCharArray)
{
	int NewCapacity;

	// empty character array -> no change
	if (NewCharArray == 0) return;

	// calculate new length of string
	NewCapacity = Length + (int)strlen(NewCharArray);

	if ((Capacity != 0) && (NewCapacity <= Capacity))
	{
		// append in existing character buffer
		strcpy(CharArray+Length, NewCharArray);
		Length = NewCapacity;
	}
	else
	{
		Append(CText(NewCharArray));
	}
}

void CText::operator+=(char NewChar)
{
	int NewCapacity = Length + 1;

	if (NewCapacity <= Capacity)
	{
		// append in existing character buffer
		Set(Length, NewChar);
	}
	else
	{
		Append(CText(NewChar));
	}
}

void CText::operator+=(int NewInteger)
{
	Append(CText(NewInteger));
}

void CText::operator+=(float NewFloat)
{
	Append(CText(NewFloat));
}

bool CText::Contains(char Char) const
{
	if (Capacity == 0) return false;
	
	return (strchr(CharArray, Char) != 0);
}

bool CText::Contains(const CText &String) const
{
	return (this->GetIndex(String) != -1);
}

CText CText::ToUppercase(void) const
{
	CText Uppercased(*this);

	strupr(Uppercased.GetBuffer());

	return Uppercased;
}

CText CText::ToLowercase(void) const
{
	CText Lowercased(*this);

	strlwr(Lowercased.GetBuffer());

	return Lowercased;
}

int CText::ToInteger(void) const
{
	return (Length == 0 ? 0 : atoi(CharArray));
}

int CText::CreateHashCode(const CText &String)
{
	int HashCode;
	int Length = String.GetLength();

	// special cases
	if (Length == 0) return 0;

	HashCode = String.CharArray[0];
	for (int Index=1; Index < Length; Index <<= 1 /* good find! */ )
	{
		HashCode *= String.CharArray[Index]* 1234567 * Index;
	}

	return CMath::Abs(HashCode);
}

/// returns the index of the first occurrence of Char in the string, starting from StartAt.
int CText::GetIndex(char Char, int StartAt) const
{
	int Index;
    
	Index = StartAt;
	while (Index < Length)
	{
		if (CharArray[Index] == Char) return Index;
		Index++;
	}

	// not found
	return -1;
}

/// Returns the index of the first occurrence of Substring, starting at index Start
/// Returns -1 if no occurrence was found
int CText::GetIndex(const CText &Substring, int Start) const
{
	int Index;

	Index = Start;
	while (Index <= (Length - Substring.Length))
	{
		if (strncmp(CharArray+Index, Substring.CharArray, Substring.Length) == 0)
		{
			return Index;
		}

		Index++;
	}

	return -1;
}

/// returns the index of the last occurrence of Char in the string, starting from StartAt.
/// if StartAt=-1, searching will start at the end
int CText::GetLastIndex(char Char, int StartAt) const
{
	int Index;

	if (StartAt == -1) Index = Length-1;
	else Index = StartAt;

	while (Index >= 0)
	{
		if (CharArray[Index] == Char) return Index;
		Index--;
	}

	// not found
	return -1;
}

/// returns the index of the last occurrence of Char in the string, starting from StartAt.
/// if StartAt=-1, searching will start at the end
int CText::GetLastIndex(const CText &Substring, int StartAt) const
{
	int Index;

	if (StartAt == -1) Index = Length-1;
	else Index = StartAt;

	while (Index >= Substring.Length-1)
	{
		if (strncmp(CharArray+Index-(Substring.Length-1), Substring.CharArray, Substring.Length) == 0)
		{
			return Index - (Substring.Length-1);
		}

		Index++;
	}

	return -1;
}

CText CText::Substring(int First, int Last) const
{
	CText Sub;
	int Size = Last - First + 1;

	// anomaly
	if (Last < First) return "";

	if ((First > Length) || (Last > Length))
		return "";
	else
		Sub.Init(CharArray + First, Size);

	return Sub;
}

/// Returns the string left of the first occurrence of the character c; or empty string if c is not found
CText CText::SubstringUpToFirst(char c) const
{
	static CText NullString;

	int Index = GetIndex(c);
	if (Index == -1) return NullString;

	return Substring(0, Index-1);
}

/// Returns the string right to the first occurrence of the character c; or empty string if c is not found
CText CText::SubstringFromFirst(char c) const
{
	static CText NullString;

	int Index = GetIndex(c);
	if (Index == -1) return NullString;

	return Substring(Index+1, Length-1);
}

/// Returns the string left of the last occurrence of the character c; or empty string if c is not found
CText CText::SubstringUpToLast(char c) const
{
	static CText NullString;

	int Index = GetLastIndex(c);
	if (Index == -1) return NullString;

	return Substring(0, Index-1);
}

/// Returns the string right to the last occurrence of the character c; or empty string if c is not found
CText CText::SubstringFromLast(char c) const
{
	static CText NullString;

	int Index = GetLastIndex(c);
	if (Index == -1) return NullString;

	return Substring(Index+1, Length-1);
}

CText CText::SubstringUpToFirst(const CText &String) const
{
	static CText NullString;

	int Index = GetIndex(String);
	if (Index == -1) return NullString;

	return Substring(0, Index-1);
}

CText CText::SubstringFromFirst(const CText &String) const
{
	static CText NullString;

	int Index = GetIndex(String);
	if (Index == -1) return NullString;

	return Substring(Index+String.GetLength(), Length-1);
}

CText CText::SubstringUpToLast(const CText &String) const
{
	static CText NullString;

	int Index = GetLastIndex(String);
	if (Index == -1) return NullString;

	return Substring(0, Index-1);
}

CText CText::SubstringFromLast(const CText &String) const
{
	static CText NullString;

	int Index = GetLastIndex(String);
	if (Index == -1) return NullString;

	return Substring(Index+String.GetLength(), Length-1);
}

/// OldSubstring may not be empty
CText CText::Replace(const CText &OldSubstring, const CText &NewSubstring) const
{
	// first: how many times does OldSubstring occur?
	int Start, NewStart, Pos = 0;
	int Occurrences = 0;
	int NewCapacity;
	CText NewString;

	assert(OldSubstring.GetLength() != 0);

	Start = 0;
	do
	{
		Start = GetIndex(OldSubstring, Start);
		if (Start != -1) 
		{
			Occurrences++;
			Start += OldSubstring.Length;
		}
	}
	while (Start != -1);

	// allocate new length
	NewCapacity = Capacity + Occurrences * (NewSubstring.Length - OldSubstring.Length);
	NewString.SetLength(NewCapacity);
	NewString.Set(NewCapacity, '\0');

	// replace
	Start = NewStart = 0;
	Pos = 0;
	for (int Index=0; Index < Occurrences; Index++)
	{
		NewStart = GetIndex(OldSubstring, Start);

		// add string before OldSubstring
		strncpy(NewString.CharArray + Pos, CharArray + Start, NewStart - Start);
		Pos += NewStart - Start;

		// add NewString
		strncpy(NewString.CharArray + Pos, NewSubstring.CharArray, NewSubstring.Length);
		Pos += NewSubstring.Length;

		Start = NewStart + OldSubstring.Length;
	}
	// add substring after last occurrence
	strncpy(NewString.CharArray + Pos, CharArray + Start, Length - Start);

	return NewString;
}

CText CText::Replace(char OldChar, char NewChar) const
{
	CText Replaced(*this);

	for (int Index=0; Index < Length; Index++)
		if (Replaced.Get(Index) == OldChar) Replaced.Set(Index, NewChar);

	return Replaced;
}

bool CText::operator==(const CText &NewString) const
{
	if ((CharArray == 0) || (NewString.CharArray == 0)) return (CharArray == NewString.CharArray);
	return (strcmp(NewString.CharArray, CharArray) == 0);
}

bool CText::operator==(const char *NewCharArray) const
{
	assert(NewCharArray != 0);

	if (CharArray == 0) return (strlen(NewCharArray) == 0);
	return (strcmp(NewCharArray, CharArray) == 0);
}

bool CText::operator!=(const CText &NewString) const
{
	if ((CharArray == 0) || (NewString.CharArray == 0)) return (CharArray != NewString.CharArray);
	return (strcmp(NewString.CharArray, CharArray) != 0);
}

bool CText::operator!=(const char *NewCharArray) const
{
	assert(NewCharArray != 0);

	if (CharArray == 0) return (strlen(NewCharArray) != 0);
	return (strcmp(NewCharArray, CharArray) != 0);
}

CText::operator const char*( ) const
{
	return CharArray;
}

int CText::GetHashCode(void) const
{
	return CText::CreateHashCode(*this);
}

}

