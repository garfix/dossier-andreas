#include "..\AI\source\dt\aiDTModel.h"
#include "..\AI\source\fuzzy\aiFuzzyModel.h"
#include "..\AI\source\fs\aiFSModel.h"
#include "..\AI\source\fsm\aiFSMModel.h"
#include "..\AI\source\genetic\aiGeneticModel.h"
#include "..\AI\source\nn\aiNNModel.h"
#include "..\AI\source\nlp\aiNLPModel.h"
#include "..\AI\source\mbn\aiMBNModel.h"
#include "..\AI\source\sdm\aiSDMModel.h"
#include "..\AI\source\pl\aiPLModel.h"
#include "..\AI\source\dmars\aidMarsModel.h"


