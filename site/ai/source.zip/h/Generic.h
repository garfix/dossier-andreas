#ifndef _GENERIC
#define _GENERIC

#include "..\Generic\source\genericText.h"
#include "..\Generic\source\genericElement.h"
#include "..\Generic\source\genericFloat.h"
#include "..\Generic\source\genericRow.h"
#include "..\Generic\source\genericRow2.h"
#include "..\Generic\source\genericPairedRow.h"
#include "..\Generic\source\genericHashTable.h"
#include "..\Generic\source\genericLinkedList.h"
#include "..\Generic\source\genericListNode.h"
#include "..\Generic\source\genericLoader.h"
#include "..\Generic\source\genericMath.h"
#include "..\Generic\source\genericPair.h"
#include "..\Generic\source\genericRing.h"
#include "..\Generic\source\genericSaver.h"
#include "..\Generic\source\genericStopwatch.h"
#include "..\Generic\source\genericXMLLoader.h"
#include "..\Generic\source\genericXMLSaver.h"
#include "..\Generic\source\genericLogger.h"
#include "..\Generic\source\genericCriticalSection.h"
#include "..\Generic\source\genericBitPattern.h"
#include "..\Generic\source\genericSmartPointer.h"

#endif